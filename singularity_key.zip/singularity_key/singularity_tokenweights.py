#!/usr/bin/env python3
"""
Singularity Token Weight Management Module
-----------------------------------------
Handles token weight calculations with dynamic context-awareness.

Features:
- Dynamic context-aware RBY weight calculations
- Thread-safe token weight operations
- Integration with lexical classification system
- Fallback mechanisms for unknown tokens
- High-precision numerical handling with Decimal
- Performance metrics and monitoring

This module extends the existing token weight system with context-awareness
and integration with the lexical classification system.
"""
import os
import time
import logging
import threading
import json
from decimal import Decimal
from typing import Dict, Optional, Tuple, Union, Callable
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.tokenweights")

# Thread safety
_weight_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "weights_calculated": 0,
    "context_adjustments": 0,
    "cache_hits": 0,
    "errors": 0
}

# Base paths
BASE_DIR = Path(__file__).parent.resolve()
ECO_DIR = BASE_DIR / "ecosystem"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Dependencies
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False
_fnum_func = None  # Will be set to _FNUM from singularity_precision
_get_token_weight_func = None  # Will be set to a function from singularity_lexical or fallback

def initialize(fnum_function=None, get_token_weight_function=None):
    """
    Initialize the module with required functions.
    
    Args:
        fnum_function: Function to convert to high-precision numeric type
        get_token_weight_function: Function to get token weights
    """
    global _fnum_func, _get_token_weight_func, _initialized
    
    with _weight_lock:
        _fnum_func = fnum_function
        _get_token_weight_func = get_token_weight_function
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info("Token weight module initialized successfully")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Token Weight Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _get_weight(tok: str, ctx_rby: Optional[Tuple[float, float, float]] = None) -> Tuple[float, float, float]:
    """
    Internal function to get token weight with context adjustment.
    
    Args:
        tok: Token to get weight for
        ctx_rby: Optional context RBY values to adjust the weight
        
    Returns:
        Tuple of (r, b, y) weights
    """
    if not _initialized:
        logger.warning("Token weight module not initialized, using default weights")
        return (0.333, 0.333, 0.334) if ctx_rby is None else ctx_rby
    
    try:
        # Update metrics
        _metrics["weights_calculated"] += 1
        
        # Get base weight from the token weight function
        if _get_token_weight_func:
            r, b, y = _get_token_weight_func(tok)
        else:
            # Fallback to default if no function is provided
            r, b, y = (0.333, 0.333, 0.334)
        
        # Apply context adjustment if provided
        if ctx_rby is not None:
            _metrics["context_adjustments"] += 1
            ctx_r, ctx_b, ctx_y = ctx_rby
            
            # Simple weighted average with context (can be adjusted as needed)
            context_weight = 0.3  # How much to weight the context
            r = (1 - context_weight) * r + context_weight * ctx_r
            b = (1 - context_weight) * b + context_weight * ctx_b
            y = (1 - context_weight) * y + context_weight * ctx_y
            
            # Ensure the sum is still 1.0
            total = r + b + y
            r, b, y = r/total, b/total, y/total
        
        return r, b, y
    except Exception as e:
        logger.error(f"Error calculating token weight: {e}")
        _metrics["errors"] += 1
        return (0.333, 0.333, 0.334) if ctx_rby is None else ctx_rby

def rby(tok: str, ctx: Optional[Tuple[float, float, float]] = None) -> Tuple[float, float, float]:
    """
    Get RBY token weight with context adjustment.
    Public function that should be used by external modules.
    
    Args:
        tok: Token to get RBY weight for
        ctx: Optional context RBY values
        
    Returns:
        Tuple of (r, b, y) weights
    """
    return _get_weight(tok, ctx_rby=ctx)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Context-Aware Weight Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def rby_with_context(token: str, context_tokens: list[str]) -> Tuple[float, float, float]:
    """
    Calculate RBY values with surrounding context.
    
    Args:
        token: Token to get RBY for
        context_tokens: List of tokens in the surrounding context
        
    Returns:
        Tuple of (r, b, y) adjusted weights
    """
    if not context_tokens:
        return rby(token)
    
    # Calculate average RBY values from context tokens
    r_sum, b_sum, y_sum = 0.0, 0.0, 0.0
    for ctx_token in context_tokens:
        r, b, y = rby(ctx_token)
        r_sum += r
        b_sum += b
        y_sum += y
    
    ctx_len = len(context_tokens)
    ctx_r = r_sum / ctx_len
    ctx_b = b_sum / ctx_len
    ctx_y = y_sum / ctx_len
    
    # Apply context to the token
    return rby(token, (ctx_r, ctx_b, ctx_y))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Monitoring and Health Check
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics():
    """
    Get performance metrics for token weights.
    
    Returns:
        Dictionary of metrics
    """
    with _weight_lock:
        return _metrics.copy()

def health_check():
    """
    Perform health check for the token weight module.
    
    Returns:
        Dictionary with health status and metrics
    """
    if not _initialized:
        return {
            "status": "error",
            "message": "Token weight module not initialized",
            "metrics": {},
            "timestamp": time.time()
        }
    
    metrics = get_metrics()
    
    # Determine overall status
    if metrics["errors"] > 0:
        status = "warning"
        message = f"Encountered {metrics['errors']} errors in weight calculations"
    else:
        status = "healthy"
        message = "Token weight module healthy"
    
    return {
        "status": status,
        "message": message,
        "metrics": metrics,
        "has_fnum": _fnum_func is not None,
        "has_token_weight_func": _get_token_weight_func is not None,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject backward compatibility functions into target module.
    
    Args:
        target_module: Module to inject functions into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "rby": rby
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_tokenweights instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Memory Management and Cleanup
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """
    Clean up resources used by the module.
    Should be called during application shutdown.
    """
    # Currently no resources to clean up,
    # but function is provided for future use and interface consistency
    logger.info("Token weight module resources cleaned up")

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'rby',
    'rby_with_context',
    'get_metrics',
    'health_check',
    'cleanup',
    'provide_backward_compatibility'
]

# Module self-test
if __name__ == "__main__":
    import random
    
    def mock_fnum(s):
        return float(s)
    
    def mock_get_token_weight(token):
        # Mock weights based on first letter for testing
        if token.startswith(('a', 'e', 'i', 'o', 'u')):
            return 0.6, 0.3, 0.1  # Vowels - perception heavy
        elif token.startswith(('b', 'c', 'd', 'f', 'g')):
            return 0.2, 0.7, 0.1  # First group consonants - cognition heavy
        else:
            return 0.1, 0.2, 0.7  # Other consonants - execution heavy
    
    # Initialize with mock functions
    initialize(mock_fnum, mock_get_token_weight)
    
    # Test basic RBY function
    test_tokens = ['apple', 'banana', 'zebra', 'thought']
    print("\nBasic RBY Values:")
    for token in test_tokens:
        r, b, y = rby(token)
        print(f"  '{token}' → R={r:.3f}, B={b:.3f}, Y={y:.3f}")
    
    # Test with context
    print("\nRBY Values with Context:")
    contexts = [
        ['see', 'view', 'observe'],  # R-heavy
        ['think', 'analyze', 'calculate'],  # B-heavy
        ['run', 'execute', 'perform']  # Y-heavy
    ]
    
    for token in test_tokens:
        for context in contexts:
            r, b, y = rby_with_context(token, context)
            print(f"  '{token}' with {context[0]}... → R={r:.3f}, B={b:.3f}, Y={y:.3f}")
    
    # Test health check
    health = health_check()
    print(f"\nHealth check: {health['status']}")
    print(f"Message: {health['message']}")
    
    # Print metrics
    metrics = get_metrics()
    print("\nMetrics:")
    for key, value in metrics.items():
        print(f"  {key}: {value}")
