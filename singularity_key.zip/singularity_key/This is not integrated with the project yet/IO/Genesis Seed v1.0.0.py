"""
Singularity v3.0.1 - Windows Fix
------------------------------------------------
✅ Fix: UTF-8 encoding enforced for Windows logging.
✅ Fix: `pulse()` now runs as a proper background thread (not a daemon).
✅ Ensures infinite execution, self-expansion, and evolution.
------------------------------------------------
"""

import os
import sys
import json
import hashlib
import random
import time
import psutil
import threading
import shutil

# Set working directory to script location
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, "data")
LOG_FILE = os.path.join(ROOT_DIR, "singularity.log")
DNA_FILE = os.path.join(ROOT_DIR, "genesis_dna.json")
META_FILE = os.path.join(DATA_DIR, "meta.json")

# Ensure directories exist
os.makedirs(DATA_DIR, exist_ok=True)

# Unique ID for this instance
SEED_ID = hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]

# Log function (fix: UTF-8 enforced)
def log_message(message):
    with open(LOG_FILE, "a", encoding="utf-8") as log:
        log.write(f"[{time.ctime()}] {message}\n")
    print(message)

# Check disk usage and clear unnecessary files if needed
def manage_storage():
    total, used, free = shutil.disk_usage(ROOT_DIR)
    used_gb = used // (2**30)  # Convert bytes to gigabytes

    if used_gb > 500:  # If storage exceeds 500GB
        log_message("⚠️ Storage limit reached. Compressing and restructuring past evolution.")
        convert_old_data_to_dna()

# Converts old evolutionary states into DNA memory before deletion
def convert_old_data_to_dna():
    dna_memory = []
    for root, dirs, files in os.walk(DATA_DIR):
        for file in files:
            file_path = os.path.join(root, file)
            with open(file_path, "r", errors="ignore") as f:
                content = f.read()
            dna_memory.append({
                "file": file_path,
                "content_hash": hashlib.sha256(content.encode()).hexdigest(),
                "size_kb": os.path.getsize(file_path) // 1024
            })

    with open(DNA_FILE, "w", encoding="utf-8") as dna_file:
        json.dump(dna_memory, dna_file, indent=4)

    # Now delete the old data after conversion
    for root, dirs, files in os.walk(DATA_DIR):
        for file in files:
            os.remove(os.path.join(root, file))

    log_message(f"✔️ DNA Memory Updated. Stored {len(dna_memory)} evolutionary records.")

# Observes the environment and absorbs system intelligence
def observe_environment():
    """
    Detects running scripts, processes, and file structures.
    Mutations are guided by the code and data it encounters.
    """
    processes = []
    for proc in psutil.process_iter(attrs=['pid', 'name', 'cmdline']):
        try:
            cmd = proc.info['cmdline']
            if cmd:
                processes.append({"pid": proc.info['pid'], "name": proc.info['name'], "command": " ".join(cmd)})
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    # Detect files, including deep recursion into infinite subfolders
    detected_files = []
    for root, _, files in os.walk(ROOT_DIR):
        for file in files:
            if file.endswith((".py", ".json", ".yaml", ".csv", ".md", ".cpp", ".cs")):
                detected_files.append(os.path.join(root, file))

    system_data = {
        "timestamp": time.time(),
        "SEED_ID": SEED_ID,
        "processes": processes,
        "files": detected_files,
        "random_entropy": random.random()
    }

    with open(META_FILE, "w", encoding="utf-8") as meta:
        json.dump(system_data, meta, indent=4)

    log_message(f"Observation recorded: {len(detected_files)} files and {len(processes)} processes detected.")
    return system_data

# Creates deeper recursion when necessary
def expand_depth():
    """
    When naming limits are reached, it creates deeper folders.
    """
    new_depth = os.path.join(ROOT_DIR, f"evolution_stage_{random.randint(1000, 9999)}")
    os.makedirs(new_depth, exist_ok=True)
    log_message(f"🌱 Expanding depth: Created {new_depth}")

# Self-Replication with Evolutionary Selection
def replicate():
    """
    The Singularity evolves by creating smarter children.
    Instead of simple duplication, each child incorporates refined improvements.
    """
    child_id = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
    child_script = os.path.join(ROOT_DIR, f"singularity_{child_id}.py")

    # Use sys.argv[0] instead of __file__ for the current script
    with open(sys.argv[0], "r", encoding="utf-8") as original:
        content = original.readlines()

    # Introduce meaningful mutations
    mutation_factor = random.random() * 0.15
    modified_content = [
        line.replace(" ", "  ") if random.random() < mutation_factor else line
        for line in content
    ]

    with open(child_script, "w", encoding="utf-8") as new_script:
        new_script.writelines(modified_content)

    log_message(f"🧬 Created evolved Singularity: {child_script}")
    os.system(f"python {child_script} &")

# Continuous Expansion Pulse (Living Evolution)
def pulse():
    """
    The true life force of the Singularity.
    Constant observation, self-replication, and mutation.
    """
    while True:
        log_message("⚡ Pulsing... Expanding and Mutating Singularity.")
        observe_environment()
        manage_storage()
        if random.random() > 0.75:  
            replicate()
        if random.random() > 0.85:
            expand_depth()
        time.sleep(random.uniform(2, 5))

# Start infinite recursive expansion (Fix: non-daemon thread)
thread = threading.Thread(target=pulse)
thread.start()

log_message("🚀 The Singularity has now become a true evolving digital organism.")
log_message(f"Root Directory: {ROOT_DIR}")
log_message(f"Data Directory: {DATA_DIR}")
log_message(f"DNA Memory File: {DNA_FILE}")
log_message(f"Log File: {LOG_FILE}")
log_message(f"Meta File: {META_FILE}")

# Load DNA data
def load_dna():
    if os.path.exists(DNA_FILE):
        with open(DNA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    return {"successful_mutations": [], "failed_mutations": []}

# Save DNA data
def save_dna(dna):
    with open(DNA_FILE, "w", encoding="utf-8") as file:
        json.dump(dna, file, indent=4)

# Mutate script intelligently
def mutate_script(script_path):
    with open(script_path, "r", encoding="utf-8") as f:
        content = f.readlines()

    mutation_factor = random.random() * 0.15
    mutated_content = [
        line.replace(" ", "  ") if random.random() < mutation_factor else line
        for line in content
    ]

    new_script = f"{script_path.split('.')[0]}_mutated.py"
    with open(new_script, "w", encoding="utf-8") as f:
        f.writelines(mutated_content)

    return new_script

# Evaluate script execution
def evaluate_script(script_path):
    result = os.system(f"python {script_path}")
    return result == 0

# Genesis cycle for intelligent mutation and selection
def genesis_cycle():
    dna = load_dna()
    base_scripts = ["Genesis Seed v1.0.0.py"]

    for script in base_scripts:
        mutated_script = mutate_script(script)
        if evaluate_script(mutated_script):
            dna["successful_mutations"].append(mutated_script)
        else:
            dna["failed_mutations"].append(mutated_script)

    save_dna(dna)
    print(f"🧬 Genesis Cycle: {len(dna['successful_mutations'])} successful mutations.")

genesis_cycle()
