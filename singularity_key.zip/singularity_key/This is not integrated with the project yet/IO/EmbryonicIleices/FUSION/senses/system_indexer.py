#!/usr/bin/env python3
"""
AIOS IO System Indexer

This module provides system indexing capabilities for AIOS IO, creating 
awareness of the computational environment following the Law of Three pattern.

It handles:
1. Full system indexing (files, drives, hardware)
2. Administrator permission management
3. Self-documentation and meta-awareness
"""

import os
import sys
import platform
import json
import time
import ctypes
import subprocess
import threading
from datetime import datetime
import hashlib
import tempfile

class SystemIndexer:
    """
    System indexing component that provides AIOS IO with awareness of its
    computational environment following the Law of Three architectural pattern.
    """
    
    def __init__(self, base_dir=None):
        """Initialize the system indexer with base directory."""
        # Determine appropriate base directory
        if base_dir is None:
            self.base_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        else:
            self.base_dir = base_dir
            
        # Set up the Apical Pulse of the Membrane (APM) folder
        self.apm_dir = os.path.join(self.base_dir, "APM")
        os.makedirs(self.apm_dir, exist_ok=True)
        
        # System index storage file
        self.system_index_file = os.path.join(self.apm_dir, "system_index.hdf5")
        
        # Hardware information file
        self.hardware_info_file = os.path.join(self.apm_dir, "hardware_info.json")
        
        # Admin permission status
        self.has_admin = self._check_admin_permissions()
        
        # Constants for the Law of Three
        self.TIER_ONE = 3    # First level
        self.TIER_TWO = 9    # Second level (3²)
        self.TIER_THREE = 27  # Third level (3³)
        
        # Initialize metrics
        self.metrics = {
            "indexed_files": 0,
            "indexed_directories": 0,
            "indexed_drives": 0,
            "last_indexing": None,
            "admin_access": self.has_admin,
            "inaccessible_paths": []
        }
        
        # Import HDF5 library if available, otherwise simulate
        try:
            import h5py
            self.h5py = h5py
            self.has_h5py = True
        except ImportError:
            self.h5py = None
            self.has_h5py = False
            print("Warning: h5py not found, using JSON fallback for system indexing")
    
    def index_system(self, max_depth=3, excluded_dirs=None):
        """
        Index the system following the Law of Three hierarchy.
        
        Args:
            max_depth: Maximum directory depth to traverse
            excluded_dirs: List of directories to exclude
            
        Returns:
            bool: Success status of indexing operation
        """
        print("Starting system indexing...")
        start_time = time.time()
        
        if excluded_dirs is None:
            excluded_dirs = ['/proc', '/sys', '/tmp', '/dev', '/run']
        
        # Get system drives
        drives = self._get_system_drives()
        self.metrics["indexed_drives"] = len(drives)
        
        # Index each drive up to max_depth
        system_index = {
            "drives": drives,
            "indexed_at": datetime.now().isoformat(),
            "hardware_info": self._get_hardware_info(),
            "drive_indices": {}
        }
        
        # Use Law of Three to determine how many drives to index
        num_drives_to_index = min(len(drives), self.TIER_ONE)
        drives_to_index = drives[:num_drives_to_index]
        
        for drive in drives_to_index:
            try:
                print(f"Indexing drive: {drive}")
                drive_index = self._index_directory(drive, 1, max_depth, excluded_dirs)
                system_index["drive_indices"][drive] = drive_index
            except Exception as e:
                print(f"Error indexing drive {drive}: {e}")
                if not drive in system_index["drive_indices"]:
                    system_index["drive_indices"][drive] = {"error": str(e)}
        
        # Save the system index
        self._save_system_index(system_index)
        
        # Update metrics
        self.metrics["last_indexing"] = datetime.now().isoformat()
        
        elapsed = time.time() - start_time
        print(f"System indexing completed in {elapsed:.2f}s")
        print(f"Indexed {self.metrics['indexed_files']} files in {self.metrics['indexed_directories']} directories")
        
        return True
    
    def _index_directory(self, path, current_depth, max_depth, excluded_dirs):
        """Recursively index a directory up to max_depth."""
        if current_depth > max_depth:
            return {"depth_limit_reached": True}
        
        if path in excluded_dirs:
            return {"excluded": True}
        
        # Track this directory
        self.metrics["indexed_directories"] += 1
        
        result = {
            "files": [],
            "dirs": {},
            "path": path,
            "indexed_at": datetime.now().isoformat()
        }
        
        try:
            entries = os.listdir(path)
            
            # For very large directories, apply Law of Three to limit
            if len(entries) > self.TIER_THREE:
                # Sample entries according to Law of Three
                sampled_entries = entries[:self.TIER_THREE]
                result["sampled"] = True
                result["total_entries"] = len(entries)
                entries = sampled_entries
            
            # Process entries
            for entry in entries:
                entry_path = os.path.join(path, entry)
                
                if os.path.isfile(entry_path):
                    # Index file
                    file_info = self._get_file_info(entry_path)
                    result["files"].append(file_info)
                    self.metrics["indexed_files"] += 1
                
                elif os.path.isdir(entry_path) and current_depth < max_depth:
                    # Use Law of Three to decide whether to recurse
                    if current_depth == 1 or len(result["dirs"]) < self.TIER_TWO:
                        # Recursive call for subdirectories
                        subdir_index = self._index_directory(
                            entry_path, current_depth + 1, max_depth, excluded_dirs
                        )
                        result["dirs"][entry] = subdir_index
            
        except PermissionError:
            result["error"] = "Permission denied"
            self.metrics["inaccessible_paths"].append(path)
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def _get_file_info(self, file_path):
        """Get detailed information about a file."""
        try:
            stats = os.stat(file_path)
            file_info = {
                "name": os.path.basename(file_path),
                "size": stats.st_size,
                "modified": datetime.fromtimestamp(stats.st_mtime).isoformat(),
                "extension": os.path.splitext(file_path)[1].lower()
            }
            
            # Get additional info based on file type following Law of Three
            if file_info["extension"] in ['.py', '.js', '.html', '.css', '.txt', '.md', '.json']:
                # For text-based files, try to get a small sample of content
                try:
                    if stats.st_size < 10240:  # Only for files < 10KB
                        with open(file_path, 'r', errors='ignore') as f:
                            content = f.read(1024)  # Read just first 1KB
                            file_info["text_sample"] = content[:256]  # Store just 256 chars
                except:
                    pass
            
            return file_info
        except Exception as e:
            return {
                "name": os.path.basename(file_path),
                "error": str(e)
            }
    
    def _get_system_drives(self):
        """Get list of system drives based on platform."""
        drives = []
        
        if platform.system() == "Windows":
            import string
            # Check for all possible drive letters
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if os.path.exists(drive):
                    drives.append(drive)
        else:
            # Unix-like systems just have a root directory
            drives.append("/")
            
            # Check common mount points
            common_mounts = ["/home", "/mnt", "/media", "/Volumes"]
            for mount in common_mounts:
                if os.path.exists(mount) and os.path.ismount(mount):
                    for item in os.listdir(mount):
                        full_path = os.path.join(mount, item)
                        if os.path.ismount(full_path):
                            drives.append(full_path)
        
        return drives
    
    def _get_hardware_info(self):
        """Get hardware information about the system."""
        hardware_info = {
            "platform": platform.system(),
            "processor": platform.processor(),
            "architecture": platform.architecture()[0],
            "python_version": platform.python_version(),
            "node": platform.node(),
            "machine": platform.machine()
        }
        
        # Try to get more detailed hardware info based on platform
        try:
            if platform.system() == "Windows":
                # Use WMI to get additional hardware info
                import wmi
                c = wmi.WMI()
                hardware_info["cpu"] = [{"name": cpu.Name, "cores": cpu.NumberOfCores} 
                                      for cpu in c.Win32_Processor()]
                hardware_info["memory"] = [{"capacity": int(memory.Capacity) / (1024**3)} 
                                         for memory in c.Win32_PhysicalMemory()]
                hardware_info["gpu"] = [{"name": gpu.Name} 
                                       for gpu in c.Win32_VideoController()]
            elif platform.system() == "Linux":
                # Use command line tools for Linux
                try:
                    hardware_info["cpu"] = subprocess.getoutput("cat /proc/cpuinfo | grep 'model name' | uniq")
                    hardware_info["memory"] = subprocess.getoutput("free -m | grep Mem:")
                    hardware_info["gpu"] = subprocess.getoutput("lspci | grep -i 'vga\\|3d\\|2d'")
                except:
                    pass
            elif platform.system() == "Darwin":  # macOS
                try:
                    hardware_info["cpu"] = subprocess.getoutput("sysctl -n machdep.cpu.brand_string")
                    hardware_info["memory"] = subprocess.getoutput("sysctl -n hw.memsize")
                    hardware_info["gpu"] = subprocess.getoutput("system_profiler SPDisplaysDataType | grep Chipset")
                except:
                    pass
        except Exception as e:
            hardware_info["error"] = str(e)
        
        # Save hardware info to file
        with open(self.hardware_info_file, 'w') as f:
            json.dump(hardware_info, f, indent=2)
            
        return hardware_info
    
    def _save_system_index(self, system_index):
        """Save the system index to a file."""
        if self.has_h5py:
            try:
                # Save as HDF5
                with self.h5py.File(self.system_index_file, 'w') as f:
                    # Recursively save system index to HDF5 groups
                    self._save_to_hdf5_group(f, system_index)
                return True
            except Exception as e:
                print(f"Error saving system index to HDF5: {e}")
                # Fall back to JSON
                pass
        
        # Fall back to JSON if HDF5 fails or isn't available
        json_path = os.path.join(self.apm_dir, "system_index.json")
        with open(json_path, 'w') as f:
            json.dump(system_index, f, indent=2)
        return True
    
    def _save_to_hdf5_group(self, parent, data, name=None):
        """Recursively save nested dict to HDF5 groups."""
        if self.has_h5py:
            if isinstance(data, dict):
                # Create a group for dict
                group = parent.create_group(name) if name else parent
                
                # Save all dict items
                for key, value in data.items():
                    self._save_to_hdf5_group(group, value, key)
            
            elif isinstance(data, list):
                # Create a group for list
                group = parent.create_group(name) if name else parent
                
                # Save each list item with index as key
                for i, item in enumerate(data):
                    self._save_to_hdf5_group(group, item, str(i))
            
            else:
                # Convert to string if not a basic type HDF5 can store
                if not isinstance(data, (int, float, str, bool, type(None))):
                    data = str(data)
                    
                # Handle None values
                if data is None:
                    data = "None"
                
                # Save as dataset
                if name:
                    parent[name] = data
    
    def _check_admin_permissions(self):
        """Check if we have administrator permissions."""
        try:
            if platform.system() == "Windows":
                return ctypes.windll.shell32.IsUserAnAdmin() != 0
            else:
                return os.geteuid() == 0
        except:
            return False
    
    def request_admin_privileges(self):
        """
        Attempt to restart with administrator privileges.
        
        Returns:
            bool: True if already admin or request sent, False if failed
        """
        if self.has_admin:
            return True
            
        try:
            if platform.system() == "Windows":
                # Re-run the program with admin rights
                script = os.path.abspath(sys.argv[0])
                params = ' '.join(sys.argv[1:])
                ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', None, 1)
                
                # Exit current non-admin process
                sys.exit()
            else:
                # For Unix-like systems, use sudo
                script = os.path.abspath(sys.argv[0])
                params = ' '.join(sys.argv[1:])
                os.system(f'sudo "{sys.executable}" "{script}" {params}')
                sys.exit()
                
            return True
        except Exception as e:
            print(f"Failed to obtain admin privileges: {e}")
            return False
    
    def extract_readable_content(self, path, max_files=100):
        """
        Extract readable content from text files for self-documentation.
        
        Args:
            path: Directory path to scan
            max_files: Maximum number of files to process
            
        Returns:
            dict: Extracted content by file
        """
        results = {
            "extracted_files": 0,
            "extraction_date": datetime.now().isoformat(),
            "content": {}
        }
        
        processed = 0
        
        for root, _, files in os.walk(path):
            for file in files:
                # Apply Law of Three to limit processing
                if processed >= max_files:
                    break
                    
                file_path = os.path.join(root, file)
                ext = os.path.splitext(file)[1].lower()
                
                # Process only text-based files
                if ext in ['.py', '.js', '.html', '.css', '.txt', '.md', '.json', '.csv']:
                    try:
                        with open(file_path, 'r', errors='ignore') as f:
                            content = f.read(8192)  # Read up to 8KB
                            
                            # Calculate file hash for identification
                            file_hash = hashlib.md5(file_path.encode()).hexdigest()
                            
                            results["content"][file_hash] = {
                                "path": file_path,
                                "type": ext,
                                "content": content[:2048],  # Store up to 2KB
                                "size": os.path.getsize(file_path)
                            }
                            
                            processed += 1
                            results["extracted_files"] += 1
                    except Exception as e:
                        pass  # Skip files we can't read
        
        # Save results as a document in APM
        extraction_file = os.path.join(self.apm_dir, f"content_extraction_{int(time.time())}.json")
        with open(extraction_file, 'w') as f:
            json.dump(results, f, indent=2)
            
        return results
    
    def generate_ml_system_awareness(self):
        """
        Generate system awareness ML file in HDF5 format.
        Falls back to JSON if HDF5 is not available.
        
        Returns:
            str: Path to the generated ML file
        """
        # First collect system metrics
        system_metrics = {
            "cpu_usage": self._get_cpu_usage(),
            "memory_usage": self._get_memory_usage(),
            "disk_usage": self._get_disk_usage(),
            "active_processes": self._get_process_count(),
            "timestamp": time.time()
        }
        
        # Generate unique filename
        timestamp = int(time.time())
        ml_filename = f"system_awareness_{timestamp}"
        
        # Create the ML data
        ml_data = {
            "system_metrics": system_metrics,
            "indexer_metrics": self.metrics,
            "hardware_info": self._get_hardware_info(),
            "generation_time": datetime.now().isoformat(),
            "has_admin": self.has_admin
        }
        
        # Save as HDF5 if available
        if self.has_h5py:
            try:
                hdf5_path = os.path.join(self.apm_dir, f"{ml_filename}.hdf5")
                with self.h5py.File(hdf5_path, 'w') as f:
                    self._save_to_hdf5_group(f, ml_data)
                return hdf5_path
            except Exception as e:
                print(f"Error saving ML file as HDF5: {e}")
        
        # Fall back to JSON
        json_path = os.path.join(self.apm_dir, f"{ml_filename}.json")
        with open(json_path, 'w') as f:
            json.dump(ml_data, f, indent=2)
        
        return json_path
    
    def _get_cpu_usage(self):
        """Get current CPU usage."""
        try:
            import psutil
            return psutil.cpu_percent(interval=1)
        except ImportError:
            return None
    
    def _get_memory_usage(self):
        """Get current memory usage."""
        try:
            import psutil
            memory = psutil.virtual_memory()
            return {
                "total": memory.total,
                "available": memory.available,
                "percent": memory.percent,
                "used": memory.used
            }
        except ImportError:
            return None
    
    def _get_disk_usage(self):
        """Get disk usage for system drives."""
        result = {}
        try:
            import psutil
            for drive in self._get_system_drives():
                try:
                    usage = psutil.disk_usage(drive)
                    result[drive] = {
                        "total": usage.total,
                        "used": usage.used,
                        "free": usage.free,
                        "percent": usage.percent
                    }
                except:
                    pass
        except ImportError:
            pass
        return result
    
    def _get_process_count(self):
        """Get count of running processes."""
        try:
            import psutil
            return len(psutil.pids())
        except ImportError:
            return None
    
    def get_metrics(self):
        """Get current indexer metrics."""
        return self.metrics.copy()

# Function to get a system indexer instance
def get_indexer(base_dir=None):
    """Get a system indexer instance."""
    return SystemIndexer(base_dir)

def system_wide_index_update(item):
    # Indexing logic across all trifectas
    # Possibly link to persistent_thought as well
    try:
        indexer = get_indexer()
        indexer.index_system()
        return True
    except Exception as e:
        print(f"Error in system-wide index update: {e}")
        return False

def subatomic_time_lens_analysis(intelligence_state):
    # RED: Subatomic level recognition (fundamental intelligence units)
    subatomic_insights = subatomic_recognition(intelligence_state)

    # BLUE: Structured temporal intelligence analysis (time lens)
    temporal_insights = analyze_temporal_trends(subatomic_insights)

    # YELLOW: Execute and structure intelligence adaptations dynamically
    structured_adaptation = temporal_subatomic_structuring(temporal_insights)

    neural_model.integrate(subatomic=structured_adaptation)
    return structured_adaptation
