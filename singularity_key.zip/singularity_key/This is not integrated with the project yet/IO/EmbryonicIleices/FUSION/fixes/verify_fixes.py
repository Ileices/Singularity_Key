#!/usr/bin/env python3
"""
AIOS IO Fix Verification Script

This script tests whether the lecture mode and dynamic response fixes
have been applied correctly to the system.
"""

import os
import sys
import importlib.util
import json
import time
import random

def test_lecture_mode():
    """Test if lecture mode has been properly integrated."""
    sperm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                             "Sperm Ileices", "sperm_ileices.py")
    
    if not os.path.exists(sperm_path):
        print("❌ Cannot find sperm_ileices.py")
        return False
    
    try:
        # Import sperm_ileices module
        spec = importlib.util.spec_from_file_location("sperm_ileices", sperm_path)
        sperm = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sperm)
        
        # Check if lecture_mode is available
        if not hasattr(sperm, 'lecture_mode'):
            print("❌ lecture_mode attribute not found in sperm_ileices.py")
            return False
        
        # Check if detect_lecture_command function is available
        if not hasattr(sperm, 'detect_lecture_command'):
            print("❌ detect_lecture_command function not found in sperm_ileices.py")
            return False
        
        # Test lecture mode detection function with a test command
        test_input = "enter lecture mode"
        result = sperm.detect_lecture_command(test_input)
        
        if result != "START":
            print(f"❌ Lecture mode detection failed. Expected 'START', got '{result}'")
            return False
        
        print("✅ Lecture mode integration verified")
        return True
        
    except Exception as e:
        print(f"❌ Error testing lecture mode: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_dynamic_responses():
    """Test if dynamic response generation is working."""
    sperm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                             "Sperm Ileices", "sperm_ileices.py")
    
    if not os.path.exists(sperm_path):
        print("❌ Cannot find sperm_ileices.py")
        return False
    
    try:
        # Import sperm_ileices module
        spec = importlib.util.spec_from_file_location("sperm_ileices", sperm_path)
        sperm = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sperm)
        
        # Check if we have the learned_templates structure
        if "learned_templates" not in sperm.memory:
            print("❌ learned_templates structure not found in memory")
            sperm.memory["learned_templates"] = []
            print("   → Added learned_templates structure to memory")
        
        # Test if enhanced reabsorb_excretions function is working
        # First, create a test excretion file with some templates
        test_excretion = {
            "yellow_patterns": {
                "test1": {
                    "response": "This is a test dynamic response template.",
                    "response_templates": ["Another test template.", "Yet another test template."]
                }
            },
            "concepts": {
                "test_concept": "This is a test concept"
            }
        }
        
        # Create test excretion directory if needed
        os.makedirs(sperm.EXCRETION_DIR, exist_ok=True)
        test_excretion_path = os.path.join(sperm.EXCRETION_DIR, f"excretion_test_{int(time.time())}.json")
        
        # Write test excretion
        with open(test_excretion_path, 'w') as f:
            json.dump(test_excretion, f)
        
        # Call reabsorb_excretions to test if it's working
        try:
            sperm.reabsorb_excretions(max_files=1)
            
            # Check if any templates were learned
            if len(sperm.memory["learned_templates"]) > 0:
                print("✅ Dynamic response system is working (learned templates)")
            else:
                print("⚠️ No templates learned; testing enhanced generate_response directly")
                
                # Add a test template directly
                sperm.memory["learned_templates"].append("This is a test dynamic response template.")
                
                # Create dummy processed data
                dummy_data = {
                    "source_perception_id": "test_perception",
                    "refined_data": {}
                }
                
                # Add a dummy history entry
                sperm.memory["history"].append({
                    "perception": {"perception_id": "test_perception"},
                    "input": "test input with keywords"
                })
                
                # Call generate_response
                response = sperm.generate_response(dummy_data)
                
                # Check if the response contains the template text
                if "test dynamic response" in response.lower():
                    print("✅ Enhanced generate_response using templates verified")
                    dynamic_templates_working = True
                else:
                    print("❌ Enhanced generate_response not using templates")
                    dynamic_templates_working = False
                
                # Clean up the test template
                if "test dynamic response" in sperm.memory["learned_templates"][0]:
                    sperm.memory["learned_templates"].pop(0)
                
                return dynamic_templates_working
            
            return True
            
        except Exception as e:
            print(f"❌ Error testing reabsorb_excretions: {e}")
            return False
            
        finally:
            # Clean up test excretion file
            if os.path.exists(test_excretion_path):
                try:
                    os.remove(test_excretion_path)
                except:
                    pass
        
    except Exception as e:
        print(f"❌ Error testing dynamic responses: {e}")
        import traceback
        traceback.print_exc()
        return False

def verify_fixes():
    """Run all verification tests."""
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║            AIOS IO FIX VERIFICATION TEST            ║")
    print("╚══════════════════════════════════════════════════════╝")
    
    print("\n[1/2] Testing Lecture Mode Fix...")
    lecture_result = test_lecture_mode()
    
    print("\n[2/2] Testing Dynamic Response Fix...")
    dynamic_result = test_dynamic_responses()
    
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║                  VERIFICATION RESULTS                ║")
    print("╚══════════════════════════════════════════════════════╝")
    print(f"Lecture Mode Integration: {'✅ PASSED' if lecture_result else '❌ FAILED'}")
    print(f"Dynamic Response System:  {'✅ PASSED' if dynamic_result else '❌ FAILED'}")
    
    if lecture_result and dynamic_result:
        print("\n✅ ALL FIXES VERIFIED SUCCESSFULLY!")
        print("You can now launch AIOS IO with the enhanced capabilities using:")
        print("   python aios_enhanced_launcher.py")
    else:
        print("\n⚠️ Some fixes could not be verified.")
        print("Please run the appropriate fix scripts:")
        if not lecture_result:
            print("   python lecture_integration_fix.py")
        if not dynamic_result:
            print("   python dynamic_response_fix.py")
    
    return lecture_result and dynamic_result

def regenerate_aios_if_corrupted():
    """
    Uses neural models and stored intelligence to rebuild AIOS IO in case of collapse.
    """
    # ...logic to detect failures...
    # ...logic to reconstruct from stored neural states...
    return

if __name__ == "__main__":
    verify_fixes()