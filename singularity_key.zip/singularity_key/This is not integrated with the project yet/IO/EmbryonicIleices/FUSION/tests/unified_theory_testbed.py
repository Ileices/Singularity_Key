#!/usr/bin/env python3
"""
AIOS IO Unified Theory Testbed

This module provides a testing environment for validating the implementation
of theoretical concepts like Absolute Focus, Absolute Thought, Absolute Perception,
and other components of the unified theoretical framework.

It allows visualization and testing of how these systems interact when processing
inputs, creating a way to observe the theories in practical operation.
"""

import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import theoretical components
try:
    from tests.focus_mechanism import FocusMechanism
    from tests.persistent_thought import PersistentThought
    from tests.perception_field import PerceptionField
    
    # Try to import core system components
    sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "Sperm Ileices"))
    import sperm_ileices as sperm
    COMPONENTS_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Some components could not be imported: {e}")
    COMPONENTS_AVAILABLE = False

class UnifiedTheoryTestbed:
    """
    Testing environment for the unified theoretical framework, allowing
    observation of how the different theories interact in practice.
    """
    
    def __init__(self):
        """Initialize the unified theory testbed."""
        self.components = {}
        self.test_results = {}
        self.visualizations = {}
        
        # Initialize theoretical components
        self._initialize_components()
        
        # Visualization settings
        self.visualization_active = False
        self.fig = None
        self.axes = None
    
    def _initialize_components(self):
        """Initialize all theoretical components for testing."""
        print("Initializing theoretical components...")
        
        # Initialize Absolute Focus
        try:
            self.components["focus"] = FocusMechanism()
            print("✓ Absolute Focus mechanism initialized")
        except Exception as e:
            print(f"✗ Failed to initialize Absolute Focus: {e}")
        
        # Initialize Absolute Thought (if memory system is available)
        try:
            if COMPONENTS_AVAILABLE and hasattr(sperm, 'memory'):
                self.components["thought"] = PersistentThought(sperm.memory)
                print("✓ Absolute Thought mechanism initialized")
            else:
                # Create a simple memory substitute
                simple_memory = {"history": [], "concepts": {}}
                self.components["thought"] = PersistentThought(simple_memory)
                print("✓ Absolute Thought mechanism initialized with simple memory")
        except Exception as e:
            print(f"✗ Failed to initialize Absolute Thought: {e}")
        
        # Initialize Absolute Perception
        try:
            self.components["perception"] = PerceptionField(dimensions=64)
            print("✓ Absolute Perception field initialized")
        except Exception as e:
            print(f"✗ Failed to initialize Absolute Perception: {e}")
        
        print("Component initialization complete.")
    
    def run_unified_test(self, input_text, context=None):
        """
        Run a test of the unified theoretical framework by processing input
        through all components in sequence and observing the interactions.
        """
        if not context:
            context = {
                "time": datetime.now().timestamp(),
                "complexity": 0.7,
                "time_delta": 0.1,
                "position": {"x": 0.5, "y": 0.5, "z": 0.5}
            }
        
        print(f"\n╔══════════════════════════════════════════════════════╗")
        print(f"║ UNIFIED TEST: Processing '{input_text[:30]}{'...' if len(input_text) > 30 else ''}")
        print(f"╚══════════════════════════════════════════════════════╝")
        
        start_time = time.time()
        test_id = f"test_{int(start_time)}"
        self.test_results[test_id] = {
            "input": input_text,
            "context": context,
            "results": {},
            "start_time": start_time
        }
        
        # 1. Process through Absolute Perception
        if "perception" in self.components:
            try:
                print("1. Applying Absolute Perception...")
                
                # Convert text to simple vector representation
                input_vector = self._text_to_vector(input_text)
                
                # Process through perception field
                perception_result = self.components["perception"].perceive(
                    input_vector, context
                )
                
                self.test_results[test_id]["results"]["perception"] = perception_result
                print(f"   → Perceptual density: {perception_result.get('local_density', 0):.4f}")
            except Exception as e:
                print(f"   → Error in Absolute Perception: {e}")
        
        # 2. Process through Absolute Focus
        if "focus" in self.components:
            try:
                print("2. Applying Absolute Focus...")
                
                # Dynamically adjust focus based on perceptual density
                if "perception" in self.components:
                    perception_result = self.test_results[test_id]["results"].get("perception", {})
                    density = perception_result.get("local_density", 0.5)
                    
                    # Higher density suggests more complex input requiring hard focus
                    # Lower density can be processed with soft focus
                    if density > 0.7:
                        self.components["focus"].shift_focus("hard", intensity=0.3)
                        print("   → Shifting to hard focus due to high perceptual density")
                    elif density < 0.3:
                        self.components["focus"].shift_focus("soft", intensity=0.3)
                        print("   → Shifting to soft focus due to low perceptual density")
                
                # Process the input with current focus state
                focus_result = self.components["focus"].process_input(
                    input_text, context
                )
                
                self.test_results[test_id]["results"]["focus"] = focus_result
                print(f"   → Focus state: {focus_result.get('focus_state', 'unknown')}")
                print(f"   → Soft focus weight: {focus_result.get('soft_focus_weight', 0):.2f}")
                print(f"   → Hard focus weight: {focus_result.get('hard_focus_weight', 0):.2f}")
            except Exception as e:
                print(f"   → Error in Absolute Focus: {e}")
        
        # 3. Process through Absolute Thought
        if "thought" in self.components:
            try:
                print("3. Stimulating Persistent Thought processes...")
                
                # Start thought process if not running
                if not self.components["thought"].running:
                    self.components["thought"].start()
                    print("   → Persistent Thought process started")
                
                # Add the input to current thoughts
                self.components["thought"].current_thoughts.append({
                    "input": input_text,
                    "timestamp": time.time(),
                    "context": context
                })
                
                # Current thought patterns (simplified representation)
                thought_patterns = self.components["thought"].thought_patterns.copy()
                
                self.test_results[test_id]["results"]["thought"] = {
                    "current_thoughts": len(self.components["thought"].current_thoughts),
                    "thought_patterns": thought_patterns
                }
                
                print(f"   → Active thought threads: {len(self.components['thought'].current_thoughts)}")
                for pattern_type, patterns in thought_patterns.items():
                    print(f"   → {pattern_type.capitalize()} thought patterns: {len(patterns)}")
            except Exception as e:
                print(f"   → Error in Absolute Thought: {e}")
        
        # Calculate processing time
        processing_time = time.time() - start_time
        self.test_results[test_id]["processing_time"] = processing_time
        
        print(f"\n┌─────────────────────────────────────────────────────┐")
        print(f"│ UNIFIED TEST COMPLETE                                │")
        print(f"│ Processing time: {processing_time:.4f}s                          │")
        print(f"└─────────────────────────────────────────────────────┘\n")
        
        # Generate visualizations
        self._generate_visualizations(test_id)
        
        return self.test_results[test_id]
    
    def _text_to_vector(self, text):
        """Convert text input to a simple vector representation."""
        # This is a simplified vectorization - in a real system,
        # you would use a more sophisticated text embedding approach
        vector = np.zeros(64)
        
        # Generate a simple hash-based embedding
        for i, char in enumerate(text):
            idx = hash(char) % 64
            vector[idx] += 1.0 / (i + 1)  # Decreasing weight for position
            
        # Normalize the vector
        if np.linalg.norm(vector) > 0:
            vector = vector / np.linalg.norm(vector)
            
        return vector
    
    def _generate_visualizations(self, test_id):
        """Generate visualizations of the test results."""
        if test_id not in self.test_results:
            print(f"No test results found for ID: {test_id}")
            return
        
        results = self.test_results[test_id]
        
        # Create visualization data
        vis_data = {
            "focus_balance": [
                results["results"].get("focus", {}).get("soft_focus_weight", 0.5),
                results["results"].get("focus", {}).get("hard_focus_weight", 0.5)
            ],
            "perception_field": results["results"].get("perception", {}).get("perceived_vector", np.zeros(64)),
            "perceptual_density": results["results"].get("perception", {}).get("local_density", 0)
        }
        
        # Store visualization data
        self.visualizations[test_id] = vis_data
        
        print("\nVisualization data ready. Use show_visualizations() to display.")
    
    def show_visualizations(self, test_id=None):
        """Show visualizations of test results."""
        if not test_id:
            # Use the most recent test if none specified
            if not self.visualizations:
                print("No visualizations available.")
                return
            test_id = list(self.visualizations.keys())[-1]
        
        if test_id not in self.visualizations:
            print(f"No visualization data found for test ID: {test_id}")
            return
        
        vis_data = self.visualizations[test_id]
        test_data = self.test_results[test_id]
        
        # Create a figure with subplots
        plt.figure(figsize=(15, 5))
        
        # 1. Focus Balance
        plt.subplot(131)
        labels = ['Soft Focus', 'Hard Focus']
        plt.pie(vis_data["focus_balance"], labels=labels, autopct='%1.1f%%',
                colors=['#3498db', '#e74c3c'], startangle=90)
        plt.title('Absolute Focus Balance')
        
        # 2. Perception Field
        plt.subplot(132)
        field = vis_data["perception_field"]
        plt.bar(range(len(field)), field)
        plt.title(f'Absolute Perception Field\nDensity: {vis_data["perceptual_density"]:.4f}')
        plt.xlabel('Dimension')
        plt.ylabel('Activation')
        
        # 3. Processing Summary
        plt.subplot(133)
        labels = ['Perception', 'Focus', 'Thought']
        values = [
            1.0 if "perception" in test_data["results"] else 0.0,
            1.0 if "focus" in test_data["results"] else 0.0,
            1.0 if "thought" in test_data["results"] else 0.0
        ]
        plt.bar(labels, values, color=['#f1c40f', '#3498db', '#2ecc71'])
        plt.title('Component Activation')
        plt.ylim(0, 1.2)
        
        # Add overall title
        plt.suptitle(f"Unified Theory Analysis: '{test_data['input']}'", fontsize=16)
        plt.tight_layout()
        plt.subplots_adjust(top=0.85)
        
        # Show the plot
        plt.show()

def run_interactive_testbed():
    """Run an interactive session with the unified theory testbed."""
    print("=" * 60)
    print("╔══════════════════════════════════════════════════════╗")
    print("║            AIOS IO UNIFIED THEORY TESTBED           ║")
    print("║        Test your theoretical frameworks with        ║")
    print("║                  real inputs                        ║")
    print("╚══════════════════════════════════════════════════════╝")
    
    testbed = UnifiedTheoryTestbed()
    
    print("\nEnter inputs to test through the unified theoretical framework.")
    print("Type 'exit' to quit, 'vis' to visualize the last result.")
    
    last_test_id = None
    
    while True:
        try:
            user_input = input("\nTest input> ")
            
            if user_input.lower() == 'exit':
                # Cleanup before exiting
                if "thought" in testbed.components and testbed.components["thought"].running:
                    testbed.components["thought"].stop()
                print("\n┌─────────────────────────────────────────────────────┐")
                print("│ AIOS IO: Testbed session ended.                      │")
                print("└─────────────────────────────────────────────────────┘\n")
                break
                
            elif user_input.lower() == 'vis':
                # Show visualization of the last test
                if last_test_id:
                    testbed.show_visualizations(last_test_id)
                else:
                    print("No tests have been run yet.")
                    
            else:
                # Run the unified test
                result = testbed.run_unified_test(user_input)
                last_test_id = list(testbed.test_results.keys())[-1]
        
        except KeyboardInterrupt:
            print("\nInterrupted. Exiting...")
            break
            
        except Exception as e:
            print(f"Error: {e}")
    
    print("\n┌─────────────────────────────────────────────────────┐")
    print("│ AIOS IO: Testbed session ended.                      │")
    print("└─────────────────────────────────────────────────────┘\n")

if __name__ == "__main__":
    run_interactive_testbed()
