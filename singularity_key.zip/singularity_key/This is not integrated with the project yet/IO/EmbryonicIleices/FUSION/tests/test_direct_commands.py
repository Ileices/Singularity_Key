#!/usr/bin/env python3
"""
Test suite for the direct command functionality of AIOS IO.
"""

import sys
import os
import unittest
import re

# Fix the import path to correctly find the modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the command module we'll create
from command_processor import (
    detect_direct_command, 
    safe_json_loads, 
    process_system_commands,
    handle_action_commands,
    extract_command_type,
    process_command
)

class TestDirectCommands(unittest.TestCase):
    """Test the direct command recognition functionality"""
    
    def test_say_command_with_quotes(self):
        """Test the Say command with quoted text"""
        command = 'Say "I should not fear mistakes."'
        result = detect_direct_command(command)
        self.assertEqual(result, "I should not fear mistakes.")
        
    def test_say_command_without_quotes(self):
        """Test the Say command without quoted text"""
        command = 'Say I should not fear mistakes.'
        result = detect_direct_command(command)
        self.assertEqual(result, "I should not fear mistakes.")
        
    def test_repeat_command(self):
        """Test the Repeat command"""
        command = 'Repeat "This is important."'
        result = detect_direct_command(command)
        self.assertEqual(result, "This is important.")
        
    def test_tell_me_command(self):
        """Test the Tell me command"""
        command = 'Tell me "The answer is 42."'
        result = detect_direct_command(command)
        self.assertEqual(result, "The answer is 42.")
        
    def test_no_command(self):
        """Test input with no command"""
        command = 'What is the meaning of life?'
        result = detect_direct_command(command)
        self.assertIsNone(result)
        
class TestJSONLoading(unittest.TestCase):
    """Test the safe JSON loading functionality"""
    
    def test_valid_json(self):
        """Test loading valid JSON"""
        import tempfile
        import json
        
        with tempfile.NamedTemporaryFile(delete=False, mode='w') as f:
            json.dump({"test": "data"}, f)
            temp_path = f.name
            
        result = safe_json_loads(temp_path)
        self.assertEqual(result, {"test": "data"})
        os.unlink(temp_path)
        
    def test_json_with_trailing_comma(self):
        """Test loading JSON with a trailing comma"""
        import tempfile
        
        with tempfile.NamedTemporaryFile(delete=False, mode='w') as f:
            f.write('{"test": "data",}')
            temp_path = f.name
            
        result = safe_json_loads(temp_path)
        self.assertEqual(result, {"test": "data"})
        os.unlink(temp_path)

class TestSystemCommands(unittest.TestCase):
    """Test system command functionality"""
    
    def setUp(self):
        """Set up test data"""
        self.test_memory = {
            "history": [
                {"input": "What is an apple?", "response": "A fruit"},
                {"input": "Tell me about learning", "response": "Acquiring knowledge"}
            ],
            "concepts": {
                "apple": "a fruit",
                "knowledge": "understanding of information"
            },
            "learning_framework": {
                "test_cycles": {"test1": {}, "test2": {}},
                "try_cycles": {"try1": {}},
                "learn_cycles": {"learn1": {}, "learn2": {}, "learn3": {}}
            }
        }
    
    def test_help_command(self):
        """Test help command"""
        was_command, response = process_system_commands("help", self.test_memory)
        self.assertTrue(was_command)
        self.assertIn("AIOS IO Command Reference", response)
    
    def test_status_command(self):
        """Test status command"""
        was_command, response = process_system_commands("status", self.test_memory)
        self.assertTrue(was_command)
        self.assertIn("System Status", response)
        self.assertIn("Test Cycles: 2", response)
        self.assertIn("Try Cycles: 1", response)
        self.assertIn("Learn Cycles: 3", response)
    
    def test_memory_command(self):
        """Test memory command"""
        was_command, response = process_system_commands("memory", self.test_memory)
        self.assertTrue(was_command)
        self.assertIn("Memory Report", response)
        self.assertIn("Concepts: 2", response)
    
    def test_non_command(self):
        """Test input that isn't a command"""
        was_command, response = process_system_commands("hello world", self.test_memory)
        self.assertFalse(was_command)
        self.assertIsNone(response)

class TestActionCommands(unittest.TestCase):
    """Test action command functionality"""
    
    def setUp(self):
        """Set up test data"""
        self.test_memory = {
            "history": [
                {"input": "What is an apple?", "response": "A fruit"},
                {"input": "Tell me about learning", "response": "Acquiring knowledge"}
            ],
            "concepts": {
                "apple": "a fruit",
                "knowledge": "understanding of information"
            }
        }
    
    def test_search_command(self):
        """Test search memory command"""
        was_action, response = handle_action_commands("search memory for 'apple'", self.test_memory)
        self.assertTrue(was_action)
        self.assertIn("apple: a fruit", response)
    
    def test_debug_command(self):
        """Test debug mode command"""
        was_action, response = handle_action_commands("debug mode on", self.test_memory)
        self.assertTrue(was_action)
        self.assertIn("Debug mode activated", response)
        
        was_action, response = handle_action_commands("debug mode off", self.test_memory)
        self.assertTrue(was_action)
        self.assertIn("Debug mode deactivated", response)
    
    def test_non_action(self):
        """Test input that isn't an action command"""
        was_action, response = handle_action_commands("hello world", self.test_memory)
        self.assertFalse(was_action)
        self.assertIsNone(response)

if __name__ == "__main__":
    unittest.main()
