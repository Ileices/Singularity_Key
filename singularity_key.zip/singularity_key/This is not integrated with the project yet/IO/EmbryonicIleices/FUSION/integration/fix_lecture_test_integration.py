#!/usr/bin/env python3
"""
AIOS IO Fix for Lecture Mode and Test Functionality

This script fixes issues where:
1. Lecture mode does not properly save learned facts
2. Test mode doesn't correctly integrate with the system
3. Memory retention across sessions isn't working

The fix ensures proper integration between lecture mode, test mode, 
and memory components following the Law of Three principles.
"""

import os
import sys
import importlib.util
import json
import re
import shutil
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def apply_all_fixes():
    """Apply all fixes to resolve lecture mode and test functionality issues."""
    print("\n╔════════════════════════════════════════════╗")
    print("║  AIOS IO LECTURE & TEST INTEGRATION FIX   ║")
    print("╚════════════════════════════════════════════╝\n")
    
    # Paths to key files
    sperm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                           "Sperm Ileices", "sperm_ileices.py")
    egg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                          "Sperm Ileices", "egg_ileices.py")
    lecture_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "Sperm Ileices", "enhanced_lecture_mode.py")
    
    # Check if files exist
    for path, name in [(sperm_path, "sperm_ileices.py"), 
                     (egg_path, "egg_ileices.py"),
                     (lecture_path, "enhanced_lecture_mode.py")]:
        if not os.path.exists(path):
            print(f"Error: {name} not found at expected location: {path}")
            return False
    
    # Create backups of files
    backup_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    for path in [sperm_path, egg_path, lecture_path]:
        backup_path = f"{path}.{backup_time}.bak"
        try:
            shutil.copy2(path, backup_path)
            print(f"Created backup of {os.path.basename(path)} at {backup_path}")
        except Exception as e:
            print(f"Warning: Failed to create backup of {os.path.basename(path)}: {e}")
    
    # Fix 1: Improve lecture mode in enhanced_lecture_mode.py
    print("\n[1/3] Fixing Enhanced Lecture Mode...")
    lecture_mode_fixed = fix_lecture_mode(lecture_path)
    
    # Fix 2: Update sperm_ileices.py to properly handle lecture and test operations
    print("\n[2/3] Fixing Sperm module for lecture and test integration...")
    sperm_fixed = fix_sperm_integration(sperm_path)
    
    # Fix 3: Ensure egg_ileices.py properly initializes lecture mode
    print("\n[3/3] Fixing Egg module lecture mode integration...")
    egg_fixed = fix_egg_integration(egg_path, sperm_path)
    
    # Final status
    if lecture_mode_fixed and sperm_fixed and egg_fixed:
        print("\n✓ All fixes successfully applied!")
        print("  Lecture mode and test functionality should now work correctly.")
        return True
    else:
        print("\n✗ Some fixes failed to apply. See errors above.")
        return False

def fix_lecture_mode(lecture_path):
    """Fix lecture mode functionality in enhanced_lecture_mode.py"""
    try:
        with open(lecture_path, 'r') as f:
            content = f.read()
        
        # First, let's check if we need to add imports
        needed_imports = [
            "import time",
            "import random",
            "import json",
            "from datetime import datetime"
        ]
        
        import_block_end = content.find("class EnhancedLectureMode:")
        if import_block_end == -1:
            print("✗ Could not find EnhancedLectureMode class in lecture mode file")
            return False
        
        # Add imports if needed
        for imp in needed_imports:
            if imp not in content:
                import_section = content[:import_block_end].rstrip() + f"\n{imp}\n\n"
                content = import_section + content[import_block_end:]
        
        # Fix 1: Update the __init__ method to properly initialize memory
        init_pattern = re.compile(r'def\s+__init__\s*\(self,\s*memory=None\).*?self\.active\s*=\s*False', re.DOTALL)
        init_match = init_pattern.search(content)
        
        if init_match:
            init_code = init_match.group(0)
            fixed_init_code = """def __init__(self, memory=None):
        \"\"\"Initialize the enhanced lecture mode with memory integration.\"\"\"
        self.memory = memory if memory is not None else {}
        
        # Ensure lecture mode memory structure exists
        if "lecture_mode" not in self.memory:
            self.memory["lecture_mode"] = {
                "active": False,
                "current_topic": "",
                "facts_learned": [],
                "opinions_processed": [],
                "questions_answered": [],
                "corrections_received": [],
                "last_active_time": None,
                "total_sessions": 0,
                "session_stats": {}
            }
        else:
            # Ensure all required keys exist in lecture mode memory
            required_keys = [
                "active", "current_topic", "facts_learned", "opinions_processed",
                "questions_answered", "corrections_received", "last_active_time",
                "total_sessions", "session_stats"
            ]
            for key in required_keys:
                if key not in self.memory["lecture_mode"]:
                    if key in ["facts_learned", "opinions_processed", "questions_answered", 
                              "corrections_received", "session_stats"]:
                        self.memory["lecture_mode"][key] = []
                    elif key == "last_active_time":
                        self.memory["lecture_mode"][key] = None
                    elif key == "total_sessions":
                        self.memory["lecture_mode"][key] = 0
                    else:
                        self.memory["lecture_mode"][key] = ""
        
        # Convenience references to memory structures
        self.lecture_memory = self.memory["lecture_mode"]
        self.active = False"""
            
            # Replace the init code
            content = content.replace(init_code, fixed_init_code)
        
        # Fix 2: Improve the detect_lecture_command function
        detect_pattern = re.compile(r'def\s+detect_lecture_command.*?return\s+lecture_command', re.DOTALL)
        detect_match = detect_pattern.search(content)
        
        if detect_match:
            detect_code = detect_match.group(0)
            fixed_detect_code = """def detect_lecture_command(self, user_input):
        \"\"\"
        Detect if the user input contains a lecture mode command.
        
        Args:
            user_input: The user's input text
            
        Returns:
            str or None: The detected command or None if no command found
        \"\"\"
        if not user_input:
            return None
            
        user_input_lower = user_input.lower().strip()
        
        # Basic lecture mode commands
        if user_input_lower in ["enter lecture mode", "start lecture mode", "begin lecture"]:
            return "start"
            
        if user_input_lower in ["exit lecture mode", "end lecture mode", "end lesson", "stop lecture"]:
            return "end"
        
        # Topic-specific lecture commands
        lecture_on_match = re.search(r"lecture(?:\s+mode)?(?:\s+on|about)?\s+(.+)", user_input_lower)
        if lecture_on_match:
            topic = lecture_on_match.group(1).strip()
            return f"topic:{topic}"
            
        # If we're in lecture mode, check for special lecture patterns
        if self.active or self.lecture_memory["active"]:
            # Fact pattern (contains equals sign or "is"/"are")
            if "=" in user_input or " is " in user_input_lower or " are " in user_input_lower:
                return "fact"
                
            # Opinion pattern (contains "I think", "I believe", "In my opinion")
            opinion_patterns = ["i think", "i believe", "in my opinion", "i feel", "i consider"]
            if any(pattern in user_input_lower for pattern in opinion_patterns):
                return "opinion"
                
            # Question pattern (ends with question mark)
            if user_input.strip().endswith("?"):
                return "question"
                
            # Correction pattern (starts with "no" or "actually" followed by a fact)
            if user_input_lower.startswith(("no ", "actually ", "correction: ")):
                return "correction"
        
        # No lecture command detected
        return None"""
            
            # Replace the detect code
            content = content.replace(detect_code, fixed_detect_code)
        
        # Fix 3: Improve the process_lecture_input function
        process_pattern = re.compile(r'def\s+process_lecture_input.*?return\s+response', re.DOTALL)
        process_match = process_pattern.search(content)
        
        if process_match:
            process_code = process_match.group(0)
            fixed_process_code = """def process_lecture_input(self, user_input, lecture_command):
        \"\"\"
        Process user input in lecture mode.
        
        Args:
            user_input: The user's input text
            lecture_command: The detected lecture command
            
        Returns:
            str: The response to the user
        \"\"\"
        # Update memory to indicate lecture mode is active
        if lecture_command == "start":
            self.active = True
            self.lecture_memory["active"] = True
            self.lecture_memory["last_active_time"] = time.time()
            self.lecture_memory["total_sessions"] += 1
            self.lecture_memory["current_topic"] = "General Knowledge"
            
            # Create a new session record
            session_id = f"session_{self.lecture_memory['total_sessions']}"
            self.lecture_memory["session_stats"][session_id] = {
                "start_time": time.time(),
                "facts_learned": 0,
                "opinions_processed": 0,
                "questions_answered": 0,
                "corrections_received": 0
            }
            
            # Return the lecture mode activation message
            return '''
┌─────────────────────────────────────────────────────┐
│AIOS IO LECTURE MODE ACTIVATED │ 
│ I am ready to learn following the Law of Three: │ 
│ Understanding, Application, and Recursive Improvement│
└─────────────────────────────────────────────────────┘'''
        
        # Handle ending lecture mode
        elif lecture_command == "end":
            # Calculate session stats
            self.active = False
            self.lecture_memory["active"] = False
            
            session_id = f"session_{self.lecture_memory['total_sessions']}"
            if session_id in self.lecture_memory["session_stats"]:
                session = self.lecture_memory["session_stats"][session_id]
                facts = session["facts_learned"]
                opinions = session["opinions_processed"]
                questions = session["questions_answered"]
                corrections = session["corrections_received"]
                
                # Determine level reached based on Law of Three
                level = "Initial Exploration"
                if facts + opinions + questions + corrections >= 27:  # 3³
                    level = "Advanced Recursive Understanding"
                elif facts + opinions + questions + corrections >= 9:  # 3²
                    level = "Intermediate Knowledge Application"
                elif facts + opinions + questions + corrections >= 3:  # 3¹
                    level = "Basic Comprehension"
                
                # Add end time to session
                session["end_time"] = time.time()
                session["duration"] = session["end_time"] - session["start_time"]
                
                # Return the lecture mode completion message
                return f'''
┌─────────────────────────────────────────────────────┐
│LECTURE SESSION COMPLETE │ 
│ Level achieved: {level} │ 
│ Facts learned: {facts} │ 
│ Opinions processed: {opinions} │ 
│ Questions answered: {questions} │ 
│ Corrections received: {corrections} │
└─────────────────────────────────────────────────────┘'''
            else:
                return "Lecture mode ended."
        
        # Handle topic-specific lecture mode
        elif lecture_command.startswith("topic:"):
            topic = lecture_command[6:].strip()
            self.active = True
            self.lecture_memory["active"] = True
            self.lecture_memory["last_active_time"] = time.time()
            self.lecture_memory["current_topic"] = topic
            
            # Create a new session record
            self.lecture_memory["total_sessions"] += 1
            session_id = f"session_{self.lecture_memory['total_sessions']}"
            self.lecture_memory["session_stats"][session_id] = {
                "start_time": time.time(),
                "topic": topic,
                "facts_learned": 0,
                "opinions_processed": 0,
                "questions_answered": 0,
                "corrections_received": 0
            }
            
            return f'''
┌─────────────────────────────────────────────────────┐
│LECTURE MODE: {topic.upper()} │ 
│ I'm ready to learn about {topic}. │
│ Please share facts, opinions, or ask me questions. │
└─────────────────────────────────────────────────────┘'''
            
        # Process facts in lecture mode
        elif lecture_command == "fact":
            # Store fact in memory
            if "facts" not in self.memory:
                self.memory["facts"] = []
            if "concepts" not in self.memory:
                self.memory["concepts"] = {}
                
            # Process the fact - look for patterns like "X is Y" or "X = Y"
            fact = user_input.strip()
            
            # Try to extract key-value from fact
            key_value = None
            
            # Try equals sign pattern
            if "=" in fact:
                parts = fact.split("=", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                key_value = (key, value)
            
            # Try "is" pattern
            elif " is " in fact.lower():
                parts = fact.lower().split(" is ", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                key_value = (key, value)
            
            # Try "are" pattern
            elif " are " in fact.lower():
                parts = fact.lower().split(" are ", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                key_value = (key, value)
            
            # Store fact in memory
            if key_value:
                key, value = key_value
                self.memory["concepts"][key] = value
            
            # Add to facts learned list
            self.memory["facts"].append(fact)
            self.lecture_memory["facts_learned"].append({
                "fact": fact,
                "topic": self.lecture_memory["current_topic"],
                "timestamp": time.time()
            })
            
            # Update session statistics
            session_id = f"session_{self.lecture_memory['total_sessions']}"]
            if session_id in self.lecture_memory["session_stats"]:
                self.lecture_memory["session_stats"][session_id]["facts_learned"] += 1
            
            return f"I've learned this fact: '{fact}'. I'll remember this going forward."
            
        # Process opinions in lecture mode
        elif lecture_command == "opinion":
            # Store opinion in memory
            if "opinions" not in self.memory:
                self.memory["opinions"] = []
                
            opinion = user_input.strip()
            self.memory["opinions"].append(opinion)
            self.lecture_memory["opinions_processed"].append({
                "opinion": opinion,
                "topic": self.lecture_memory["current_topic"],
                "timestamp": time.time()
            })
            
            # Update session statistics
            session_id = f"session_{self.lecture_memory['total_sessions']}"]
            if session_id in self.lecture_memory["session_stats"]:
                self.lecture_memory["session_stats"][session_id]["opinions_processed"] += 1
            
            return f"I've noted your perspective: '{opinion}'. Thanks for sharing your insight."
            
        # Process questions in lecture mode
        elif lecture_command == "question":
            question = user_input.strip()
            
            # Try to find an answer in our stored facts and concepts
            answer = "I don't have enough information to answer this question yet. Could you teach me about this topic?"
            
            # Check if the question matches any of our stored concepts
            if "concepts" in self.memory:
                for key, value in self.memory["concepts"].items():
                    # Check if the key is in the question
                    if key.lower() in question.lower():
                        answer = f"Based on what I've learned, {key} is {value}."
                        break
            
            # Record the question and our answer
            self.lecture_memory["questions_answered"].append({
                "question": question,
                "answer": answer,
                "topic": self.lecture_memory["current_topic"],
                "timestamp": time.time()
            })
            
            # Update session statistics
            session_id = f"session_{self.lecture_memory['total_sessions']}"]
            if session_id in self.lecture_memory["session_stats"]:
                self.lecture_memory["session_stats"][session_id]["questions_answered"] += 1
            
            return answer
            
        # Process corrections in lecture mode
        elif lecture_command == "correction":
            correction = user_input.strip()
            
            # Extract the correction
            if correction.lower().startswith("no "):
                correction_text = correction[3:].strip()
            elif correction.lower().startswith("actually "):
                correction_text = correction[9:].strip()
            elif correction.lower().startswith("correction: "):
                correction_text = correction[12:].strip()
            else:
                correction_text = correction
            
            # Try to extract key-value from correction
            key_value = None
            
            # Try equals sign pattern
            if "=" in correction_text:
                parts = correction_text.split("=", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                key_value = (key, value)
            
            # Try "is" pattern
            elif " is " in correction_text.lower():
                parts = correction_text.lower().split(" is ", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                key_value = (key, value)
            
            # Store correction in memory
            if key_value and "concepts" in self.memory:
                key, value = key_value
                self.memory["concepts"][key] = value
            
            # Record the correction
            self.lecture_memory["corrections_received"].append({
                "correction": correction_text,
                "topic": self.lecture_memory["current_topic"],
                "timestamp": time.time()
            })
            
            # Update session statistics
            session_id = f"session_{self.lecture_memory['total_sessions']}"]
            if session_id in self.lecture_memory["session_stats"]:
                self.lecture_memory["session_stats"][session_id]["corrections_received"] += 1
            
            return f"Thank you for the correction. I've updated my understanding with: '{correction_text}'."
        
        # Default response if we don't know how to handle the lecture command
        response = "I'm still learning how to process this type of input in lecture mode."
        return response"""
            
            # Replace the process code
            content = content.replace(process_code, fixed_process_code)
        
        # Fix 4: Add a new method for testing knowledge gained in lecture mode
        if "def test_knowledge" not in content:
            class_end = content.rfind("}")
            if class_end == -1:
                class_end = len(content)
            
            test_knowledge_method = """
    def test_knowledge(self, query):
        \"\"\"
        Test the knowledge gained during lecture mode.
        
        Args:
            query: The knowledge query to test
            
        Returns:
            str: The response with the knowledge if found
        \"\"\"
        if not query:
            return "Please ask a specific question to test my knowledge."
            
        query_lower = query.lower().strip()
        
        # Check if we have concepts that match this query
        if "concepts" in self.memory:
            # First try direct matching
            for key, value in self.memory["concepts"].items():
                # Exact match - query is asking about a key we know
                if key.lower() == query_lower:
                    return f"I know that {key} is {value}."
                    
                # Query contains the key
                if key.lower() in query_lower:
                    # If it's a question about the key
                    if query_lower.startswith(("what is", "who is", "where is", "when is", "how is")):
                        return f"I know that {key} is {value}."
                    # If it contains "what about" or similar phrases
                    elif any(phrase in query_lower for phrase in ["what about", "tell me about", "describe"]):
                        return f"About {key}: it is {value}."
                
                # Handle mathematical questions
                if "+" in query_lower and "=" in query_lower:
                    # Extract the calculation
                    calc_match = re.search(r'(\d+)\s*\+\s*(\d+)\s*=\s*(\d+)', query_lower)
                    if calc_match:
                        a = int(calc_match.group(1))
                        b = int(calc_match.group(2))
                        expected_result = int(calc_match.group(3))
                        actual_result = a + b
                        
                        if actual_result == expected_result:
                            return f"Yes, {a} + {b} = {actual_result} is correct."
                        else:
                            return f"No, {a} + {b} = {actual_result}, not {expected_result}."
                        
                elif "+" in query_lower:
                    # Extract the calculation
                    calc_match = re.search(r'(\d+)\s*\+\s*(\d+)', query_lower)
                    if calc_match:
                        a = int(calc_match.group(1))
                        b = int(calc_match.group(2))
                        result = a + b
                        return f"{a} + {b} = {result}"
                
                # For multiplication
                if "*" in query_lower or " times " in query_lower:
                    # Extract the calculation
                    calc_match = re.search(r'(\d+)\s*(?:\*|times)\s*(\d+)', query_lower)
                    if calc_match:
                        a = int(calc_match.group(1))
                        b = int(calc_match.group(2))
                        result = a * b
                        return f"{a} * {b} = {result}"
        
        # If we reach here, we don't have the answer
        return "I don't know the answer to that question yet. Would you like to teach me?"
"""
            # Add the test knowledge method
            content = content[:class_end] + test_knowledge_method + content[class_end:]
        
        # Fix 5: Add a method to save/load lecture memory persistently
        if "def save_lecture_memory" not in content:
            class_end = content.rfind("}")
            if class_end == -1:
                class_end = len(content)
            
            save_load_methods = """
    def save_lecture_memory(self, filename=None):
        \"\"\"
        Save the current lecture memory to a file.
        
        Args:
            filename: Optional filename to save to
            
        Returns:
            bool: Success status
        \"\"\"
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"lecture_memory_{timestamp}.json"
            
        try:
            # Create directory if it doesn't exist
            directory = os.path.dirname(filename)
            if directory and not os.path.exists(directory):
                os.makedirs(directory)
                
            with open(filename, 'w') as f:
                json.dump(self.lecture_memory, f, indent=2)
                
            return True
        except Exception as e:
            print(f"Error saving lecture memory: {e}")
            return False
    
    def load_lecture_memory(self, filename):
        \"\"\"
        Load lecture memory from a file.
        
        Args:
            filename: The file to load from
            
        Returns:
            bool: Success status
        \"\"\"
        try:
            with open(filename, 'r') as f:
                loaded_memory = json.load(f)
                
            # Update the memory with the loaded data
            self.lecture_memory.update(loaded_memory)
            
            # Update the memory reference in the parent memory structure
            if self.memory is not None:
                self.memory["lecture_mode"] = self.lecture_memory
                
            return True
        except Exception as e:
            print(f"Error loading lecture memory: {e}")
            return False
"""
            # Add the save/load methods
            content = content[:class_end] + save_load_methods + content[class_end:]
        
        # Write the updated file
        with open(lecture_path, 'w') as f:
            f.write(content)
            
        print("✓ Successfully fixed enhanced lecture mode")
        return True
        
    except Exception as e:
        print(f"✗ Error fixing lecture mode: {e}")
        import traceback
        traceback.print_exc()
        return False

def fix_sperm_integration(sperm_path):
    """Fix sperm_ileices.py for proper lecture and test integration"""
    try:
        with open(sperm_path, 'r') as f:
            content = f.read()
        
        # Fix 1: Add global lecture_mode attribute if missing
        global_vars_section = content.find("# Memory structure")
        if global_vars_section == -1:
            global_vars_section = content.find("# Constants for")
        
        if global_vars_section != -1:
            if "lecture_mode = None" not in content:
                insert_point = global_vars_section
                global_var_addition = "\n# Lecture mode integration\nlecture_mode = None\n"
                content = content[:insert_point] + global_var_addition + content[insert_point:]
        
        # Fix 2: Update initialize_aios to ensure proper memory structure
        init_pattern = re.compile(r'def\s+initialize_aios.*?memory\s*=\s*{', re.DOTALL)
        init_match = init_pattern.search(content)
        
        if init_match:
            init_code = init_match.group(0)
            fixed_init_code = init_code.replace('memory = {', """memory = {
        # Core memory structures
""")
            content = content.replace(init_code, fixed_init_code)
        
        # Fix 3: Add lecture mode detection function if missing
        if "def detect_lecture_command" not in content:
            helper_section = content.find("# Helper functions")
            if helper_section == -1:
                helper_section = content.find("def chat_loop(")
                if helper_section == -1:
                    helper_section = len(content) - 1
            
            detect_lecture_function = """
# Lecture mode integration
def detect_lecture_command(user_input):
    \"\"\"Detect if input contains lecture mode commands.\"\"\"
    if lecture_mode:
        return lecture_mode.detect_lecture_command(user_input)
    return None

"""
            content = content[:helper_section] + detect_lecture_function + content[helper_section:]
        
        # Fix 4: Update process_input to handle lecture commands and tests
        process_input_pattern = re.compile(r'def\s+process_input\s*\(user_input\).*?return\s+response', re.DOTALL)
        process_input_match = process_input_pattern.search(content)
        
        if process_input_match:
            process_input_code = process_input_match.group(0)
            
            # Check if already has lecture mode integration
            if "lecture_command" not in process_input_code:
                # Add lecture mode integration
                response_section = process_input_code.rfind("return response")
                if response_section != -1:
                    lecture_integration = """
    # Check for lecture mode commands
    lecture_command = detect_lecture_command(user_input)
    if lecture_command and lecture_mode:
        lecture_response = lecture_mode.process_lecture_input(user_input, lecture_command)
        if lecture_response:
            return lecture_response
    
    # Check for test questions (in format "Test: query")
    if user_input.lower().startswith("test:") and lecture_mode:
        test_query = user_input[5:].strip()
        test_response = lecture_mode.test_knowledge(test_query)
        if test_response:
            return test_response

"""
                    fixed_process_input = (
                        process_input_code[:response_section] + 
                        lecture_integration + 
                        process_input_code[response_section:]
                    )
                    content = content.replace(process_input_code, fixed_process_input)
        
        # Fix 5: Update generate_response to properly handle lecture mode responses
        if "current_lecture_response" in content:
            generate_response_pattern = re.compile(r'def\s+generate_response.*?return\s+response', re.DOTALL)
            generate_match = generate_response_pattern.search(content)
            
            if generate_match:
                generate_code = generate_match.group(0)
                
                # Check if already has lecture response check
                if "current_lecture_response" not in generate_code:
                    response_section = generate_code.rfind("return response")
                    if response_section != -1:
                        lecture_check = """
    # Check if we have a lecture response to return
    if "current_lecture_response" in memory:
        response = memory["current_lecture_response"]
        del memory["current_lecture_response"]  # Clear it after use
        return response

"""
                        fixed_generate = (
                            generate_code[:response_section] + 
                            lecture_check + 
                            generate_code[response_section:]
                        )
                        content = content.replace(generate_code, fixed_generate)
        
        # Fix 6: Update the reabsorb_excretions function for better learning from lecture data
        reabsorb_pattern = re.compile(r'def\s+reabsorb_excretions.*?return\s+results', re.DOTALL)
        reabsorb_match = reabsorb_pattern.search(content)
        
        if reabsorb_match:
            reabsorb_code = reabsorb_match.group(0)
            
            # Check if already has lecture data handling
            if "lecture_mode" not in reabsorb_code:
                results_section = reabsorb_code.rfind("return results")
                if results_section != -1:
                    lecture_handling = """
    # Apply learning from lecture mode to excretions
    if lecture_mode and "lecture_mode" in memory:
        lecture_memory = memory["lecture_mode"]
        
        # Extract facts from lecture mode and ensure they're in concepts
        if "facts_learned" in lecture_memory:
            for fact_entry in lecture_memory["facts_learned"]:
                fact = fact_entry.get("fact", "")
                
                # Try to extract key-value pairs from facts
                if "=" in fact:
                    parts = fact.split("=", 1)
                    key, value = parts[0].strip(), parts[1].strip()
                    if "concepts" not in memory:
                        memory["concepts"] = {}
                    memory["concepts"][key] = value
                
                elif " is " in fact.lower():
                    parts = fact.lower().split(" is ", 1)
                    key, value = parts[0].strip(), parts[1].strip()
                    if "concepts" not in memory:
                        memory["concepts"] = {}
                    memory["concepts"][key] = value
    """
                    fixed_reabsorb = (
                        reabsorb_code[:results_section] + 
                        lecture_handling + 
                        reabsorb_code[results_section:]
                    )
                    content = content.replace(reabsorb_code, fixed_reabsorb)
        
        # Write the updated file
        with open(sperm_path, 'w') as f:
            f.write(content)
            
        print("✓ Successfully fixed sperm_ileices.py for lecture mode integration")
        return True
        
    except Exception as e:
        print(f"✗ Error fixing sperm module: {e}")
        import traceback
        traceback.print_exc()
        return False

def fix_egg_integration(egg_path, sperm_path):
    """Fix egg_ileices.py for proper lecture mode integration"""
    try:
        with open(egg_path, 'r') as f:
            content = f.read()
        
        # Fix 1: Ensure egg properly initializes lecture mode
        initialize_pattern = re.compile(r'def\s+_initialize_support_systems.*?self\.ml_processor', re.DOTALL)
        initialize_match = initialize_pattern.search(content)
        
        if initialize_match:
            init_code = initialize_match.group(0)
            
            # Check if lecture mode is already properly initialized
            if "lecture_mode = lecture_module.EnhancedLectureMode(self.memory)" not in init_code:
                # Add lecture mode initialization
                ml_processor_pos = init_code.rfind("self.ml_processor")
                if ml_processor_pos != -1:
                    lecture_init = """
        # Initialize lecture mode
        try:
            lecture_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "enhanced_lecture_mode.py")
            if os.path.exists(lecture_path):
                # Import enhanced lecture mode
                spec = importlib.util.spec_from_file_location("enhanced_lecture_mode", lecture_path)
                lecture_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(lecture_module)
                
                # Create lecture mode instance with memory
                self.lecture_mode = lecture_module.EnhancedLectureMode(self.memory)
                
                # Make it available to sperm module
                if hasattr(sperm, 'lecture_mode'):
                    sperm.lecture_mode = self.lecture_mode
                    
                print("✓ Enhanced Lecture Mode initialized")
            else:
                print("✗ Enhanced Lecture Mode not found")
        except Exception as e:
            print(f"✗ Error initializing lecture mode: {e}")
        
        """
                    new_init_code = init_code[:ml_processor_pos] + lecture_init + init_code[ml_processor_pos:]
                    content = content.replace(init_code, new_init_code)
        
        # Fix 2: Add lecture mode integration in the binding method
        bind_pattern = re.compile(r'def\s+_bind_egg_sperm_system.*?return\s+True', re.DOTALL)
        bind_match = bind_pattern.search(content)
        
        if bind_match:
            bind_code = bind_match.group(0)
            
            # Check if lecture mode is already integrated
            if "lecture_mode" not in bind_code:
                # Add lecture mode binding
                return_pos = bind_code.rfind("return True")
                if return_pos != -1:
                    lecture_binding = """
            # Bind lecture mode to sperm if available
            if hasattr(self, 'lecture_mode'):
                sperm.lecture_mode = self.lecture_mode
                print("✓ Lecture mode bound to sperm module")
                
            # Enhance process_input to handle lecture mode commands
            if hasattr(sperm, 'process_input') and hasattr(sperm, 'lecture_mode'):
                original_process_input = sperm.process_input
                
                def enhanced_process_input(user_input):
                    \"\"\"Enhanced version of process_input that checks for lecture mode commands.\"\"\"
                    # Check for lecture mode commands
                    lecture_command = None
                    if hasattr(sperm, 'detect_lecture_command'):
                        lecture_command = sperm.detect_lecture_command(user_input)
                    
                    # Process lecture commands
                    if lecture_command and sperm.lecture_mode:
                        lecture_response = sperm.lecture_mode.process_lecture_input(user_input, lecture_command)
                        if lecture_response:
                            return lecture_response
                            
                    # Process test commands
                    if user_input.lower().startswith("test:") and sperm.lecture_mode:
                        test_query = user_input[5:].strip()
                        test_response = sperm.lecture_mode.test_knowledge(test_query)
                        if test_response:
                            return test_response
                    
                    # If not a lecture command, continue with original process
                    return original_process_input(user_input)
                
                # Replace the function
                sperm.process_input = enhanced_process_input
        """
                    new_bind_code = bind_code[:return_pos] + lecture_binding + bind_code[return_pos:]
                    content = content.replace(bind_code, new_bind_code)
        
        # Fix 3: Add importlib if needed
        if "import importlib.util" not in content:
            # Find import section
            import_section = content.find("import os")
            if import_section == -1:
                import_section = content.find("import sys")
            
            if import_section != -1:
                # Add importlib import
                import_line = "import importlib.util\n"
                content = content[:import_section] + import_line + content[import_section:]
        
        # Write the updated file
        with open(egg_path, 'w') as f:
            f.write(content)
            
        print("✓ Successfully fixed egg_ileices.py for lecture mode integration")
        return True
        
    except Exception as e:
        print(f"✗ Error fixing egg module: {e}")
        import traceback
        traceback.print_exc()
        return False

def fix_lecture_memory():
    integrate_lecture_mode_memory()
    ensure_lecture_test_memory_consistency()

if __name__ == "__main__":
    print("AIOS IO Lecture & Test Integration Fix")
    print("=" * 50)
    success = apply_all_fixes()
    
    if success:
        print("\nAll integration fixes successfully applied!")
        print("Restart the system to apply the changes.")
    else:
        print("\nSome fixes could not be applied. Please check the errors above.")