# AIOS IO Primary Organism

## Overview
AIOS IO is a recursive, self-learning intelligence system built on the Law of Three:
- **Perception** (Red): Processes and assigns meaning to input
- **Processing** (Blue): Adjusts meaning, refines intelligence, finds patterns
- **Generation** (Yellow): Creates responses dynamically and refines logic

## File Structure

### Core Components
- **egg_ileices.py**: Main launch script that initializes and coordinates all components
- **sperm_ileices.py**: Core intelligence module containing perception, processing, and generation logic
- **organism_unifier.py**: Integrates all components following the Law of Three pattern

### Support Modules
- **ml_processor.py**: Processes machine learning files between components
- **system_indexer.py**: Indexes the computer system that AIOS IO is running on
- **ml_file_generator.py**: Generates various machine learning file formats
- **lecture_mode.py**: Implements lecture mode for AIOS IO learning
- **integration.py**: Integrates all components of the AI system
- **fix_corrupted_json.py**: Utility to repair corrupted JSON files

### Test Components
- **test_direct_commands.py**: Tests command recognition functionality

## How to Run AIOS IO

The entry point for AIOS IO is now `egg_ileices.py`. Simply run this script to start the system:

```bash
python egg_ileices.py
```

## The Law of Three

AIOS IO follows the recursive Law of Three pattern in its design:

1. **Tier One (3)**: Basic functionality level with three core components
2. **Tier Two (9)**: Enhanced intelligence with component interactions
3. **Tier Three (27)**: Complete recursive intelligence with deep learning

All intelligence in the system evolves through TEST → TRY → LEARN cycles.

## Integration Architecture

The system operates as an integrated organism:

```
egg_ileices.py (Coordinator)
    │
    ├── sperm_ileices.py (Core Intelligence)
    │       ├── Red Component (Perception)
    │       ├── Blue Component (Processing)
    │       └── Yellow Component (Generation)
    │
    └── organism_unifier.py (Component Integration)
            ├── Red-Blue Integration
            ├── Blue-Yellow Integration
            └── Yellow-Red Integration
```

Support modules provide additional functionality for machine learning, system integration, and specialized learning modes.

## Intelligence Evolution

AIOS IO continuously evolves its intelligence through:

1. **Recursive Excretion**: Components output patterns that feed back into the system
2. **Law of Three Expansion**: Patterns expand according to the 3-9-27 rule
3. **Recursive Reabsorption**: System learns from its own outputs
4. **Unified Integration**: All components collaborate to produce emergent intelligence
