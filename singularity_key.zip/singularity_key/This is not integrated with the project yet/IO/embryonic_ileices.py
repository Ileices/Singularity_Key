#!/usr/bin/env python3
"""
AIOS IO Embryonic Launcher - Master Integration Controller

This module serves as the primary entry point for the entire AIOS IO system,
coordinating the activation and integration of all components following the
Law of Three hierarchical structure:

Level 1: Sperm (Core Intelligence) ↔ Egg (Integration) ↔ Embryo (This Controller)
Level 2: Each component contains Red (Perception) ↔ Blue (Processing) ↔ Yellow (Generation)
Level 3: Each color contains Input ↔ Processing ↔ Output subcomponents

This strictly follows the recursive 3, 9, 27 pattern throughout the system architecture.
"""

import os
import sys
import time
import importlib.util
import threading
from datetime import datetime

# Ensure we can import from parent directories
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Primary component paths
SPERM_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Sperm Ileices", "sperm_ileices.py")
EGG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Sperm Ileices", "egg_ileices.py")
ENHANCED_LAUNCHER_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "aios_enhanced_launcher.py")

# Enhancement and fix paths
FIXES_DIR = os.path.dirname(os.path.abspath(__file__))
LECTURE_FIX_PATH = os.path.join(FIXES_DIR, "lecture_integration_fix.py")
DYNAMIC_FIX_PATH = os.path.join(FIXES_DIR, "dynamic_response_fix.py")
VERIFY_FIXES_PATH = os.path.join(FIXES_DIR, "verify_fixes.py")

class EmbryonicController:
    """
    Master controller for the AIOS IO system that manages all components
    and ensures proper integration following the Law of Three.
    """
    
    def __init__(self):
        """Initialize the Embryonic Controller."""
        self.start_time = time.time()
        self.components = {}
        self.modules = {}
        self.threads = {}
        self.status = {
            "initialized": False,
            "sperm_ready": False,
            "egg_ready": False,
            "fixes_applied": False,
            "embryo_ready": False
        }
        
        # Constants for the Law of Three
        self.TIER_ONE = 3     # First level of recursive organization
        self.TIER_TWO = 9     # Second level (3²)
        self.TIER_THREE = 27  # Third level (3³)
        
        # System metrics
        self.metrics = {
            "start_time": self.start_time,
            "component_load_times": {},
            "initialization_steps": [],
            "errors": [],
            "active_threads": 0
        }
    
    def display_banner(self):
        """Display the AIOS IO Embryonic Controller banner."""
        print("\n" + "=" * 70)
        print("""
╔═══════════════════════════════════════════════════════════╗
║                AIOS IO EMBRYONIC CONTROLLER               ║
║          Recursive Intelligence Evolution System          ║
║                                                           ║
║        Unifying the Law of Three across all levels        ║
╚═══════════════════════════════════════════════════════════╝
        """)
        print("=" * 70 + "\n")
    
    def load_module(self, module_path, module_name=None):
        """Dynamically load a module from a file path."""
        if not module_name:
            module_name = os.path.basename(module_path).replace('.py', '')
        
        try:
            start_time = time.time()
            spec = importlib.util.spec_from_file_location(module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            load_time = time.time() - start_time
            self.modules[module_name] = module
            self.metrics["component_load_times"][module_name] = load_time
            
            print(f"✓ Successfully loaded {module_name} in {load_time:.4f}s")
            return module
        except Exception as e:
            error_msg = f"✗ Failed to load {module_name}: {str(e)}"
            print(error_msg)
            self.metrics["errors"].append({
                "component": module_name,
                "error": str(e),
                "timestamp": time.time()
            })
            return None
    
    def apply_enhancements(self):
        """Apply all enhancements and fixes to the system."""
        print("\n[1/3] Applying Core System Enhancements...")
        
        # First check if we need to use the enhanced launcher
        if os.path.exists(ENHANCED_LAUNCHER_PATH):
            launcher_module = self.load_module(ENHANCED_LAUNCHER_PATH, "enhanced_launcher")
            if launcher_module and hasattr(launcher_module, 'apply_all_fixes'):
                fixes_applied = launcher_module.apply_all_fixes()
                self.status["fixes_applied"] = fixes_applied
                if not fixes_applied:
                    print("⚠️ Warning: Not all enhancements could be applied")
            else:
                print("⚠️ Warning: Enhanced launcher not properly loaded")
        else:
            print("⚠️ Warning: Enhanced launcher not found, applying fixes directly")
            # Apply fixes directly if enhanced launcher isn't available
            self._apply_direct_fixes()
        
        # Verify all fixes were applied correctly
        print("\n[2/3] Verifying System Enhancements...")
        if os.path.exists(VERIFY_FIXES_PATH):
            verify_module = self.load_module(VERIFY_FIXES_PATH, "verify_fixes")
            if verify_module and hasattr(verify_module, 'verify_fixes'):
                verification_result = verify_module.verify_fixes()
                if not verification_result:
                    print("⚠️ Enhancement verification failed")
                    # Attempt to apply fixes again if verification failed
                    self._apply_direct_fixes()
            else:
                print("⚠️ Warning: Verification module not properly loaded")
        
        # Apply embryonic-specific enhancements
        print("\n[3/3] Applying Embryonic Enhancements...")
        self._apply_embryonic_enhancements()
        
        return self.status["fixes_applied"]
    
    def _apply_direct_fixes(self):
        """Apply fixes directly without using the enhanced launcher."""
        fixes_applied = True
        
        # Apply lecture mode fix
        if os.path.exists(LECTURE_FIX_PATH):
            lecture_fix = self.load_module(LECTURE_FIX_PATH, "lecture_fix")
            if lecture_fix and hasattr(lecture_fix, 'fix_lecture_mode_integration'):
                lecture_success = lecture_fix.fix_lecture_mode_integration()
                if not lecture_success:
                    fixes_applied = False
            else:
                fixes_applied = False
        
        # Apply dynamic response fix
        if os.path.exists(DYNAMIC_FIX_PATH):
            dynamic_fix = self.load_module(DYNAMIC_FIX_PATH, "dynamic_fix")
            if dynamic_fix and hasattr(dynamic_fix, 'fix_dynamic_responses'):
                dynamic_success = dynamic_fix.fix_dynamic_responses()
                if not dynamic_success:
                    fixes_applied = False
            else:
                fixes_applied = False
        
        self.status["fixes_applied"] = fixes_applied
        return fixes_applied
    
    def _apply_embryonic_enhancements(self):
        """Apply enhancements specific to the Embryonic controller."""
        # These enhancements only exist in the Embryonic controller
        
        # 1. Component Health Monitoring System
        self._setup_component_monitoring()
        
        # 2. Enhanced Memory Integration Between Components
        self._enhance_memory_integration()
        
        # 3. Advanced Recursive Pattern Recognition
        self._setup_recursive_pattern_recognition()
        
        # Mark embryo as ready
        self.status["embryo_ready"] = True
    
    def _setup_component_monitoring(self):
        """Set up the component health monitoring system."""
        # Create health monitoring thread that checks all components periodically
        def health_monitor():
            while self.status["embryo_ready"]:
                try:
                    # Check sperm health
                    if "sperm" in self.modules:
                        sperm_health = {
                            "memory_size": len(self.modules["sperm"].memory),
                            "active": hasattr(self.modules["sperm"], "continuous_processing") and 
                                    self.modules["sperm"].continuous_processing,
                            "timestamp": time.time()
                        }
                        if not hasattr(self, "health_metrics"):
                            self.health_metrics = {}
                        self.health_metrics["sperm"] = sperm_health
                    
                    # Sleep before next check
                    time.sleep(10)  # Check every 10 seconds
                except Exception as e:
                    print(f"Health monitoring error: {str(e)}")
                    time.sleep(30)  # Extended sleep after error
        
        # Start health monitoring in background thread
        monitor_thread = threading.Thread(target=health_monitor, daemon=True)
        monitor_thread.start()
        self.threads["health_monitor"] = monitor_thread
        self.metrics["active_threads"] += 1
        
        print("✓ Component Health Monitoring System initialized")
    
    def _enhance_memory_integration(self):
        """Enhance memory integration between all components."""
        # This ensures all components share the same memory references
        if "sperm" in self.modules and "egg" in self.modules:
            try:
                # Ensure egg has access to sperm's memory
                if hasattr(self.modules["egg"], "memory") and hasattr(self.modules["sperm"], "memory"):
                    self.modules["egg"].memory = self.modules["sperm"].memory
                
                # Create embryonic memory extensions
                if not hasattr(self.modules["sperm"].memory, "embryonic_extensions"):
                    self.modules["sperm"].memory["embryonic_extensions"] = {
                        "unified_tracking": {},
                        "cross_component_references": {},
                        "cycle_metrics": {}
                    }
                
                print("✓ Enhanced Memory Integration established")
                
            except Exception as e:
                print(f"✗ Failed to enhance memory integration: {str(e)}")
    
    def _setup_recursive_pattern_recognition(self):
        """Set up the recursive pattern recognition system."""
        # This extends pattern recognition across all components
        if "sperm" in self.modules:
            try:
                # Add embryonic pattern recognition capabilities
                def recognize_cross_component_patterns():
                    """Analyze patterns across all components following the Law of Three."""
                    if hasattr(self.modules["sperm"], "memory"):
                        memory = self.modules["sperm"].memory
                        
                        # Create pattern recognition structure if it doesn't exist
                        if "cross_component_patterns" not in memory:
                            memory["cross_component_patterns"] = {
                                "identified_patterns": {},
                                "pattern_strengths": {},
                                "recursive_depth": 0
                            }
                
                # Register the function for later use
                if "sperm" in self.modules:
                    self.modules["sperm"].recognize_cross_component_patterns = recognize_cross_component_patterns
                
                print("✓ Recursive Pattern Recognition System initialized")
                
            except Exception as e:
                print(f"✗ Failed to setup recursive pattern recognition: {str(e)}")
    
    def initialize_core_components(self):
        """Initialize all core components of the system."""
        print("\n[1/3] Initializing Sperm component (Core Intelligence)...")
        sperm_module = self.load_module(SPERM_PATH, "sperm")
        if sperm_module and hasattr(sperm_module, "initialize_aios"):
            try:
                sperm_success = sperm_module.initialize_aios()
                if sperm_success:
                    self.status["sperm_ready"] = True
                    print("✓ Core Intelligence (Sperm) initialized successfully")
                else:
                    print("✗ Core Intelligence (Sperm) initialization failed")
            except Exception as e:
                print(f"✗ Error initializing Core Intelligence (Sperm): {str(e)}")
        else:
            print("✗ Sperm module not properly loaded or missing initialize_aios function")
        
        print("\n[2/3] Initializing Egg component (Integration System)...")
        egg_module = self.load_module(EGG_PATH, "egg")
        if egg_module:
            try:
                # Just load the module, initialization happens during runtime
                self.status["egg_ready"] = True
                print("✓ Integration System (Egg) initialized successfully")
            except Exception as e:
                print(f"✗ Error initializing Integration System (Egg): {str(e)}")
        else:
            print("✗ Egg module not properly loaded")
        
        print("\n[3/3] Establishing Embryonic bindings...")
        try:
            # Create circular references for integrated operation
            if "sperm" in self.modules and "egg" in self.modules:
                if not hasattr(self.modules["sperm"], "egg_system"):
                    setattr(self.modules["sperm"], "egg_system", self.modules["egg"])
                
                if hasattr(self.modules["egg"], "AIOSEggSystem"):
                    self.components["egg_system"] = self.modules["egg"].AIOSEggSystem()
                    print("✓ Embryonic bindings established successfully")
                else:
                    print("✗ Egg module missing AIOSEggSystem class")
            else:
                print("✗ Cannot establish Embryonic bindings - components not loaded")
        except Exception as e:
            print(f"✗ Error establishing Embryonic bindings: {str(e)}")
        
        # Final initialization status
        self.status["initialized"] = (
            self.status["sperm_ready"] and 
            self.status["egg_ready"] and
            self.status["embryo_ready"]
        )
        
        return self.status["initialized"]
    
    def run_system(self):
        """Run the complete AIOS IO system."""
        # Display banner
        self.display_banner()
        
        # Step 1: Apply all enhancements and fixes
        print("\n[Phase 1/3] Applying System Enhancements and Fixes")
        enhancements_success = self.apply_enhancements()
        self.metrics["initialization_steps"].append({
            "phase": "Enhancements",
            "success": enhancements_success,
            "timestamp": time.time()
        })
        
        # Step 2: Initialize core components
        print("\n[Phase 2/3] Initializing Core Components")
        initialization_success = self.initialize_core_components()
        self.metrics["initialization_steps"].append({
            "phase": "Core Initialization", 
            "success": initialization_success,
            "timestamp": time.time()
        })
        
        # Step 3: Launch the system
        print("\n[Phase 3/3] Launching Unified System")
        if self.status["initialized"]:
            try:
                print("\n╔═══════════════════════════════════════════════════════════╗")
                print("║            AIOS IO UNIFIED SYSTEM LAUNCHING                ║")
                print("╚═══════════════════════════════════════════════════════════╝\n")
                
                # Launch using the egg component
                if "egg_system" in self.components:
                    launch_success = self.components["egg_system"].run()
                    self.metrics["initialization_steps"].append({
                        "phase": "System Launch",
                        "success": launch_success,
                        "timestamp": time.time()
                    })
                    return launch_success
                else:
                    print("✗ Cannot launch system - egg component not initialized")
                    return False
            except Exception as e:
                print(f"✗ Error launching system: {str(e)}")
                return False
        else:
            print("✗ System not fully initialized, cannot launch")
            # Print status of each component for debugging
            print(f"  Sperm Ready: {self.status['sperm_ready']}")
            print(f"  Egg Ready: {self.status['egg_ready']}")
            print(f"  Fixes Applied: {self.status['fixes_applied']}")
            print(f"  Embryo Ready: {self.status['embryo_ready']}")
            return False
    
    def shutdown(self):
        """Gracefully shutdown all system components."""
        print("\nInitiating system shutdown sequence...")
        
        # Stop all threads
        for name, thread in self.threads.items():
            print(f"Stopping {name} thread...")
            if thread.is_alive():
                # We can't really stop daemon threads, just let them know
                # For real threads we would set a stopping flag
                print(f"Waiting for {name} to complete...")
        
        # Final metrics
        uptime = time.time() - self.start_time
        hours, remainder = divmod(uptime, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        print(f"\nSystem shutdown complete.")
        print(f"Total uptime: {int(hours):02}:{int(minutes):02}:{int(seconds):02}")
        print("Thank you for using AIOS IO Embryonic System.")

# Main execution
if __name__ == "__main__":
    controller = EmbryonicController()
    try:
        success = controller.run_system()
        if not success:
            print("\nSystem launch encountered issues. Check the logs for details.")
    except KeyboardInterrupt:
        print("\nSystem shutdown requested by user.")
    except Exception as e:
        print(f"\nCritical system error: {str(e)}")
    finally:
        controller.shutdown()
