import os
import json
import sys

def fix_json_file(file_path):
    """Attempt to fix a corrupted JSON file"""
    print(f"Attempting to fix: {file_path}")
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Try to load it first to see if it's actually corrupted
        try:
            json.loads(content)
            print(f"File {file_path} is not corrupted, no fix needed.")
            return True
        except json.JSONDecodeError as e:
            print(f"JSON error at position {e.pos}, line {e.lineno}, column {e.colno}")
            print(f"Error message: {e.msg}")
            
            # Basic error recovery - try to fix common JSON issues
            # 1. Check for unmatched brackets
            open_curly = content.count('{')
            close_curly = content.count('}')
            if open_curly > close_curly:
                content += '}' * (open_curly - close_curly)
                print(f"Added {open_curly - close_curly} closing braces")
            
            # 2. Check for trailing commas before closing brackets
            content = content.replace(',}', '}').replace(',]', ']')
            
            # 3. Create a backup of the original file
            backup_path = file_path + ".bak"
            with open(backup_path, 'w') as f:
                f.write(open(file_path, 'r').read())
            print(f"Created backup at {backup_path}")
            
            # 4. Write the fixed content
            with open(file_path, 'w') as f:
                f.write(content)
            
            # 5. Verify the fix worked
            try:
                json.loads(content)
                print(f"Successfully fixed {file_path}")
                return True
            except json.JSONDecodeError as e:
                # If still failing, try a more aggressive approach
                print("Basic fix failed, attempting aggressive fix...")
                
                # Try to extract the valid portion of the JSON
                with open(file_path, 'r') as f:
                    content = f.read()
                
                valid_json = content[:e.pos]
                last_brace = valid_json.rfind('}')
                if last_brace > 0:
                    valid_json = valid_json[:last_brace+1]
                    with open(file_path, 'w') as f:
                        f.write(valid_json)
                    
                    try:
                        json.loads(valid_json)
                        print(f"Aggressive fix successful for {file_path}")
                        return True
                    except:
                        print(f"Aggressive fix failed for {file_path}, manual intervention required")
                        return False
                else:
                    print(f"Could not repair {file_path}, manual intervention required")
                    return False
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return False

def scan_directory_for_corrupted_json(directory):
    """Scan a directory for corrupted JSON files and fix them"""
    print(f"Scanning directory: {directory}")
    fixed_count = 0
    corrupted_count = 0
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.json'):
                file_path = os.path.join(root, file)
                
                try:
                    # Check if the file is corrupted
                    with open(file_path, 'r') as f:
                        try:
                            json.load(f)
                            # File is fine, continue
                        except json.JSONDecodeError:
                            corrupted_count += 1
                            print(f"\nFound corrupted JSON file: {file_path}")
                            if fix_json_file(file_path):
                                fixed_count += 1
                except Exception as e:
                    print(f"Error checking {file_path}: {e}")
    
    print(f"\nScan complete: Found {corrupted_count} corrupted files, fixed {fixed_count}")
    return fixed_count, corrupted_count

if __name__ == "__main__":
    if len(sys.argv) > 1:
        directory = sys.argv[1]
    else:
        directory = os.path.join("AIOS_IO", "Excretions")
        
        # If not found, try relative to the current directory
        if not os.path.exists(directory):
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            directory = os.path.join(base_dir, "AIOS_IO", "Excretions")
            
            # If still not found, use the current directory
            if not os.path.exists(directory):
                directory = "."
    
    print(f"Starting JSON corruption scanner on directory: {directory}")
    scan_directory_for_corrupted_json(directory)
