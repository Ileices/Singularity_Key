#!/usr/bin/env python3
"""
AIOS IO Command Processor

This module provides functions for processing direct commands and utilities for
JSON file handling. It extracts and modularizes functionality from sperm_ileices.py
to improve maintainability and testability.

Following the Law of Three pattern, it handles:
1. Command Detection
2. Command Extraction
3. Command Execution
"""

import os
import json
import re

def detect_direct_command(user_input):
    """
    Detect if the user input contains a direct command instruction.
    
    Args:
        user_input (str): The user's input message
        
    Returns:
        str or None: The extracted command content, or None if no command detected
    """
    if not user_input:
        return None
        
    user_input_lower = user_input.lower()
    
    # Define command patterns based on Law of Three
    say_commands = ["say", "repeat", "tell me"]
    
    # Check for "Say X" pattern - this is the most common direct command
    say_match = None
    for cmd in say_commands:
        if user_input_lower.startswith(cmd.lower()):
            # Try to extract the content after the command
            cmd_index = len(cmd)
            content = user_input[cmd_index:].strip()
            
            # If enclosed in quotes, extract just the quoted part
            if content.startswith('"') and '"' in content[1:]:
                end_quote = content[1:].find('"') + 1
                say_match = content[1:end_quote]
            elif content.startswith("'") and "'" in content[1:]:
                end_quote = content[1:].find("'") + 1
                say_match = content[1:end_quote]
            else:
                # Otherwise just take the rest of the string
                say_match = content
                
            break
    
    return say_match

def extract_command_type(user_input):
    """
    Identify the type of command in the user input.
    
    Args:
        user_input (str): The user's input message
        
    Returns:
        str: The command type ('say', 'direct_instruction', 'knowledge_recall', or 'none')
    """
    user_input_lower = user_input.lower()
    
    # Check for say command
    if any(user_input_lower.startswith(cmd) for cmd in ["say ", "repeat ", "tell me "]):
        return "say_command"
    
    # Check for direct instruction
    if any(phrase in user_input_lower for phrase in ["you should", "you must", "you need to"]):
        return "direct_instruction"
    
    # Check for knowledge recall
    if any(phrase in user_input_lower for phrase in ["you already know", "remember that", "recall that"]):
        return "knowledge_recall"
    
    return "none"

def process_command(command_type, user_input, memory=None):
    """
    Process the command based on its type.
    
    Args:
        command_type (str): The type of command
        user_input (str): The user's input message
        memory (dict, optional): The memory context for knowledge recall
        
    Returns:
        str or None: The processed command result, or None if not applicable
    """
    if command_type == "say_command":
        return detect_direct_command(user_input)
    
    elif command_type == "direct_instruction":
        # Extract the instruction part
        instruction_match = re.search(r'you (should|must|need to) (.+)', user_input.lower())
        if instruction_match:
            return f"I understand I should {instruction_match.group(2)}"
    
    elif command_type == "knowledge_recall" and memory:
        # Try to find relevant knowledge in memory
        recall_phrase = user_input.lower()
        for key, value in memory.get("concepts", {}).items():
            if key in recall_phrase:
                return f"Yes, I recall that {key} is {value}"
    
    return None

def safe_json_loads(file_path):
    """
    Safely load JSON file with error recovery.
    
    Args:
        file_path (str): Path to the JSON file
        
    Returns:
        dict: The parsed JSON content, or an empty dict if parsing failed
    """
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            
        # Basic error recovery - try to fix common JSON issues
        # 1. Check for unmatched brackets
        open_curly = content.count('{')
        close_curly = content.count('}')
        if open_curly > close_curly:
            content += '}' * (open_curly - close_curly)
        
        # 2. Check for trailing commas before closing brackets
        content = content.replace(',}', '}').replace(',]', ']')
        
        # 3. Try to parse the JSON
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            # If still failing, try a more aggressive cleanup
            print(f"Attempting aggressive JSON repair for {file_path}")
            
            # Try to extract the valid portion of the JSON
            valid_json = content[:e.pos]
            last_brace = valid_json.rfind('}')
            if last_brace > 0:
                valid_json = valid_json[:last_brace+1]
                try:
                    return json.loads(valid_json)
                except:
                    pass
            
            # If all fails, return empty dict
            return {}
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
        return {}

# Adding more command processing functionality from sperm_ileices.py

def process_system_commands(user_input, memory=None):
    """
    Process system commands like help, status, memory, etc.
    
    Args:
        user_input (str): The user's input message
        memory (dict, optional): The memory context for status reports
        
    Returns:
        tuple: (bool, str) - (was_command, response_message)
    """
    user_input_lower = user_input.lower().strip()
    
    # System commands based on the Law of Three
    if user_input_lower == "help":
        return True, _generate_help_text()
    
    elif user_input_lower == "status" or user_input_lower == "system status":
        if memory:
            status_report = _generate_status_report(memory)
            return True, status_report
        return True, "System is operational, but memory access is restricted."
    
    elif user_input_lower == "memory" or user_input_lower == "show memory":
        if memory:
            memory_report = _generate_memory_report(memory)
            return True, memory_report
        return True, "Memory access is restricted."
    
    # Not a system command
    return False, None

def _generate_help_text():
    """Generate help text for available commands"""
    return """
AIOS IO Command Reference:
-------------------------
General Commands:
  help             - Display this help information
  status           - Show system status
  memory           - Display memory statistics

Direct Instruction Commands:
  Say "text"       - Makes the system directly repeat text
  Repeat "text"    - Works like the Say command
  Tell me "text"   - Works like the Say command
  
Learning Framework Commands:
  Enter lecture mode           - Start teaching the system
  End lecture mode             - Stop teaching the system
  Lecture on [topic]           - Start teaching about a specific topic
  
Other commands may be available based on system configuration.
"""

def _generate_status_report(memory):
    """Generate a status report based on the current memory state"""
    history_length = len(memory.get("history", []))
    excretion_count = len(memory.get("excretions", []))
    
    # Calculate memory size
    memory_size = sum(sys.getsizeof(str(v)) for v in memory.values())
    memory_mb = memory_size / (1024 * 1024)
    
    report = f"""
AIOS IO System Status:
--------------------
System: Active
Memory Usage: {memory_mb:.2f} MB
History Items: {history_length}
Excretions: {excretion_count}

Learning Framework:
  Test Cycles: {len(memory.get("learning_framework", {}).get("test_cycles", {}))}
  Try Cycles: {len(memory.get("learning_framework", {}).get("try_cycles", {}))}
  Learn Cycles: {len(memory.get("learning_framework", {}).get("learn_cycles", {}))}

Lecture Mode: {"Active" if memory.get("lecture_mode", {}).get("active", False) else "Inactive"}
"""
    return report

def _generate_memory_report(memory):
    """Generate a report of memory contents"""
    # Get counts of different memory components
    history_length = len(memory.get("history", []))
    
    # Get concept counts
    concepts = memory.get("concepts", {})
    concept_count = len(concepts)
    
    # Recent concepts
    recent_concepts = []
    if concept_count > 0:
        recent_concepts = list(concepts.items())[-3:]  # Get the last 3 concepts
    
    # Learning cycle stats
    test_cycles = len(memory.get("learning_framework", {}).get("test_cycles", {}))
    try_cycles = len(memory.get("learning_framework", {}).get("try_cycles", {}))
    learn_cycles = len(memory.get("learning_framework", {}).get("learn_cycles", {}))
    
    report = f"""
AIOS IO Memory Report:
--------------------
Total History Items: {history_length}
Concepts: {concept_count}

Recent Concepts:
"""
    
    for key, value in recent_concepts:
        report += f"  {key}: {value}\n"
        
    report += f"""
Learning Framework:
  Test Cycles: {test_cycles}
  Try Cycles: {try_cycles}
  Learn Cycles: {learn_cycles}
"""
    return report

def handle_action_commands(user_input, memory=None):
    """
    Process action commands that require the system to perform specific tasks.
    
    Args:
        user_input (str): The user's input message
        memory (dict, optional): The memory context
        
    Returns:
        tuple: (bool, str) - (was_action, result_or_none)
    """
    user_input_lower = user_input.lower().strip()
    
    # Search memory command
    search_match = re.search(r"search (?:memory|concepts) for ['\"](.*)['\"]", user_input_lower)
    if search_match:
        search_term = search_match.group(1).strip()
        if memory and search_term:
            results = _search_memory(search_term, memory)
            return True, results
    
    # Save memory command (administrative)
    if user_input_lower == "save memory" or user_input_lower == "export memory":
        if memory:
            result = _export_memory(memory)
            return True, result
    
    # Debug commands
    if user_input_lower == "debug mode on":
        return True, "Debug mode activated. Additional information will be displayed."
    
    if user_input_lower == "debug mode off":
        return True, "Debug mode deactivated. Returning to normal operation."
    
    return False, None

def _search_memory(term, memory):
    """Search memory for specified term"""
    results = []
    
    # Search concepts
    concept_matches = []
    for key, value in memory.get("concepts", {}).items():
        if term in key or term in value:
            concept_matches.append(f"{key}: {value}")
    
    if concept_matches:
        results.append("Concept matches:")
        results.extend([f"  {match}" for match in concept_matches[:5]])  # Limit to 5 matches
        
        if len(concept_matches) > 5:
            results.append(f"  ... and {len(concept_matches) - 5} more matches")
    
    # Search history (last 10 items only)
    history_matches = []
    for item in memory.get("history", [])[-10:]:
        if "input" in item and term in item["input"].lower():
            history_matches.append(item["input"])
    
    if history_matches:
        if results:  # Add separator if we already have concept results
            results.append("")
        
        results.append("Recent history matches:")
        results.extend([f"  {match}" for match in history_matches[:3]])  # Limit to 3 matches
    
    # If no results found
    if not results:
        return f"No matches found for '{term}' in memory."
    
    return "\n".join(results)

def _export_memory(memory):
    """Export memory to a file (administrative function)"""
    try:
        import json
        from datetime import datetime
        
        # Create a simplified memory export (exclude large structures)
        export_data = {
            "concepts": memory.get("concepts", {}),
            "system_stats": {
                "history_length": len(memory.get("history", [])),
                "test_cycles": len(memory.get("learning_framework", {}).get("test_cycles", {})),
                "try_cycles": len(memory.get("learning_framework", {}).get("try_cycles", {})),
                "learn_cycles": len(memory.get("learning_framework", {}).get("learn_cycles", {})),
            },
            "export_time": datetime.now().isoformat()
        }
        
        filename = f"memory_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, "w") as f:
            json.dump(export_data, f, indent=2)
            
        return f"Memory exported successfully to {filename}"
    except Exception as e:
        return f"Failed to export memory: {str(e)}"

# Integration helper for launch scripts
def integrate_command_processor(target_module):
    """
    Integrate the command processor with a target module.
    
    Args:
        target_module: The module to integrate with
        
    Returns:
        bool: True if integration was successful
    """
    try:
        # Export main functions to target module
        function_list = [
            'detect_direct_command',
            'extract_command_type',
            'process_command',
            'safe_json_loads',
            'process_system_commands',
            'handle_action_commands'
        ]
        
        # Export helper functions too, keep them private with underscore prefix
        helper_functions = [
            '_generate_help_text',
            '_generate_status_report',
            '_generate_memory_report',
            '_search_memory',
            '_export_memory'
        ]
        
        # Add main functions
        for func_name in function_list:
            setattr(target_module, func_name, globals()[func_name])
        
        # Add helper functions
        for func_name in helper_functions:
            setattr(target_module, func_name, globals()[func_name])
            
        return True
    except Exception as e:
        print(f"Error integrating command processor: {e}")
        return False

if __name__ == "__main__":
    # Demonstrate basic functionality
    test_inputs = [
        'Say "Hello, world!"',
        'Repeat this is a test',
        'Tell me "The sky is blue"',
        'What is the meaning of life?',
        'You should analyze this input',
        'You need to remember this fact'
    ]
    
    print("Command Processor Module Test")
    print("=" * 40)
    
    for input_text in test_inputs:
        cmd_type = extract_command_type(input_text)
        cmd_content = detect_direct_command(input_text)
        
        print(f"Input: '{input_text}'")
        print(f"Command Type: {cmd_type}")
        print(f"Command Content: {cmd_content}")
        print("-" * 30)
    
    # Additional demonstration for system commands
    print("\nSystem Command Examples:")
    print("-" * 30)
    sample_memory = {
        "history": [{"input": "test input 1"}, {"input": "tell me about apples"}],
        "concepts": {"apple": "a fruit", "knowledge": "understanding of information"},
        "learning_framework": {"test_cycles": {}, "try_cycles": {}, "learn_cycles": {}}
    }
    
    system_commands = ["help", "status", "memory"]
    for cmd in system_commands:
        was_cmd, response = process_system_commands(cmd, sample_memory)
        print(f"Command: '{cmd}'")
        print(f"Response: {'Command recognized' if was_cmd else 'Not a system command'}")
        print("-" * 30)
