import os
import json
import time
import random
import traceback
from datetime import datetime

class MLProcessor:
    """Processes and manages machine learning files between components following the 3-9-27 pattern."""
    
    def __init__(self, ml_generator, base_dir="AIOS_IO"):
        """Initialize with an ML file generator and base directory."""
        self.ml_generator = ml_generator
        self.base_dir = base_dir
        self.excretion_dir = os.path.join(base_dir, "Excretions")
        self.ml_files_dir = os.path.join(self.excretion_dir, "ML_Files")
        
        # Ensure ML files directory exists
        os.makedirs(self.ml_files_dir, exist_ok=True)
        
        # Metrics to track processing
        self.metrics = {
            "processed_files": 0,
            "completed_cycles": 0,
            "errors": 0,
            "last_processing": time.time()
        }
        
        # Constants for the Law of Three
        self.TIER_ONE = 3
        self.TIER_TWO = 9
        self.TIER_THREE = 27
    
    def process_red_to_blue(self, red_file_path, red_data):
        """Process Red's HDF5 file and transform it into Blue's ONNX file."""
        try:
            # Apply analytical transformations according to the Law of Three
            transformation_level = random.choice([self.TIER_ONE, self.TIER_TWO, self.TIER_THREE])
            
            # Create Blue's enhanced data based on Red's input
            blue_data = {
                "source_component": "Red",
                "source_file": red_file_path,
                "analysis_level": transformation_level,
                "processing_timestamp": time.time(),
                "analytical_enhancements": []
            }
            
            # Apply Law of Three transformations
            for i in range(transformation_level):
                # Each enhancement adds a different analytical perspective
                enhancement = {
                    "perspective": f"Analysis_{i+1}",
                    "insight_depth": min(1.0, 0.1 * (i+1)),
                    "pattern_detection": random.uniform(0, 1),
                    "metadata": {
                        "original_red_timestamp": red_data.get("timestamp", time.time()),
                        "transformation_index": i
                    }
                }
                blue_data["analytical_enhancements"].append(enhancement)
            
            # Generate the ONNX file
            blue_file_path = self.ml_generator.generate_onnx_file("Blue", blue_data)
            
            # Return the processed file path and enhanced data
            return blue_file_path, blue_data
            
        except Exception as e:
            self.metrics["errors"] += 1
            print(f"Error in Red to Blue processing: {str(e)}")
            traceback.print_exc()
            return None, None
    
    def process_blue_to_yellow(self, blue_file_path, blue_data):
        """Process Blue's ONNX file and transform it into Yellow's TFRecord file."""
        try:
            # Apply creative transformations according to the Law of Three
            transformation_level = random.choice([self.TIER_ONE, self.TIER_TWO, self.TIER_THREE])
            
            # Create Yellow's enhanced data based on Blue's input
            yellow_data = {
                "source_component": "Blue",
                "source_file": blue_file_path,
                "creativity_level": transformation_level,
                "generation_timestamp": time.time(),
                "creative_enhancements": []
            }
            
            # Apply Law of Three transformations
            for i in range(transformation_level):
                # Each enhancement adds a different creative perspective
                enhancement = {
                    "perspective": f"Creation_{i+1}",
                    "novelty_factor": min(1.0, 0.1 * (i+1)),
                    "generation_quality": random.uniform(0, 1),
                    "metadata": {
                        "original_blue_timestamp": blue_data.get("timestamp", time.time()),
                        "transformation_index": i
                    }
                }
                yellow_data["creative_enhancements"].append(enhancement)
            
            # Generate the TFRecord file
            yellow_file_path = self.ml_generator.generate_tfrecord_file("Yellow", yellow_data)
            
            # Return the processed file path and enhanced data
            return yellow_file_path, yellow_data
            
        except Exception as e:
            self.metrics["errors"] += 1
            print(f"Error in Blue to Yellow processing: {str(e)}")
            traceback.print_exc()
            return None, None
    
    def process_yellow_to_red(self, yellow_file_path, yellow_data):
        """Process Yellow's TFRecord file and transform it back into Red's HDF5 file to complete the cycle."""
        try:
            # Apply perception transformations according to the Law of Three
            transformation_level = random.choice([self.TIER_ONE, self.TIER_TWO, self.TIER_THREE])
            
            # Create Red's enhanced data based on Yellow's input
            red_data = {
                "source_component": "Yellow",
                "source_file": yellow_file_path,
                "perception_level": transformation_level,
                "reprocessing_timestamp": time.time(),
                "perception_enhancements": []
            }
            
            # Apply Law of Three transformations
            for i in range(transformation_level):
                # Each enhancement adds a different perceptual perspective
                enhancement = {
                    "perspective": f"Perception_{i+1}",
                    "clarity_factor": min(1.0, 0.1 * (i+1)),
                    "pattern_recognition": random.uniform(0, 1),
                    "metadata": {
                        "original_yellow_timestamp": yellow_data.get("timestamp", time.time()),
                        "transformation_index": i,
                        "recursive_cycle": True
                    }
                }
                red_data["perception_enhancements"].append(enhancement)
            
            # Generate the HDF5 file
            red_file_path = self.ml_generator.generate_hdf5_file("Red", red_data)
            
            # Return the processed file path and enhanced data
            return red_file_path, red_data
            
        except Exception as e:
            self.metrics["errors"] += 1
            print(f"Error in Yellow to Red processing: {str(e)}")
            traceback.print_exc()
            return None, None
    
    def process_chatbot_input(self, user_input, ai_response):
        """Process chatbot interaction and generate ML files based on it."""
        try:
            # Create a Red (perception) ML file based on user input
            red_data = {
                "user_input": user_input,
                "input_timestamp": time.time(),
                "input_vector": [hash(word) % 100 / 100 for word in user_input.split()],
                "perception_timestamp": time.time()
            }
            
            red_file_path = self.ml_generator.generate_hdf5_file("Red", red_data)
            
            # Process through Blue (analysis)
            blue_file_path, blue_data = self.process_red_to_blue(red_file_path, red_data)
            
            # Add AI response to Blue's data
            if blue_data:
                blue_data["ai_response"] = ai_response
                blue_data["response_timestamp"] = time.time()
                
                # Re-save the enhanced Blue file
                blue_file_path = self.ml_generator.generate_onnx_file("Blue", blue_data)
            
            # Process through Yellow (generation)
            if blue_file_path and blue_data:
                yellow_file_path, yellow_data = self.process_blue_to_yellow(blue_file_path, blue_data)
                
                # Complete the cycle by processing back to Red (perception)
                if yellow_file_path and yellow_data:
                    self.process_yellow_to_red(yellow_file_path, yellow_data)
                    self.metrics["completed_cycles"] += 1
            
            self.metrics["processed_files"] += 3  # One file for each component
            self.metrics["last_processing"] = time.time()
            
            return True
        
        except Exception as e:
            self.metrics["errors"] += 1
            print(f"Error processing chatbot input: {str(e)}")
            traceback.print_exc()
            return False

    def get_metrics(self):
        """Get the current processing metrics."""
        return self.metrics.copy()
