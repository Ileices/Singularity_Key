import os
import sys
import time
import threading
import importlib
from datetime import datetime

class AISystemIntegrator:
    """Integrates all components of the AI system and ensures they work together."""
    
    def __init__(self, base_dir="AIOS_IO"):
        """Initialize the system integrator with the base directory."""
        self.base_dir = base_dir
        self.start_time = time.time()
        self.components = {}
        self.threads = {}
        self.status = {
            "running": False,
            "initialized": False,
            "system_indexed": False,
            "ml_pipeline_active": False,
            "lecture_mode_available": False,
            "errors": []
        }
    
    def load_component(self, name, module_path):
        """Dynamically load a component module."""
        try:
            # Import the module
            module = importlib.import_module(module_path)
            self.components[name] = module
            return True
        except Exception as e:
            self.status["errors"].append(f"Error loading component {name}: {str(e)}")
            return False
    
    def initialize_system(self):
        """Initialize the entire AI system."""
        print(f"AISystemIntegrator: Starting initialization at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Try to load all required components
        required_components = [
            ("ml_generator", "ml_file_generator"),
            ("system_indexer", "system_indexer"),
            ("lecture_mode", "lecture_mode"),
            ("ml_processor", "ml_processor")
        ]
        
        for name, module_path in required_components:
            if self.load_component(name, module_path):
                print(f"AISystemIntegrator: Successfully loaded {name}")
            else:
                print(f"AISystemIntegrator: Failed to load {name}, will continue with limited functionality")
        
        # Create the base directory structure
        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(os.path.join(self.base_dir, "Excretions"), exist_ok=True)
        os.makedirs(os.path.join(self.base_dir, "Apical_Pulse_of_the_Membrane"), exist_ok=True)
        
        # Initialize system indexing
        self.status["system_indexed"] = self.initialize_system_indexing()
        
        # Initialize ML file pipeline
        self.status["ml_pipeline_active"] = self.initialize_ml_pipeline()
        
        # Initialize lecture mode
        self.status["lecture_mode_available"] = self.initialize_lecture_mode()
        
        self.status["initialized"] = True
        print(f"AISystemIntegrator: Initialization complete at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return self.status
    
    def initialize_system_indexing(self):
        """Initialize the system indexing component."""
        if "system_indexer" not in self.components:
            print("AISystemIntegrator: System indexer not available, skipping system indexing")
            return False
        
        try:
            # Create system indexer
            indexer_module = self.components["system_indexer"]
            self.system_indexer = indexer_module.SystemIndexer(self.base_dir)
            
            # Start indexing in a separate thread
            return True
        except Exception as e:
            print(f"AISystemIntegrator: Error initializing system indexer: {str(e)}")
            return False