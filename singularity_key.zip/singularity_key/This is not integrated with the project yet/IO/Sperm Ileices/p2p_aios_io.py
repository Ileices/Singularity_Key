import socket
import threading
import os
import base64

# Configuration
PORT = 5050
BUFFER_SIZE = 4096
SEPARATOR = "<SEPARATOR>"

# Global Variables
peer_socket = None

# ASCII UI for CLI
def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    banner = """
    ============================================
    |  P2P Secure Chat & File Share System     |
    |  Connected Peer-to-Peer Network          |
    |  Encrypted Communication Enabled         |
    ============================================
    """
    print(banner)

# Encrypt message
def encrypt_message(message):
    message_bytes = message.encode('utf-8')
    encrypted_bytes = base64.b64encode(message_bytes)
    return encrypted_bytes

# Decrypt message
def decrypt_message(encrypted_bytes):
    decrypted_bytes = base64.b64decode(encrypted_bytes)
    return decrypted_bytes.decode('utf-8')

# Handle incoming messages
def handle_client(client_socket):
    try:
        while True:
            data = client_socket.recv(BUFFER_SIZE)
            if not data:
                break
            decrypted_data = decrypt_message(data)
            print(f"\n[Peer]: {decrypted_data}")
            print(">>> ", end="", flush=True)
    except Exception as e:
        print(f"[Error]: {e}")
    finally:
        client_socket.close()

# Start Server (Listening Mode)
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("", PORT))
    server_socket.listen(5)
    print_banner()
    print(f"[*] Waiting for peer connection on port {PORT}...")
    
    client_socket, addr = server_socket.accept()
    print(f"[*] Connection received from {addr}")
    threading.Thread(target=handle_client, args=(client_socket,)).start()
    return client_socket

# Connect to Peer (Client Mode)
def connect_to_peer(peer_ip):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((peer_ip, PORT))
        print(f"[*] Connected to peer at {peer_ip}:{PORT}")
        return client_socket
    except Exception as e:
        print(f"[Error] Unable to connect: {e}")
        return None

# Send messages
def send_message():
    while True:
        message = input(">>> ")
        if message.lower() == "/exit":
            print("[*] Closing connection...")
            peer_socket.close()
            break
        elif message.lower() == "/sendfile":
            send_file()
        else:
            encrypted_msg = encrypt_message(message)
            peer_socket.send(encrypted_msg)

# File Transfer (Send)
def send_file():
    file_path = input("[*] Enter file path: ").strip()
    if not os.path.exists(file_path):
        print("[Error] File does not exist!")
        return
    
    file_name = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)

    # Notify peer of incoming file
    peer_socket.send(f"FILE{SEPARATOR}{file_name}{SEPARATOR}{file_size}".encode())

    with open(file_path, "rb") as file:
        while (chunk := file.read(BUFFER_SIZE)):
            peer_socket.send(chunk)
    
    print(f"[*] File '{file_name}' sent successfully.")

# File Transfer (Receive)
def receive_file(client_socket):
    file_info = client_socket.recv(BUFFER_SIZE).decode()
    if "FILE" in file_info:
        _, file_name, file_size = file_info.split(SEPARATOR)
        file_size = int(file_size)

        with open(f"received_{file_name}", "wb") as file:
            received = 0
            while received < file_size:
                chunk = client_socket.recv(BUFFER_SIZE)
                if not chunk:
                    break
                file.write(chunk)
                received += len(chunk)
        print(f"[*] File '{file_name}' received successfully.")

# Main Execution
if __name__ == "__main__":
    print_banner()
    mode = input("[*] Run as (1) Server or (2) Client? ").strip()

    if mode == "1":
        peer_socket = start_server()
    elif mode == "2":
        peer_ip = input("[*] Enter peer IP address: ").strip()
        peer_socket = connect_to_peer(peer_ip)
        if peer_socket is None:
            exit()

    # Start message thread
    threading.Thread(target=send_message).start()
