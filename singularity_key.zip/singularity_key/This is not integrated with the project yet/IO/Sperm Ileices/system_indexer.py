import os
import sys
import json
import platform
import time
import ctypes
from datetime import datetime
import subprocess
import traceback

class SystemIndexer:
    """Indexes the computer system that AIOS IO is running on."""
    
    def __init__(self, base_dir="AIOS_IO"):
        """Initialize the system indexer with the base directory."""
        self.base_dir = base_dir
        self.apical_pulse_dir = os.path.join(base_dir, "Apical_Pulse_of_the_Membrane")
        
        # Create the Apical Pulse directory
        os.makedirs(self.apical_pulse_dir, exist_ok=True)
        
        # Create subdirectories for different types of system information
        self.system_info_dir = os.path.join(self.apical_pulse_dir, "System_Info")
        self.drive_info_dir = os.path.join(self.apical_pulse_dir, "Drive_Info")
        self.file_info_dir = os.path.join(self.apical_pulse_dir, "File_Info")
        
        for d in [self.system_info_dir, self.drive_info_dir, self.file_info_dir]:
            os.makedirs(d, exist_ok=True)
        
        # Track the system scanning state
        self.is_admin = self._check_admin()
        self.indexed_drives = []
    
    def _check_admin(self):
        """Check if the script is running with administrator privileges."""
        try:
            if os.name == 'nt':  # Windows
                return ctypes.windll.shell32.IsUserAnAdmin() != 0
            else:  # Unix-based systems
                return os.geteuid() == 0
        except:
            return False
    
    def request_admin_access(self):
        """Try to elevate privileges to administrator level."""
        if self.is_admin:
            return True
            
        try:
            if os.name == 'nt':  # Windows
                # Re-run the script with admin privileges
                ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
                # The above should trigger a UAC prompt. If successful, this process will exit.
                time.sleep(1)  # Give time for UAC prompt to appear
                return False  # Original process continues with non-admin access
            else:
                # For Unix systems, try using sudo
                print("Attempting to gain sudo privileges...")
                time.sleep(1)  # Give time for sudo prompt to appear
                return False
        except Exception as e:
            print(f"Failed to get admin access: {e}")
            return False
    
    def get_system_info(self):
        """Collect basic system information."""
        system_info = {
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "architecture": platform.architecture(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python_version": platform.python_version(),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "is_admin": self.is_admin
        }
        
        # Save the system info
        filename = f"system_info_{int(time.time())}.json"
        filepath = os.path.join(self.system_info_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(system_info, f, indent=4)
        
        return system_info
    
    def get_drive_info(self):
        """Collect information about available drives."""
        drives = []
        
        if os.name == 'nt':  # Windows
            try:
                import win32api
                drive_letters = win32api.GetLogicalDriveStrings()
                drive_letters = drive_letters.split('\000')[:-1]
                
                for letter in drive_letters:
                    try:
                        drive_type = win32api.GetDriveType(letter)
                        drive_info = {
                            "drive": letter,
                            "type": drive_type
                        }
                        
                        try:
                            stats = os.statvfs(letter)
                            drive_info["total_space"] = stats.f_frsize * stats.f_blocks
                            drive_info["free_space"] = stats.f_frsize * stats.f_bfree
                        except:
                            pass  # Some drives may not support statvfs
                        
                        drives.append(drive_info)
                        self.indexed_drives.append(letter)
                    except Exception as e:
                        print(f"Error getting info for drive {letter}: {e}")
            except ImportError:
                # Fallback if win32api is not available
                for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                    drive = f"{letter}:\\"
                    if os.path.exists(drive):
                        drive_info = {"drive": drive}
                        drives.append(drive_info)
                        self.indexed_drives.append(drive)
        else:  # Unix-based systems
            try:
                # Get mount points
                with open('/proc/mounts', 'r') as f:
                    mounts = f.readlines()
                
                for mount in mounts:
                    try:
                        parts = mount.split()
                        if len(parts) >= 2:
                            device, mountpoint = parts[0], parts[1]
                            drive_info = {
                                "device": device,
                                "mountpoint": mountpoint
                            }
                            
                            try:
                                stats = os.statvfs(mountpoint)
                                drive_info["total_space"] = stats.f_frsize * stats.f_blocks
                                drive_info["free_space"] = stats.f_frsize * stats.f_bfree
                            except:
                                pass  # Some mounts may not support statvfs
                            
                            drives.append(drive_info)
                            self.indexed_drives.append(mountpoint)
                    except Exception as e:
                        print(f"Error getting info for mount {mount}: {e}")
            except Exception as e:
                print(f"Error getting mount points: {e}")
                # Fallback - just index the root directory
                drives.append({"mountpoint": "/"})
                self.indexed_drives.append("/")
        
        # Save the drive info
        filename = f"drive_info_{int(time.time())}.json"
        filepath = os.path.join(self.drive_info_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(drives, f, indent=4)
        
        return drives
    
    def index_directory(self, directory, max_depth=3, current_depth=0):
        """Index the contents of a directory up to a maximum depth."""
        if current_depth > max_depth:
            return {
                "name": os.path.basename(directory),
                "path": directory,
                "type": "directory",
                "max_depth_reached": True
            }
        
        try:
            dir_info = {
                "name": os.path.basename(directory),
                "path": directory,
                "type": "directory",
                "contents": []
            }
            
            # List all items in the directory
            try:
                items = os.listdir(directory)
                
                for item in items:
                    item_path = os.path.join(directory, item)
                    
                    try:
                        if os.path.isdir(item_path):
                            # Recursively index subdirectories
                            subdir_info = self.index_directory(item_path, max_depth, current_depth + 1)
                            dir_info["contents"].append(subdir_info)
                        else:
                            # Add file information
                            file_info = {
                                "name": item,
                                "path": item_path,
                                "type": "file",
                                "size": os.path.getsize(item_path),
                                "modified": datetime.fromtimestamp(os.path.getmtime(item_path)).strftime("%Y-%m-%d %H:%M:%S")
                            }
                            
                            # Add file extension
                            _, ext = os.path.splitext(item)
                            if ext:
                                file_info["extension"] = ext.lower()[1:]  # Remove the dot
                            
                            dir_info["contents"].append(file_info)
                    except Exception as e:
                        # Skip items that can't be accessed
                        pass
            except Exception as e:
                dir_info["error"] = str(e)
                dir_info["accessible"] = False
                
            return dir_info
            
        except Exception as e:
            return {
                "name": os.path.basename(directory),
                "path": directory,
                "type": "directory",
                "error": str(e),
                "accessible": False
            }
    
    def index_system(self, max_depth=3):
        """Index the entire computer system."""
        try:
            # First, get system info
            system_info = self.get_system_info()
            
            # Then, get drive info
            drives = self.get_drive_info()
            
            # Index each drive up to the maximum depth
            indexed_drives = []
            
            for drive in self.indexed_drives:
                try:
                    print(f"Indexing drive: {drive}")
                    drive_index = self.index_directory(drive, max_depth)
                    indexed_drives.append(drive_index)
                    
                    # Save the drive index
                    safe_drive_name = "".join(c if c.isalnum() else "_" for c in drive)
                    filename = f"drive_index_{safe_drive_name}_{int(time.time())}.json"
                    filepath = os.path.join(self.file_info_dir, filename)
                    
                    with open(filepath, 'w') as f:
                        json.dump(drive_index, f, indent=2)
                        
                except Exception as e:
                    print(f"Error indexing drive {drive}: {e}")
                    traceback.print_exc()
            
            # Create a summary file
            summary = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "system_info": system_info,
                "drives": drives,
                "indexed_drives": self.indexed_drives,
                "indexed_drives_count": len(indexed_drives)
            }
            
            summary_file = os.path.join(self.apical_pulse_dir, f"system_index_summary_{int(time.time())}.json")
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=4)
            
            return summary
            
        except Exception as e:
            print(f"Error during system indexing: {e}")
            traceback.print_exc()
            
            # Create an error file
            error_file = os.path.join(self.apical_pulse_dir, f"system_index_error_{int(time.time())}.json")
            with open(error_file, 'w') as f:
                json.dump({
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "error": str(e),
                    "traceback": traceback.format_exc()
                }, f, indent=4)
            
            return None
