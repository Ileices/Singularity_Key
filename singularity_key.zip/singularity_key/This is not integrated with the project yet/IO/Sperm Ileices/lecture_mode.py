import os
import json
import time
import random
from datetime import datetime

class LectureMode:
    """Implements Lecture Mode for AIOS IO to learn directly from teaching sessions."""
    
    def __init__(self, memory, base_dir="AIOS_IO"):
        """Initialize the lecture mode with the memory system."""
        self.memory = memory
        self.base_dir = base_dir
        self.excretion_dir = os.path.join(base_dir, "Excretions")
        self.lecture_dir = os.path.join(self.excretion_dir, "Lectures")
        
        # Create the lecture directory
        os.makedirs(self.lecture_dir, exist_ok=True)
        
        # Ensure the memory has lecture-specific structures
        if "lecture_mode" not in self.memory:
            self.memory["lecture_mode"] = {
                "active": False,
                "current_session": None,
                "sessions": {},
                "facts": {},
                "opinions": {},
                "reviews": {}
            }
        
        # Constants for the Law of Three
        self.TIER_ONE = 3
        self.TIER_TWO = 9
        self.TIER_THREE = 27
    
    def is_lecture_mode_active(self):
        """Check if lecture mode is currently active."""
        return self.memory["lecture_mode"].get("active", False)
    
    def start_lecture_mode(self, session_name=None):
        """Start a new lecture mode session."""
        if not session_name:
            session_name = f"lecture_session_{int(time.time())}"
        
        session_id = f"lecture_{int(time.time())}"
        
        session = {
            "id": session_id,
            "name": session_name,
            "start_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "facts": [],
            "opinions": [],
            "reviews": [],
            "active": True
        }
        
        # Store the session
        self.memory["lecture_mode"]["active"] = True
        self.memory["lecture_mode"]["current_session"] = session_id
        self.memory["lecture_mode"]["sessions"][session_id] = session
        
        # Save the session to a file
        self._save_session(session_id)
        
        return session_id
    
    def end_lecture_mode(self):
        """End the current lecture mode session."""
        if not self.is_lecture_mode_active():
            return False
        
        session_id = self.memory["lecture_mode"].get("current_session")
        if not session_id:
            self.memory["lecture_mode"]["active"] = False
            return False
        
        # Mark the session as ended
        session = self.memory["lecture_mode"]["sessions"].get(session_id)
        if session:
            session["end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            session["active"] = False
            
            # Save the final session state
            self._save_session(session_id)
        
        # Deactivate lecture mode
        self.memory["lecture_mode"]["active"] = False
        self.memory["lecture_mode"]["current_session"] = None
        
        return True
    
    def detect_lecture_command(self, input_text):
        """Detect if input contains lecture mode commands."""
        input_lower = input_text.lower()
        
        # Check for lecture start commands
        start_commands = [
            "enter lecture mode",
            "begin lesson",
            "i want to teach you",
            "let's start learning",
            "activate intellectual mode",
            "start teaching",
            "lesson begins",
            "time to learn"
        ]
        
        if any(cmd in input_lower for cmd in start_commands):
            return "START"
        
        # Check for lecture end commands
        end_commands = [
            "exit lecture mode",
            "end lesson",
            "lesson complete",
            "end of lecture",
            "that's all for today",
            "class dismissed",
            "learning session over",
            "exit intellectual mode"
        ]
        
        if any(cmd in input_lower for cmd in end_commands):
            return "END"
        
        # In lecture mode, detect fact vs opinion vs review
        if self.is_lecture_mode_active():
            # Check for opinion indicators
            opinion_indicators = [
                "in my opinion",
                "i believe",
                "i think",
                "some people think",
                "it is said that",
                "personally,"
            ]
            
            if any(indicator in input_lower for indicator in opinion_indicators):
                return "OPINION"
            
            # Check for review indicators
            review_indicators = [
                "what do you think",
                "do you agree",
                "would you like to revise",
                "review what you've learned",
                "test your understanding",
                "let me test you",
                "pop quiz",
                "let's review",
                "would you say"
            ]
            
            if any(indicator in input_lower for indicator in review_indicators):
                return "REVIEW"
            
            # Default to fact if no other indicators
            return "FACT"
        
        # Not a lecture mode command
        return None
    
    def process_lecture_input(self, input_text, input_type):
        """Process the lecture mode input based on its type."""
        if not self.is_lecture_mode_active():
            if input_type == "START":
                session_id = self.start_lecture_mode()
                return f"Lecture mode activated. Session ID: {session_id}"
            return None
        
        session_id = self.memory["lecture_mode"].get("current_session")
        if not session_id:
            return None
        
        session = self.memory["lecture_mode"]["sessions"].get(session_id)
        if not session:
            return None
        
        if input_type == "END":
            self.end_lecture_mode()
            fact_count = len(session.get("facts", []))
            opinion_count = len(session.get("opinions", []))
            review_count = len(session.get("reviews", []))
            return f"Lecture mode ended. Learned {fact_count} facts, {opinion_count} opinions, and conducted {review_count} reviews."
        
        elif input_type == "FACT":
            fact_id = f"fact_{int(time.time())}"
            fact = {
                "id": fact_id,
                "content": input_text,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "confirmations": 1
            }
            
            # Store the fact
            session["facts"].append(fact_id)
            self.memory["lecture_mode"]["facts"][fact_id] = fact
            
            # Save the updated session
            self._save_session(session_id)
            
            return f"Learned fact: '{input_text}'. Facts are stored in the absolute knowledge base."
        
        elif input_type == "OPINION":
            opinion_id = f"opinion_{int(time.time())}"
            opinion = {
                "id": opinion_id,
                "content": input_text,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "confidence": 0.5  # Opinions start at 50% confidence
            }
            
            # Store the opinion
            session["opinions"].append(opinion_id)
            self.memory["lecture_mode"]["opinions"][opinion_id] = opinion
            
            # Save the updated session
            self._save_session(session_id)
            
            return f"Noted opinion: '{input_text}'. Opinions are stored separately from absolute facts."
        
        elif input_type == "REVIEW":
            review_id = f"review_{int(time.time())}"
            review = {
                "id": review_id,
                "review_question": input_text,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "related_facts": session["facts"][-3:] if session["facts"] else [],
                "related_opinions": session["opinions"][-3:] if session["opinions"] else [],
                "conclusion": self._generate_review_conclusion(session)
            }
            
            # Store the review
            session["reviews"].append(review_id)
            self.memory["lecture_mode"]["reviews"][review_id] = review
            
            # Save the updated session
            self._save_session(session_id)
            
            # Create a response based on the review
            return self._format_review_response(review)
    
    def _generate_review_conclusion(self, session):
        """Generate a conclusion based on the facts and opinions in the session."""
        facts_count = len(session.get("facts", []))
        opinions_count = len(session.get("opinions", []))
        
        # Apply the Law of Three to the review process
        if facts_count >= self.TIER_THREE or opinions_count >= self.TIER_THREE:
            conclusion = "Comprehensive understanding achieved through multiple reinforced concepts."
        elif facts_count >= self.TIER_TWO or opinions_count >= self.TIER_TWO:
            conclusion = "Strong understanding with a good foundation of knowledge."
        elif facts_count >= self.TIER_ONE or opinions_count >= self.TIER_ONE:
            conclusion = "Basic understanding established with core concepts."
        else:
            conclusion = "Initial exploration of the topic has begun."
        
        return conclusion
    
    def _format_review_response(self, review):
        """Format a response for a review question."""
        conclusion = review.get("conclusion", "")
        
        # Create responses based on the Law of Three
        response_templates = [
            f"Based on what I've learned, {conclusion}",
            f"I've been processing the information, and {conclusion}",
            f"After reviewing the facts and opinions, I believe {conclusion}"
        ]
        
        # Add information about fact/opinion counts
        fact_ids = review.get("related_facts", [])
        opinion_ids = review.get("related_opinions", [])
        
        if fact_ids:
            facts_summary = f"I've learned {len(fact_ids)} facts related to this topic."
            response_templates[0] += f" {facts_summary}"
        
        if opinion_ids:
            opinions_summary = f"I've also noted {len(opinion_ids)} opinions on the matter."
            if len(response_templates) > 1:
                response_templates[1] += f" {opinions_summary}"
            else:
                response_templates[0] += f" {opinions_summary}"
        
        # Select a random response template
        response = random.choice(response_templates)
        return response
    
    def _save_session(self, session_id):
        """Save the session data to a file."""
        session = self.memory["lecture_mode"]["sessions"].get(session_id)
        if not session:
            return False
        
        # Create a serializable version of the session
        save_data = {
            "session": session,
            "facts": {fact_id: self.memory["lecture_mode"]["facts"].get(fact_id) 
                     for fact_id in session.get("facts", [])},
            "opinions": {opinion_id: self.memory["lecture_mode"]["opinions"].get(opinion_id) 
                        for opinion_id in session.get("opinions", [])},
            "reviews": {review_id: self.memory["lecture_mode"]["reviews"].get(review_id) 
                       for review_id in session.get("reviews", [])}
        }
        
        # Save to file
        filename = f"lecture_session_{session_id}.json"
        filepath = os.path.join(self.lecture_dir, filename)
        
        try:
            with open(filepath, "w") as f:
                json.dump(save_data, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving lecture session: {str(e)}")
            return False
    
    def load_sessions(self):
        """Load all saved lecture sessions from files."""
        loaded = 0
        
        try:
            # List all session files
            files = [f for f in os.listdir(self.lecture_dir) if f.endswith(".json")]
            
            for file in files:
                try:
                    filepath = os.path.join(self.lecture_dir, file)
                    
                    with open(filepath, "r") as f:
                        save_data = json.load(f)
                    
                    # Extract the session data
                    session = save_data.get("session")
                    if not session or not session.get("id"):
                        continue
                    
                    # Store the session in memory
                    session_id = session.get("id")
                    self.memory["lecture_mode"]["sessions"][session_id] = session
                    
                    # Store the facts, opinions, and reviews
                    for fact_id, fact in save_data.get("facts", {}).items():
                        self.memory["lecture_mode"]["facts"][fact_id] = fact
                    
                    for opinion_id, opinion in save_data.get("opinions", {}).items():
                        self.memory["lecture_mode"]["opinions"][opinion_id] = opinion
                    
                    for review_id, review in save_data.get("reviews", {}).items():
                        self.memory["lecture_mode"]["reviews"][review_id] = review
                    
                    loaded += 1
                except Exception as e:
                    print(f"Error loading lecture session file {file}: {str(e)}")
            
            return loaded
        except Exception as e:
            print(f"Error listing lecture session files: {str(e)}")
            return 0
    
    def get_facts_summary(self):
        """Get a summary of all stored facts."""
        facts = list(self.memory["lecture_mode"]["facts"].values())
        
        summary = {
            "total_facts": len(facts),
            "recent_facts": facts[-10:] if len(facts) > 10 else facts,
            "fact_counts": {
                "total": len(facts),
                "tier_one": sum(1 for f in facts if f.get("confirmations", 0) >= self.TIER_ONE),
                "tier_two": sum(1 for f in facts if f.get("confirmations", 0) >= self.TIER_TWO),
                "tier_three": sum(1 for f in facts if f.get("confirmations", 0) >= self.TIER_THREE)
            }
        }
        
        return summary
    
    def get_opinions_summary(self):
        """Get a summary of all stored opinions."""
        opinions = list(self.memory["lecture_mode"]["opinions"].values())
        
        summary = {
            "total_opinions": len(opinions),
            "recent_opinions": opinions[-10:] if len(opinions) > 10 else opinions,
            "confidence_levels": {
                "high": sum(1 for o in opinions if o.get("confidence", 0) > 0.8),
                "medium": sum(1 for o in opinions if 0.4 <= o.get("confidence", 0) <= 0.8),
                "low": sum(1 for o in opinions if o.get("confidence", 0) < 0.4)
            }
        }
        
        return summary
    
    def reinforce_fact(self, fact_id):
        """Reinforce a fact by increasing its confirmation count."""
        if fact_id in self.memory["lecture_mode"]["facts"]:
            fact = self.memory["lecture_mode"]["facts"][fact_id]
            fact["confirmations"] = fact.get("confirmations", 0) + 1
            
            # Apply the Law of Three to fact reinforcement
            if fact["confirmations"] == self.TIER_ONE:
                fact["verification_level"] = "verified"
            elif fact["confirmations"] == self.TIER_TWO:
                fact["verification_level"] = "core_truth"
            elif fact["confirmations"] == self.TIER_THREE:
                fact["verification_level"] = "fundamental"
            
            return fact["confirmations"]
        
        return 0
    
    def adjust_opinion_confidence(self, opinion_id, adjustment):
        """Adjust the confidence level of an opinion."""
        if opinion_id in self.memory["lecture_mode"]["opinions"]:
            opinion = self.memory["lecture_mode"]["opinions"][opinion_id]
            opinion["confidence"] = max(0, min(1, opinion.get("confidence", 0.5) + adjustment))
            
            # Apply the Law of Three to opinion confidence
            confidence = opinion["confidence"]
            if confidence >= 0.9:
                opinion["confidence_level"] = "high"
            elif confidence >= 0.6:
                opinion["confidence_level"] = "medium"
            elif confidence >= 0.3:
                opinion["confidence_level"] = "low"
            else:
                opinion["confidence_level"] = "speculative"
            
            return opinion["confidence"]
        
        return 0
