import os
import json
import numpy as np
import time
from datetime import datetime

# We'll use these as placeholders - in a production environment,
# you would install these packages: h5py, onnx, tensorflow
try:
    import h5py
    HAS_H5PY = True
except ImportError:
    HAS_H5PY = False

try:
    import onnx
    from onnx import helper, TensorProto
    HAS_ONNX = True
except ImportError:
    HAS_ONNX = False

try:
    import tensorflow as tf
    HAS_TF = True
except ImportError:
    HAS_TF = False

class MLFileGenerator:
    """Generates various machine learning file formats for AIOS IO intelligence evolution."""
    
    def __init__(self, base_dir="AIOS_IO"):
        """Initialize the ML file generator with the base directory."""
        self.base_dir = base_dir
        self.excretion_dir = os.path.join(base_dir, "Excretions")
        self.red_ml_dir = os.path.join(self.excretion_dir, "Red_ML")
        self.blue_ml_dir = os.path.join(self.excretion_dir, "Blue_ML")
        self.yellow_ml_dir = os.path.join(self.excretion_dir, "Yellow_ML")
        
        # Create a new directory for ML files specifically
        self.ml_files_dir = os.path.join(self.excretion_dir, "ML_Files")
        self.apical_pulse_dir = os.path.join(base_dir, "Apical_Pulse_of_the_Membrane")
        
        # Ensure all directories exist
        for d in [self.excretion_dir, self.red_ml_dir, self.blue_ml_dir, 
                 self.yellow_ml_dir, self.ml_files_dir, self.apical_pulse_dir]:
            os.makedirs(d, exist_ok=True)
    
    def _convert_to_numpy(self, data):
        """Convert dictionary data to numpy arrays for ML file formats."""
        if isinstance(data, dict):
            result = {}
            for key, value in data.items():
                if isinstance(value, dict):
                    result[key] = self._convert_to_numpy(value)
                elif isinstance(value, list):
                    try:
                        result[key] = np.array(value, dtype=np.float32)
                    except:
                        result[key] = np.array(value, dtype=object)
                else:
                    result[key] = value
            return result
        return data
    
    def generate_hdf5_file(self, component, data):
        """Generate HDF5 file from perception data (RED component)."""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"{component.lower()}_perception_{timestamp}.h5"
        filepath = os.path.join(self.ml_files_dir, filename)
        
        try:
            if HAS_H5PY:
                np_data = self._convert_to_numpy(data)
                
                with h5py.File(filepath, 'w') as f:
                    # Store metadata
                    meta_grp = f.create_group('metadata')
                    meta_grp.attrs['timestamp'] = timestamp
                    meta_grp.attrs['component'] = component
                    
                    # Recursively store all data
                    def store_data(group, data_dict):
                        for key, value in data_dict.items():
                            if isinstance(value, dict):
                                subgroup = group.create_group(key)
                                store_data(subgroup, value)
                            elif isinstance(value, np.ndarray):
                                group.create_dataset(key, data=value, compression="gzip")
                            else:
                                group.attrs[key] = str(value)
                    
                    # Create main data group and store data
                    data_grp = f.create_group('data')
                    store_data(data_grp, np_data)
                
                return filepath
            else:
                # Fallback if h5py not available - just write a JSON with .h5 extension
                with open(filepath.replace('.h5', '.json'), 'w') as f:
                    json.dump(data, f, indent=2)
                print(f"Warning: h5py not available. Created JSON file instead: {filepath}")
                return filepath.replace('.h5', '.json')
        except Exception as e:
            print(f"Error creating HDF5 file: {str(e)}")
            # Fallback to JSON if any error occurs
            json_path = filepath.replace('.h5', '.json')
            with open(json_path, 'w') as f:
                json.dump(data, f, indent=2)
            return json_path
    
    def generate_onnx_file(self, component, data):
        """Generate ONNX file from processing data (BLUE component)."""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"{component.lower()}_processing_{timestamp}.onnx"
        filepath = os.path.join(self.ml_files_dir, filename)
        
        try:
            if HAS_ONNX:
                # Create a simple ONNX model from the data
                # This is a placeholder - in practice you would build a real model
                
                # Create a simple input to represent the data
                input_tensor = helper.make_tensor_value_info(
                    'input', TensorProto.FLOAT, [1, 10]
                )
                
                # Create a simple output
                output_tensor = helper.make_tensor_value_info(
                    'output', TensorProto.FLOAT, [1, 5]
                )
                
                # Create a node (placeholder)
                node_def = helper.make_node(
                    'Identity',
                    inputs=['input'],
                    outputs=['output'],
                    name='simple_identity'
                )
                
                # Create the graph
                graph_def = helper.make_graph(
                    [node_def],
                    'simple-model',
                    [input_tensor],
                    [output_tensor]
                )
                
                # Create the model
                model_def = helper.make_model(graph_def, producer_name='aios_io_blue')
                
                # Save the ONNX model
                onnx.save(model_def, filepath)
                
                return filepath
            else:
                # Fallback if onnx not available - just write a JSON with .onnx extension
                with open(filepath.replace('.onnx', '.json'), 'w') as f:
                    json.dump(data, f, indent=2)
                print(f"Warning: ONNX not available. Created JSON file instead: {filepath}")
                return filepath.replace('.onnx', '.json')
        except Exception as e:
            print(f"Error creating ONNX file: {str(e)}")
            # Fallback to JSON if any error occurs
            json_path = filepath.replace('.onnx', '.json')
            with open(json_path, 'w') as f:
                json.dump(data, f, indent=2)
            return json_path
    
    def generate_tfrecord_file(self, component, data):
        """Generate TFRecord file from generative data (YELLOW component)."""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"{component.lower()}_generative_{timestamp}.tfrecord"
        filepath = os.path.join(self.ml_files_dir, filename)
        
        try:
            if HAS_TF:
                # Helper function to create features
                def _bytes_feature(value):
                    if isinstance(value, type(tf.constant(0))):
                        value = value.numpy()
                    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))
                
                def _float_feature(value):
                    return tf.train.Feature(float_list=tf.train.FloatList(value=[value]))
                
                def _int64_feature(value):
                    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value]))
                
                # Create a simple example
                feature = {
                    'timestamp': _bytes_feature(str(timestamp).encode()),
                    'component': _bytes_feature(component.encode()),
                    'data': _bytes_feature(json.dumps(data).encode())
                }
                
                example = tf.train.Example(features=tf.train.Features(feature=feature))
                
                # Write to TFRecord file
                with tf.io.TFRecordWriter(filepath) as writer:
                    writer.write(example.SerializeToString())
                
                return filepath
            else:
                # Fallback if tensorflow not available
                with open(filepath.replace('.tfrecord', '.json'), 'w') as f:
                    json.dump(data, f, indent=2)
                print(f"Warning: TensorFlow not available. Created JSON file instead: {filepath}")
                return filepath.replace('.tfrecord', '.json')
        except Exception as e:
            print(f"Error creating TFRecord file: {str(e)}")
            # Fallback to JSON if any error occurs
            json_path = filepath.replace('.tfrecord', '.json')
            with open(json_path, 'w') as f:
                json.dump(data, f, indent=2)
            return json_path
    
    def generate_ml_file(self, component, data):
        """Generate the appropriate ML file based on the component."""
        if component == "Red":
            return self.generate_hdf5_file(component, data)
        elif component == "Blue":
            return self.generate_onnx_file(component, data)
        elif component == "Yellow":
            return self.generate_tfrecord_file(component, data)
        else:
            # Default to JSON for unknown components
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            filename = f"unknown_{timestamp}.json"
            filepath = os.path.join(self.ml_files_dir, filename)
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
            return filepath
