#!/usr/bin/env python3
"""
AIOS IO Math Capability Enhancer

This module improves AIOS IO's ability to understand, learn, and recall
mathematical operations following the Law of Three learning principles.

It enhances the lecture mode to properly handle mathematical equations
and ensures math knowledge persists in memory.
"""

import os
import sys
import re
import importlib.util
import random
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class MathCapabilityEnhancer:
    """
    Enhances AIOS IO with improved mathematical capabilities,
    focusing on learning, memory, and recall.
    """
    
    def __init__(self):
        """Initialize the math capability enhancer."""
        self.sperm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                                "Sperm Ileices", "sperm_ileices.py")
        self.lecture_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                                 "Sperm Ileices", "enhanced_lecture_mode.py")
        
        # Get original module content
        self.sperm_content = self._read_file(self.sperm_path)
        self.lecture_content = self._read_file(self.lecture_path)
        
        # Define the Law of Three constants
        self.TIER_ONE = 3    # First level
        self.TIER_TWO = 9    # Second level (3²)
        self.TIER_THREE = 27 # Third level (3³)

    def _read_file(self, path):
        """Read file content safely."""
        if not os.path.exists(path):
            print(f"Error: File not found: {path}")
            return None
            
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            print(f"Error reading file {path}: {e}")
            return None
    
    def _write_file(self, path, content):
        """Write content to file safely."""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Error writing to file {path}: {e}")
            return False
    
    def enhance_all(self):
        """Apply all math capability enhancements."""
        if not self.sperm_content or not self.lecture_content:
            print("Error: Cannot proceed without valid source files.")
            return False
        
        # 1. Add math operation detection to lecture mode
        print("[1/4] Adding math operation detection...")
        if not self._add_math_detection():
            return False
            
        # 2. Add math learning persistence to lecture mode
        print("[2/4] Adding math learning persistence...")
        if not self._add_math_persistence():
            return False
            
        # 3. Update lecture mode to process math operations
        print("[3/4] Updating lecture mode to handle math operations...")
        if not self._integrate_math_processing():
            return False
            
        # 4. Integrate with excretions for recursive learning
        print("[4/4] Integrating with excretions...")
        if not self._integrate_with_excretions():
            return False
        
        print("\n✓ All math capability enhancements successfully applied!")
        return True
    
    def _add_math_detection(self):
        """Add math operation detection capabilities to enhanced_lecture_mode.py."""
        # Check if already implemented
        if "def detect_math_expression" in self.lecture_content:
            print("✓ Math detection already implemented.")
            return True
        
        # Find insertion point - at the end of the class
        insertion_point = self.lecture_content.rfind("}")
        if insertion_point == -1:
            print("Error: Could not find the end of the EnhancedLectureMode class.")
            return False
        
        # Create the math detection function
        math_detection_code = """
    def detect_math_expression(self, text):
        \"\"\"Detect and evaluate mathematical expressions in text.\"\"\"
        # Match patterns like "1+2=3", "5*4", "what is 10/2"
        patterns = [
            # Pattern for equations with results: "1+2=3"
            (r'(\d+)\s*([\+\-\*\/])\s*(\d+)\s*=\s*(\d+)', self._evaluate_equation),
            # Pattern for operations: "5*4" 
            (r'(\d+)\s*([\+\-\*\/])\s*(\d+)', self._evaluate_operation),
            # Pattern for questions: "what is 10/2?"
            (r'what\s+is\s+(\d+)\s*([\+\-\*\/])\s*(\d+)', self._evaluate_operation)
        ]
        
        # Try each pattern
        for pattern, handler in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return handler(match)
        
        return None
    
    def _evaluate_equation(self, match):
        \"\"\"Evaluate a matched equation like "1+2=3" and determine correctness.\"\"\"
        try:
            num1 = int(match.group(1))
            operator = match.group(2)
            num2 = int(match.group(3))
            stated_result = int(match.group(4))
            
            # Calculate actual result
            if operator == '+':
                actual_result = num1 + num2
            elif operator == '-':
                actual_result = num1 - num2
            elif operator == '*':
                actual_result = num1 * num2
            elif operator == '/' and num2 != 0:
                actual_result = num1 / num2
            else:
                return None
                
            # Return information about the equation
            return {
                "type": "equation",
                "operation": f"{num1}{operator}{num2}",
                "stated_result": stated_result,
                "actual_result": actual_result,
                "is_correct": stated_result == actual_result
            }
        except:
            return None
    
    def _evaluate_operation(self, match):
        \"\"\"Evaluate a matched operation like "5*4" or from "what is 5*4".\"\"\"
        try:
            num1 = int(match.group(1))
            operator = match.group(2)
            num2 = int(match.group(3))
            
            # Calculate result
            if operator == '+':
                result = num1 + num2
            elif operator == '-':
                result = num1 - num2
            elif operator == '*':
                result = num1 * num2
            elif operator == '/' and num2 != 0:
                result = num1 / num2
            else:
                return None
                
            # Return information about the operation
            return {
                "type": "operation",
                "operation": f"{num1}{operator}{num2}",
                "result": result
            }
        except:
            return None
    
    def learn_math_fact(self, operation, result):
        \"\"\"Store a math fact in memory with the Law of Three learning stages.\"\"\"
        # Initialize math facts dictionary if needed
        if "math_knowledge" not in self.memory:
            self.memory["math_knowledge"] = {}
        
        # Store or update the math fact
        if operation in self.memory["math_knowledge"]:
            fact = self.memory["math_knowledge"][operation]
            fact["encounters"] += 1
            
            # Apply Law of Three for learning stages
            if fact["encounters"] >= self.TIER_THREE:  # 27
                fact["confidence"] = "permanent"
            elif fact["encounters"] >= self.TIER_TWO:  # 9
                fact["confidence"] = "strong"
            elif fact["encounters"] >= self.TIER_ONE:  # 3
                fact["confidence"] = "moderate"
        else:
            # First encounter with this fact
            self.memory["math_knowledge"][operation] = {
                "result": result,
                "encounters": 1,
                "confidence": "initial",
                "first_learned": datetime.now().isoformat(),
                "last_encountered": datetime.now().isoformat()
            }
        
        # Also store in general concepts for broader access
        if "concepts" not in self.memory:
            self.memory["concepts"] = {}
        
        self.memory["concepts"][operation] = str(result)
        
        return self.memory["math_knowledge"][operation]
"""

        # Insert the code before the last closing brace of the class
        updated_lecture_content = (
            self.lecture_content[:insertion_point] +
            math_detection_code + 
            self.lecture_content[insertion_point:]
        )
        
        # Write the updated content back to the file
        if not self._write_file(self.lecture_path, updated_lecture_content):
            return False
            
        # Update our local copy
        self.lecture_content = updated_lecture_content
        print("✓ Added math detection capabilities.")
        return True
    
    def _add_math_persistence(self):
        """Add math learning persistence to enhanced_lecture_mode.py."""
        # Check if already implemented
        if "def recall_math_fact" in self.lecture_content:
            print("✓ Math persistence already implemented.")
            return True
        
        # Find insertion point - at the end of the class
        insertion_point = self.lecture_content.rfind("}")
        if insertion_point == -1:
            print("Error: Could not find the end of the EnhancedLectureMode class.")
            return False
        
        # Create the math recall function
        math_persistence_code = """
    def recall_math_fact(self, operation):
        \"\"\"Recall a previously learned math fact.\"\"\"
        # Check if we have this math fact in memory
        if "math_knowledge" in self.memory and operation in self.memory["math_knowledge"]:
            fact = self.memory["math_knowledge"][operation]
            
            # Update the encounter count and last encountered time
            fact["encounters"] += 1
            fact["last_encountered"] = datetime.now().isoformat()
            
            # Check if we need to upgrade the confidence level
            if fact["confidence"] != "permanent":
                if fact["encounters"] >= self.TIER_THREE:  # 27
                    fact["confidence"] = "permanent"
                elif fact["encounters"] >= self.TIER_TWO:  # 9
                    fact["confidence"] = "strong"
                elif fact["encounters"] >= self.TIER_ONE:  # 3
                    fact["confidence"] = "moderate"
            
            return fact
        
        return None
    
    def save_math_knowledge(self, filename=None):
        \"\"\"Save math knowledge to a persistent file.\"\"\"
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"math_knowledge_{timestamp}.json"
            
        # Make sure the directory exists
        os.makedirs(os.path.dirname(os.path.abspath(filename)), exist_ok=True)
        
        # Extract just the math knowledge for storage
        if "math_knowledge" in self.memory:
            import json
            try:
                with open(filename, 'w') as f:
                    json.dump(self.memory["math_knowledge"], f, indent=2)
                return True
            except Exception as e:
                print(f"Error saving math knowledge: {e}")
        
        return False
    
    def load_math_knowledge(self, filename):
        \"\"\"Load math knowledge from a persistent file.\"\"\"
        import json
        try:
            with open(filename, 'r') as f:
                math_knowledge = json.load(f)
            
            # Merge with existing math knowledge
            if "math_knowledge" not in self.memory:
                self.memory["math_knowledge"] = {}
                
            self.memory["math_knowledge"].update(math_knowledge)
            
            # Also update concepts
            if "concepts" not in self.memory:
                self.memory["concepts"] = {}
                
            for operation, fact in math_knowledge.items():
                self.memory["concepts"][operation] = str(fact["result"])
                
            return True
        except Exception as e:
            print(f"Error loading math knowledge: {e}")
            return False
"""
        
        # Insert the code before the last closing brace of the class
        updated_lecture_content = (
            self.lecture_content[:insertion_point] +
            math_persistence_code + 
            self.lecture_content[insertion_point:]
        )
        
        # Write the updated content back to the file
        if not self._write_file(self.lecture_path, updated_lecture_content):
            return False
            
        # Update our local copy
        self.lecture_content = updated_lecture_content
        print("✓ Added math persistence capabilities.")
        return True
    
    def _integrate_math_processing(self):
        """Update process_lecture_input to handle math operations."""
        # Check if math processing is already integrated
        if "math_expression =" in self.lecture_content and "detect_math_expression" in self.lecture_content:
            print("✓ Math processing already integrated.")
            return True
            
        # Find the process_lecture_input method
        pattern = re.compile(r'def\s+process_lecture_input.*?elif lecture_command == "fact":', re.DOTALL)
        match = pattern.search(self.lecture_content)
        
        if not match:
            print("Error: Could not find the process_lecture_input method in enhanced_lecture_mode.py")
            return False
            
        # Get the code before the "elif lecture_command == 'fact'" part
        before_fact_section = match.group(0)
        
        # Create math handling code to insert
        math_processing_code = """
        # Check for mathematical expressions
        math_expression = self.detect_math_expression(user_input)
        if math_expression:
            if math_expression["type"] == "equation":
                # This is a statement like "2+2=4"
                operation = math_expression["operation"]
                is_correct = math_expression["is_correct"]
                
                if is_correct:
                    # Store the correct equation
                    fact = self.learn_math_fact(operation, math_expression["actual_result"])
                    confidence = fact["confidence"]
                    
                    # Add to facts learned in this session
                    self.lecture_memory["facts_learned"].append({
                        "fact": f"{operation} = {math_expression['actual_result']}",
                        "topic": "Mathematics",
                        "timestamp": time.time()
                    })
                    
                    # Update session statistics
                    session_id = f"session_{self.lecture_memory['total_sessions']}"
                    if session_id in self.lecture_memory["session_stats"]:
                        self.lecture_memory["session_stats"][session_id]["facts_learned"] += 1
                    
                    # Response varies based on confidence level
                    if confidence == "permanent":
                        return f"Yes, {operation} = {math_expression['actual_result']}. I've thoroughly learned this fact."
                    elif confidence == "strong":
                        return f"That's correct! {operation} = {math_expression['actual_result']}. I have this fact well-established in my memory."
                    elif confidence == "moderate":
                        return f"I agree that {operation} = {math_expression['actual_result']}. I'm becoming confident with this fact."
                    else:
                        return f"I've learned that {operation} = {math_expression['actual_result']}. Thank you for teaching me this."
                else:
                    # This is an incorrect equation
                    actual = math_expression["actual_result"]
                    stated = math_expression["stated_result"]
                    return f"I believe there's a mistake. {operation} actually equals {actual}, not {stated}."
            
            elif math_expression["type"] == "operation":
                # This is just a math expression like "5*4" or a question "what is 5*4"
                operation = math_expression["operation"]
                result = math_expression["result"]
                
                # Check if we already know this fact
                known_fact = self.recall_math_fact(operation)
                
                if known_fact:
                    # We've seen this before
                    confidence = known_fact["confidence"]
                    
                    if confidence == "permanent":
                        return f"{operation} = {result}. This is a well-established mathematical fact."
                    elif confidence in ["strong", "moderate"]:
                        return f"{operation} = {result}. I'm confident in this answer."
                    else:
                        return f"{operation} = {result}. I'm still reinforcing this knowledge."
                else:
                    # This is new knowledge
                    self.learn_math_fact(operation, result)
                    return f"I calculate that {operation} = {result}."

        elif lecture_command == "fact":"""
        
        # Replace the original "elif lecture_command == 'fact':" with our new code
        updated_lecture_content = self.lecture_content.replace(
            "elif lecture_command == \"fact\":", 
            math_processing_code
        )
        
        # Write the updated content back to the file
        if not self._write_file(self.lecture_path, updated_lecture_content):
            return False
            
        # Now enhance the test_knowledge method to handle math operations
        pattern = re.compile(r'def\s+test_knowledge.*?return\s+"I don', re.DOTALL)
        match = pattern.search(updated_lecture_content)
        
        if not match:
            print("Error: Could not find the test_knowledge method in enhanced_lecture_mode.py")
            return False
            
        # Get the code ending with the default "I don't know" response
        test_method = match.group(0)
        default_response_pos = test_method.rfind("return")
        
        if default_response_pos == -1:
            print("Error: Could not find the default response in test_knowledge method")
            return False
            
        # Create math testing code
        math_testing_code = """
        # Test for math expressions
        math_expression = self.detect_math_expression(query)
        if math_expression:
            if math_expression["type"] == "operation":
                operation = math_expression["operation"]
                result = math_expression["result"]
                
                # Check if we already know this fact
                known_fact = self.recall_math_fact(operation)
                
                if known_fact:
                    # Return based on our confidence
                    confidence = known_fact["confidence"]
                    if confidence in ["permanent", "strong"]:
                        return f"{operation} = {result}. I'm certain of this."
                    else:
                        return f"{operation} = {result}. This is my current understanding."
                else:
                    # We don't have this in memory, but we can calculate it
                    self.learn_math_fact(operation, result)  # Learn it now
                    return f"Based on calculation: {operation} = {result}"
        
        """
        
        # Insert the math testing code before the default response
        updated_test_method = test_method[:default_response_pos] + math_testing_code + test_method[default_response_pos:]
        
        # Replace the original test method with the updated one
        updated_lecture_content = updated_lecture_content.replace(test_method, updated_test_method)
        
        # Write the updated content back to the file
        if not self._write_file(self.lecture_path, updated_lecture_content):
            return False
            
        # Update our local copy
        self.lecture_content = updated_lecture_content
        print("✓ Integrated math processing capabilities.")
        return True
    
    def _integrate_with_excretions(self):
        """Integrate math knowledge with the excretion system for continuous learning."""
        # Check if it's already integrated
        if "if 'math_knowledge' in self.memory:" in self.sperm_content:
            print("✓ Math excretion integration already implemented.")
            return True
            
        # Find the excretion function
        pattern = re.compile(r'def\s+excrete_ml_pattern.*?pattern_dict\s*=\s*{.*?}', re.DOTALL)
        match = pattern.search(self.sperm_content)
        
        if not match:
            print("Error: Could not find the excrete_ml_pattern function in sperm_ileices.py")
            return False
            
        # Get the pattern_dict initialization
        pattern_dict_code = match.group(0)
        closing_brace_pos = pattern_dict_code.rfind("}")
        
        if closing_brace_pos == -1:
            print("Error: Could not find the closing brace of pattern_dict")
            return False
            
        # Create math knowledge excretion code
        math_excretion_code = """
        # Include math knowledge if available
        if "math_knowledge" in self.memory:
            # Only include permanent (high confidence) math facts
            verified_math = {}
            for operation, fact in self.memory["math_knowledge"].items():
                if fact["confidence"] in ["permanent", "strong"]:
                    verified_math[operation] = fact["result"]
            
            if verified_math:
                pattern_dict["verified_math"] = verified_math
        """
        
        # Insert the math excretion code right after the closing brace of pattern_dict
        updated_pattern_dict = (
            pattern_dict_code[:closing_brace_pos+1] +
            math_excretion_code +
            pattern_dict_code[closing_brace_pos+1:]
        )
        
        # Replace the original pattern_dict with the updated one
        updated_sperm_content = self.sperm_content.replace(pattern_dict_code, updated_pattern_dict)
        
        # Add math knowledge reabsorption to improve continuous learning
        pattern = re.compile(r'def\s+reabsorb_excretions.*?return\s+results', re.DOTALL)
        match = pattern.search(updated_sperm_content)
        
        if not match:
            print("Error: Could not find the reabsorb_excretions function in sperm_ileices.py")
            return False
            
        # Get the reabsorb function code
        reabsorb_code = match.group(0)
        return_pos = reabsorb_code.rfind("return results")
        
        if return_pos == -1:
            print("Error: Could not find the return statement in reabsorb_excretions")
            return False
            
        # Create math knowledge reabsorption code
        math_reabsorption_code = """
        # Integrate math knowledge from excretions
        try:
            for file_name in files_processed:
                with open(os.path.join(excretion_dir, file_name), 'r') as f:
                    excretion_data = json.load(f)
                
                # Look for verified math facts
                if "verified_math" in excretion_data:
                    if "math_knowledge" not in memory:
                        memory["math_knowledge"] = {}
                        
                    for operation, result in excretion_data["verified_math"].items():
                        if operation not in memory["math_knowledge"]:
                            # Add as a new fact with moderate confidence
                            memory["math_knowledge"][operation] = {
                                "result": result,
                                "encounters": 3,  # Start at Tier One
                                "confidence": "moderate",
                                "first_learned": datetime.now().isoformat(),
                                "last_encountered": datetime.now().isoformat()
                            }
                        else:
                            # Increase encounters for existing facts
                            memory["math_knowledge"][operation]["encounters"] += 1
                            
                            # Update confidence based on Law of Three
                            encounters = memory["math_knowledge"][operation]["encounters"]
                            if encounters >= 27:  # Tier Three
                                memory["math_knowledge"][operation]["confidence"] = "permanent"
                            elif encounters >= 9:  # Tier Two
                                memory["math_knowledge"][operation]["confidence"] = "strong"
        except Exception as e:
            print(f"Error reabsorbing math knowledge: {e}")
        """
        
        # Insert the math reabsorption code before the return statement
        updated_reabsorb = (
            reabsorb_code[:return_pos] +
            math_reabsorption_code +
            reabsorb_code[return_pos:]
        )
        
        # Replace the original reabsorb function with the updated one
        updated_sperm_content = updated_sperm_content.replace(reabsorb_code, updated_reabsorb)
        
        # Write the updated content back to the file
        if not self._write_file(self.sperm_path, updated_sperm_content):
            return False
            
        # Update our local copy
        self.sperm_content = updated_sperm_content
        print("✓ Integrated math knowledge with excretion system.")
        return True

def enhance_math_capabilities():
    """Main function to enhance all math capabilities."""
    print("AIOS IO Math Capability Enhancer")
    print("=" * 50)
    
    enhancer = MathCapabilityEnhancer()
    result = enhancer.enhance_all()
    
    if result:
        print("\nMath capabilities successfully enhanced!")
        print("\nYou can now use lecture mode to teach and test math facts:")
        print("  1. Enter lecture mode:       'enter lecture mode'")
        print("  2. Teach math facts:         '2+2=4', '5*3=15'")
        print("  3. Ask math questions:       'what is 7+8?'")
        print("  4. Test learned knowledge:   'test: what is 2+2?'")
        print("\nThe system will learn and improve over time following the Law of Three.")
        return True
    else:
        print("\nError: Failed to enhance math capabilities")
        return False

if __name__ == "__main__":
    enhance_math_capabilities()
