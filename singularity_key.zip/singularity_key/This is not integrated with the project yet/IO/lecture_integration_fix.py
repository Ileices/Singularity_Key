#!/usr/bin/env python3
"""
AIOS IO Lecture Mode Integration Fix

This script ensures proper integration between the Enhanced Lecture Mode
and the main AIOS IO system, fixing the issues with lecture functionality.
"""

import os
import sys
import importlib.util

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def fix_lecture_mode_integration():
    """Fix the integration between lecture mode and sperm_ileices.py"""
    
    # First check if sperm_ileices and enhanced_lecture_mode are available
    sperm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                             "Sperm Ileices", "sperm_ileices.py")
    lecture_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                               "Sperm Ileices", "enhanced_lecture_mode.py")
    
    if not (os.path.exists(sperm_path) and os.path.exists(lecture_path)):
        print("Error: Required modules not found in expected locations.")
        return False
    
    try:
        # Import sperm_ileices module
        spec = importlib.util.spec_from_file_location("sperm_ileices", sperm_path)
        sperm = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sperm)
        
        # Import enhanced_lecture_mode module
        spec = importlib.util.spec_from_file_location("enhanced_lecture_mode", lecture_path)
        lecture_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(lecture_module)
        
        # Create instance of enhanced lecture mode
        lecture_mode = lecture_module.EnhancedLectureMode(sperm.memory)
        
        # Check if lecture_mode detection is properly integrated
        if not hasattr(sperm, 'detect_lecture_command'):
            print("Adding lecture mode detection to sperm_ileices.py...")
            
            # Define the new lecture command detection function
            def detect_lecture_command(user_input):
                """Detect if input contains lecture mode commands."""
                if hasattr(sperm, 'lecture_mode') and sperm.lecture_mode:
                    return sperm.lecture_mode.detect_lecture_command(user_input)
                return None
                
            # Add the function to the sperm module
            setattr(sperm, 'detect_lecture_command', detect_lecture_command)
        
        # Modify perceive_input to check for lecture commands
        original_perceive_input = sperm.perceive_input
        
        def enhanced_perceive_input(user_input):
            """Enhanced version of perceive_input that checks for lecture commands."""
            # Check for lecture mode commands
            lecture_command = None
            if hasattr(sperm, 'detect_lecture_command'):
                lecture_command = sperm.detect_lecture_command(user_input)
            
            if lecture_command and hasattr(sperm, 'lecture_mode') and sperm.lecture_mode:
                # If it's a lecture command, process it through lecture mode
                response = sperm.lecture_mode.process_lecture_input(user_input, lecture_command)
                if response:
                    # Store the response for direct use in generate_response
                    sperm.memory["current_lecture_response"] = response
            
            # Continue with normal perception
            return original_perceive_input(user_input)
        
        # Replace the original perceive_input with our enhanced version
        setattr(sperm, 'perceive_input', enhanced_perceive_input)
        
        # Now modify generate_response to check for lecture responses
        original_generate_response = sperm.generate_response
        
        def enhanced_generate_response(processed_data):
            """Enhanced version of generate_response that checks for lecture responses."""
            # Check if we have a lecture response to return
            if "current_lecture_response" in sperm.memory:
                response = sperm.memory["current_lecture_response"]
                del sperm.memory["current_lecture_response"]  # Clear it after use
                return response
            
            # Otherwise continue with normal response generation
            return original_generate_response(processed_data)
        
        # Replace the original generate_response with our enhanced version
        setattr(sperm, 'generate_response', enhanced_generate_response)
        
        # Make sure lecture_mode is available to the sperm module
        setattr(sperm, 'lecture_mode', lecture_mode)
        
        print("✓ Successfully integrated Enhanced Lecture Mode")
        return True
        
    except Exception as e:
        print(f"Error fixing lecture mode integration: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("AIOS IO Lecture Mode Integration Fix")
    success = fix_lecture_mode_integration()
    print(f"Integration fix {'successful' if success else 'failed'}")
