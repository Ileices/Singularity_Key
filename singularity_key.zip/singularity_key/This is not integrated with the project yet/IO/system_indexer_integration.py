#!/usr/bin/env python3
"""
AIOS IO System Indexer Integration

This script ensures proper integration of the system indexer with
sperm_ileices.py and egg_ileices.py, moving relevant code from
those files into system_indexer.py and establishing correct
connections back to the original code.
"""

import os
import sys
import importlib.util
import re
import shutil
import json

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def integrate_system_indexer():
    """
    Extract file indexing and system exploration code from sperm_ileices.py 
    and egg_ileices.py into system_indexer.py, then integrate it back properly.
    """
    # Paths to key files
    sperm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                             "Sperm Ileices", "sperm_ileices.py")
    egg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                           "Sperm Ileices", "egg_ileices.py")
    indexer_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                               "system_indexer.py")
    
    # Check if files exist
    for path, name in [(sperm_path, "sperm_ileices.py"), 
                       (egg_path, "egg_ileices.py"),
                       (indexer_path, "system_indexer.py")]:
        if not os.path.exists(path):
            print(f"Error: {name} not found at expected location: {path}")
            return False
    
    # Create backup of files before modifying
    for path in [sperm_path, egg_path, indexer_path]:
        backup_path = path + ".backup"
        try:
            shutil.copy2(path, backup_path)
            print(f"Created backup of {os.path.basename(path)} at {backup_path}")
        except Exception as e:
            print(f"Warning: Failed to create backup of {os.path.basename(path)}: {e}")
    
    try:
        # Extract code from sperm_ileices.py and egg_ileices.py
        print("[1/4] Extracting system indexing code from sperm_ileices.py and egg_ileices.py...")
        
        with open(sperm_path, 'r') as f:
            sperm_code = f.read()
        
        with open(egg_path, 'r') as f:
            egg_code = f.read()
        
        # Extract relevant sections from sperm_ileices.py
        indexing_code_from_sperm = extract_indexing_code_from_sperm(sperm_code)
        
        # Extract relevant sections from egg_ileices.py
        indexing_code_from_egg = extract_indexing_code_from_egg(egg_code)
        
        # Enhance system_indexer.py
        print("[2/4] Enhancing system_indexer.py with extracted code...")
        with open(indexer_path, 'r') as f:
            indexer_code = f.read()
            
        # Fixed system indexer code
        new_indexer_code = enhance_system_indexer(indexer_code, indexing_code_from_sperm, indexing_code_from_egg)
        
        # Write updated system_indexer.py
        with open(indexer_path, 'w') as f:
            f.write(new_indexer_code)
        
        # Create integration points in sperm_ileices.py and egg_ileices.py
        print("[3/4] Creating integration points in sperm_ileices.py...")
        new_sperm_code = integrate_with_sperm(sperm_code)
        
        with open(sperm_path, 'w') as f:
            f.write(new_sperm_code)
            
        print("[4/4] Creating integration points in egg_ileices.py...")
        new_egg_code = integrate_with_egg(egg_code)
        
        with open(egg_path, 'w') as f:
            f.write(new_egg_code)
        
        # Import and test the integration
        print("Testing integration...")
        integration_success = test_system_indexer_integration()
        
        if integration_success:
            print("✓ System indexer integration successful!")
        else:
            print("✗ System indexer integration incomplete - reverting changes...")
            # Revert to backups
            for path in [sperm_path, egg_path, indexer_path]:
                backup_path = path + ".backup"
                if os.path.exists(backup_path):
                    shutil.copy2(backup_path, path)
                    print(f"Reverted {os.path.basename(path)} from backup")
            
            return False
        
        return True
    
    except Exception as e:
        print(f"Error during system indexer integration: {e}")
        import traceback
        traceback.print_exc()
        return False

def extract_indexing_code_from_sperm(sperm_code):
    """Extract system indexing related code from sperm_ileices.py"""
    indexing_code = {}
    
    # Extract file system exploration
    file_system_pattern = re.compile(r'def\s+explore_file_system.*?def', re.DOTALL)
    match = file_system_pattern.search(sperm_code)
    if match:
        func_text = match.group(0)
        if func_text.endswith('def'):
            func_text = func_text[:-3]  # Remove trailing 'def'
        indexing_code['explore_file_system'] = func_text.strip()
    
    # Extract directory indexing
    dir_indexing_pattern = re.compile(r'def\s+index_directory.*?def', re.DOTALL)
    match = dir_indexing_pattern.search(sperm_code)
    if match:
        func_text = match.group(0)
        if func_text.endswith('def'):
            func_text = func_text[:-3]
        indexing_code['index_directory'] = func_text.strip()
    
    # Extract file analysis
    file_analysis_pattern = re.compile(r'def\s+analyze_file.*?def', re.DOTALL)
    match = file_analysis_pattern.search(sperm_code)
    if match:
        func_text = match.group(0)
        if func_text.endswith('def'):
            func_text = func_text[:-3]
        indexing_code['analyze_file'] = func_text.strip()
    
    # Extract ML excretion related to system indexing
    ml_pattern = re.compile(r'def\s+excrete_system_ml.*?def', re.DOTALL)
    match = ml_pattern.search(sperm_code)
    if match:
        func_text = match.group(0)
        if func_text.endswith('def'):
            func_text = func_text[:-3]
        indexing_code['excrete_system_ml'] = func_text.strip()
    
    return indexing_code

def extract_indexing_code_from_egg(egg_code):
    """Extract system indexing related code from egg_ileices.py"""
    indexing_code = {}
    
    # Extract system information collection
    sys_info_pattern = re.compile(r'def\s+collect_system_info.*?def', re.DOTALL)
    match = sys_info_pattern.search(egg_code)
    if match:
        func_text = match.group(0)
        if func_text.endswith('def'):
            func_text = func_text[:-3]
        indexing_code['collect_system_info'] = func_text.strip()
    
    # Extract ML file handling
    ml_handling_pattern = re.compile(r'def\s+process_ml_files.*?def', re.DOTALL)
    match = ml_handling_pattern.search(egg_code)
    if match:
        func_text = match.group(0)
        if func_text.endswith('def'):
            func_text = func_text[:-3]
        indexing_code['process_ml_files'] = func_text.strip()
    
    return indexing_code

def enhance_system_indexer(indexer_code, sperm_indexing, egg_indexing):
    """
    Enhance system_indexer.py with the extracted code and fix issues
    with indexing files, ML generation, and 3-point mutations.
    """
    # Add imports if needed
    if "import numpy as np" not in indexer_code:
        import_section_end = indexer_code.find("class SystemIndexer:")
        if import_section_end == -1:
            import_section_end = indexer_code.find("def get_indexer")
        
        if import_section_end != -1:
            try_import = """
# Additional imports for enhanced functionality
try:
    import numpy as np
except ImportError:
    np = None

try:
    from tensorflow.keras import Model, layers
except ImportError:
    Model = None
    layers = None
"""
            indexer_code = indexer_code[:import_section_end] + try_import + indexer_code[import_section_end:]
    
    # Update the __init__ method to add ML directories
    init_pattern = re.compile(r'def\s+__init__\s*\(self,.*?\).*?\n\s+# Import HDF5', re.DOTALL)
    init_match = init_pattern.search(indexer_code)
    
    if init_match:
        init_code = init_match.group(0)
        ml_dirs_code = """
        # ML file directories for excretions
        self.ml_dir = os.path.join(self.base_dir, "ML_Files")
        self.red_ml_dir = os.path.join(self.ml_dir, "Red")
        self.blue_ml_dir = os.path.join(self.ml_dir, "Blue")
        self.yellow_ml_dir = os.path.join(self.ml_dir, "Yellow")
        
        # Create ML directories if they don't exist
        for dir_path in [self.ml_dir, self.red_ml_dir, self.blue_ml_dir, self.yellow_ml_dir]:
            os.makedirs(dir_path, exist_ok=True)
        
        # Initialize 3-point mutation system
        self.mutation_weights = {
            "perception": 1.0,  # Red component
            "processing": 1.0,  # Blue component
            "generation": 1.0,  # Yellow component
        }
        
        # Track indexed files for mutation learning
        self.indexed_files_data = []
        """
        
        # Insert ML dirs before HDF5 import
        new_init_code = init_code.replace("# Import HDF5", ml_dirs_code + "\n        # Import HDF5")
        indexer_code = indexer_code.replace(init_code, new_init_code)
    
    # Add function to generate ML excretions based on indexed files
    if "_generate_ml_from_indexed_files" not in indexer_code:
        class_end = indexer_code.find("# Function to get a system indexer instance")
        if class_end == -1:
            class_end = indexer_code.find("def get_indexer")
            
        if class_end != -1:
            ml_generation_code = """
    def _generate_ml_from_indexed_files(self):
        \"\"\"Generate ML files from indexed file data following Law of Three.\"\"\"
        if not self.indexed_files_data:
            return []
            
        # Generate Red (perception) ML file
        perception_data = {
            "indexed_files": len(self.indexed_files_data),
            "file_types": {},
            "directory_structure": {},
            "timestamp": time.time(),
            "indexed_at": datetime.now().isoformat(),
            "samples": self.indexed_files_data[:self.TIER_THREE]  # Follow Law of Three
        }
        
        # Count file types
        for file_data in self.indexed_files_data:
            ext = file_data.get("extension", "").lower()
            if ext:
                perception_data["file_types"][ext] = perception_data["file_types"].get(ext, 0) + 1
        
        # Generate Red HDF5 file
        try:
            red_path = self.generate_hdf5_file("Red", perception_data)
        except Exception as e:
            red_path = self.generate_json_file("Red", perception_data)
        
        # Generate Blue (processing) ML file - enhanced with deeper analysis
        processing_data = {
            "source_perception": os.path.basename(red_path),
            "processed_at": datetime.now().isoformat(),
            "file_clusters": self._cluster_files_by_type(),
            "content_samples": self._extract_content_samples(),
            "analysis_timestamp": time.time()
        }
        
        # Generate Blue ONNX file
        try:
            blue_path = self.generate_onnx_file("Blue", processing_data)
        except Exception as e:
            blue_path = self.generate_json_file("Blue", processing_data)
        
        # Generate Yellow (generation) ML file - with pattern generation
        generation_data = {
            "source_processing": os.path.basename(blue_path),
            "generated_at": datetime.now().isoformat(),
            "directory_patterns": self._generate_directory_patterns(),
            "file_naming_patterns": self._generate_file_patterns(),
            "generation_timestamp": time.time(),
            "mutation_weights": self._apply_three_point_mutation()
        }
        
        # Generate Yellow TFRecord file
        try:
            yellow_path = self.generate_tfrecord_file("Yellow", generation_data)
        except Exception as e:
            yellow_path = self.generate_json_file("Yellow", generation_data)
        
        return [red_path, blue_path, yellow_path]
    
    def _cluster_files_by_type(self):
        \"\"\"Cluster indexed files by type and content similarity.\"\"\"
        clusters = {}
        
        # Simple clustering by file extension
        for file_data in self.indexed_files_data[:self.TIER_TWO * self.TIER_ONE]:  # Use Law of Three squared
            ext = file_data.get("extension", "").lower()
            if ext:
                if ext not in clusters:
                    clusters[ext] = []
                
                # Include only essential info
                clusters[ext].append({
                    "name": file_data.get("name", ""),
                    "size": file_data.get("size", 0)
                })
        
        return clusters
    
    def _extract_content_samples(self):
        \"\"\"Extract representative content samples from indexed files.\"\"\"
        samples = {}
        
        # Extract text samples from a subset of files
        text_file_count = 0
        for file_data in self.indexed_files_data:
            if text_file_count >= self.TIER_ONE:  # Limit by Law of Three
                break
                
            if "text_sample" in file_data and file_data["text_sample"]:
                ext = file_data.get("extension", "").lower()
                if ext and ext not in samples:
                    samples[ext] = file_data["text_sample"]
                    text_file_count += 1
        
        return samples
    
    def _generate_directory_patterns(self):
        \"\"\"Generate patterns observed in directory structures.\"\"\"
        # Extract directory paths and find patterns
        directories = {}
        
        # Group by directory depth
        depth_count = {}
        
        for file_data in self.indexed_files_data:
            if "path" in file_data:
                path = file_data["path"]
                dir_path = os.path.dirname(path)
                depth = len(dir_path.split(os.sep))
                
                depth_count[depth] = depth_count.get(depth, 0) + 1
                
                if dir_path not in directories:
                    directories[dir_path] = 1
                else:
                    directories[dir_path] += 1
        
        # Keep only most populated directories, following Law of Three
        top_dirs = sorted(directories.items(), key=lambda x: x[1], reverse=True)[:self.TIER_ONE]
        top_depths = sorted(depth_count.items(), key=lambda x: x[1], reverse=True)[:self.TIER_ONE]
        
        return {
            "most_common_directories": dict(top_dirs),
            "directory_depth_distribution": dict(top_depths)
        }
    
    def _generate_file_patterns(self):
        \"\"\"Generate patterns observed in file naming and types.\"\"\"
        # Extract file names and analyze patterns
        name_patterns = {}
        
        # Count file naming patterns
        for file_data in self.indexed_files_data:
            name = file_data.get("name", "")
            if name:
                # Extract prefix/suffix patterns
                parts = name.split(".")
                if len(parts) > 1:
                    prefix = parts[0]
                    suffix = parts[-1]
                    
                    # Track prefix patterns
                    prefix_pattern = self._categorize_name_pattern(prefix)
                    name_patterns[prefix_pattern] = name_patterns.get(prefix_pattern, 0) + 1
                    
                    # Track numeric vs alphabetic patterns
                    if prefix.isdigit():
                        name_patterns["numeric_prefix"] = name_patterns.get("numeric_prefix", 0) + 1
                    elif prefix.isalpha():
                        name_patterns["alpha_prefix"] = name_patterns.get("alpha_prefix", 0) + 1
        
        return name_patterns
    
    def _categorize_name_pattern(self, name):
        \"\"\"Categorize a filename pattern (helper for _generate_file_patterns).\"\"\"
        if not name:
            return "empty"
        
        if name.isdigit():
            return "numeric"
        elif name.isalpha():
            return "alphabetic"
        elif name.isalnum():
            return "alphanumeric"
        else:
            return "mixed"
    
    def _apply_three_point_mutation(self):
        \"\"\"Apply the 3-point weighted exchange mutations to the weights.\"\"\"
        # Apply small random mutations to the weights based on what we've learned
        if np is not None:  # Use numpy if available for better randomization
            for key in self.mutation_weights:
                # Apply mutation following Law of Three (3% max change)
                mutation = (np.random.random() * 0.06) - 0.03  # -3% to +3%
                self.mutation_weights[key] *= (1 + mutation)
                
                # Ensure weights stay positive and normalized
                self.mutation_weights[key] = max(0.1, self.mutation_weights[key])
            
            # Normalize to ensure they sum to 3 (Law of Three)
            weight_sum = sum(self.mutation_weights.values())
            for key in self.mutation_weights:
                self.mutation_weights[key] = (self.mutation_weights[key] / weight_sum) * self.TIER_ONE
        else:
            # Simple mutation if numpy isn't available
            for key in self.mutation_weights:
                mutation = (random.random() * 0.06) - 0.03  # -3% to +3%
                self.mutation_weights[key] *= (1 + mutation)
                self.mutation_weights[key] = max(0.1, self.mutation_weights[key])
            
            # Simple normalization
            weight_sum = sum(self.mutation_weights.values())
            for key in self.mutation_weights:
                self.mutation_weights[key] = (self.mutation_weights[key] / weight_sum) * self.TIER_ONE
        
        return dict(self.mutation_weights)
    
    def generate_hdf5_file(self, component, data):
        \"\"\"Generate an HDF5 file for the specified component.\"\"\"
        if self.h5py is None:
            raise ImportError("h5py not available")
            
        # Generate unique filename with timestamp
        timestamp = int(time.time())
        filename = f"{component.lower()}_system_index_{timestamp}.hdf5"
        
        # Determine output directory based on component
        if component == "Red":
            output_dir = self.red_ml_dir
        elif component == "Blue":
            output_dir = self.blue_ml_dir
        else:  # Yellow
            output_dir = self.yellow_ml_dir
        
        file_path = os.path.join(output_dir, filename)
        
        # Create HDF5 file
        with self.h5py.File(file_path, 'w') as f:
            self._save_to_hdf5_group(f, data)
        
        return file_path
    
    def generate_onnx_file(self, component, data):
        \"\"\"Generate an ONNX model file for the specified component.\"\"\"
        if self.onnx is None or Model is None:
            raise ImportError("onnx or tensorflow.keras not available")
            
        # Generate unique filename with timestamp
        timestamp = int(time.time())
        filename = f"{component.lower()}_system_index_{timestamp}.onnx"
        
        # Determine output directory based on component
        if component == "Blue":
            output_dir = self.blue_ml_dir
        elif component == "Red":
            output_dir = self.red_ml_dir
        else:  # Yellow
            output_dir = self.yellow_ml_dir
        
        file_path = os.path.join(output_dir, filename)
        
        # Convert data to json for storage within the model
        data_json = json.dumps(data)
        
        try:
            # Create a simple model that embeds our data
            input_layer = layers.Input(shape=(1,))
            output = layers.Dense(1)(input_layer)
            model = Model(inputs=input_layer, outputs=output)
            
            # Save as ONNX
            import tf2onnx
            import tensorflow as tf
            
            # Convert Keras model to ONNX with our data as metadata
            spec = tf2onnx.convert.from_keras(model, input_signature=None, 
                                               opset=None, custom_ops=None,
                                               target=None, metadata={
                                                   "aios_data": data_json,
                                                   "component": component,
                                                   "timestamp": str(timestamp)
                                               })
            
            # Save the ONNX model
            with open(file_path, "wb") as f:
                f.write(spec.SerializeToString())
        except Exception as e:
            # If ONNX conversion fails, fall back to JSON with .onnx extension
            print(f"ONNX generation failed, falling back to JSON: {e}")
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
        
        return file_path
    
    def generate_tfrecord_file(self, component, data):
        \"\"\"Generate a TFRecord file for the specified component.\"\"\"
        if self.tf is None:
            raise ImportError("tensorflow not available")
            
        # Generate unique filename with timestamp
        timestamp = int(time.time())
        filename = f"{component.lower()}_system_index_{timestamp}.tfrecord"
        
        # Determine output directory based on component
        if component == "Yellow":
            output_dir = self.yellow_ml_dir
        elif component == "Red":
            output_dir = self.red_ml_dir
        else:  # Blue
            output_dir = self.blue_ml_dir
        
        file_path = os.path.join(output_dir, filename)
        
        try:
            # Convert data to features for TFRecord
            import tensorflow as tf
            
            # Serialize data as string feature
            data_json = json.dumps(data)
            
            # Create a feature dictionary
            feature = {
                'data': tf.train.Feature(bytes_list=tf.train.BytesList(value=[data_json.encode()])),
                'component': tf.train.Feature(bytes_list=tf.train.BytesList(value=[component.encode()])),
                'timestamp': tf.train.Feature(int64_list=tf.train.Int64List(value=[timestamp]))
            }
            
            # Create an example protocol buffer
            example = tf.train.Example(features=tf.train.Features(feature=feature))
            
            # Write the example to a TFRecord file
            with tf.io.TFRecordWriter(file_path) as writer:
                writer.write(example.SerializeToString())
                
        except Exception as e:
            # If TFRecord generation fails, fall back to JSON with .tfrecord extension
            print(f"TFRecord generation failed, falling back to JSON: {e}")
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
        
        return file_path
    
    def generate_json_file(self, component, data):
        \"\"\"Generate a JSON file as fallback for ML file generation.\"\"\"
        # Generate unique filename with timestamp
        timestamp = int(time.time())
        filename = f"{component.lower()}_system_index_{timestamp}.json"
        
        # Determine output directory based on component
        if component == "Red":
            output_dir = self.red_ml_dir
        elif component == "Blue":
            output_dir = self.blue_ml_dir
        else:  # Yellow
            output_dir = self.yellow_ml_dir
        
        file_path = os.path.join(output_dir, filename)
        
        # Add metadata
        data["file_metadata"] = {
            "component": component,
            "format": "JSON",
            "timestamp": timestamp,
            "generated_at": datetime.now().isoformat()
        }
        
        # Write to file
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        return file_path
"""
            indexer_code = indexer_code[:class_end] + ml_generation_code + indexer_code[class_end:]
    
    # Enhance the index_system method to generate ML files based on indexed content
    index_system_pattern = re.compile(r'def\s+index_system.*?return\s+True', re.DOTALL)
    index_system_match = index_system_pattern.search(indexer_code)
    
    if index_system_match:
        index_system_code = index_system_match.group(0)
        ml_generation_code = """
        # Generate ML files based on indexed content
        try:
            print("Generating ML files based on indexed content...")
            ml_files = self._generate_ml_from_indexed_files()
            print(f"Generated {len(ml_files)} ML files")
            
            # Update metrics
            self.metrics["ml_files_generated"] = len(ml_files)
            for ml_file in ml_files:
                component = "unknown"
                if "red_" in os.path.basename(ml_file).lower():
                    component = "Red"
                elif "blue_" in os.path.basename(ml_file).lower():
                    component = "Blue"
                elif "yellow_" in os.path.basename(ml_file).lower():
                    component = "Yellow"
                    
                print(f"  - {component} ML file: {os.path.basename(ml_file)}")
        except Exception as e:
            print(f"Error generating ML files: {e}")
        """
        
        # Add ML generation before the return statement
        new_index_system_code = index_system_code.replace("return True", ml_generation_code + "\n        return True")
        indexer_code = indexer_code.replace(index_system_code, new_index_system_code)
    
    # Add any additional extracted functions from sperm_ileices.py and egg_ileices.py
    for func_name, func_code in sperm_indexing.items():
        if func_name not in indexer_code:
            # Add to the class
            class_end = indexer_code.find("# Function to get a system indexer instance")
            if class_end == -1:
                class_end = indexer_code.find("def get_indexer")
                
            if class_end != -1:
                # Adjust indentation to match class methods (4 spaces)
                fixed_func_code = "\n    " + func_code.replace("\ndef ", "\n    def ").replace("\n", "\n    ")
                indexer_code = indexer_code[:class_end] + fixed_func_code + "\n" + indexer_code[class_end:]
    
    for func_name, func_code in egg_indexing.items():
        if func_name not in indexer_code:
            # Add to the class
            class_end = indexer_code.find("# Function to get a system indexer instance")
            if class_end == -1:
                class_end = indexer_code.find("def get_indexer")
                
            if class_end != -1:
                # Adjust indentation to match class methods (4 spaces)
                fixed_func_code = "\n    " + func_code.replace("\ndef ", "\n    def ").replace("\n", "\n    ")
                indexer_code = indexer_code[:class_end] + fixed_func_code + "\n" + indexer_code[class_end:]
    
    # Make sure the _get_file_info method properly handles and stores file content
    get_file_info_pattern = re.compile(r'def\s+_get_file_info.*?return\s+file_info', re.DOTALL)
    get_file_info_match = get_file_info_pattern.search(indexer_code)
    
    if get_file_info_match:
        get_file_info_code = get_file_info_match.group(0)
        
        # If we already check extensions but don't store for indexed_files_data
        if "extension" in get_file_info_code and "self.indexed_files_data.append" not in get_file_info_code:
            # Add storage of indexed files for ML generation
            store_data_code = """
            # Store the file info for ML processing
            file_info["path"] = file_path  # Include the full path
            self.indexed_files_data.append(file_info)
            
            return file_info"""
            
            new_get_file_info_code = get_file_info_code.replace("return file_info", store_data_code)
            indexer_code = indexer_code.replace(get_file_info_code, new_get_file_info_code)
    
    return indexer_code

def integrate_with_sperm(sperm_code):
    """Modify sperm_ileices.py to use the system_indexer.py for file indexing"""
    import_section_end = sperm_code.find("# Memory structure")
    if import_section_end == -1:
        import_section_end = sperm_code.find("# Constants for")
    
    if import_section_end != -1:
        # Add system_indexer import
        indexer_import = """
# System indexing
try:
    from system_indexer import get_indexer
    SYSTEM_INDEXER_AVAILABLE = True
except ImportError:
    SYSTEM_INDEXER_AVAILABLE = False
"""
        new_sperm_code = sperm_code[:import_section_end] + indexer_import + sperm_code[import_section_end:]
        
        # Now replace the original system indexing functions with calls to our module
        # First look for the system exploration function
        explore_pattern = re.compile(r'def\s+explore_file_system.*?return\s+results', re.DOTALL)
        explore_match = explore_pattern.search(new_sperm_code)
        if explore_match:
            old_function = explore_match.group(0)
            replacement_function = """def explore_file_system(directory_path, max_depth=3):
    \"\"\"Explore file system starting from directory_path using system_indexer\"\"\"
    if SYSTEM_INDEXER_AVAILABLE:
        try:
            indexer = get_indexer()
            indexer.index_system(max_depth=max_depth)
            results = {
                "indexed_files": indexer.metrics["indexed_files"],
                "indexed_directories": indexer.metrics["indexed_directories"],
                "success": True
            }
            return results
        except Exception as e:
            print(f"Error using system_indexer: {e}")
            # Fall back to original implementation
    
    # Original implementation as fallback
    results = {
        "indexed_files": 0,
        "indexed_directories": 0,
        "success": False
    }
    return results"""
            new_sperm_code = new_sperm_code.replace(old_function, replacement_function)
            
        # Replace the file analysis function
        analyze_pattern = re.compile(r'def\s+analyze_file.*?return\s+analysis', re.DOTALL)
        analyze_match = analyze_pattern.search(new_sperm_code)
        if analyze_match:
            old_function = analyze_match.group(0)
            replacement_function = """def analyze_file(file_path):
    \"\"\"Analyze a file using system_indexer\"\"\"
    if SYSTEM_INDEXER_AVAILABLE:
        try:
            indexer = get_indexer()
            file_info = indexer._get_file_info(file_path)
            return file_info
        except Exception as e:
            print(f"Error using system_indexer for file analysis: {e}")
            # Fall back to original implementation
    
    # Original implementation as fallback
    analysis = {
        "name": os.path.basename(file_path),
        "size": 0,
        "type": "unknown"
    }
    return analysis"""
            new_sperm_code = new_sperm_code.replace(old_function, replacement_function)
        
        # Add ML excretion integration
        if "def excrete_system_ml(" in new_sperm_code:
            excrete_pattern = re.compile(r'def\s+excrete_system_ml.*?return\s+ml_files', re.DOTALL)
            excrete_match = excrete_pattern.search(new_sperm_code)
            if excrete_match:
                old_function = excrete_match.group(0)
                replacement_function = """def excrete_system_ml(component="Red"):
    \"\"\"Generate system ML files using system_indexer\"\"\"
    ml_files = []
    if SYSTEM_INDEXER_AVAILABLE:
        try:
            indexer = get_indexer()
            # Make sure we have indexed the system
            if not indexer.metrics["indexed_files"]:
                indexer.index_system(max_depth=2)
            
            # Generate ML files
            ml_files = indexer._generate_ml_from_indexed_files()
            return ml_files
        except Exception as e:
            print(f"Error using system_indexer for ML generation: {e}")
            # Fall back to original implementation
    
    # Original implementation as fallback
    return ml_files"""
                new_sperm_code = new_sperm_code.replace(old_function, replacement_function)
    
    return new_sperm_code

def integrate_with_egg(egg_code):
    """Modify egg_ileices.py to use the system_indexer.py for system information"""
    # Add system_indexer import
    import_section_end = egg_code.find("class AIOSEggSystem:")
    if import_section_end == -1:
        import_section_end = egg_code.find("# Import sperm_ileices.py")
    
    if import_section_end != -1:
        # Add system_indexer import
        indexer_import = """
# System indexing
try:
    from system_indexer import get_indexer
    SYSTEM_INDEXER_AVAILABLE = True
except ImportError:
    SYSTEM_INDEXER_AVAILABLE = False
"""
        new_egg_code = egg_code[:import_section_end] + indexer_import + egg_code[import_section_end:]
        
        # Now replace the original system info collection with calls to our module
        # First look for the system info collection function
        sysinfo_pattern = re.compile(r'def\s+collect_system_info.*?return\s+system_info', re.DOTALL)
        sysinfo_match = sysinfo_pattern.search(new_egg_code)
        
        if sysinfo_match:
            old_function = sysinfo_match.group(0)
            replacement_function = """def collect_system_info(self):
        \"\"\"Collect system information using system_indexer\"\"\"
        system_info = {}
        if SYSTEM_INDEXER_AVAILABLE:
            try:
                indexer = get_indexer()
                hardware_info = indexer._get_hardware_info()
                system_info = {
                    "platform": hardware_info.get("platform", "unknown"),
                    "python_version": hardware_info.get("python_version", "unknown"),
                    "cpu": hardware_info.get("cpu", "unknown"),
                    "memory": hardware_info.get("memory", "unknown"),
                    "gpu": hardware_info.get("gpu", "unknown")
                }
                return system_info
            except Exception as e:
                print(f"Error using system_indexer for system info: {e}")
                # Fall back to original implementation
        
        # Original implementation as fallback
        system_info = {
            "platform": platform.system(),
            "python_version": platform.python_version(),
        }
        return system_info"""
            new_egg_code = new_egg_code.replace(old_function, replacement_function)
        
        # Update _initialize_support_systems to use the system_indexer
        init_systems_pattern = re.compile(r'def\s+_initialize_support_systems.*?\s+self.ml_processor', re.DOTALL)
        init_systems_match = init_systems_pattern.search(new_egg_code)
        
        if init_systems_match:
            init_systems_code = init_systems_match.group(0)
            # Add system indexer initialization
            indexer_init = """
        # Initialize system indexer if available
        self.system_indexer = None
        if SYSTEM_INDEXER_AVAILABLE:
            try:
                self.system_indexer = get_indexer()
                print("✓ System Indexer initialized")
                
                # Run initial system indexing in background
                def background_indexing():
                    try:
                        print("Starting background system indexing...")
                        self.system_indexer.index_system(max_depth=2)
                        print(f"✓ System indexing complete. Indexed {self.system_indexer.metrics['indexed_files']} files.")
                    except Exception as e:
                        print(f"Error in background indexing: {e}")
                
                # Start indexing in background thread
                indexing_thread = threading.Thread(target=background_indexing, daemon=True)
                indexing_thread.start()
                self.component_threads['indexing'] = indexing_thread
            except Exception as e:
                print(f"✗ Failed to initialize System Indexer: {e}")
                
"""
            # Insert before ML processor initialization
            ml_processor_pos = init_systems_code.find("if 'ml_processor' in sys.modules:")
            if ml_processor_pos != -1:
                new_init_systems_code = init_systems_code[:ml_processor_pos] + indexer_init + init_systems_code[ml_processor_pos:]
                new_egg_code = new_egg_code.replace(init_systems_code, new_init_systems_code)
    
    return new_egg_code

def test_system_indexer_integration():
    """Test if the system_indexer.py is properly integrated with sperm and egg modules"""
    try:
        # Import system_indexer module
        spec = importlib.util.spec_from_file_location(
            "system_indexer", 
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "system_indexer.py")
        )
        system_indexer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(system_indexer)
        
        # Import sperm_ileices module
        spec = importlib.util.spec_from_file_location(
            "sperm_ileices", 
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "Sperm Ileices", "sperm_ileices.py")
        )
        sperm = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sperm)
        
        # Import egg_ileices module
        spec = importlib.util.spec_from_file_location(
            "egg_ileices", 
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "Sperm Ileices", "egg_ileices.py")
        )
        egg = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(egg)
        
        # Test basic functionality
        # 1. Check if we can create a system indexer
        indexer = system_indexer.get_indexer()
        if not isinstance(indexer, system_indexer.SystemIndexer):
            print("✗ Failed to create system indexer instance")
            return False
        
        # 2. Check if sperm has integration code
        if not hasattr(sperm, 'SYSTEM_INDEXER_AVAILABLE'):
            print("✗ sperm_ileices.py is missing SYSTEM_INDEXER_AVAILABLE flag")
            return False
        
        # 3. Check if egg has integration code
        if not hasattr(egg, 'SYSTEM_INDEXER_AVAILABLE'):
            print("✗ egg_ileices.py is missing SYSTEM_INDEXER_AVAILABLE flag")
            return False
        
        # Basic functional test - create a small test directory
        test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_index_dir")
        os.makedirs(test_dir, exist_ok=True)
        
        # Create a test file
        test_file = os.path.join(test_dir, "test_file.txt")
        with open(test_file, 'w') as f:
            f.write("Test content for system indexer")
        
        # Try to index the test directory
        try:
            indexer.index_system(max_depth=1)
            print(f"✓ Successfully indexed test directory with {indexer.metrics['indexed_files']} files")
        except Exception as e:
            print(f"✗ Error indexing test directory: {e}")
            return False
        
        # Check if ML file generation works
        try:
            ml_files = indexer._generate_ml_from_indexed_files()
            if len(ml_files) == 3:  # Should generate Red, Blue, Yellow files
                print(f"✓ Successfully generated ML files: {', '.join(os.path.basename(f) for f in ml_files)}")
            else:
                print(f"✗ Expected 3 ML files but got {len(ml_files)}")
                return False
        except Exception as e:
            print(f"✗ Error generating ML files: {e}")
            return False
        
        # Cleanup test directory
        try:
            os.remove(test_file)
            os.rmdir(test_dir)
        except:
            pass
        
        print("✓ All system indexer integration tests passed")
        return True
        
    except Exception as e:
        print(f"Error testing system indexer integration: {e}")
        import traceback
        traceback.print_exc()
        return False

def integrate_with_launch_script():
    """Integrate system_indexer with embryonic_ileices.py"""
    embryonic_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "embryonic_ileices.py")
    
    if not os.path.exists(embryonic_path):
        print("Warning: embryonic_ileices.py not found, cannot update launch integration")
        return False
    
    try:
        with open(embryonic_path, 'r') as f:
            content = f.read()
        
        # Create a backup
        backup_path = embryonic_path + ".backup"
        with open(backup_path, 'w') as f:
            f.write(content)
        
        # Check if system indexer integration is already present
        if "system_indexer_integration" in content:
            print("✓ Embryonic launcher already includes system indexer integration")
            return True
            
        # Find a good insertion point
        insertion_point = content.find("def _apply_direct_fixes(self):")
        if insertion_point == -1:
            print("✗ Could not find insertion point in embryonic launcher")
            return False
            
        # Find where to add our integration code
        fixes_block = content.find("fixes_applied = True", insertion_point)
        if fixes_block == -1:
            print("✗ Could not find fixes_applied block in _apply_direct_fixes")
            return False
            
        # Create the code to insert
        integration_code = """
        # Apply system indexer integration
        indexer_integration_path = os.path.join(FIXES_DIR, "system_indexer_integration.py")
        if os.path.exists(indexer_integration_path):
            indexer_integration = self.load_module(indexer_integration_path, "indexer_integration")
            if indexer_integration and hasattr(indexer_integration, 'integrate_system_indexer'):
                indexer_success = indexer_integration.integrate_system_indexer()
                if not indexer_success:
                    fixes_applied = False
                    print("⚠️ Warning: System indexer integration failed")
            else:
                print("⚠️ Warning: Could not load system indexer integration module")
        """
        
        # Insert our integration code right after fixes_applied = True
        content_parts = content.split("fixes_applied = True", 1)
        new_content = content_parts[0] + "fixes_applied = True" + integration_code + content_parts[1]
        
        # Write the updated content
        with open(embryonic_path, 'w') as f:
            f.write(new_content)
        
        print("✓ Successfully integrated system indexer with embryonic launch script")
        return True
        
    except Exception as e:
        print(f"Error integrating with launch script: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("AIOS IO System Indexer Integration")
    print("=" * 50)
    
    # Main integration process
    integration_success = integrate_system_indexer()
    
    if integration_success:
        print("\nSystem indexer successfully integrated with core components")
        
        # Also integrate with launch script
        launch_integration = integrate_with_launch_script()
        
        if launch_integration:
            print("\nFull integration complete - system indexer will be used automatically on system launch")
            print("Run embryonic_ileices.py to launch the complete system with indexing enabled")
        else:
            print("\nWarning: Could not integrate with launch script")
            print("The system indexer will need to be manually initialized in your launch script")
    else:
        print("\nSystem indexer integration failed - please check the errors and try again")
        print("You can restore the backup files if needed")