#!/usr/bin/env python3
"""
Singularity Fact Learning Module
--------------------------------
Extends fact learning capabilities with advanced integration across multiple systems.

Features:
- Enhanced fact learning that feeds the KnowledgeAPI
- Vector index integration for semantic search
- Cross-component fact propagation (periodic table, knowledge API, vector index)
- Thread-safe operations
- Comprehensive logging and error handling
- Performance metrics and health monitoring

This module serves as an integration layer to ensure facts learned by the system
are properly propagated to all relevant components.
"""

import logging
import threading
import time
import os
import json
import re
import pathlib
import sqlite3
import hashlib
from typing import Callable, Dict, List, Tuple, Any, Optional, Union, Pattern
from pathlib import Path
import warnings
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.fact_learning")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "facts_learned": 0,
    "facts_propagated": 0,
    "cache_hits": 0,
    "cache_misses": 0,
    "errors": 0
}

# Thread safety
_fact_learning_lock = threading.RLock()
_stats_lock = threading.RLock()
_initialized = False

# Global references to required components - populated during initialization
_glyph_id_function = None
_trifecta_function = None
_db_connection = None
_knowledge_api = None
_vector_index = None
_fact_patterns = []

# Base paths
_BASE = Path(__file__).parent.resolve()
_ECO = _BASE / "ecosystem"
_ECO.mkdir(exist_ok=True)

class FactLearningSystem:
    """
    Handles the learning and propagation of facts throughout the system.
    
    Integrates with:
    - Knowledge API
    - Vector Index
    - Periodic Table (axioms)
    - RBY system (trifecta)
    """
    
    def __init__(self, db_connection, glyph_id_func, trifecta_func, 
                 knowledge_api=None, vector_index=None, fact_patterns=None):
        """
        Initialize the FactLearningSystem.
        
        Args:
            db_connection: SQLite database connection
            glyph_id_func: Function to generate glyph IDs
            trifecta_func: Function for RBY update through trifecta
            knowledge_api: Knowledge API instance
            vector_index: Vector Index instance
            fact_patterns: Patterns used for fact extraction
        """
        self.db = db_connection
        self.cursor = db_connection.cursor()
        self.glyph_id = glyph_id_func
        self.trifecta = trifecta_func
        self.knowledge_api = knowledge_api
        self.vector_index = vector_index
        self.fact_patterns = fact_patterns or []
        self.lock = threading.RLock()
        self.fact_cache = {}  # Cache for recently processed facts
        
        logger.info("FactLearningSystem initialized")
    
    def learn_fact(self, line: str) -> bool:
        """
        Process a line of text to extract and learn any facts it contains.
        
        This is an enhanced version of the original _learn_fact function that:
        1. Extracts facts using registered patterns
        2. Stores them in the axiom table
        3. Feeds them to the Knowledge API
        4. Adds them to the Vector Index
        5. Updates the RBY system through trifecta
        
        Args:
            line: Line of text to process
            
        Returns:
            True if a fact was learned, False otherwise
        """
        try:
            with self.lock:
                # Check cache first for identical lines
                line_hash = hashlib.md5(line.encode()).hexdigest()
                if line_hash in self.fact_cache:
                    with _stats_lock:
                        _STATS["cache_hits"] += 1
                    return True
                
                with _stats_lock:
                    _STATS["cache_misses"] += 1
                
                fact_learned = False
                
                # Try each pattern to extract a fact
                for rx, fn in self.fact_patterns:
                    m = rx.match(line)
                    if not m:
                        continue
                    
                    try:
                        # Extract subject, predicate, object
                        subj, pred, obj = fn(m)
                        
                        # Generate a unique glyph ID for this fact
                        gid = self.glyph_id(f"{subj}|{pred}|{obj}".encode())
                        
                        # (a) Store triple in existing axiom table
                        with self.db:
                            self.db.execute(
                                "INSERT OR IGNORE INTO axiom(glyph,title,latex,definition) VALUES(?,?,?,?)",
                                (gid, pred, pred, f"{subj} {pred} {obj}")
                            )
                        
                        # (b) Feed KnowledgeAPI if available
                        if self.knowledge_api:
                            try:
                                self.knowledge_api.ingest_fact(subj, pred, obj, line)
                            except Exception as e:
                                logger.warning(f"Knowledge API ingestion failed: {e}")
                        
                        # (c) Feed VectorIndex if available
                        if self.vector_index:
                            try:
                                self.vector_index.add_doc(gid, line)
                            except Exception as e:
                                logger.warning(f"Vector index addition failed: {e}")
                        
                        # (d) Give RBY a nudge through trifecta
                        if self.trifecta:
                            try:
                                self.trifecta(line, weight=0.15)
                            except Exception as e:
                                logger.warning(f"Trifecta update failed: {e}")
                        
                        # Update cache
                        self.fact_cache[line_hash] = (subj, pred, obj)
                        
                        # Limit cache size
                        if len(self.fact_cache) > 1000:
                            # Remove oldest entries (approximately)
                            for _ in range(100):
                                self.fact_cache.pop(next(iter(self.fact_cache)), None)
                        
                        # Update statistics
                        with _stats_lock:
                            _STATS["facts_learned"] += 1
                            _STATS["facts_propagated"] += 1
                        
                        logger.debug(f"[fact-learn] {subj} |{pred}| {obj}")
                        fact_learned = True
                        break
                    
                    except Exception as e:
                        logger.error(f"Error processing fact pattern: {e}")
                        with _stats_lock:
                            _STATS["errors"] += 1
                
                return fact_learned
                
        except Exception as e:
            logger.error(f"Error in learn_fact: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False

    def learn_facts_from_text(self, text: str) -> int:
        """
        Process a block of text to extract and learn facts.
        
        Args:
            text: Text to process
            
        Returns:
            Number of facts learned
        """
        count = 0
        for line in text.split("\n"):
            if self.learn_fact(line):
                count += 1
        return count

    def learn_fact_tuple(self, subject: str, predicate: str, object_value: str, source: str = "api") -> bool:
        """
        Learn a fact from explicitly provided subject-predicate-object tuple.
        
        Args:
            subject: Subject of the fact
            predicate: Predicate relating subject to object
            object_value: Object of the fact
            source: Source of the fact
            
        Returns:
            True if the fact was learned, False otherwise
        """
        try:
            with self.lock:
                # Generate line representation
                line = f"{subject} {predicate} {object_value}"
                
                # Generate a unique glyph ID
                gid = self.glyph_id(f"{subject}|{predicate}|{object_value}".encode())
                
                # (a) Store triple in existing axiom table
                with self.db:
                    self.db.execute(
                        "INSERT OR IGNORE INTO axiom(glyph,title,latex,definition) VALUES(?,?,?,?)",
                        (gid, predicate, predicate, line)
                    )
                
                # (b) Feed KnowledgeAPI if available
                if self.knowledge_api:
                    try:
                        self.knowledge_api.ingest_fact(subject, predicate, object_value, source)
                    except Exception as e:
                        logger.warning(f"Knowledge API ingestion failed: {e}")
                
                # (c) Feed VectorIndex if available
                if self.vector_index:
                    try:
                        self.vector_index.add_doc(gid, line)
                    except Exception as e:
                        logger.warning(f"Vector index addition failed: {e}")
                
                # (d) Give RBY a nudge through trifecta
                if self.trifecta:
                    try:
                        self.trifecta(line, weight=0.15)
                    except Exception as e:
                        logger.warning(f"Trifecta update failed: {e}")
                
                # Update statistics
                with _stats_lock:
                    _STATS["facts_learned"] += 1
                    _STATS["facts_propagated"] += 1
                
                logger.debug(f"[fact-tuple] {subject} |{predicate}| {object_value}")
                return True
                
        except Exception as e:
            logger.error(f"Error in learn_fact_tuple: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False

# Global fact learning system instance
fact_learning_system = None

# ──────────────────────────────────────────────────────────────────────────
# Legacy compatibility wrapper for original _learn_fact function
# ──────────────────────────────────────────────────────────────────────────
def _learn_fact(line: str) -> None:
    """
    Enhanced version of the original _learn_fact function from singularity_boot.py.
    
    This function extracts facts from a line using registered patterns, stores them
    in the axiom table, feeds them to the Knowledge API, adds them to the Vector Index,
    and updates the RBY system through trifecta.
    
    Args:
        line: Line of text to process
    """
    global fact_learning_system
    
    if not fact_learning_system:
        logger.warning("Fact learning system not initialized - using legacy implementation")
        
        # Import original dependencies
        try:
            from singularity_boot import _FACT_PATTERNS, glyph_id, con, trifecta
            import logging as _log
            
            # Legacy implementation based on original code
            for rx, fn in _FACT_PATTERNS:
                m = rx.match(line)
                if not m:
                    continue
                
                subj, pred, obj = fn(m)
                
                # (a) store triple in existing table
                gid = glyph_id(f"{subj}|{pred}|{obj}".encode())
                with con:
                    con.execute("INSERT OR IGNORE INTO axiom(glyph,title,latex,definition) VALUES(?,?,?,?)",
                                (gid, pred, pred, f"{subj} {pred} {obj}"))
                
                # (b) feed KnowledgeAPI if it exists
                try:
                    from singularity_knowledge_api import β_kn
                    β_kn.ingest_fact(subj, pred, obj, line)
                except ImportError:
                    pass  # KnowledgeAPI not available
                
                # (c) feed VectorIndex if it exists
                try:
                    from singularity_vector_index import β_vdx
                    β_vdx.add_doc(gid, line)
                except ImportError:
                    pass  # VectorIndex not available
                
                # (d) give RBY a nudge
                trifecta(line, weight=0.15)
                _log.debug(f"[β-learn] {subj} |{pred}| {obj}")
                break
                
        except ImportError as e:
            logger.error(f"Legacy implementation failed: {e}")
    else:
        # Use the new implementation
        fact_learning_system.learn_fact(line)

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(db_connection=None, glyph_id_function=None, trifecta_function=None,
               knowledge_api=None, vector_index=None, fact_patterns=None):
    """
    Initialize the fact learning system.
    
    Args:
        db_connection: SQLite database connection
        glyph_id_function: Function to generate glyph IDs
        trifecta_function: Function for RBY update through trifecta
        knowledge_api: Knowledge API instance
        vector_index: Vector Index instance
        fact_patterns: Patterns used for fact extraction
        
    Returns:
        Initialized fact learning system instance
    """
    global fact_learning_system, _initialized
    global _glyph_id_function, _trifecta_function, _db_connection, _knowledge_api, _vector_index, _fact_patterns
    
    logger.info("Initializing fact learning system")
    
    # Store references to required components
    _glyph_id_function = glyph_id_function
    _trifecta_function = trifecta_function
    _db_connection = db_connection
    _knowledge_api = knowledge_api
    _vector_index = vector_index
    _fact_patterns = fact_patterns or []
    
    # Create fact learning system
    fact_learning_system = FactLearningSystem(
        db_connection=db_connection,
        glyph_id_func=glyph_id_function,
        trifecta_func=trifecta_function,
        knowledge_api=knowledge_api,
        vector_index=vector_index,
        fact_patterns=fact_patterns
    )
    
    _initialized = True
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Fact learning system initialized in {_STATS['init_time_ms']} ms")
    
    return fact_learning_system

def health_check() -> dict:
    """
    Perform a health check on the fact learning system.
    
    Returns:
        Dictionary with health status information
    """
    global fact_learning_system
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not fact_learning_system:
        status = "error"
        warnings.append("Fact learning system not initialized")
    else:
        try:
            # Get cache stats
            fact_cache_size = len(fact_learning_system.fact_cache)
            details["fact_cache_size"] = fact_cache_size
        except Exception as e:
            status = "error"
            warnings.append(f"Fact learning system error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "fact_learning",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the fact learning system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown():
    """
    Perform clean shutdown of fact learning system resources.
    """
    global fact_learning_system
    
    if fact_learning_system:
        logger.info("Shutting down fact learning system")
        # Nothing to clean up for now

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_fact_learning_status():
    """Command handler for /fact-learning-status"""
    if not fact_learning_system:
        print("Fact learning system not initialized")
        return
    
    health = health_check()
    
    print("\nFact Learning System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    if "fact_cache_size" in health["details"]:
        print(f"\nFact Cache Size: {health['details']['fact_cache_size']} entries")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

def _cmd_add_fact():
    """Command handler for /add-fact"""
    if not fact_learning_system:
        print("Fact learning system not initialized")
        return
    
    subject = input("Subject> ")
    predicate = input("Predicate> ")
    object_value = input("Object> ")
    source = input("Source (optional)> ")
    
    if not subject.strip() or not predicate.strip() or not object_value.strip():
        print("Subject, predicate, and object are required")
        return
    
    if fact_learning_system.learn_fact_tuple(subject, predicate, object_value, source or "user_input"):
        print("Fact added successfully")
    else:
        print("Failed to add fact")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'FactLearningSystem',
    '_learn_fact',
    'fact_learning_system',
    '_cmd_fact_learning_status',
    '_cmd_add_fact'
]
