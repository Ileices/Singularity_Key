#!/usr/bin/env python3
"""
Singularity RBY Helpers Module
-----------------------------
Provides core perceptive, cognitive, and executive functions for the Singularity organism.

Features:
- Thread-safe trifecta processing
- R,B,Y weight calculations
- Energy state management
- Glyph excretion for significant executions
- DNA and history tracking
- High-precision numerical handling

This module implements the fundamental trifecta (perception, cognition, execution) functions
that form the core of the Singularity organism's text processing capabilities.
"""
import threading
import logging
import time
import re
from pathlib import Path
from typing import Tuple, List, Dict, Any, Union, Optional, Callable

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.rby_helpers")

# Thread safety
_helper_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "trifecta_calls": 0,
    "perception_calls": 0,
    "cognition_calls": 0,
    "execution_calls": 0,
    "glyph_excretions": 0,
    "errors": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Dependencies
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False

# These will be set during initialization
_fnum_func = None           # _FNUM from singularity_precision
_rby_func = None            # rby from singularity_tokenweights or singularity_lexical
_glyph_id_func = None       # glyph_id from singularity_glyphs
_valid_glyph_func = None    # valid_glyph from singularity_glyphs
_log_excretion_func = None  # log_excretion from singularity_memory
_delta_e_func = None        # delta_E from singularity_energy
_dna = None                 # DNA from singularity_memory
_hist = None                # _HIST from singularity_memory
_energy = None              # ENERGY from singularity_memory

# Default R0, B0, Y0 values (these will be overridden during initialization)
R0 = 0.333333333333333333333333333333333333333333333333333333333333
B0 = 0.333333333333333333333333333333333333333333333333333333333333
Y0 = 0.333333333333333333333333333333333333333333333333333333333333

def initialize(fnum_function=None, rby_function=None, glyph_id_function=None,
              valid_glyph_function=None, log_excretion_function=None,
              delta_e_function=None, dna=None, hist=None, energy=None,
              r0=None, b0=None, y0=None):
    """
    Initialize the RBY helpers module with required functions and references.
    
    Args:
        fnum_function: High precision number conversion function
        rby_function: Token weight calculation function
        glyph_id_function: Glyph ID generation function
        valid_glyph_function: Glyph validation function
        log_excretion_function: Function to log excretions
        delta_e_function: Energy delta calculation function
        dna: Reference to DNA deque
        hist: Reference to _HIST deque
        energy: Reference to ENERGY variable
        r0, b0, y0: Default R, B, Y values
    """
    global _fnum_func, _rby_func, _glyph_id_func, _valid_glyph_func
    global _log_excretion_func, _delta_e_func, _dna, _hist, _energy
    global R0, B0, Y0, _initialized
    
    with _helper_lock:
        # Store function references
        _fnum_func = fnum_function
        _rby_func = rby_function
        _glyph_id_func = glyph_id_function
        _valid_glyph_func = valid_glyph_function
        _log_excretion_func = log_excretion_function
        _delta_e_func = delta_e_function
        
        # Store references to shared memory structures
        _dna = dna
        _hist = hist
        _energy = energy
        
        # Set default RBY values if provided
        if r0 is not None:
            R0 = r0
        if b0 is not None:
            B0 = b0
        if y0 is not None:
            Y0 = y0
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info("RBY helpers module initialized successfully")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Core RBY Helper Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _sum(txt, idx, default):
    """
    Helper function to sum RBY values at a specific index for all tokens in text.
    
    Args:
        txt: Text to process
        idx: Index of RBY tuple to sum (0=R, 1=B, 2=Y)
        default: Default value if sum is 0
        
    Returns:
        Sum of the specified RBY component across all tokens
    """
    if not _initialized or not _rby_func:
        logger.warning("RBY helpers module not initialized, using default value")
        return default
    
    try:
        # Calculate the sum of the specified RBY component for all tokens
        v = sum(_rby_func(t)[idx] for t in txt.split())
        
        # Return the sum, or default if sum is 0
        return v or default
    except Exception as e:
        logger.error(f"Error in _sum calculation: {e}")
        _metrics["errors"] += 1
        return default

def perception(t):
    """
    Calculate the perceptive (R) weight of text.
    
    Args:
        t: Text to process
        
    Returns:
        Perception (R) weight
    """
    with _helper_lock:
        _metrics["perception_calls"] += 1
        return _sum(t, 0, R0)

def cognition(t):
    """
    Calculate the cognitive (B) weight of text.
    
    Args:
        t: Text to process
        
    Returns:
        Cognition (B) weight
    """
    with _helper_lock:
        _metrics["cognition_calls"] += 1
        return _sum(t, 1, B0)

def execution(t):
    """
    Calculate the executive (Y) weight of text and log glyph if valid.
    
    Args:
        t: Text to process
        
    Returns:
        Execution (Y) weight
    """
    with _helper_lock:
        _metrics["execution_calls"] += 1
        
        # Calculate the Y weight
        y = _sum(t, 2, Y0)
        
        # Check if text encodes to a valid glyph, and if so, log as an excretion
        if _glyph_id_func and _valid_glyph_func and _log_excretion_func:
            try:
                gid = _glyph_id_func(t.encode())
                if _valid_glyph_func(gid):
                    _log_excretion_func(f"GLYPH {gid} {t[:40]}")
                    _metrics["glyph_excretions"] += 1
            except Exception as e:
                logger.error(f"Error in glyph handling: {e}")
                _metrics["errors"] += 1
        
        return y

def trifecta(text, weight=1.0):
    """
    Process text through the trifecta of perception, cognition, and execution.
    Updates DNA, history, and energy state.
    
    Args:
        text: Text to process
        weight: Weight multiplier for RBY values
        
    Returns:
        Tuple of (R, B, Y) weighted values
    """
    global _energy
    
    if not _initialized:
        logger.warning("RBY helpers module not initialized, using default trifecta")
        return (R0, B0, Y0)
    
    with _helper_lock:
        _metrics["trifecta_calls"] += 1
        
        try:
            # Convert weight to high precision if available
            w = _fnum_func(weight) if _fnum_func else weight
            
            # Calculate RBY values with weight
            r, b, y = perception(text) * w, cognition(text) * w, execution(text) * w
            
            # Update DNA and history if available
            if _dna is not None:
                _dna.append((r, b, y))
                
            if _hist is not None:
                _hist.append(r + b + y)
            
            # Update energy if available
            if _energy is not None and _delta_e_func is not None:
                try:
                    delta = _delta_e_func()
                    _energy += delta
                except Exception as e:
                    logger.error(f"Error updating energy: {e}")
                    _metrics["errors"] += 1
            
            return r, b, y
        except Exception as e:
            logger.error(f"Error in trifecta processing: {e}")
            _metrics["errors"] += 1
            return (R0, B0, Y0)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Monitoring and Health Check
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics():
    """
    Get performance metrics for RBY helpers.
    
    Returns:
        Dictionary of metrics
    """
    with _helper_lock:
        return _metrics.copy()

def health_check():
    """
    Perform health check for RBY helper functions.
    
    Returns:
        Dictionary with health status and metrics
    """
    if not _initialized:
        return {
            "status": "error",
            "message": "RBY helpers module not initialized",
            "metrics": {},
            "timestamp": time.time()
        }
    
    metrics = get_metrics()
    
    # Determine overall status
    if metrics["errors"] > 0:
        status = "warning"
        message = f"Encountered {metrics['errors']} errors in RBY processing"
    else:
        status = "healthy"
        message = "RBY helpers operating normally"
    
    # Check dependency health
    dependencies = {
        "rby_function": _rby_func is not None,
        "glyph_functions": _glyph_id_func is not None and _valid_glyph_func is not None,
        "excretion_function": _log_excretion_func is not None,
        "energy_function": _delta_e_func is not None,
        "memory_structures": _dna is not None and _hist is not None and _energy is not None
    }
    
    # If any dependency is missing, mark as warning
    if not all(dependencies.values()):
        status = "warning"
        message = "Some dependencies are missing"
    
    return {
        "status": status,
        "message": message,
        "metrics": metrics,
        "dependencies": dependencies,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject backward compatibility functions into target module.
    
    Args:
        target_module: Module to inject functions into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "perception": perception,
        "cognition": cognition,
        "execution": execution,
        "trifecta": trifecta
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_rby_helpers instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    
                    wrapper.__name__ = func.__name__
                    wrapper.__doc__ = func.__doc__
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Memory Management and Cleanup
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """
    Clean up resources used by the RBY helpers module.
    Should be called during application shutdown.
    """
    logger.info("RBY helpers module resources cleaned up")

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'perception',
    'cognition',
    'execution',
    'trifecta',
    'get_metrics',
    'health_check',
    'provide_backward_compatibility',
    'cleanup'
]

# Module self-test
if __name__ == "__main__":
    # Mock dependencies for stand-alone testing
    def mock_fnum(n):
        return float(n)
    
    def mock_rby(token):
        # Simple mock that returns different weights based on first letter
        if token.startswith(('a', 'e', 'i', 'o', 'u')):
            return (0.6, 0.3, 0.1)  # Perception-heavy
        elif token.startswith(('t', 'd', 's', 'c')):
            return (0.3, 0.6, 0.1)  # Cognition-heavy
        else:
            return (0.1, 0.2, 0.7)  # Execution-heavy
    
    def mock_glyph_id(b):
        import hashlib
        return f"⟐{hashlib.md5(b).hexdigest()[:16]}"
    
    def mock_valid_glyph(gid):
        # Consider glyphs valid if they start with ⟐
        return gid.startswith("⟐")
    
    def mock_log_excretion(msg):
        print(f"EXCRETION: {msg}")
    
    def mock_delta_e():
        return 0.01
    
    # Mock memory structures
    from collections import deque
    mock_dna = deque(maxlen=100)
    mock_hist = deque(maxlen=100)
    mock_energy = 1.0
    
    # Initialize with mocks
    initialize(
        fnum_function=mock_fnum,
        rby_function=mock_rby,
        glyph_id_function=mock_glyph_id,
        valid_glyph_function=mock_valid_glyph,
        log_excretion_function=mock_log_excretion,
        delta_e_function=mock_delta_e,
        dna=mock_dna,
        hist=mock_hist,
        energy=mock_energy
    )
    
    # Test basic RBY functions
    test_texts = [
        "apple banana",            # Starts with vowel (perception-heavy)
        "thought discussion",      # Starts with t/d (cognition-heavy)
        "perform work operation",  # Other (execution-heavy)
    ]
    
    print("\nTesting RBY functions:")
    for text in test_texts:
        p = perception(text)
        c = cognition(text)
        e = execution(text)
        print(f"'{text}':")
        print(f"  R: {p:.4f}, B: {c:.4f}, Y: {e:.4f}")
    
    # Test trifecta
    print("\nTesting trifecta:")
    for text in test_texts:
        r, b, y = trifecta(text)
        print(f"'{text}':")
        print(f"  R: {r:.4f}, B: {b:.4f}, Y: {y:.4f}")
    
    # Test trifecta with weight
    weight = 2.0
    print(f"\nTesting trifecta with weight {weight}:")
    for text in test_texts:
        r, b, y = trifecta(text, weight)
        print(f"'{text}':")
        print(f"  R: {r:.4f}, B: {b:.4f}, Y: {y:.4f}")
    
    # Test metrics
    metrics = get_metrics()
    print("\nMetrics:")
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    
    # Test health check
    health = health_check()
    print(f"\nHealth check: {health['status']}")
    print(f"Message: {health['message']}")
    print(f"Dependencies:")
    for key, value in health['dependencies'].items():
        print(f"  {key}: {'✓' if value else '✗'}")
    
    print("\nRBY helpers module self-test completed successfully.")
