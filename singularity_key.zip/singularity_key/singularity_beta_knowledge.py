#!/usr/bin/env python3
"""
Singularity Beta Knowledge Module
--------------------------------
Advanced knowledge representation and retrieval systems that integrate with the
Singularity organism's core functionality.

Features:
- Thread-safe persistent key-value store
- Vector-based similarity search for natural language
- Rule-based natural language generation
- Unified knowledge API for all Singularity components

This module enhances the organism with efficient storage and retrieval mechanisms,
enabling more sophisticated understanding and reasoning capabilities.
"""

import math as _βm
import itertools as _βit
import threading as _βth
import random as _βrnd
import pickle as _βpkl
import numpy as np
import time
import re
import os
import json
import hashlib
import logging
import sqlite3
import pathlib
from datetime import datetime
from collections import defaultdict as _βdd, Counter, deque
from pathlib import Path as _βPath
from typing import Dict, List, Tuple, Any, Optional, Union, Set, Callable

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.beta_knowledge")

# Module initialization time for performance metrics
_start_time = time.time()

# Module stats
_STATS = {
    "init_time_ms": 0,
    "kv_reads": 0,
    "kv_writes": 0,
    "vector_searches": 0,
    "nlg_generations": 0,
    "cache_hits": 0,
    "cache_misses": 0,
    "errors": 0,
}

# Thread safety
_kv_lock = _βth.RLock()
_vector_lock = _βth.RLock()
_nlg_lock = _βth.RLock()
_stats_lock = _βth.RLock()

# Base paths
_BASE = _βPath(__file__).parent.resolve()
_ECO = _BASE / "ecosystem"
_ECO.mkdir(exist_ok=True)
_BETA_DIR = _ECO / "beta"
_BETA_DIR.mkdir(exist_ok=True)
_VECTOR_DIR = _BETA_DIR / "vectors"
_VECTOR_DIR.mkdir(exist_ok=True)
_SCHEMA_DIR = _BETA_DIR / "schemas"
_SCHEMA_DIR.mkdir(exist_ok=True)

# ──────────────────────────────────────────────────────────────────────────
# 1. persistent KV store (uses _existing_ cursor/DB connection `con`)
# ──────────────────────────────────────────────────────────────────────────
class β_KVStore:
    """Ultra-thin key/value table (string→bytes)."""
    _INIT_SQL = "CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY,val BLOB)"
    def __init__(self, dbcon):
        self.cur = dbcon.cursor()
        self.cur.execute(self._INIT_SQL)
        self.lock = _βth.Lock()

    def __setitem__(self, k, v:bytes):
        with self.lock, self.cur.connection:
            self.cur.execute("INSERT OR REPLACE INTO kv(key,val) VALUES(?,?)",(k,v))
            with _stats_lock:
                _STATS["kv_writes"] += 1

    def __getitem__(self, k)->bytes:
        with _stats_lock:
            _STATS["kv_reads"] += 1
        row = self.cur.execute("SELECT val FROM kv WHERE key=?",(k,)).fetchone()
        if not row: raise KeyError(k)
        return row[0]

    def get(self, k, default=None):
        try: return self[k]
        except KeyError: return default

    def keys(self):
        return [r[0] for r in self.cur.execute("SELECT key FROM kv")]

    def items(self):
        return [(r[0], r[1]) for r in self.cur.execute("SELECT key, val FROM kv")]
    
    def delete(self, k):
        with self.lock, self.cur.connection:
            self.cur.execute("DELETE FROM kv WHERE key=?", (k,))
            return self.cur.rowcount > 0

    def count(self):
        return self.cur.execute("SELECT COUNT(*) FROM kv").fetchone()[0]

# ──────────────────────────────────────────────────────────────────────────
# 2. Vector indexing and similarity search
# ──────────────────────────────────────────────────────────────────────────
class β_VectorIndex:
    """
    Vector-based text similarity search.
    Uses sentence embeddings for fast retrieval of similar content.
    """
    def __init__(self, vector_dir=None, embedding_model=None):
        self.vector_dir = vector_dir or _VECTOR_DIR
        self.vector_dir.mkdir(exist_ok=True, parents=True)
        self.lock = _βth.RLock()
        self.cache = {}
        self.embedding_model = embedding_model
        self.index_path = self.vector_dir / "index.pkl"
        self.metadata_path = self.vector_dir / "metadata.json"
        self._load_or_initialize()
        
    def _load_or_initialize(self):
        """Load existing index or initialize a new one."""
        try:
            if self.index_path.exists() and self.metadata_path.exists():
                # Load existing index
                with self.index_path.open('rb') as f:
                    self.vectors = _βpkl.load(f)
                with self.metadata_path.open('r', encoding='utf-8') as f:
                    self.metadata = json.load(f)
                logger.info(f"Loaded vector index with {len(self.vectors)} entries")
            else:
                # Initialize new index
                self.vectors = []
                self.metadata = {"entries": [], "timestamps": [], "version": "1.0"}
                logger.info("Initialized new vector index")
        except Exception as e:
            logger.error(f"Error loading vector index: {e}. Initializing new one.")
            self.vectors = []
            self.metadata = {"entries": [], "timestamps": [], "version": "1.0"}
    
    def save(self):
        """Save the index to disk."""
        with self.lock:
            try:
                with self.index_path.open('wb') as f:
                    _βpkl.dump(self.vectors, f)
                with self.metadata_path.open('w', encoding='utf-8') as f:
                    json.dump(self.metadata, f)
                logger.info(f"Saved vector index with {len(self.vectors)} entries")
                return True
            except Exception as e:
                logger.error(f"Error saving vector index: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return False
    
    def add_text(self, text: str, metadata: dict = None) -> int:
        """
        Add text to the index.
        
        Args:
            text: The text to index
            metadata: Additional information about the text
            
        Returns:
            Index of the added text
        """
        if not self.embedding_model:
            logger.error("No embedding model available")
            with _stats_lock:
                _STATS["errors"] += 1
            return -1
        
        if not text:
            return -1
        
        # Generate embedding
        try:
            vector = self.embedding_model.encode(text)
            
            # Add to index
            with self.lock:
                idx = len(self.vectors)
                self.vectors.append(vector)
                self.metadata["entries"].append({
                    "text": text[:1000],  # Limit size for storage efficiency
                    "meta": metadata or {},
                    "idx": idx
                })
                self.metadata["timestamps"].append(time.time())
                
                # Save index periodically
                if idx % 100 == 0:
                    self.save()
                
                return idx
        except Exception as e:
            logger.error(f"Error adding text to vector index: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return -1
    
    def search(self, query: str, k: int = 5) -> List[Tuple[int, float, dict]]:
        """
        Search for similar texts.
        
        Args:
            query: The query text
            k: Number of results to return
            
        Returns:
            List of (idx, similarity, metadata) tuples
        """
        if not self.embedding_model or not self.vectors:
            return []
        
        with _stats_lock:
            _STATS["vector_searches"] += 1
        
        try:
            # Check cache first
            cache_key = f"{query}:{k}"
            with self.lock:
                if cache_key in self.cache:
                    with _stats_lock:
                        _STATS["cache_hits"] += 1
                    return self.cache[cache_key]
            
            with _stats_lock:
                _STATS["cache_misses"] += 1
            
            # Generate query embedding
            query_vec = self.embedding_model.encode(query)
            
            # Calculate similarities
            similarities = []
            with self.lock:
                for i, vec in enumerate(self.vectors):
                    sim = np.dot(query_vec, vec) / (np.linalg.norm(query_vec) * np.linalg.norm(vec))
                    similarities.append((i, float(sim), self.metadata["entries"][i]))
            
            # Sort by similarity
            results = sorted(similarities, key=lambda x: x[1], reverse=True)[:k]
            
            # Cache results
            with self.lock:
                self.cache[cache_key] = results
                if len(self.cache) > 1000:  # Limit cache size
                    self.cache.pop(next(iter(self.cache)))
            
            return results
        except Exception as e:
            logger.error(f"Error searching vector index: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return []

# ──────────────────────────────────────────────────────────────────────────
# 3. Rule-based Natural Language Generation
# ──────────────────────────────────────────────────────────────────────────
class β_NLG:
    """
    Rule-based natural language generation.
    Generates answers using templates and context.
    """
    def __init__(self):
        self.templates = {
            "definition": [
                "{subject} is defined as {definition}.",
                "{subject} refers to {definition}.",
                "The term '{subject}' means {definition}.",
                "In essence, {subject} is {definition}."
            ],
            "property": [
                "{subject} has {property} of {value}.",
                "The {property} of {subject} is {value}.",
                "{subject}'s {property} is {value}.",
                "Regarding {subject}, its {property} is {value}."
            ],
            "relation": [
                "{subject} {relation} {object}.",
                "{subject} is {relation} to {object}.",
                "There is a {relation} relationship between {subject} and {object}.",
                "The {relation} between {subject} and {object} is established."
            ],
            "unknown": [
                "I don't have specific information about {query}.",
                "I don't know about {query}.",
                "No information found regarding {query}.",
                "I can't provide details about {query} based on my knowledge."
            ]
        }
        self.lock = _βth.RLock()
    
    def add_template(self, category: str, template: str):
        """
        Add a new template for a category.
        
        Args:
            category: Template category (definition, property, etc.)
            template: The template string
        """
        with self.lock:
            if category not in self.templates:
                self.templates[category] = []
            self.templates[category].append(template)
    
    def generate(self, category: str, **kwargs) -> str:
        """
        Generate text using a template.
        
        Args:
            category: Template category
            **kwargs: Values to fill in the template
            
        Returns:
            Generated text
        """
        with _stats_lock:
            _STATS["nlg_generations"] += 1
        
        with self.lock:
            if category not in self.templates:
                category = "unknown"
            
            template = _βrnd.choice(self.templates[category])
            
            try:
                return template.format(**kwargs)
            except KeyError as e:
                logger.error(f"Missing key in template: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return f"Error generating response: missing {e}"
            except Exception as e:
                logger.error(f"Error generating text: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return "Error generating response."

# ──────────────────────────────────────────────────────────────────────────
# 4. Knowledge API: unified interface
# ──────────────────────────────────────────────────────────────────────────
class β_KnowledgeAPI:
    """
    Unified API for knowledge storage, retrieval, and generation.
    Integrates KV store, vector search, and NLG.
    """
    def __init__(self, kv_store=None, vector_index=None, nlg=None, embedding_model=None):
        self.kv = kv_store
        self.vector = vector_index
        self.nlg = nlg or β_NLG()
        self.embedding_model = embedding_model
        self.recent_queries = deque(maxlen=100)
        self.recent_answers = {}  # query_hash -> answer
        self.explanations = {}  # query_hash -> explanation
        self.max_context_items = 5
    
    def store(self, key: str, value: Any, metadata: dict = None) -> bool:
        """
        Store a key-value pair with optional metadata.
        Also adds to vector index if text.
        
        Args:
            key: The key
            value: The value (will be serialized)
            metadata: Optional metadata
            
        Returns:
            True if successful
        """
        if not self.kv:
            return False
        
        try:
            # Store in KV
            serialized = _βpkl.dumps(value)
            self.kv[key] = serialized
            
            # If it's text and we have vector capabilities, index it too
            if self.vector and self.embedding_model and isinstance(value, str):
                metadata = metadata or {}
                metadata["key"] = key
                self.vector.add_text(value, metadata)
            
            return True
        except Exception as e:
            logger.error(f"Error storing knowledge: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False
    
    def retrieve(self, key: str, default=None) -> Any:
        """
        Retrieve a value by key.
        
        Args:
            key: The key to look up
            default: Default value if not found
            
        Returns:
            The value, or default if not found
        """
        if not self.kv:
            return default
        
        try:
            serialized = self.kv.get(key)
            if serialized is None:
                return default
            return _βpkl.loads(serialized)
        except Exception as e:
            logger.error(f"Error retrieving knowledge: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return default
    
    def search_similar(self, query: str, k: int = 3) -> List[dict]:
        """
        Search for content similar to the query.
        
        Args:
            query: The search query
            k: Number of results to return
            
        Returns:
            List of content items with similarity scores
        """
        if not self.vector or not self.embedding_model:
            return []
        
        results = self.vector.search(query, k)
        return [
            {
                "text": item[2].get("text", ""),
                "similarity": item[1],
                "metadata": item[2].get("meta", {})
            }
            for item in results
        ]
    
    def answer(self, query: str) -> str:
        """
        Generate an answer to a query.
        Uses vector search for context and NLG for generation.
        
        Args:
            query: The question to answer
            
        Returns:
            Generated answer
        """
        # Create a hash for this query for tracking
        query_hash = hashlib.sha256(query.encode()).hexdigest()[:16]
        
        # Check if we've seen this exact query before
        if query_hash in self.recent_answers:
            return self.recent_answers[query_hash]
        
        # Get relevant context through vector search
        contexts = self.search_similar(query)
        
        # Track this query
        self.recent_queries.append({
            "query": query,
            "hash": query_hash,
            "time": time.time(),
            "contexts": contexts[:self.max_context_items]
        })
        
        # If we have no context, respond accordingly
        if not contexts:
            answer = self.nlg.generate("unknown", query=query)
            self.recent_answers[query_hash] = answer
            self.explanations[query_hash] = {"method": "unknown", "context": []}
            return answer
        
        # Extract information from contexts to use in answer generation
        subject = re.sub(r'[\W_]+', ' ', query).lower().split()
        subject = ' '.join([w for w in subject if len(w) > 2])[:30]
        
        # Use the best-matching context to form a response
        best_context = contexts[0]
        context_text = best_context["text"]
        
        # Try to determine relationship type from query
        if any(w in query.lower() for w in ["what is", "what's", "define", "meaning of"]):
            category = "definition"
            answer = self.nlg.generate(category, subject=subject, definition=context_text)
        elif any(w in query.lower() for w in ["property", "attribute", "feature", "characteristic"]):
            category = "property"
            # Try to extract property and value
            property_match = re.search(r'(?:what is|what\'s) the (\w+) of', query.lower())
            property_name = property_match.group(1) if property_match else "property"
            answer = self.nlg.generate(category, subject=subject, property=property_name, value=context_text)
        else:
            category = "relation"
            answer = self.nlg.generate(category, subject=subject, relation="relates", object=context_text)
        
        # Store the answer and explanation for future reference
        self.recent_answers[query_hash] = answer
        self.explanations[query_hash] = {
            "method": category,
            "context": [{"text": c["text"], "similarity": c["similarity"]} for c in contexts[:3]]
        }
        
        return answer
    
    def explain(self, query: str = None, query_hash: str = None) -> dict:
        """
        Explain how an answer was generated.
        
        Args:
            query: Original query (optional)
            query_hash: Hash of the query (optional)
            
        Returns:
            Dictionary with explanation
        """
        # If query is provided but not hash, compute hash
        if query and not query_hash:
            query_hash = hashlib.sha256(query.encode()).hexdigest()[:16]
        
        # If we have an explanation for this query, return it
        if query_hash in self.explanations:
            return self.explanations[query_hash]
        
        # If we don't have this query hash but have the query, try to generate an answer
        if query:
            self.answer(query)
            if query_hash in self.explanations:
                return self.explanations[query_hash]
        
        # If we still don't have an explanation
        return {
            "method": "unknown",
            "context": [],
            "note": "No explanation available for this query"
        }
    
    def recall(self, limit: int = 10) -> List[dict]:
        """
        Recall recent queries and answers.
        
        Args:
            limit: Maximum number of items to return
            
        Returns:
            List of recent query/answer pairs
        """
        items = []
        for query_item in list(self.recent_queries)[-limit:]:
            query_hash = query_item["hash"]
            items.append({
                "query": query_item["query"],
                "answer": self.recent_answers.get(query_hash, "No answer recorded"),
                "time": query_item["time"]
            })
        return items

# Global instance placeholder - will be initialized during setup
β_kv = None
β_vector = None
β_nlg = None
β_knowledge = None

# ──────────────────────────────────────────────────────────────────────────
# 5. Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(db_connection=None, embedding_model=None, config=None):
    """
    Initialize the Beta Knowledge system.
    
    Args:
        db_connection: SQLite connection to use for KV store
        embedding_model: SentenceTransformer model for vector search
        config: Configuration dictionary
        
    Returns:
        Initialized β_KnowledgeAPI instance
    """
    global β_kv, β_vector, β_nlg, β_knowledge
    
    logger.info("Initializing Beta Knowledge system")
    
    # If no connection provided, create our own
    if not db_connection:
        beta_db_path = _BETA_DIR / "beta_knowledge.db"
        db_connection = sqlite3.connect(str(beta_db_path), check_same_thread=False)
    
    # Initialize components
    β_kv = β_KVStore(db_connection)
    β_nlg = β_NLG()
    
    # Only initialize vector search if embedding model is provided
    if embedding_model:
        β_vector = β_VectorIndex(_VECTOR_DIR, embedding_model)
    else:
        β_vector = None
        logger.warning("No embedding model provided, vector search will be unavailable")
    
    # Create unified API
    β_knowledge = β_KnowledgeAPI(β_kv, β_vector, β_nlg, embedding_model)
    
    # Update initialization timing metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Beta Knowledge system initialized in {_STATS['init_time_ms']} ms")
    
    return β_knowledge

def health_check() -> dict:
    """
    Perform a health check on the Beta Knowledge system.
    
    Returns:
        Dictionary with health status information
    """
    global β_kv, β_vector, β_nlg, β_knowledge
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check KV store
    if not β_kv:
        status = "error"
        warnings.append("KV store not initialized")
    else:
        try:
            kv_count = β_kv.count()
            details["kv_count"] = kv_count
        except Exception as e:
            status = "error"
            warnings.append(f"KV store error: {e}")
    
    # Check vector index
    if not β_vector:
        warnings.append("Vector index not available")
    elif not hasattr(β_vector, 'vectors') or not β_vector.vectors:
        warnings.append("Vector index is empty")
    else:
        details["vector_count"] = len(β_vector.vectors)
    
    # Check knowledge API
    if not β_knowledge:
        status = "error"
        warnings.append("Knowledge API not initialized")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "beta_knowledge",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the Beta Knowledge system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown():
    """
    Perform clean shutdown of Beta Knowledge resources.
    """
    global β_vector
    
    logger.info("Shutting down Beta Knowledge system")
    
    # Save vector index if it exists
    if β_vector:
        β_vector.save()

# Automatic cleanup
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# 6. Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_ask(query=None):
    """Command handler for /ask"""
    if not β_knowledge:
        print("Beta Knowledge system not initialized")
        return
    
    if query is None:
        query = input("Question> ")
    
    if not query.strip():
        print("Please enter a question")
        return
    
    answer = β_knowledge.answer(query)
    print(f"\n{answer}\n")

def _cmd_why():
    """Command handler for /why - explain last answer"""
    if not β_knowledge:
        print("Beta Knowledge system not initialized")
        return
    
    recent = list(β_knowledge.recent_queries)
    if not recent:
        print("No recent queries to explain")
        return
    
    last_query = recent[-1]
    query_hash = last_query["hash"]
    explanation = β_knowledge.explain(query_hash=query_hash)
    
    print(f"\nExplanation for: {last_query['query']}")
    print(f"Method: {explanation['method']}")
    
    if explanation["context"]:
        print("\nContext used:")
        for i, ctx in enumerate(explanation["context"], 1):
            print(f"{i}. Similarity: {ctx['similarity']:.4f}")
            print(f"   Text: {ctx['text'][:100]}...")
    else:
        print("\nNo context was used to generate the answer.")

def _cmd_recall():
    """Command handler for /recall - show recent Q&A history"""
    if not β_knowledge:
        print("Beta Knowledge system not initialized")
        return
    
    recent = β_knowledge.recall()
    if not recent:
        print("No recent queries to recall")
        return
    
    print("\nRecent Questions and Answers:")
    for i, item in enumerate(recent, 1):
        timestamp = datetime.fromtimestamp(item["time"]).strftime("%H:%M:%S")
        print(f"\n{i}. [{timestamp}] Q: {item['query']}")
        print(f"   A: {item['answer']}")

def _cmd_beta_status():
    """Command handler for /beta-status - show system status"""
    if not β_knowledge:
        print("Beta Knowledge system not initialized")
        return
    
    health = health_check()
    
    print("\nBeta Knowledge System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")
    
    if "kv_count" in health.get("details", {}):
        print(f"\nKV Store entries: {health['details']['kv_count']}")
    
    if "vector_count" in health.get("details", {}):
        print(f"Vector index entries: {health['details']['vector_count']}")
    
    if β_knowledge:
        print(f"Recent queries: {len(β_knowledge.recent_queries)}")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'β_KVStore',
    'β_VectorIndex',
    'β_NLG',
    'β_KnowledgeAPI',
    '_cmd_ask',
    '_cmd_why',
    '_cmd_recall',
    '_cmd_beta_status'
]
