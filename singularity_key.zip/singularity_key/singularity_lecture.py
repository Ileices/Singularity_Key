#!/usr/bin/env python3
"""
Singularity Lecture Module
-------------------------
Handles lecture mode processing and text ingestion with RBY evaluation.

Features:
- Thread-safe lecture processing
- RBY scoring of ingested text
- Automatic fact extraction
- Integration with neural corpus and glyph system
- Cross-platform text handling with proper encoding

This module serves as the primary knowledge ingestion system for the Singularity
organism, converting text into properly weighted RBY values and extracting
structured facts for long-term storage.
"""
import os
import re
import time
import json
import threading
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union, Set, Callable
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.lecture")

# Thread safety
_lecture_lock = threading.RLock()
_last_lecture_time = 0
_startup_time = time.time()

# Performance metrics
_metrics = {
    "lectures_processed": 0,
    "total_tokens_processed": 0,
    "facts_extracted": 0,
    "processing_time_ms": 0,
    "errors": 0
}

# Import from other Singularity modules with proper fallback handling
try:
    from singularity_config import CFG
    from singularity_precision import _FNUM, R0, B0, Y0
    from singularity_glyphs import glyph_id
except ImportError:
    # Fallback for standalone testing
    import yaml
    from decimal import Decimal, getcontext
    getcontext().prec = 60
    
    BASE = Path(__file__).parent.resolve()
    config_path = BASE / "singularity_config.yml"
    
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            CFG = yaml.safe_load(f)
    else:
        CFG = {"high_precision_mode": True}
    
    _FNUM = Decimal if CFG.get("high_precision_mode", True) else float
    R0 = B0 = Y0 = _FNUM("0.333333333333333333333333333333333333333333333333333333333333")
    
    def glyph_id(b):
        import hashlib
        return f"⟐{hashlib.blake2b(b, digest_size=8).hexdigest()}"

try:
    from neural_engine import push_into_corpus
except ImportError:
    def push_into_corpus(text, source):
        logger.warning("neural_engine.push_into_corpus not available")

# Lecture mode markers
_LECTURE_ON = ["<BEGIN LECTURE>", "```lecture", "```block"]
_LECTURE_OFF = ["<END LECTURE>", "```", "</lecture>"]

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Lecture Processing
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _γ_consume_block(lines: str, seq: int = 0) -> Tuple[_FNUM, _FNUM, _FNUM]:
    """
    Process a block of text, accumulating RBY values.
    
    Args:
        lines: The text to process
        seq: Sequence number for logging/tracking
        
    Returns:
        Tuple of (r_tot, b_tot, y_tot) values
    """
    global _metrics
    
    start_time = time.time()
    
    with _lecture_lock:
        tokens = _tokenize_text(lines)
        num_tokens = len(tokens)
        
        r_tot = b_tot = y_tot = _FNUM(0)
        facts_extracted = 0
        
        for i, token in enumerate(tokens):
            # Get RBY values for this token
            r, b, y = _compute_token_rby(token)
            
            # Apply appropriate weight based on token type
            r_tot += r
            b_tot += b
            y_tot += y
            
            # Fact extraction (sample every 5th token as a potential subject)
            if i % 5 == 0 and i + 2 < num_tokens:
                try:
                    subject = tokens[i]
                    predicate = tokens[i+1]
                    object_token = tokens[i+2]
                    
                    # Check if this looks like a valid fact
                    if _is_potential_fact(subject, predicate, object_token):
                        _learn_fact(subject, predicate, object_token)
                        facts_extracted += 1
                except Exception as e:
                    logger.debug(f"Fact extraction error: {e}")
        
        # Update metrics
        _metrics["lectures_processed"] += 1
        _metrics["total_tokens_processed"] += num_tokens
        _metrics["facts_extracted"] += facts_extracted
        _metrics["processing_time_ms"] += (time.time() - start_time) * 1000
        
        # Push to neural corpus for training
        try:
            push_into_corpus(lines, source=f"lecture_{seq:04d}")
        except Exception as e:
            logger.error(f"Error pushing to corpus: {e}")
            _metrics["errors"] += 1
        
        # Log the results
        logger.info(f"[lecture absorbed] tokens={num_tokens}  R={r_tot:.3f} B={b_tot:.3f} Y={y_tot:.3f}")
        
        return r_tot, b_tot, y_tot

# Token processing functions
def _tokenize_text(text: str) -> List[str]:
    """Split text into tokens using simple rules."""
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Split on spaces and punctuation
    tokens = []
    for word in text.split():
        # Extract any punctuation at the end
        match = re.match(r'(.*?)([,.!?;:]*)$', word)
        if match:
            word_part, punct_part = match.groups()
            if word_part:
                tokens.append(word_part)
            if punct_part:
                tokens.append(punct_part)
        else:
            tokens.append(word)
    
    return tokens

def _compute_token_rby(token: str) -> Tuple[_FNUM, _FNUM, _FNUM]:
    """Compute RBY values for a token based on its characteristics."""
    # Determine token class based on simple rules
    token_class = _classify_token(token)
    
    # Get weights from config
    token_weights = CFG.get("token_weights", {})
    weights = token_weights.get(token_class)
    
    if weights:
        return _FNUM(weights[0]), _FNUM(weights[1]), _FNUM(weights[2])
    
    # Use baseline if no specific weights
    return R0, B0, Y0

def _classify_token(token: str) -> str:
    """Classify a token into a category for RBY weighting."""
    if token in ["if", "then", "else", "for", "while", "def", "class"]:
        return "imperative"
    elif token in ["may", "might", "could", "would", "should"]:
        return "modal"
    elif token in ["not", "no", "never", "none"]:
        return "negation"
    elif token in [".", ";", ":", "!", "?"]:
        return "punct_exec"
    elif token.isupper() and len(token) >= 2:
        return "acronym"
    elif token[0:1].isupper() and len(token) > 1:
        return "proper_noun"
    elif token.isalpha() and len(token) > 2:
        return "noun"
    else:
        return "glue"

def _is_potential_fact(subject: str, predicate: str, obj: str) -> bool:
    """
    Check if three consecutive tokens might form a valid fact.
    Very simplified heuristic for demonstration.
    """
    # Simple check: subject should be a noun, object should not be punctuation
    return (
        _classify_token(subject) in ["noun", "proper_noun", "acronym"] and
        len(predicate) > 1 and
        not obj in [".", ",", "!", "?", ";", ":"]
    )

def _learn_fact(subject: str, predicate: str, obj: str) -> None:
    """
    Learn a potential fact from three tokens.
    
    In a real implementation, this would be connected to the 
    knowledge graph or fact storage system.
    """
    # This is just a stub - in the real system, it would call back to
    # the main organism's fact learning mechanism
    logger.debug(f"Learned fact: {subject} {predicate} {obj}")
    
    # The actual implementation would call:
    # _persist_fact(subject, predicate, obj)
    pass

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Public API for Lecture Processing
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def process_lecture_text(text: str, seq: int = 0) -> Tuple[_FNUM, _FNUM, _FNUM]:
    """
    Process text in lecture mode, updating the RBY values and extracting facts.
    This is the main entry point for lecture processing.
    
    Args:
        text: The lecture text to process
        seq: Sequence number for tracking
        
    Returns:
        Tuple of (r_tot, b_tot, y_tot) after processing
    """
    return _γ_consume_block(text, seq)

def is_lecture_start(line: str) -> bool:
    """Check if a line marks the beginning of a lecture block."""
    return any(marker in line for marker in _LECTURE_ON)

def is_lecture_end(line: str) -> bool:
    """Check if a line marks the end of a lecture block."""
    return any(marker in line for marker in _LECTURE_OFF)

def get_lecture_metrics() -> Dict[str, Union[int, float]]:
    """Get metrics about lecture processing."""
    with _lecture_lock:
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """Perform a health check on the lecture subsystem."""
    status = "healthy"
    details = {}
    
    # Check if we've seen any errors
    if _metrics["errors"] > 0:
        status = "degraded"
        details["error_count"] = _metrics["errors"]
    
    # Check if we're processing text at a reasonable rate
    avg_time = (_metrics["processing_time_ms"] / _metrics["lectures_processed"]) if _metrics["lectures_processed"] > 0 else 0
    if avg_time > 5000:  # More than 5 seconds per lecture
        status = status if status == "degraded" else "warning"
        details["high_processing_time"] = f"{avg_time:.2f} ms per lecture"
    
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_γ_consume_block": _γ_consume_block,
        "_LECTURE_ON": _LECTURE_ON,
        "_LECTURE_OFF": _LECTURE_OFF
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # Add deprecation warning wrapper for functions
            if callable(value):
                original = getattr(target_module, name)
                
                @functools.wraps(original)
                def wrapper(*args, **kwargs):
                    warnings.warn(
                        f"Accessing {name} from {target_module.__name__} is deprecated. "
                        f"Import from singularity_lecture instead.",
                        DeprecationWarning, 2
                    )
                    return original(*args, **kwargs)
                
                setattr(target_module, name, wrapper)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Clean Shutdown
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _cleanup():
    """Clean up resources when module is shutting down."""
    logger.info(f"Lecture module shutting down, processed {_metrics['lectures_processed']} lectures")
    # No specific cleanup needed for this module, but good practice to have this

# Register cleanup handler
import atexit
import functools
atexit.register(_cleanup)

# Module self-test
if __name__ == "__main__":
    print(f"Testing {__file__}")
    
    sample_text = """
    This is a sample lecture about Python programming.
    Python is an interpreted language that emphasizes readability.
    It supports multiple programming paradigms including procedural, 
    object-oriented, and functional programming.
    """
    
    r, b, y = process_lecture_text(sample_text, 999)
    print(f"Sample lecture processed with RBY: R={r}, B={b}, Y={y}")
    print(f"Metrics: {get_lecture_metrics()}")
