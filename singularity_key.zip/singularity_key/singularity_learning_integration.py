#!/usr/bin/env python3
"""
Singularity Learning Integration Module (Module γ)
-------------------------------------------------
Integrates all input streams into the knowledge API and neural systems for comprehensive learning.

Features:
- Enhanced _consume_block that feeds input to neural systems and fact learning
- Remote embedding and vector storage of lecture content
- Neural corpus integration for continuous learning
- Distributed learning across cluster nodes
- Comprehensive error handling and recovery
- Thread-safe operations

This module serves as the glue between input streams and the various learning systems,
ensuring that all knowledge is properly processed, stored, and integrated.
"""

import os
import sys
import time
import logging
import threading
import gzip as _γgz
import psutil as _γps
import functools as _γft
from datetime import datetime as _γnow
from pathlib import Path
from typing import Callable, Dict, Any, List, Optional, Union

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.learning_integration")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "blocks_consumed": 0,
    "neural_ingests": 0,
    "remote_calls": 0,
    "facts_learned": 0,
    "errors": 0,
    "distributed_learning_events": 0
}

# Thread safety
_stats_lock = threading.RLock()
_consume_lock = threading.RLock()

# Original function references - populated during initialization
_original_consume_block = None
_trifecta_function = None
_neuro_ingest_function = None
_remote_call_function = None
_push_into_corpus_function = None
_learn_fact_function = None
_logger = None

class LearningIntegrationSystem:
    """
    Integrates various learning systems to ensure comprehensive knowledge acquisition.
    
    This class handles the coordination between different learning mechanisms:
    - Traditional RBY-based trifecta learning
    - Neural embedding and storage
    - Fact pattern extraction and learning
    - Corpus-based training data accumulation
    """
    
    def __init__(
        self,
        original_consume_block=None,
        trifecta_function=None,
        neuro_ingest_function=None,
        remote_call_function=None,
        push_into_corpus_function=None,
        learn_fact_function=None,
        logger=None
    ):
        """
        Initialize the learning integration system.
        
        Args:
            original_consume_block: Original consume block function
            trifecta_function: Function for RBY-based learning
            neuro_ingest_function: Function for neural ingestion
            remote_call_function: Function for remote procedure calls
            push_into_corpus_function: Function for corpus integration
            learn_fact_function: Function for fact learning
            logger: Logger instance
        """
        self.original_consume = original_consume_block
        self.trifecta = trifecta_function
        self.neuro_ingest = neuro_ingest_function
        self.remote_call = remote_call_function
        self.push_into_corpus = push_into_corpus_function
        self.learn_fact = learn_fact_function
        self.logger = logger or logging.getLogger("singularity.learning_integration")
        
        # Thread safety
        self.lock = threading.RLock()
        
        logger.info("LearningIntegrationSystem initialized")
        
    def consume_block(self, lines: str, seq: int) -> None:
        """
        Enhanced block consumption that integrates all learning mechanisms.
        
        This function extends the original _consume_block by adding:
        1. Neural embedding and storage
        2. Remote call for distributed cluster learning
        3. Corpus integration for transformer training
        4. Fact learning per sentence
        
        Args:
            lines: Text block to consume
            seq: Sequence number for the block
        """
        try:
            with self.lock:
                # Call original consume block (handles ENERGY, RBY, idf, etc.)
                if self.original_consume:
                    try:
                        self.original_consume(lines, seq)
                    except Exception as e:
                        self.logger.error(f"Error in original_consume_block: {e}")

                # 1. Neural embedding and storage
                if self.neuro_ingest:
                    try:
                        self.neuro_ingest(lines, tag=f"lecture_{seq:04d}")
                        with _stats_lock:
                            _STATS["neural_ingests"] += 1
                    except Exception as e:
                        self.logger.error(f"Error in neuro_ingest: {e}")
                        with _stats_lock:
                            _STATS["errors"] += 1

                # 2. Remote call for distributed cluster learning
                if self.remote_call:
                    try:
                        self.remote_call("organism_neuro.embed_and_store", lines, f"lecture_{seq:04d}")
                        with _stats_lock:
                            _STATS["remote_calls"] += 1
                            _STATS["distributed_learning_events"] += 1
                    except Exception as e:
                        self.logger.error(f"Error in remote_call: {e}")
                        with _stats_lock:
                            _STATS["errors"] += 1

                # 3. Corpus integration for transformer training
                if self.push_into_corpus:
                    try:
                        self.push_into_corpus(lines, source=f"lecture_{seq}")
                    except Exception as e:
                        self.logger.error(f"Error in push_into_corpus: {e}")
                        with _stats_lock:
                            _STATS["errors"] += 1

                # 4. Fact learning per sentence
                if self.learn_fact:
                    facts_learned = 0
                    for ln in lines.splitlines():
                        if ln.strip():
                            try:
                                self.learn_fact(ln.strip())
                                facts_learned += 1
                            except Exception as e:
                                self.logger.error(f"Error in learn_fact: {e}")
                                with _stats_lock:
                                    _STATS["errors"] += 1
                    
                    with _stats_lock:
                        _STATS["facts_learned"] += facts_learned

                with _stats_lock:
                    _STATS["blocks_consumed"] += 1
                
                self.logger.info(f"Processed lecture block {seq} through all learning systems")
                
        except Exception as e:
            self.logger.error(f"Error in consume_block: {e}")
            with _stats_lock:
                _STATS["errors"] += 1

# Global learning integration system instance
learning_integration = None

# ──────────────────────────────────────────────────────────────────────────
# Public API: Enhanced _consume_block function for learning integration
# ──────────────────────────────────────────────────────────────────────────
def _γ_consume_block(lines: str, seq: int) -> None:
    """
    Enhanced block consumption that integrates all learning mechanisms.
    
    This function extends the original _consume_block by adding:
    1. Neural embedding and storage
    2. Remote call for distributed cluster learning
    3. Corpus integration for transformer training
    4. Fact learning per sentence
    
    Args:
        lines: Text block to consume
        seq: Sequence number for the block
    """
    global learning_integration
    
    if learning_integration:
        learning_integration.consume_block(lines, seq)
    else:
        logger.warning("Learning integration system not initialized - using legacy implementation")
        
        # Fallback implementation for backward compatibility
        try:
            # Try to import required functions
            from singularity_boot import _consume_block, trifecta, _learn_fact
            from organism_neuro import neuro_ingest
            from organism_cluster import remote_call
            from neural_engine import push_into_corpus
            
            # Call original consume block
            _consume_block(lines, seq)
            
            # Add learning integrations
            neuro_ingest(lines, tag=f"lecture_{seq:04d}")
            remote_call("organism_neuro.embed_and_store", lines, f"lecture_{seq:04d}")
            push_into_corpus(lines, source=f"lecture_{seq}")
            
            # Process facts
            for ln in lines.splitlines():
                if ln.strip():
                    _learn_fact(ln.strip())
                    
            logger.info(f"Processed lecture block {seq} through legacy implementation")
            
        except ImportError as e:
            logger.error(f"Legacy implementation failed: {e}")
            logger.error("Cannot process lecture block - required functions not available")

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(
    original_consume_block=None,
    trifecta_function=None,
    neuro_ingest_function=None,
    remote_call_function=None,
    push_into_corpus_function=None,
    learn_fact_function=None,
    logger=None
) -> LearningIntegrationSystem:
    """
    Initialize the learning integration system.
    
    Args:
        original_consume_block: Original consume block function
        trifecta_function: Function for RBY-based learning
        neuro_ingest_function: Function for neural ingestion
        remote_call_function: Function for remote procedure calls
        push_into_corpus_function: Function for corpus integration
        learn_fact_function: Function for fact learning
        logger: Logger instance
        
    Returns:
        Initialized LearningIntegrationSystem
    """
    global learning_integration
    global _original_consume_block, _trifecta_function, _neuro_ingest_function
    global _remote_call_function, _push_into_corpus_function, _learn_fact_function, _logger
    
    logger.info("Initializing learning integration system")
    
    # Store references to required functions
    _original_consume_block = original_consume_block
    _trifecta_function = trifecta_function
    _neuro_ingest_function = neuro_ingest_function
    _remote_call_function = remote_call_function
    _push_into_corpus_function = push_into_corpus_function
    _learn_fact_function = learn_fact_function
    _logger = logger or logging.getLogger("singularity.learning_integration")
    
    # Create learning integration system
    learning_integration = LearningIntegrationSystem(
        original_consume_block=original_consume_block,
        trifecta_function=trifecta_function,
        neuro_ingest_function=neuro_ingest_function,
        remote_call_function=remote_call_function,
        push_into_corpus_function=push_into_corpus_function,
        learn_fact_function=learn_fact_function,
        logger=_logger
    )
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Learning integration system initialized in {_STATS['init_time_ms']} ms")
    
    return learning_integration

def health_check() -> dict:
    """
    Perform a health check on the learning integration system.
    
    Returns:
        Dictionary with health status information
    """
    global learning_integration
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not learning_integration:
        status = "error"
        warnings.append("Learning integration system not initialized")
    else:
        try:
            # Check dependencies
            dependencies = {
                "original_consume": learning_integration.original_consume is not None,
                "trifecta": learning_integration.trifecta is not None,
                "neuro_ingest": learning_integration.neuro_ingest is not None,
                "remote_call": learning_integration.remote_call is not None,
                "push_into_corpus": learning_integration.push_into_corpus is not None,
                "learn_fact": learning_integration.learn_fact is not None,
            }
            
            details["dependencies"] = dependencies
            
            # Check if any dependencies are missing
            missing_deps = [name for name, present in dependencies.items() if not present]
            if missing_deps:
                if status != "error":
                    status = "warning"
                warnings.append(f"Missing dependencies: {', '.join(missing_deps)}")
                
            # System resource checks
            memory_usage = _γps.Process(os.getpid()).memory_info().rss / 1024**2  # MB
            details["memory_usage_mb"] = round(memory_usage, 2)
            
            if memory_usage > 1000:  # Over 1GB
                warnings.append(f"High memory usage: {memory_usage:.2f} MB")
                if status != "error":
                    status = "warning"
            
        except Exception as e:
            status = "error"
            warnings.append(f"Learning integration system error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": _γnow.utcnow().isoformat(),
        "module": "learning_integration",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the learning integration system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown() -> None:
    """
    Perform clean shutdown of learning integration system resources.
    """
    global learning_integration
    
    if learning_integration:
        logger.info("Shutting down learning integration system")
        # Nothing to clean up for now

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_learning_integration_status() -> None:
    """
    Command handler for /learning-status
    """
    if not learning_integration:
        print("Learning integration system not initialized")
        return
    
    health = health_check()
    
    print("\nLearning Integration System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    print("\nDependencies:")
    for name, status in health["details"].get("dependencies", {}).items():
        status_symbol = "✓" if status else "✗"
        print(f"  {name}: {status_symbol}")
    
    if "memory_usage_mb" in health["details"]:
        print(f"\nMemory Usage: {health['details']['memory_usage_mb']} MB")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

def _cmd_learning_optimization() -> None:
    """
    Command handler for /optimize-learning
    Shows optimization suggestions based on current system usage
    """
    if not learning_integration:
        print("Learning integration system not initialized")
        return
        
    metrics = get_metrics()
    health = health_check()
    
    print("\nLearning System Optimization Suggestions:")
    
    # Check neural vs fact learning ratio
    neural_fact_ratio = metrics["neural_ingests"] / max(1, metrics["facts_learned"])
    if neural_fact_ratio < 0.5:
        print("• Neural ingestion rate is low compared to fact learning.")
        print("  Consider enhancing neural_ingest calls or reviewing patterns.")
        
    # Check distributed learning usage
    distributed_ratio = metrics["distributed_learning_events"] / max(1, metrics["blocks_consumed"])
    if distributed_ratio < 0.8:
        print("• Distributed learning is underutilized.")
        print("  Verify cluster configuration and connectivity.")
        
    # Check error rate
    error_rate = metrics["errors"] / max(1, sum(v for k, v in metrics.items() if k != "errors" and k != "init_time_ms"))
    if error_rate > 0.01:
        print(f"• Error rate is high: {error_rate:.2%}")
        print("  Review logs for recurring error patterns.")
        
    if "memory_usage_mb" in health["details"] and health["details"]["memory_usage_mb"] > 500:
        print(f"• Memory usage is high: {health['details']['memory_usage_mb']} MB")
        print("  Consider implementing memory-efficient processing.")
        
    # Check if all looks good
    if neural_fact_ratio >= 0.5 and distributed_ratio >= 0.8 and error_rate <= 0.01:
        print("✓ All learning systems are operating optimally!")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'LearningIntegrationSystem',
    '_γ_consume_block',
    'learning_integration',
    '_cmd_learning_integration_status',
    '_cmd_learning_optimization'
]
