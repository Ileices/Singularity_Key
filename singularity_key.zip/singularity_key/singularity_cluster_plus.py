#!/usr/bin/env python3
"""
ClusterPlus - Advanced Node Discovery and Task Distribution
----------------------------------------------------------
Provides automatic peer discovery, resource scoring, and job distribution
for the Singularity organism.

Features:
- Thread-safe peer discovery and communication
- GPU/CPU task distribution with fallback chain
- Intelligent storage selection based on available space
- Cross-platform mount point management
- Robust error handling with local fallback execution

This module enables Singularity to scale across multiple machines by
distributing computationally intensive tasks to the most suitable nodes
and managing storage allocation across available resources.
"""
from __future__ import annotations
import json, os, socket, struct, threading, time, queue, pickle, pathlib, shutil, psutil, subprocess
from typing import Dict, Tuple, Any, Callable, List, Optional, Union
import torch
import logging
import uuid
import hashlib
import sys
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.cluster_plus")

# ===== 0. CONSTANTS =========================================================
_CL_PORT     = 39401
_PROTO_ID    = b'\xE2\x9F\x90CLU'  # 4-byte magic, ignore foreign traffic
_AD, _REQ, _ACK, _DEN, _RPC     = range(1,6)

_TASK_TIMEOUT = 30              # sec – if no response, run locally
_BROADCAST    = ('255.255.255.255', _CL_PORT)

_BASE  = pathlib.Path(__file__).parent.resolve()
_NETFS = _BASE / "net_mounts"    # local dir where remote shares are mounted
_NETFS.mkdir(exist_ok=True, parents=True)

# Thread safety
_cluster_lock = threading.RLock()
_job_lock = threading.RLock()
_peers_lock = threading.RLock()
_mount_lock = threading.RLock()

# ===== 1. helpers ===========================================================
def _profile() -> Dict[str,Any]:
    """Live hardware & capacity report"""
    cuda = torch.cuda.is_available()
    rocm = torch.version.hip is not None and torch.version.hip != ""
    disks = { d.mountpoint: psutil.disk_usage(d.mountpoint).free//2**30
              for d in psutil.disk_partitions(all=False)
              if os.access(d.mountpoint, os.W_OK) }
    return dict(
        host   = socket.gethostname(),
        pid    = os.getpid(),
        cores  = psutil.cpu_count(logical=False),
        ram    = psutil.virtual_memory().total//2**30,
        cuda   = cuda,
        rocm   = rocm,
        vram   = torch.cuda.get_device_properties(0).total_memory//2**30
                 if cuda else 0,
        free_gb= sum(disks.values()),
        disks  = disks,
        ts     = time.time()
    )

def _score(p:Dict)->int:        # bigger = better
    s  = p["cores"]*10 + p["ram"]
    s += p["free_gb"]//10
    s += p["vram"]*5
    if p["cuda"]: s += 500
    elif p["rocm"]: s += 300
    return s

# ===== 2. GLOBAL STATE ======================================================
class _ClusterState:
    def __init__(self):
        self.peers: Dict[str, Dict] = {}  # hostname → profile
        self.peers_last_seen: Dict[str, float] = {}  # hostname → timestamp
        self.job_queue: queue.Queue = queue.Queue()
        self.results: Dict[str, Any] = {}  # job_id → result
        self.results_ready: Dict[str, threading.Event] = {}  # job_id → event
        self.sock = None  # socket for UDP broadcast/receive
        self.running = False
        self.my_profile = _profile()
        self.AUTO = True  # auto-accept incoming jobs
        self.startup_time = time.time()
        self.metrics = {
            "init_time_ms": 0,
            "jobs_submitted": 0,
            "jobs_completed": 0,
            "jobs_failed": 0,
            "jobs_executing": 0,
            "peers_discovered": 0,
            "advertise_count": 0,
            "storage_operations": 0,
            "errors": 0
        }

_state = _ClusterState()

# ===== 3. NETWORK PROTOCOL ==================================================
def _mk_packet(type_code:int, payload:Dict) -> bytes:
    """Create a packet with the given type code and payload."""
    blob = pickle.dumps(payload)
    header = struct.pack("!6sBI", _PROTO_ID, type_code, len(blob))
    return header + blob

def _parse_packet(data:bytes) -> Tuple[int, Dict]:
    """Parse a packet, returning type code and payload."""
    if len(data) < 11:  # Header length
        raise ValueError("Packet too short")
        
    proto_id, type_code, payload_len = struct.unpack("!6sBI", data[:11])
    
    if proto_id != _PROTO_ID:
        raise ValueError(f"Invalid protocol ID: {proto_id}")
        
    if payload_len + 11 != len(data):
        raise ValueError(f"Payload length mismatch: expected {payload_len}, got {len(data) - 11}")
        
    payload = pickle.loads(data[11:])
    return type_code, payload

# ===== 4. NETWORK LISTENER THREADS ==========================================
def _advertise_loop():
    """Periodically broadcast own profile to the network."""
    try:
        with _cluster_lock:
            sock = _state.sock
        
        if not sock:
            logger.error("Socket not initialized in advertise loop")
            return
            
        while _state.running:
            try:
                with _cluster_lock:
                    # Update profile before broadcasting
                    _state.my_profile = _profile()
                    _state.my_profile["ts"] = time.time()
                    
                    packet = _mk_packet(_AD, _state.my_profile)
                    sock.sendto(packet, _BROADCAST)
                    _state.metrics["advertise_count"] += 1
                    
            except Exception as e:
                logger.error(f"Error in advertise loop: {e}")
                with _cluster_lock:
                    _state.metrics["errors"] += 1
            
            # Wait before next broadcast
            time.sleep(15)
    except Exception as e:
        logger.error(f"Fatal error in advertise loop: {e}")

def _receive_loop():
    """Listen for incoming packets and handle them."""
    try:
        with _cluster_lock:
            sock = _state.sock
        
        if not sock:
            logger.error("Socket not initialized in receive loop")
            return
            
        while _state.running:
            try:
                data, addr = sock.recvfrom(65536)  # Max UDP packet size
                
                try:
                    type_code, payload = _parse_packet(data)
                except ValueError as e:
                    logger.debug(f"Ignoring invalid packet from {addr}: {e}")
                    continue
                
                # Handle packet based on type
                if type_code == _AD:
                    _handle_advertisement(payload, addr)
                elif type_code == _REQ:
                    _handle_job_request(payload, addr)
                elif type_code == _ACK:
                    _handle_job_ack(payload)
                elif type_code == _DEN:
                    _handle_job_denial(payload)
                elif type_code == _RPC:
                    _handle_job_result(payload)
                else:
                    logger.warning(f"Unknown packet type: {type_code}")
                    
            except socket.timeout:
                # This is normal, just continue
                continue
            except Exception as e:
                logger.error(f"Error handling packet: {e}")
                with _cluster_lock:
                    _state.metrics["errors"] += 1
    except Exception as e:
        logger.error(f"Fatal error in receive loop: {e}")

def _handle_advertisement(profile:Dict, addr:Tuple[str,int]):
    """Process an advertisement from another node."""
    host = profile.get("host", addr[0])
    
    with _peers_lock:
        if host not in _state.peers:
            _state.metrics["peers_discovered"] += 1
            logger.info(f"Discovered new peer: {host}")
            
        _state.peers[host] = profile
        _state.peers_last_seen[host] = time.time()
    
    # Remove stale peers
    _prune_stale_peers()

def _prune_stale_peers():
    """Remove peers that haven't been seen recently."""
    now = time.time()
    stale_threshold = 60  # 1 minute
    
    with _peers_lock:
        stale = [host for host, ts in _state.peers_last_seen.items() 
                if now - ts > stale_threshold]
        
        for host in stale:
            logger.info(f"Removing stale peer: {host}")
            if host in _state.peers:
                del _state.peers[host]
            if host in _state.peers_last_seen:
                del _state.peers_last_seen[host]

def _handle_job_request(req:Dict, addr:Tuple[str,int]):
    """Process a job request from another node."""
    job_id = req.get("id")
    kind = req.get("kind", "cpu")
    
    # Check if we should accept this job
    should_accept = False
    
    # Auto-accept if configured, otherwise ask the user
    if _state.AUTO:
        # Check if we're suitable for this job type
        if kind == "gpu" and (_state.my_profile.get("cuda", False) or _state.my_profile.get("rocm", False)):
            should_accept = True
        elif kind == "cpu":
            should_accept = True
    else:
        # Here we would ask the user, but for now we'll decline
        should_accept = False
    
    if should_accept:
        # Accept the job
        with _cluster_lock:
            ack_packet = _mk_packet(_ACK, {"id": job_id})
            _state.sock.sendto(ack_packet, addr)
        
        # Put in job queue for processing
        _state.job_queue.put((req, addr))
    else:
        # Decline the job
        with _cluster_lock:
            den_packet = _mk_packet(_DEN, {"id": job_id})
            _state.sock.sendto(den_packet, addr)

def _handle_job_ack(payload:Dict):
    """Handle acknowledgment for a job request."""
    job_id = payload.get("id")
    logger.debug(f"Job accepted: {job_id}")
    # Note: actual handling happens in _wait_for_response

def _handle_job_denial(payload:Dict):
    """Handle denial for a job request."""
    job_id = payload.get("id")
    logger.debug(f"Job denied: {job_id}")
    # Note: actual handling happens in _wait_for_response

def _handle_job_result(payload:Dict):
    """Handle a job result from a remote node."""
    job_id = payload.get("id")
    result = payload.get("result")
    error = payload.get("error")
    
    if error:
        logger.warning(f"Remote job {job_id} failed: {error}")
    else:
        logger.debug(f"Received result for job {job_id}")
    
    with _job_lock:
        _state.results[job_id] = {"result": result, "error": error}
        if job_id in _state.results_ready:
            _state.results_ready[job_id].set()

def _job_processor():
    """Process jobs in the job queue."""
    while _state.running:
        try:
            # Get a job from the queue
            try:
                req, addr = _state.job_queue.get(timeout=1)
            except queue.Empty:
                continue
            
            job_id = req.get("id")
            fn_name = req.get("fn")
            args = req.get("args", ())
            kwargs = req.get("kwargs", {})
            
            logger.info(f"Processing job {job_id}: {fn_name}")
            
            with _cluster_lock:
                _state.metrics["jobs_executing"] += 1
            
            # Execute the job
            result = None
            error = None
            try:
                # Import the function dynamically
                module_name, func_name = fn_name.rsplit(".", 1)
                module = __import__(module_name, fromlist=[func_name])
                func = getattr(module, func_name)
                
                # Call the function
                result = func(*args, **kwargs)
            except Exception as e:
                error = str(e)
                logger.error(f"Error executing job {job_id}: {e}")
                with _cluster_lock:
                    _state.metrics["errors"] += 1
            
            # Send the result back
            with _cluster_lock:
                response = {"id": job_id, "result": result, "error": error}
                packet = _mk_packet(_RPC, response)
                _state.sock.sendto(packet, addr)
                
                if error:
                    _state.metrics["jobs_failed"] += 1
                else:
                    _state.metrics["jobs_completed"] += 1
                _state.metrics["jobs_executing"] -= 1
                
        except Exception as e:
            logger.error(f"Error in job processor: {e}")
            with _cluster_lock:
                _state.metrics["errors"] += 1

# ===== 5. JOB SUBMISSION ===================================================
def _get_best_peer(kind:str) -> Optional[Tuple[str, Dict]]:
    """Get the best peer for a job based on kind and score."""
    with _peers_lock:
        valid_peers = []
        
        # Filter peers based on job kind
        for host, profile in _state.peers.items():
            # For GPU jobs, peer needs CUDA or ROCm
            if kind == "gpu" and not (profile.get("cuda", False) or profile.get("rocm", False)):
                continue
            
            # Add peer with its score
            valid_peers.append((host, profile, _score(profile)))
        
        # Sort by score (highest first)
        valid_peers.sort(key=lambda x: x[2], reverse=True)
        
        # Return best peer if any
        if valid_peers:
            host, profile, _ = valid_peers[0]
            return (host, profile)
        
        return None

def _wait_for_response(job_id:str, addr:Tuple[str,int], timeout:int=_TASK_TIMEOUT) -> Dict:
    """Wait for a response to a job request."""
    # Create an event to wait for the response
    with _job_lock:
        event = threading.Event()
        _state.results_ready[job_id] = event
    
    # Wait for the response
    event.wait(timeout)
    
    # Get the result if available
    with _job_lock:
        result = _state.results.get(job_id)
        
        # Clean up
        if job_id in _state.results:
            del _state.results[job_id]
        if job_id in _state.results_ready:
            del _state.results_ready[job_id]
    
    return result

# ===== 6. PUBLIC API =======================================================
class ClusterPlus:
    """Public API for ClusterPlus functionality."""
    
    @staticmethod
    def start(auto_accept:bool = True):
        """
        Initialize and start the cluster networking.
        
        Args:
            auto_accept: Whether to automatically accept jobs from peers.
        """
        with _cluster_lock:
            if _state.running:
                logger.warning("ClusterPlus already running")
                return
            
            # Set auto_accept policy
            _state.AUTO = auto_accept
            
            try:
                # Create socket
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("", _CL_PORT))
                sock.settimeout(0.5)  # Short timeout for non-blocking recv
                
                _state.sock = sock
                _state.running = True
                _state.metrics["init_time_ms"] = (time.time() - _state.startup_time) * 1000
                
                # Start worker threads
                threading.Thread(target=_advertise_loop, daemon=True).start()
                threading.Thread(target=_receive_loop, daemon=True).start()
                threading.Thread(target=_job_processor, daemon=True).start()
                
                logger.info("ClusterPlus started successfully")
                return True
                
            except Exception as e:
                logger.error(f"Failed to start ClusterPlus: {e}")
                _state.metrics["errors"] += 1
                return False
    
    @staticmethod
    def stop():
        """Stop the cluster networking."""
        with _cluster_lock:
            if not _state.running:
                return
            
            _state.running = False
            
            if _state.sock:
                try:
                    _state.sock.close()
                except:
                    pass
                _state.sock = None
            
            logger.info("ClusterPlus stopped")
    
    @staticmethod
    def put_job(kind:str, fn:str, args:tuple, kw:dict) -> Any:
        """
        Execute a job on the cluster, with fallback to local execution.
        
        Args:
            kind: "gpu" or "cpu" - type of resource needed
            fn: Fully qualified function name (e.g., "module.submodule.function")
            args: Positional arguments for the function
            kw: Keyword arguments for the function
            
        Returns:
            Result from the function execution.
        """
        if not _state.running:
            # Fall back to local execution if not connected
            return ClusterPlus._local_exec(fn, args, kw)
            
        with _cluster_lock:
            _state.metrics["jobs_submitted"] += 1
            
        # Find best peer for this job
        peer = _get_best_peer(kind)
        
        if not peer:
            logger.info(f"No suitable peers for {kind} job, executing locally")
            return ClusterPlus._local_exec(fn, args, kw)
        
        host, profile = peer
        
        # Create job request
        job_id = str(uuid.uuid4())
        req = {
            "id": job_id,
            "kind": kind,
            "fn": fn,
            "args": args,
            "kwargs": kw
        }
        
        # Get peer address
        addr = (host, _CL_PORT)
        
        # Send job request
        with _cluster_lock:
            packet = _mk_packet(_REQ, req)
            _state.sock.sendto(packet, addr)
        
        # Wait for response
        logger.debug(f"Waiting for response from {host} for job {job_id}")
        response = _wait_for_response(job_id, addr)
        
        if not response:
            logger.warning(f"No response from {host} for job {job_id}, executing locally")
            return ClusterPlus._local_exec(fn, args, kw)
        
        if response.get("error"):
            logger.warning(f"Remote error executing {job_id}: {response['error']}, falling back to local")
            return ClusterPlus._local_exec(fn, args, kw)
        
        return response.get("result")
    
    @staticmethod
    def _local_exec(fn:str, args:tuple, kw:dict) -> Any:
        """Execute a function locally."""
        try:
            module_name, func_name = fn.rsplit(".", 1)
            module = __import__(module_name, fromlist=[func_name])
            func = getattr(module, func_name)
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in local execution of {fn}: {e}")
            with _cluster_lock:
                _state.metrics["errors"] += 1
            raise
    
    @staticmethod
    def best_path(size_MiB:int) -> pathlib.Path:
        """
        Find the best path (local or remote) with at least size_MiB free space.
        
        Args:
            size_MiB: Minimum required free space in MiB
            
        Returns:
            Path object pointing to suitable directory
        """
        with _cluster_lock:
            _state.metrics["storage_operations"] += 1
            
        size_bytes = size_MiB * 1024 * 1024
        
        # Check local disks first
        local_paths = []
        for path, gb_free in _state.my_profile.get("disks", {}).items():
            if gb_free * 1024 * 1024 * 1024 >= size_bytes:
                scratch = pathlib.Path(path) / "singularity_scratch"
                scratch.mkdir(exist_ok=True)
                local_paths.append((scratch, gb_free))
        
        if local_paths:
            # Return local path with most free space
            best_path = max(local_paths, key=lambda x: x[1])[0]
            logger.debug(f"Selected local path: {best_path}")
            return best_path
            
        # If no suitable local paths, check remote peers
        with _peers_lock:
            for host, profile in _state.peers.items():
                for path, gb_free in profile.get("disks", {}).items():
                    if gb_free * 1024 * 1024 * 1024 >= size_bytes:
                        # Mount remote path
                        remote_path = ClusterPlus._mount_remote(host, path)
                        if remote_path:
                            logger.debug(f"Selected remote path: {remote_path}")
                            return remote_path
        
        # If no suitable remote paths, create a temporary directory as fallback
        import tempfile
        fallback = tempfile.mkdtemp(prefix="singularity_")
        logger.warning(f"No paths with {size_MiB} MiB free, using temporary directory: {fallback}")
        return pathlib.Path(fallback)
    
    @staticmethod
    def _mount_remote(host:str, path:str) -> Optional[pathlib.Path]:
        """Mount a remote path locally."""
        # For now, this is a placeholder
        # In a real implementation, this would use SSHFS, SMB, NFS, etc.
        logger.warning("Remote mounting not implemented yet")
        return None
    
    @staticmethod
    def get_peers() -> List[Dict]:
        """Get a list of all discovered peers."""
        with _peers_lock:
            return [profile for host, profile in _state.peers.items()]
    
    @staticmethod
    def get_metrics() -> Dict:
        """Get metrics about cluster operations."""
        with _cluster_lock:
            return _state.metrics.copy()
    
    @staticmethod
    def health_check() -> Dict:
        """Perform a health check of the cluster system."""
        if not _state.running:
            return {
                "status": "error",
                "message": "ClusterPlus not running",
                "metrics": {},
                "timestamp": time.time()
            }
        
        with _cluster_lock:
            metrics = _state.metrics.copy()
        
        with _peers_lock:
            peer_count = len(_state.peers)
            # Prune stale peers first
            _prune_stale_peers()
            peer_count_after = len(_state.peers)
            
        # Determine overall status
        if metrics["errors"] > 0:
            status = "warning"
            message = f"Encountered {metrics['errors']} errors in cluster operations"
        else:
            status = "healthy"
            message = "ClusterPlus operating normally"
        
        return {
            "status": status,
            "message": message,
            "metrics": metrics,
            "peer_count": peer_count_after,
            "stale_peers_removed": peer_count - peer_count_after,
            "my_profile": _profile(),
            "timestamp": time.time()
        }

# Automatic cleanup on module unload
import atexit
atexit.register(ClusterPlus.stop)

# If this file is run directly, show cluster info
if __name__ == "__main__":
    ClusterPlus.start()
    print("ClusterPlus started. Press Ctrl+C to exit.")
    try:
        while True:
            print("\nCluster status:")
            health = ClusterPlus.health_check()
            print(f"Status: {health['status']}")
            print(f"Message: {health['message']}")
            print(f"Peers: {health['peer_count']}")
            print(f"My profile:")
            for k, v in health['my_profile'].items():
                print(f"  {k}: {v}")
            time.sleep(10)
    except KeyboardInterrupt:
        print("Stopping ClusterPlus...")
        ClusterPlus.stop()
