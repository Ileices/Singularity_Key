#!/usr/bin/env python3
"""
Singularity Science Pattern Recognition Module
--------------------------------------------
Advanced pattern matching and fact extraction for scientific and mathematical content.

Features:
- Specialized pattern recognition for mathematical equations and scientific relations
- Thread-safe extraction operations with proper locking
- Integration with the knowledge database and pattern system
- Support for LaTeX and Unicode mathematical notations
- Context-aware pattern matching for scientific literature
- Confidence scoring based on pattern specificity

This module extends the core pattern recognition capabilities with specialized
patterns for extracting structured knowledge from scientific and mathematical text.
"""
import re
import os
import time
import json
import logging
import threading
import warnings
import hashlib
from typing import List, Dict, Tuple, Callable, Optional, Any, Union, Pattern, Set
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.science_patterns")

# Thread safety
_pattern_lock = threading.RLock()
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "patterns_loaded": 0,
    "total_extractions": 0,
    "successful_extractions": 0,
    "errors": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Scientific and Mathematical Pattern Definitions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_SCI_MATH_PATTERNS: list[tuple[re.Pattern, callable]] = [
    # 13) "Let x be the length of the rod"
    (re.compile(r"\blet (?P<subj>\w+) be (?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "defined_as", m.group("obj"))),
    
    # 14) "x ∈ ℝ" or "n ∈ ℤ"
    (re.compile(r"^(?P<subj>\w+)\s*∈\s*(?P<obj>.+)$", re.I),
        lambda m: (m.group("subj"), "in_set", m.group("obj"))),
    
    # 15) "f is continuous on [a,b]"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(?P<pred>continuous|differentiable|integrable)\s+on\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), m.group("pred"), m.group("obj"))),
    
    # 16) "E = mc^2"
    (re.compile(r"^(?P<subj>[^=]+?)\s*=\s*(?P<obj>.+)$"),
        lambda m: (m.group("subj").strip(), "equals", m.group("obj").strip())),
    
    # 17) "p ≥ 0" or "θ < π/2"
    (re.compile(r"^(?P<subj>[^<>=]+?)\s*(?P<sym>[<>]=?)\s*(?P<obj>.+)$"),
        lambda m: (m.group("subj").strip(), m.group("sym"), m.group("obj").strip())),
    
    # 18) "c is 3.00×10^8 m/s"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(?P<obj>[\d\.\s×\^eE\-\+]+.*)$"),
        lambda m: (m.group("subj"), "value", m.group("obj"))),
    
    # 19) "Theorem X states that …"
    (re.compile(r"^(?P<subj>[\w\s\-]+?)\s+states that\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "states", m.group("obj"))),
    
    # 20) "Smith et al. (2021) showed that …"
    (re.compile(r"^(?P<subj>[\w\s\.]+?)\s*\(\s*\d{4}\s*\)\s+(?P<pred>showed|proved|demonstrated|found)\s+that\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), m.group("pred"), m.group("obj"))),
    
    # 21) "H₂O is water"
    (re.compile(r"^(?P<subj>[A-Za-z0-9₀-₉\(\)]+)\s+is\s+(?P<obj>[\w\s\-]+)$", re.I),
        lambda m: (m.group("subj"), "alias_of", m.group("obj"))),
    
    # 22) "2 H₂ + O₂ → 2 H₂O"
    (re.compile(r"^(?P<subj>.+?)\s*→\s*(?P<obj>.+)$"),
        lambda m: (m.group("subj").strip(), "yields", m.group("obj").strip())),
    
    # 23) "dV/dt equals …"
    (re.compile(r"^(?P<subj>d\w+/d\w+)\s+equals\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "equals", m.group("obj"))),
        
    # Advanced mathematical patterns
    # 24) "The derivative of f(x) with respect to x is g(x)"
    (re.compile(r"^(?:the\s+)?derivative\s+of\s+(?P<subj>.+?)\s+with\s+respect\s+to\s+(?P<pred>\w+)\s+is\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), f"derivative_wrt_{m.group('pred')}", m.group("obj"))),
        
    # 25) "The integral of f(x) dx equals F(x) + C"
    (re.compile(r"^(?:the\s+)?integral\s+of\s+(?P<subj>.+?)\s+(?:d\w+)\s+(?:equals|is)\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "integral", m.group("obj"))),
        
    # 26) "For all x in R, f(x) > 0"
    (re.compile(r"^for\s+all\s+(?P<subj>\w+)\s+in\s+(?P<pred>.+?),\s+(?P<obj>.+)", re.I),
        lambda m: (f"∀{m.group('subj')}∈{m.group('pred')}", "implies", m.group("obj"))),
        
    # 27) "lim x->0 f(x) = L"
    (re.compile(r"^lim\s+(?P<subj>\w+)(?:\s*->|→)\s*(?P<pred>.+?)\s+(?P<obj>.+?)\s*=\s*(?P<val>.+)", re.I),
        lambda m: (f"lim_{m.group('subj')}->{m.group('pred')}({m.group('obj')})", "equals", m.group("val")))
]

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LaTeX pattern recognition for mathematical expressions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_LATEX_PATTERNS = [
    # LaTeX equation extraction
    (re.compile(r"\\begin\{equation\}(.*?)\\end\{equation\}", re.DOTALL),
     lambda m: ("equation", "latex_form", m.group(1).strip())),
     
    # LaTeX theorem extraction
    (re.compile(r"\\begin\{theorem\}(.*?)\\end\{theorem\}", re.DOTALL),
     lambda m: ("theorem", "states", m.group(1).strip())),
     
    # Inline math with $...$ or \(...\)
    (re.compile(r"\$([^$]+?)\$|\\\((.*?)\\\)"),
     lambda m: ("inline_math", "form", (m.group(1) or m.group(2)).strip())),
     
    # LaTeX definitions and declarations
    (re.compile(r"\\newcommand\{\\(\w+)\}\{(.*?)\}"),
     lambda m: (f"\\{m.group(1)}", "defined_as", m.group(2)))
]

# Combine with the main patterns
_SCI_MATH_PATTERNS.extend(_LATEX_PATTERNS)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Integration with Core Fact Patterns
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
try:
    from singularity_patterns import _FACT_PATTERNS, add_pattern as _core_add_pattern
    _has_core_patterns = True
    _metrics["patterns_loaded"] = len(_FACT_PATTERNS)
except ImportError:
    _has_core_patterns = False
    _FACT_PATTERNS = []  # Use our own if core module not available
    logger.warning("Core pattern module not found, using science patterns only")

# Extend with new patterns
for pattern, handler in _SCI_MATH_PATTERNS:
    # Add to core patterns if available
    if _has_core_patterns:
        try:
            _core_add_pattern(pattern, handler, "Science/Math pattern")
        except Exception as e:
            logger.error(f"Failed to add pattern to core: {e}")
    
    # Add to our local list as well
    _FACT_PATTERNS.append((pattern, handler))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# User-defined and dynamic patterns
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_USER_PATTERNS = []  # User-defined patterns can be added at runtime

def add_pattern(regex_pattern: str, extractor_fn: Callable, description: str = "") -> bool:
    """
    Add a new pattern to the scientific fact extraction system.
    
    Args:
        regex_pattern: Regular expression pattern string
        extractor_fn: Function that takes a match object and returns (subj, pred, obj)
        description: Optional description of the pattern
        
    Returns:
        True if successfully added, False otherwise
    """
    with _pattern_lock:
        try:
            compiled_pattern = re.compile(regex_pattern, re.I)
            _USER_PATTERNS.append((compiled_pattern, extractor_fn))
            
            # Also add to core pattern system if available
            if _has_core_patterns:
                _core_add_pattern(regex_pattern, extractor_fn, description)
                
            logger.info(f"Added new scientific pattern: {description or regex_pattern}")
            return True
        except Exception as e:
            logger.error(f"Failed to add pattern: {e}")
            _metrics["errors"] += 1
            return False

def get_all_patterns() -> List[Tuple[Pattern, Callable]]:
    """Get all available scientific patterns (built-in + user-defined)."""
    with _pattern_lock:
        return _FACT_PATTERNS + _USER_PATTERNS

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Scientific Fact Extraction Engine
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_scientific_facts(text: str, confidence_threshold: float = 0.6) -> List[Tuple[str, str, str, float]]:
    """
    Extract scientific and mathematical facts from text using specialized patterns.
    
    Args:
        text: Input text to analyze
        confidence_threshold: Minimum confidence level for returned facts
        
    Returns:
        List of (subject, predicate, object, confidence) tuples
    """
    _metrics["total_extractions"] += 1
    facts = []
    
    # Split into sentences for better pattern matching
    sentences = [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]
    
    # Also extract potential LaTeX blocks for separate processing
    latex_blocks = re.findall(r'\\begin\{.*?\}.*?\\end\{.*?\}', text, re.DOTALL)
    if latex_blocks:
        sentences.extend(latex_blocks)
    
    all_patterns = get_all_patterns()
    
    for sentence in sentences:
        for pattern, extractor in all_patterns:
            try:
                for match in pattern.finditer(sentence):
                    try:
                        # Extract the triple
                        subj, pred, obj = extractor(match)
                        
                        # Calculate confidence score based on pattern specificity
                        confidence = _calculate_confidence(subj, pred, obj, sentence, pattern)
                        
                        if confidence >= confidence_threshold:
                            facts.append((subj, pred, obj, confidence))
                            _metrics["successful_extractions"] += 1
                    except Exception as e:
                        logger.debug(f"Extraction error: {e}")
            except Exception as e:
                logger.debug(f"Pattern matching error: {e}")
                _metrics["errors"] += 1
    
    return facts

def _calculate_confidence(subj: str, pred: str, obj: str, original_text: str, pattern: Pattern) -> float:
    """
    Calculate a confidence score for an extracted scientific fact.
    
    Specialized scoring that recognizes mathematical notation, LaTeX expressions,
    and scientific phrasing.
    """
    confidence = 0.7  # Base confidence
    
    # Higher confidence for mathematical notation
    if any(c in subj + pred + obj for c in "∈∀∃∂∇∆∑∏∞∫≤≥≠≈"):
        confidence += 0.1
    
    # Higher confidence for LaTeX expressions
    if '\\begin{' in original_text or '\\end{' in original_text or '\\frac' in original_text:
        confidence += 0.1
    
    # Adjust based on length of components
    if len(subj) < 1 or len(pred) < 1 or len(obj) < 1:
        confidence -= 0.3
    
    # Adjust based on pattern specificity (more complex patterns are more reliable)
    pattern_complexity = len(pattern.pattern) / 100  # Normalize
    confidence += min(0.1, pattern_complexity * 0.5)  # Max 0.1 boost
    
    # Cap at 0.0-1.0 range
    return max(0.0, min(1.0, confidence))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Integration with Knowledge Database
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_and_store(text: str, source: str = "science_extraction") -> List[Tuple[str, str, str, float]]:
    """
    Extract scientific facts from text and store them in the knowledge database.
    
    Args:
        text: Input text to analyze
        source: Source identifier for the extracted facts
        
    Returns:
        List of extracted and stored (subject, predicate, object, confidence) tuples
    """
    facts = extract_scientific_facts(text)
    stored_facts = []
    
    try:
        # Import knowledge module dynamically to avoid circular imports
        from singularity_knowledge import add_fact
        
        for subj, pred, obj, conf in facts:
            try:
                success = add_fact(subj, pred, obj, confidence=conf, source=source)
                if success:
                    stored_facts.append((subj, pred, obj, conf))
            except Exception as e:
                logger.error(f"Error storing fact: {e}")
                _metrics["errors"] += 1
    except ImportError:
        logger.warning("Knowledge module not available, facts not stored")
        _metrics["errors"] += 1
    
    return stored_facts

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LaTeX Processing Utilities
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_latex_definitions(text: str) -> Dict[str, str]:
    """
    Extract LaTeX definitions and commands from a document.
    
    Args:
        text: LaTeX content
        
    Returns:
        Dictionary of command/symbol -> definition
    """
    definitions = {}
    
    # Extract \newcommand definitions
    for match in re.finditer(r"\\newcommand\{\\(\w+)\}\{(.*?)\}", text):
        command = f"\\{match.group(1)}"
        definition = match.group(2)
        definitions[command] = definition
    
    # Extract \def definitions
    for match in re.finditer(r"\\def\\(\w+)\{(.*?)\}", text):
        command = f"\\{match.group(1)}"
        definition = match.group(2)
        definitions[command] = definition
        
    # Extract theorem environments
    for match in re.finditer(r"\\begin\{theorem\}\[(.*?)\](.*?)\\end\{theorem\}", text, re.DOTALL):
        theorem_name = match.group(1).strip()
        theorem_content = match.group(2).strip()
        definitions[f"Theorem: {theorem_name}"] = theorem_content
        
    return definitions

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_science_metrics() -> Dict[str, Union[int, float]]:
    """Get metrics about scientific pattern recognition operations."""
    with _pattern_lock:
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """Perform a health check on the science pattern recognition subsystem."""
    status = "healthy"
    details = {}
    
    # Check pattern counts
    total_patterns = len(_SCI_MATH_PATTERNS) + len(_USER_PATTERNS)
    _metrics["patterns_loaded"] = total_patterns
    details["total_patterns"] = total_patterns
    
    # Check extraction success rate
    if _metrics["total_extractions"] > 0:
        success_rate = _metrics["successful_extractions"] / _metrics["total_extractions"]
        details["extraction_success_rate"] = success_rate
        
        if success_rate < 0.3:  # Less than 30% success rate is concerning
            status = "warning" if status == "healthy" else status
            details["low_success_rate"] = f"Only {success_rate:.1%} of extractions succeed"
    
    # Check for errors
    if _metrics["errors"] > 0:
        status = "warning" if status == "healthy" else status
        details["error_count"] = _metrics["errors"]
    
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_SCI_MATH_PATTERNS": _SCI_MATH_PATTERNS,
        "_FACT_PATTERNS": _FACT_PATTERNS,
        "extract_scientific_facts": extract_scientific_facts,
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_science_patterns instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    '_SCI_MATH_PATTERNS',
    'extract_scientific_facts',
    'extract_and_store',
    'extract_latex_definitions',
    'add_pattern',
    'get_all_patterns',
    'get_science_metrics',
    'health_check'
]

# Register startup time
_metrics["init_time_ms"] = (time.time() - _startup_time) * 1000

# Module self-test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"=== Science Pattern Recognition Module Self-Test ===")
    print(f"Total built-in patterns: {len(_SCI_MATH_PATTERNS)}")
    
    # Test with some example sentences
    test_sentences = [
        "Let x be the variable representing time.",
        "The function f is continuous on [0,1].",
        "E = mc^2 is Einstein's famous equation.",
        "The derivative of x^2 with respect to x is 2x.",
        "For all x in R, x^2 >= 0.",
        "H₂O is the chemical formula for water.",
        "2 H₂ + O₂ → 2 H₂O",
        "The integral of x^2 dx equals x^3/3 + C."
    ]
    
    print("\nExtracting facts from test sentences:")
    all_facts = []
    
    for sentence in test_sentences:
        print(f"\nFrom: '{sentence}'")
        facts = extract_scientific_facts(sentence)
        all_facts.extend(facts)
        
        for subj, pred, obj, conf in facts:
            print(f"  • {subj} {pred} {obj} (confidence: {conf:.2f})")
    
    print(f"\nSuccessfully extracted {len(all_facts)} facts from {len(test_sentences)} sentences")
    
    # Health check
    health = health_check()
    print(f"\nHealth status: {health['status']}")
    print(f"Metrics: {health['metrics']}")
