#!/usr/bin/env python3
"""
Singularity Asset Watcher Module (Module γ - Part 3)
---------------------------------------------------
Monitors seed_assets directory and processes any new files that appear.

Features:
- Real-time monitoring of seed_assets directory
- Automatic text extraction and processing through consume_block
- Thread-safe file tracking with proper locking
- Metrics and monitoring with health check endpoints
- Configurable scanning interval and error handling
- Cross-platform file path handling

This module extends the Learning Integration module to handle asset watching.
"""

import os
import sys
import time
import logging
import threading
import json
from pathlib import Path
from typing import Callable, Dict, Any, Optional, Union, List, Set
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.asset_watcher")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "files_processed": 0,
    "bytes_processed": 0,
    "errors": 0,
    "last_scan_time": 0
}

# Thread safety
_stats_lock = threading.RLock()
_files_lock = threading.RLock()

# Function references - populated during initialization
_consume_block_function = None
_logger = None

# Global state
_seen_files: Set[str] = set()
_watcher_thread = None
_stopping = False

class AssetWatcherSystem:
    """
    Watches the seed_assets directory and processes new files.
    
    This class:
    1. Monitors the seed_assets directory
    2. Identifies new files
    3. Processes them through consume_block
    4. Maintains statistics and state
    """
    
    def __init__(
        self,
        base_dir: Path,
        consume_block_function: Callable[[str, int], None],
        scan_interval: int = 15,
        logger=None
    ):
        """
        Initialize the asset watcher system.
        
        Args:
            base_dir: Base directory of the application
            consume_block_function: Function to process text content
            scan_interval: How often to scan for new files (seconds)
            logger: Logger instance
        """
        self.base_dir = base_dir
        self.asset_dir = (base_dir / "seed_assets").resolve()
        self.consume_block = consume_block_function
        self.scan_interval = scan_interval
        self.logger = logger or logging.getLogger("singularity.asset_watcher")
        
        # Ensure the seed_assets directory exists
        self.asset_dir.mkdir(exist_ok=True)
        
        # Thread safety
        self.lock = threading.RLock()
        
        # Initialize seen files set
        with self.lock:
            global _seen_files
            _seen_files = set(f.name for f in self.asset_dir.iterdir())
        
        self.logger.info(f"AssetWatcherSystem initialized with {len(_seen_files)} existing files")
        
    def watch_assets(self):
        """
        Main loop that watches for new files.
        Runs in a separate thread.
        """
        global _stopping
        
        self.logger.info(f"Asset watcher started for directory: {self.asset_dir}")
        
        while not _stopping:
            try:
                scan_start_time = time.time()
                
                with self.lock:
                    for fp in self.asset_dir.iterdir():
                        if fp.name in _seen_files or not fp.is_file():
                            continue
                        
                        _seen_files.add(fp.name)
                        self.logger.info(f"[seed_asset] NEW {fp.name}")
                        
                        try:
                            # Read file content
                            data = fp.read_text(encoding="utf-8", errors="ignore")
                            
                            # Generate sequence number from timestamp
                            seq = int(time.time()) % 10_000
                            
                            # Process the content
                            self.consume_block(data, seq)
                            
                            # Update statistics
                            with _stats_lock:
                                _STATS["files_processed"] += 1
                                _STATS["bytes_processed"] += len(data)
                                
                        except Exception as e:
                            self.logger.error(f"Error processing file {fp.name}: {e}")
                            with _stats_lock:
                                _STATS["errors"] += 1
                
                # Update scan time metric
                with _stats_lock:
                    _STATS["last_scan_time"] = time.time() - scan_start_time
                
                # Sleep until next scan
                time.sleep(self.scan_interval)
                
            except Exception as e:
                self.logger.error(f"Error in asset watcher: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                time.sleep(self.scan_interval)  # Sleep anyway to prevent busy-looping
    
    def start_watching(self):
        """
        Start watching for new assets in a separate thread.
        """
        global _watcher_thread, _stopping
        
        if _watcher_thread is not None and _watcher_thread.is_alive():
            self.logger.warning("Asset watcher already running")
            return
        
        _stopping = False
        _watcher_thread = threading.Thread(target=self.watch_assets, daemon=True)
        _watcher_thread.start()
        self.logger.info("Asset watcher thread started")
    
    def stop_watching(self):
        """
        Signal the watcher thread to stop.
        """
        global _stopping
        
        _stopping = True
        self.logger.info("Asset watcher signaled to stop")

# Global asset watcher instance
asset_watcher = None

# ──────────────────────────────────────────────────────────────────────────
# Public API: Asset watching function for integration with singularity_boot
# ──────────────────────────────────────────────────────────────────────────
def _γ_asset_watch():
    """
    Start watching for new assets in the seed_assets directory.
    This function is the entry point from singularity_boot.py.
    """
    global asset_watcher
    
    if asset_watcher:
        asset_watcher.start_watching()
    else:
        logger.warning("Asset watcher system not initialized")

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(
    base_dir: Path,
    consume_block_function: Callable,
    scan_interval: int = 15,
    logger=None,
    autostart: bool = True
) -> AssetWatcherSystem:
    """
    Initialize the asset watcher system.
    
    Args:
        base_dir: Base directory of the application
        consume_block_function: Function to process text content
        scan_interval: How often to scan for new files (seconds)
        logger: Logger instance
        autostart: Whether to start watching automatically
        
    Returns:
        Initialized AssetWatcherSystem
    """
    global asset_watcher
    global _consume_block_function, _logger
    
    logger = logger or logging.getLogger("singularity.asset_watcher")
    logger.info("Initializing asset watcher system")
    
    # Store references to required functions
    _consume_block_function = consume_block_function
    _logger = logger
    
    # Create asset watcher system
    asset_watcher = AssetWatcherSystem(
        base_dir=base_dir,
        consume_block_function=consume_block_function,
        scan_interval=scan_interval,
        logger=logger
    )
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Asset watcher system initialized in {_STATS['init_time_ms']} ms")
    
    # Start watching if requested
    if autostart:
        asset_watcher.start_watching()
    
    return asset_watcher

def health_check() -> dict:
    """
    Perform a health check on the asset watcher system.
    
    Returns:
        Dictionary with health status information
    """
    global asset_watcher
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not asset_watcher:
        status = "error"
        warnings.append("Asset watcher system not initialized")
    else:
        try:
            # Check dependencies
            dependencies = {
                "consume_block": asset_watcher.consume_block is not None,
            }
            
            details["dependencies"] = dependencies
            
            # Check if watcher thread is running
            thread_running = (_watcher_thread is not None and _watcher_thread.is_alive())
            details["thread_running"] = thread_running
            
            if not thread_running:
                if status != "error":
                    status = "warning"
                warnings.append("Asset watcher thread is not running")
            
            # Directory checks
            asset_dir_exists = asset_watcher.asset_dir.exists()
            asset_dir_readable = os.access(asset_watcher.asset_dir, os.R_OK)
            
            details["asset_dir_exists"] = asset_dir_exists
            details["asset_dir_readable"] = asset_dir_readable
            
            if not asset_dir_exists:
                status = "error"
                warnings.append(f"Asset directory does not exist: {asset_watcher.asset_dir}")
            elif not asset_dir_readable:
                status = "error"
                warnings.append(f"Asset directory is not readable: {asset_watcher.asset_dir}")
            
            # Check scan time
            with _stats_lock:
                last_scan_time = _STATS.get("last_scan_time", 0)
            
            if last_scan_time > 5:  # More than 5 seconds is suspicious
                if status != "error":
                    status = "warning"
                warnings.append(f"Last scan took {last_scan_time:.2f} seconds, which is high")
            
            # Check seen files count
            with _files_lock:
                seen_files_count = len(_seen_files)
            
            details["seen_files_count"] = seen_files_count
            
        except Exception as e:
            status = "error"
            warnings.append(f"Asset watcher system error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "asset_watcher",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the asset watcher system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def rescan_all():
    """
    Force a rescan of all files in the seed_assets directory.
    This will process all files again, regardless of whether they've been seen before.
    """
    global asset_watcher, _seen_files
    
    if not asset_watcher:
        logger.warning("Asset watcher system not initialized")
        return False
    
    try:
        # Clear the seen files set to force reprocessing
        with _files_lock:
            _seen_files.clear()
        
        logger.info("Forced rescan of all seed assets initiated")
        return True
    except Exception as e:
        logger.error(f"Error initiating rescan: {e}")
        return False

def shutdown() -> None:
    """
    Perform clean shutdown of asset watcher system resources.
    """
    global asset_watcher
    
    if asset_watcher:
        logger.info("Shutting down asset watcher system")
        asset_watcher.stop_watching()

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_asset_watcher_status() -> None:
    """
    Command handler for /asset-status
    """
    if not asset_watcher:
        print("Asset watcher system not initialized")
        return
    
    health = health_check()
    
    print("\nAsset Watcher System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    print("\nDetails:")
    for name, value in health["details"].items():
        status_symbol = "✓" if value else "✗"
        print(f"  {name}: {status_symbol}")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

def _cmd_asset_rescan() -> None:
    """
    Command handler for /asset-rescan
    """
    if not asset_watcher:
        print("Asset watcher system not initialized")
        return
    
    success = rescan_all()
    if success:
        print("Asset rescan initiated successfully")
    else:
        print("Failed to initiate asset rescan")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'rescan_all',
    'AssetWatcherSystem',
    '_γ_asset_watch',
    'asset_watcher',
    '_cmd_asset_watcher_status',
    '_cmd_asset_rescan'
]
