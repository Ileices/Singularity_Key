#!/usr/bin/env python3
"""
Singularity Lexical Classification Module
----------------------------------------
Manages lexical classes and dynamic token weights for the Singularity organism.

Features:
- Token classification into high-level lexical categories
- Static token weights for known classes
- Dynamic token weight learning system for new words
- Thread-safe operations for weight updates
- High-precision numerical handling with Decimal
- Cross-platform path handling with pathlib
- Automatic weight persistence and recovery

This module extends the token-weight system with more sophisticated classifications
and adaptive learning for unknown tokens based on their context.
"""
import re
import os
import json
import time
import logging
import threading
import pathlib
import hashlib
from typing import Dict, Tuple, List, Set, Union, Optional, Callable, Pattern
from decimal import Decimal

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.lexical")

# Thread safety
_token_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "tokens_classified": 0,
    "tokens_learned": 0,
    "weight_updates": 0,
    "cache_hits": 0,
    "errors": 0
}

# Base paths - will be set during initialization
BASE_DIR = pathlib.Path(__file__).parent.resolve()
ECO_DIR = BASE_DIR / "ecosystem"
TOKEN_WEIGHTS_FILE = ECO_DIR / "token_weights.json"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Dependencies
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False
_fnum_func = None  # Will be set to _FNUM from singularity_precision

def initialize(fnum_function, token_weights_from_config=None):
    """
    Initialize the module with required functions and configuration.
    
    Args:
        fnum_function: Function to convert to high-precision numeric type
        token_weights_from_config: Initial token weights dictionary from config
    """
    global _fnum_func, _initialized, STATIC_TOKEN_W
    
    with _token_lock:
        _fnum_func = fnum_function
        
        # Initialize static token weights with high precision
        if token_weights_from_config:
            STATIC_TOKEN_W = _initialize_static_weights(token_weights_from_config)
            # Add default weights for new classes if they don't exist
            STATIC_TOKEN_W = _update_static_weights_with_defaults(STATIC_TOKEN_W)
        
        # Load any saved dynamic weights
        _load_dynamic_weights()
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info(f"Lexical module initialized successfully with {len(STATIC_TOKEN_W)} static classes")

def _initialize_static_weights(config_weights):
    """Convert config weights to high precision using _fnum_func."""
    result = {}
    
    if not _fnum_func:
        logger.warning("High precision function not available, using floats")
        return config_weights
    
    try:
        for class_name, weights in config_weights.items():
            if isinstance(weights, (list, tuple)) and len(weights) == 3:
                result[class_name] = (
                    _fnum_func(str(weights[0])),
                    _fnum_func(str(weights[1])),
                    _fnum_func(str(weights[2]))
                )
            else:
                logger.warning(f"Invalid weight format for {class_name}: {weights}")
                result[class_name] = config_weights[class_name]  # Keep original as fallback
    except Exception as e:
        logger.error(f"Error initializing static weights: {e}")
        _metrics["errors"] += 1
        return config_weights  # Return original on error
    
    return result

def _update_static_weights_with_defaults(token_weights_dict):
    """
    Update the static token weights with the default values for new classes.
    This ensures backward compatibility with old config files.
    """
    if not _fnum_func:
        return token_weights_dict
    
    # Define default weights for new classes
    default_weights = {
        # Stop/function words – almost zero execution value
        "stop": (_fnum_func("0.01"), _fnum_func("0.05"), _fnum_func("0.02")),
        "conj": (_fnum_func("0.02"), _fnum_func("0.08"), _fnum_func("0.02")),
        
        # Question words – cognition-heavy
        "qword": (_fnum_func("0.05"), _fnum_func("0.85"), _fnum_func("0.10")),
        
        # Auxiliaries / light verbs
        "aux": (_fnum_func("0.10"), _fnum_func("0.30"), _fnum_func("0.60")),
        
        # State adjectives
        "state": (_fnum_func("0.25"), _fnum_func("0.55"), _fnum_func("0.20")),
        
        # Numeric tokens
        "number": (_fnum_func("0.40"), _fnum_func("0.50"), _fnum_func("0.10")),
    }
    
    # Add default weights if not already in the token_weights_dict
    result = token_weights_dict.copy()
    for cls, weights in default_weights.items():
        if cls not in result:
            result[cls] = weights
    
    return result

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Static Token Weights and Word Classes
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Default static weights will be populated during initialization
STATIC_TOKEN_W = {}

# Word class regex patterns
_WORD_CLASS = [
    # HIGH-PRIORITY specialised classes first
    ("stop", re.compile(r"^(?:a|an|the|and|or|of|in|on|to|for|with|as|at|by|from)$", re.I)),
    ("conj", re.compile(r"^(?:but|yet|so|nor|though|although)$", re.I)),
    ("qword", re.compile(r"^(?:who|what|when|where|why|how|which|whom|whose)$", re.I)),
    ("aux", re.compile(r"^(?:do|does|did|dont|doesnt|go|goes|went|try|tries|tried|help|fix|run|make)$", re.I)),
    ("state", re.compile(r"^(?:full|empty|none|complete|incomplete|broken|ready|busy|idle)$", re.I)),
    ("number", re.compile(r"^\d+(\.\d+)?$")),   #  42   3.14159 …

    # legacy specialised classes
    ("imperative", re.compile(r"^(run|build|create|delete)\b", re.I)),
    ("modal",      re.compile(r"^(can|should|must|may|might|could|shall|will|would)\b", re.I)),
    ("negation",   re.compile(r"^(not|never|no|none)$", re.I)),
    ("punct_exec", re.compile(r"^[!?]$")),
]

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Dynamic Token Weight System
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_DYNAMIC_W = {}  # token -> (r, b, y)

def _load_dynamic_weights():
    """Load dynamic weights from the persistent store."""
    if not TOKEN_WEIGHTS_FILE.exists():
        return
    
    try:
        with open(TOKEN_WEIGHTS_FILE, 'r', encoding='utf-8') as f:
            weights_data = json.load(f)
        
        with _token_lock:
            for token, weights in weights_data.items():
                if isinstance(weights, list) and len(weights) == 3:
                    if _fnum_func:
                        _DYNAMIC_W[token] = tuple(_fnum_func(str(w)) for w in weights)
                    else:
                        _DYNAMIC_W[token] = tuple(weights)
        
        logger.info(f"Loaded {len(_DYNAMIC_W)} dynamic token weights")
    except Exception as e:
        logger.error(f"Error loading dynamic weights: {e}")
        _metrics["errors"] += 1

def _save_dynamic_weights():
    """Save dynamic weights to the persistent store."""
    ECO_DIR.mkdir(exist_ok=True)
    
    try:
        # Convert to serializable format
        weights_data = {}
        with _token_lock:
            for token, weights in _DYNAMIC_W.items():
                weights_data[token] = [str(w) for w in weights]
        
        # Write to a temporary file first, then rename for atomicity
        temp_file = TOKEN_WEIGHTS_FILE.with_suffix('.tmp')
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(weights_data, f, indent=2)
        
        # Safe rename
        temp_file.replace(TOKEN_WEIGHTS_FILE)
        
        logger.debug(f"Saved {len(_DYNAMIC_W)} dynamic token weights")
    except Exception as e:
        logger.error(f"Error saving dynamic weights: {e}")
        _metrics["errors"] += 1

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Token Classification and Weight Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def classify_token(token: str) -> str:
    """
    Classify a token into one of the lexical categories.
    
    Args:
        token: The token to classify
        
    Returns:
        The lexical class name
    """
    if not _initialized:
        logger.warning("Lexical module not initialized, using default classification")
        return "unknown"
    
    _metrics["tokens_classified"] += 1
    
    for cls_name, regex in _WORD_CLASS:
        if regex.search(token):
            return cls_name
    
    return "unknown"

def get_token_weight(token: str, default_rby=None):
    """
    Get the RBY weight for a token.
    
    Args:
        token: The token to look up
        default_rby: Default (r, b, y) values to use if token not found
        
    Returns:
        Tuple of (r, b, y) weights
    """
    if not _initialized:
        logger.warning("Lexical module not initialized, using default weights")
        return default_rby or (0.333, 0.333, 0.334)
    
    with _token_lock:
        # First check dynamic weights (learned)
        if token in _DYNAMIC_W:
            _metrics["cache_hits"] += 1
            return _DYNAMIC_W[token]
        
        # Then try to classify and use static weights
        cls_name = classify_token(token)
        if cls_name in STATIC_TOKEN_W:
            return STATIC_TOKEN_W[cls_name]
        
        # Fall back to default if provided
        if default_rby:
            return default_rby
        
        # Last resort: use balanced weights (1/3 each)
        if _fnum_func:
            return (_fnum_func("0.333"), _fnum_func("0.333"), _fnum_func("0.334"))
        else:
            return (0.333, 0.333, 0.334)

def learn_token_weight(token: str, r: Union[float, Decimal], b: Union[float, Decimal], y: Union[float, Decimal]):
    """
    Learn or update the RBY weight for a token.
    
    Args:
        token: The token to update
        r, b, y: The new weight values
        
    Returns:
        True if the update was successful, False otherwise
    """
    if not _initialized:
        logger.warning("Lexical module not initialized, cannot learn token weight")
        return False
    
    try:
        # Normalize to high precision if available
        if _fnum_func:
            r_val = _fnum_func(str(r))
            b_val = _fnum_func(str(b))
            y_val = _fnum_func(str(y))
        else:
            r_val, b_val, y_val = r, b, y
        
        # Update weights with thread safety
        with _token_lock:
            _DYNAMIC_W[token] = (r_val, b_val, y_val)
            _metrics["tokens_learned"] += 1
            _metrics["weight_updates"] += 1
        
        # Periodically save weights (every 100 updates)
        if _metrics["weight_updates"] % 100 == 0:
            _save_dynamic_weights()
        
        return True
    except Exception as e:
        logger.error(f"Error learning token weight: {e}")
        _metrics["errors"] += 1
        return False

def update_token_weight(token: str, r_delta: float, b_delta: float, y_delta: float, learning_rate: float = 0.1):
    """
    Update a token's weight by applying deltas with a learning rate.
    
    Args:
        token: The token to update
        r_delta, b_delta, y_delta: The weight adjustments
        learning_rate: How strongly to apply the update (0.0-1.0)
        
    Returns:
        The new (r, b, y) weights
    """
    if not _initialized:
        logger.warning("Lexical module not initialized, cannot update token weight")
        return None
    
    try:
        # Get current weights
        curr_r, curr_b, curr_y = get_token_weight(token)
        
        # Apply deltas with learning rate
        if _fnum_func:
            new_r = curr_r + _fnum_func(str(r_delta * learning_rate))
            new_b = curr_b + _fnum_func(str(b_delta * learning_rate))
            new_y = curr_y + _fnum_func(str(y_delta * learning_rate))
        else:
            new_r = curr_r + r_delta * learning_rate
            new_b = curr_b + b_delta * learning_rate
            new_y = curr_y + y_delta * learning_rate
        
        # Normalize to ensure sum = 1.0
        total = new_r + new_b + new_y
        if _fnum_func:
            new_r = new_r / total
            new_b = new_b / total
            new_y = new_y / total
        else:
            new_r = new_r / total
            new_b = new_b / total
            new_y = new_y / total
        
        # Store updated weights
        learn_token_weight(token, new_r, new_b, new_y)
        
        return new_r, new_b, new_y
    except Exception as e:
        logger.error(f"Error updating token weight: {e}")
        _metrics["errors"] += 1
        return None

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Contextual Weight Learning
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def tune_unknown_word(token: str, context: str):
    """
    Enhanced unknown-word tuner that assigns an adaptive RBY vector 
    based on the sentence context it first appears in.
    
    Args:
        token: The token to learn weights for
        context: The full sentence or paragraph containing the token
        
    Returns:
        Tuple of (r, b, y) assigned weights
    """
    # If we already know this token, return its weights
    with _token_lock:
        if token in _DYNAMIC_W:
            return _DYNAMIC_W[token]
    
    # Try first to classify it based on regex patterns
    cls_name = classify_token(token)
    if cls_name != "unknown" and cls_name in STATIC_TOKEN_W:
        # We found a class for it, use those static weights
        return STATIC_TOKEN_W[cls_name]
    
    # Advanced context analysis for unknown words
    context_lower = context.lower()
    
    # Initialize with balanced weights
    r, b, y = 0.333, 0.333, 0.334
    
    # Check for context indicators of perception (R)
    perception_indicators = [
        "see", "look", "view", "watch", "observe", "notice", "detect", 
        "sense", "feel", "perceive", "hear", "listen", "touch", "smell"
    ]
    if any(ind in context_lower for ind in perception_indicators):
        r += 0.1
    
    # Check for context indicators of cognition (B)
    cognition_indicators = [
        "think", "know", "understand", "learn", "analyze", "evaluate", 
        "consider", "judge", "reason", "calculate", "compute", "logic",
        "theory", "concept", "idea", "thought", "mind", "brain", "solution"
    ]
    if any(ind in context_lower for ind in cognition_indicators):
        b += 0.1
    
    # Check for context indicators of action/execution (Y)
    action_indicators = [
        "do", "make", "create", "build", "run", "execute", "perform", 
        "act", "go", "move", "start", "stop", "change", "modify", "transform",
        "implement", "operate", "process", "handle", "control"
    ]
    if any(ind in context_lower for ind in action_indicators):
        y += 0.1
    
    # Linguistic features that suggest certain RBY values
    if token.endswith(("ing", "tion", "ment")):
        # Process/action words tend to be execution-oriented
        y += 0.1
    elif token.endswith(("ity", "ism", "logy", "ics")):
        # Abstract concepts tend to be cognition-oriented
        b += 0.1
    elif token.endswith(("able", "ible", "ful", "ous", "ive")):
        # Descriptive adjectives tend to be perception-oriented
        r += 0.1
    
    # Normalize to ensure sum = 1.0
    total = r + b + y
    r, b, y = r/total, b/total, y/total
    
    # Store the learned weights
    learn_token_weight(token, r, b, y)
    
    return r, b, y

learn_from_context = tune_unknown_word

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Batch Operations and Statistics
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def process_text(text: str):
    """
    Process a text and learn weights for any unknown tokens.
    
    Args:
        text: The text to process
    
    Returns:
        Dictionary of tokens and their assigned weights
    """
    if not _initialized:
        logger.warning("Lexical module not initialized, cannot process text")
        return {}
    
    # Simple tokenization (just for demonstration)
    tokens = re.findall(r'\b\w+\b', text.lower())
    
    results = {}
    for token in tokens:
        # Skip tokens we already know
        with _token_lock:
            if token in _DYNAMIC_W:
                results[token] = _DYNAMIC_W[token]
                continue
        
        # Learn from surrounding context for new tokens
        weights = learn_from_context(token, text)
        if weights:
            results[token] = weights
    
    return results

def get_lexical_stats():
    """
    Get statistics about the lexical classification system.
    
    Returns:
        Dictionary of statistics
    """
    with _token_lock:
        dynamic_count = len(_DYNAMIC_W)
        static_count = len(STATIC_TOKEN_W)
    
    stats = {
        "static_classes": static_count,
        "dynamic_tokens": dynamic_count,
        "total_vocabulary": static_count + dynamic_count,
        "classifications": _metrics["tokens_classified"],
        "learning_events": _metrics["tokens_learned"],
        "cache_hit_rate": (_metrics["cache_hits"] / max(1, _metrics["tokens_classified"])) * 100,
        "errors": _metrics["errors"]
    }
    
    return stats

def health_check():
    """
    Perform a health check on the lexical module.
    
    Returns:
        Dictionary with status and metrics
    """
    status = "healthy"
    details = {}
    
    # Check initialization
    if not _initialized:
        status = "error"
        details["initialization"] = "Module not initialized"
        return {
            "status": status,
            "metrics": _metrics,
            "details": details,
            "timestamp": time.time()
        }
    
    # Check disk persistence
    try:
        _save_dynamic_weights()
        details["persistence"] = "OK"
    except Exception as e:
        status = "warning"
        details["persistence"] = f"Failed: {e}"
    
    # Check error metrics
    if _metrics["errors"] > 0:
        status = "warning"
        details["errors"] = f"{_metrics['errors']} errors encountered"
    
    # Get vocabulary stats
    stats = get_lexical_stats()
    
    return {
        "status": status,
        "metrics": _metrics,
        "vocabulary": stats,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_WORD_CLASS": _WORD_CLASS,
        "STATIC_TOKEN_W": STATIC_TOKEN_W,
        "_DYNAMIC_W": _DYNAMIC_W,
        "get_token_weight": get_token_weight,
        "update_token_weight": update_token_weight
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_lexical instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Shutdown Handler
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def shutdown():
    """
    Clean shutdown procedure. Save weights and release resources.
    """
    if not _initialized:
        return
    
    try:
        # Save dynamic weights
        _save_dynamic_weights()
        logger.info("Lexical module shutdown complete")
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")

import atexit
atexit.register(shutdown)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'STATIC_TOKEN_W',
    '_WORD_CLASS',
    'classify_token',
    'get_token_weight',
    'learn_token_weight',
    'update_token_weight',
    'learn_from_context',
    'tune_unknown_word',
    'process_text',
    'get_lexical_stats',
    'health_check',
    'shutdown'
]

# Module self-test
if __name__ == "__main__":
    from decimal import Decimal
    
    def mock_fnum(s):
        return Decimal(s)
    
    print("Running singularity_lexical self-test...")
    
    # Mock initialization
    initialize(mock_fnum, {
        "imperative": (0.05, 0.15, 0.80),
        "modal": (0.15, 0.70, 0.15)
    })
    
    # Test classification
    test_tokens = ["the", "but", "why", "does", "empty", "42", "run", "can", "not", "?", "python"]
    print("\nToken Classification:")
    for token in test_tokens:
        cls = classify_token(token)
        print(f"  '{token}' → {cls}")
    
    # Test weight lookup
    print("\nToken Weights:")
    for token in test_tokens:
        r, b, y = get_token_weight(token)
        print(f"  '{token}' → R={r:.3f}, B={b:.3f}, Y={y:.3f}")
    
    # Test learning
    test_contexts = [
        "I can see the mountain from here.",
        "Let me think about the problem carefully.",
        "Please run this program immediately."
    ]
    
    print("\nLearning from context:")
    for context in test_contexts:
        print(f"  Context: '{context}'")
        tokens = re.findall(r'\b\w+\b', context.lower())
        for token in tokens[:2]:  # Just test the first couple tokens
            r, b, y = learn_from_context(token, context)
            print(f"    '{token}' → R={r:.3f}, B={b:.3f}, Y={y:.3f}")
    
    # Test health check
    health = health_check()
    print(f"\nHealth check: {health['status']}")
    print(f"Vocabulary size: {health['vocabulary']['dynamic_tokens']} tokens")
