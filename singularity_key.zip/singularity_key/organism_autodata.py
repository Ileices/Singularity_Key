"""
organism_autodata.py
────────────────────────────────────────────────────────────────────────────
Zero-config data discovery, curation & continuous ingestion for Singularity.

• On start it pops a GUI asking *which drives / folders* to treat as the
  organism's personal universe.  Choices are remembered.
• A background thread walks those trees forever (low-priority I/O),
  classifies every file (video / audio / code / text / image / archive …),
  and writes a compact JSON stub into `ecosystem/corpus/stubs-YYYYMMDD.parquet`
  plus an on-demand "read-once" copy into `ecosystem/seed_assets/`.
• New file-types automatically register a handler by simple `@register` decorator.
• When the user clicks **'Ingest NOW'** the current queue is flushed through
  `singularity_boot._consume_block()` (with the LECTURE weight multiplier).
• All heavy lifting (speech-->text, OCR, frame sampling, syntax strip, …) is
  *lazy*: only triggered when the training loop first requests that stub.

Drop-in: requires only `pip install watchdog pyarrow pillow pytesseract ffmpeg-python`.
"""
from __future__ import annotations
import os, threading, queue, json, pathlib, shutil, mimetypes, datetime as _dt
from functools import wraps
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from tkinter import Tk, filedialog, ttk, messagebox
import pyarrow as pa, pyarrow.parquet as pq

BASE        = pathlib.Path(__file__).parent.resolve()
ECO         = BASE / "ecosystem"
STUBS_DIR   = ECO / "corpus";      STUBS_DIR.mkdir(parents=True, exist_ok=True)
ASSET_DIR   = ECO / "seed_assets"

########################################################################
# 1. SIMPLE PLUG-IN REGISTRY                                            #
########################################################################
_HANDLERS: dict[str, callable] = {}
def register(exts: str|tuple[str,...]):          # decorator
    def deco(fn):
        for e in ([exts] if isinstance(exts,str) else exts):
            _HANDLERS[e.lower()] = fn
        return fn
    return deco

@register((".txt",".md",".rst",".log"))
def _text_stub(path: pathlib.Path)->dict:
    txt = path.read_text(errors="ignore")[:32_000]
    return {"kind":"text","chars":len(txt),"preview":txt[:240]}

@register((".py",".js",".ts",".java",".cpp",".c",".html",".css"))
def _code_stub(path):
    src = path.read_text(errors="ignore")[:60_000]
    return {"kind":"code","lines":src.count("\n"),"preview":src[:240]}

@register((".mp4",".mkv",".webm",".mov"))
def _video_stub(path):
    # lazy: do NOT decode now
    return {"kind":"video","bytes":path.stat().st_size}

@register((".mp3",".wav",".flac"))
def _audio_stub(path):
    return {"kind":"audio","bytes":path.stat().st_size}

@register((".png",".jpg",".jpeg",".gif",".bmp",".tiff"))
def _image_stub(path):
    return {"kind":"image","bytes":path.stat().st_size}

########################################################################
# 2. WATCHDOG + QUEUE                                                  #
########################################################################
_EVENT_Q: queue.Queue[pathlib.Path] = queue.Queue()
class _Handler(FileSystemEventHandler):
    def on_created(self, ev): 
        if not ev.is_directory: _EVENT_Q.put(pathlib.Path(ev.src_path))
    on_modified = on_created

def _walker_thread(watch_paths:set[pathlib.Path]):
    for p in list(watch_paths):
        for root,_,files in os.walk(p):
            for f in files: _EVENT_Q.put(pathlib.Path(root)/f)
    obs = Observer()
    handler = _Handler()
    for p in watch_paths: obs.schedule(handler, str(p), recursive=True)
    obs.start()
    while True: 
        try: obs.join(1)
        except KeyboardInterrupt: obs.stop(); break

########################################################################
# 3. STUB WRITER                                                       #
########################################################################
def _write_parquet(batch:list[dict]):
    day = _dt.datetime.utcnow().strftime("%Y%m%d")
    path = STUBS_DIR / f"stubs-{day}.parquet"
    table = pa.Table.from_pylist(batch)
    if path.exists():
        old = pq.read_table(path)
        table = pa.concat_tables([old, table])
    pq.write_table(table, path)

def _ingest_loop():
    batch=[]
    while True:
        try: path = _EVENT_Q.get(timeout=2)
        except queue.Empty:
            if batch: _write_parquet(batch); batch=[]; continue
            continue
        ext = path.suffix.lower()
        h   = _HANDLERS.get(ext)
        if not h: continue          # unsupported type
        try:
            stub = h(path)
            stub.update({"path":str(path),"mtime":path.stat().st_mtime})
            # quick copy into seed_assets (idempotent)
            dst = ASSET_DIR/ f"auto_{path.name}"
            if not dst.exists():
                shutil.copy2(path, dst, follow_symlinks=False)
            batch.append(stub)
        except Exception as e:
            print("stub-error:",e)

########################################################################
# 4. USER GUI                                                          #
########################################################################
_cfg_file = ECO / "autodata_config.json"
def _load_cfg():  return json.loads(_cfg_file.read_text()) if _cfg_file.exists() else {}
def _save_cfg(cfg): _cfg_file.write_text(json.dumps(cfg,indent=2))

# Enhance flush_to_organism to properly integrate with singularity_boot

def flush_to_organism():
    """Flush queued data through the organism's consumption pipeline."""
    try:
        # Import dynamically to avoid circular imports
        import sys, os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        
        from singularity_boot import _γ_consume_block
        
        batch_size = 0
        processed_files = []
        
        # Process the current batch in EVENT_Q
        while not _EVENT_Q.empty() and batch_size < 50:  # Limit batch size
            try:
                path = _EVENT_Q.get_nowait()
                ext = path.suffix.lower()
                h = _HANDLERS.get(ext)
                
                if not h:
                    continue  # Unsupported type
                
                try:
                    # Read content
                    if ext in (".txt", ".md", ".rst", ".log", ".py", ".js", ".ts", ".java", ".cpp", ".c", ".html", ".css"):
                        content = path.read_text(errors="ignore")
                        # Process through organism's consume block
                        _γ_consume_block(content, seq=int(time.time() % 10_000))
                        processed_files.append(path.name)
                        batch_size += 1
                except Exception as e:
                    print(f"Error processing {path}: {e}")
            except queue.Empty:
                break
                
        if processed_files:
            print(f"Ingested {len(processed_files)} files: {', '.join(processed_files[:5])}" + 
                  (f" and {len(processed_files) - 5} more..." if len(processed_files) > 5 else ""))
        else:
            print("No files to ingest at this time.")
            
    except ImportError as e:
        print(f"WARNING: Could not import required functions - {e}")
        print("Make sure singularity_boot.py is accessible.")

def _add_ingest_button(root):
    """Add 'Ingest NOW' button to the GUI."""
    import tkinter as tk
    from tkinter import ttk
    
    ttk.Button(root, text="Ingest NOW", command=flush_to_organism).pack(side="right", padx=8)

def gui_pick_folders():
    cfg = _load_cfg()
    root = Tk(); root.title("Singularity – data universe picker")
    sel  = ttk.Treeview(root); sel.pack(expand=True,fill="both",padx=8,pady=8)
    for p in cfg.get("paths",[]):
        sel.insert("", "end", p, text=p)
    def _add():
        paths = filedialog.askdirectory(mustexist=True, multiple=True)
        for p in paths: sel.insert("", "end", p, text=p)
    def _rem():
        for i in sel.selection(): sel.delete(i)
    ttk.Button(root,text="Add...", command=_add).pack(side="left",padx=4,pady=4)
    ttk.Button(root,text="Remove", command=_rem).pack(side="left",padx=4)
    _add_ingest_button(root)
    def _ok():
        cfg["paths"]=[sel.item(i,"text") for i in sel.get_children("")]
        _save_cfg(cfg); root.destroy()
    ttk.Button(root,text="Start ingest", command=_ok).pack(side="right",padx=8)
    root.mainloop()
    return [pathlib.Path(p) for p in cfg.get("paths",[])]

########################################################################
# 5.  PUBLIC START FUNCTION                                            #
########################################################################
def start_autodata():
    paths = gui_pick_folders()
    if not paths: 
        messagebox.showinfo("Abort","No folders selected – autodata disabled.")
        return
    threading.Thread(target=_walker_thread, args=(set(paths),), daemon=True).start()
    threading.Thread(target=_ingest_loop, daemon=True).start()
    print("[autodata] watching", len(paths), "paths   (close window to stop)")

# call immediately when imported
start_autodata()
