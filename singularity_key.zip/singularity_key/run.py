#!/usr/bin/env python3
"""
Singularity Runner
-----------------
Entry point script for running the Singularity framework.
"""
import os
import sys
import subprocess
import argparse
from pathlib import Path

def check_environment():
    """Check if the environment is properly set up."""
    from singularity_utils import check_dependencies
    return check_dependencies()

def install_dependencies():
    """Install all dependencies."""
    subprocess.run([sys.executable, "install_deps.py"])

def create_directories():
    """Create necessary directories if they don't exist."""
    os.makedirs("ecosystem", exist_ok=True)
    os.makedirs("ecosystem/corpus", exist_ok=True)
    os.makedirs("ecosystem/models", exist_ok=True)
    os.makedirs("ecosystem/glyph_archive", exist_ok=True)
    os.makedirs("ecosystem/vectordb", exist_ok=True)
    os.makedirs("ecosystem/seed_assets", exist_ok=True)
    os.makedirs("ecosystem/lectures", exist_ok=True)
    os.makedirs("ecosystem/drafts", exist_ok=True)
    os.makedirs("ecosystem/projects", exist_ok=True)
    os.makedirs("ecosystem/capsules", exist_ok=True)
    os.makedirs("ecosystem/scratch", exist_ok=True)

def main():
    parser = argparse.ArgumentParser(description="Singularity Framework Runner")
    parser.add_argument('--install', action='store_true', help='Install dependencies')
    parser.add_argument('--manual', action='store_true', help='Run in manual mode')
    parser.add_argument('--cuda', action='store_true', help='Force CUDA usage')
    parser.add_argument('--cpu', action='store_true', help='Force CPU usage')
    
    args = parser.parse_args()
    
    if args.install:
        install_dependencies()
        return
    
    create_directories()
    
    if not check_environment():
        print("Environment check failed.")
        answer = input("Would you like to install dependencies now? (y/n): ")
        if answer.lower() in ('y', 'yes'):
            install_dependencies()
        else:
            print("Please install dependencies manually and try again.")
            return
    
    # Prepare command line arguments
    cmd_args = [sys.executable, "singularity_boot.py"]
    if args.manual:
        cmd_args.append("--manual")
    
    # Set environment variables if needed
    env = os.environ.copy()
    if args.cuda:
        env["FORCE_CUDA"] = "1"
    if args.cpu:
        env["FORCE_CPU"] = "1"
    
    try:
        subprocess.run(cmd_args, env=env)
    except KeyboardInterrupt:
        print("\nSingularity stopped by user.")
    
if __name__ == "__main__":
    main()
