#!/usr/bin/env python3
"""
Singularity Fact Extractor Module
---------------------------------
Sophisticated fact extraction and knowledge persistence mechanisms for the Singularity organism.

Features:
- Extracts (subject, predicate, object) triples from text using pattern matching
- Persists facts to both the periodic table and knowledge databases
- Thread-safe database operations with proper locking
- Integrated with RBY cycle for energy/DNA reflection
- Basic question answering capabilities using stored knowledge
- Cross-platform path handling and UTF-8 encoding

This module extends the pattern-based fact extraction system with persistence
capabilities and a minimalist deterministic QA engine.
"""
import re
import os
import time
import json
import logging
import threading
import sqlite3
import pathlib
import hashlib as _h
from typing import List, Dict, Tuple, Callable, Optional, Any, Union, Pattern, Match
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.fact_extractors")

# Thread safety
_db_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "facts_extracted": 0,
    "facts_persisted": 0,
    "errors": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Database Connections and Paths
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Import database connections - will be populated from singularity_boot.py
_initialized = False
_ptdb_connection = None  # Periodic table database connection
_kdb_connection = None   # Knowledge database connection

# Base paths - will be set during initialization
BASE = pathlib.Path(__file__).parent.resolve()
ECO = BASE / "ecosystem"

# Import key functions needed by this module - will be set during initialization
_glyph_id_fn = None
_trifecta_fn = None
_pattern_list = []

def initialize(ptdb_con, kdb_con, glyph_id_function, trifecta_function, fact_patterns):
    """
    Initialize the module with required connections and functions.
    
    Args:
        ptdb_con: Connection to the periodic table database
        kdb_con: Connection to the knowledge database
        glyph_id_function: Function to generate glyph IDs
        trifecta_function: Function to feed into RBY cycle
        fact_patterns: List of regex patterns and handler functions
    """
    global _ptdb_connection, _kdb_connection, _glyph_id_fn, _trifecta_fn, _pattern_list, _initialized
    
    with _db_lock:
        _ptdb_connection = ptdb_con
        _kdb_connection = kdb_con
        _glyph_id_fn = glyph_id_function
        _trifecta_fn = trifecta_function
        _pattern_list = fact_patterns
        _initialized = True
        
    _verify_connections()
    logger.info("Fact extractor module initialized successfully.")
    _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000

def _verify_connections():
    """Verify database connections are working."""
    try:
        if _ptdb_connection:
            _ptdb_connection.execute("SELECT 1")
        if _kdb_connection:
            _kdb_connection.execute("SELECT 1")
    except sqlite3.Error as e:
        logger.error(f"Database connection error: {e}")
        _metrics["errors"] += 1
        raise RuntimeError(f"Failed to verify database connections: {e}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Fact Extraction and Persistence
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def persist_fact(line: str) -> bool:
    """
    Try to harvest (subject,predicate,object) from *line* into periodic-table DB.
    
    Args:
        line: Text line to analyze
        
    Returns:
        True if a fact was successfully extracted and persisted
    """
    if not _initialized:
        logger.error("Fact extractor not initialized")
        return False
    
    _verify_connections()
    
    for rx, fn in _pattern_list:
        m = rx.match(line)
        if not m:                                  # no match → keep trying
            continue
            
        try:
            subj, pred, obj = fn(m)

            # 1) store in DB  (subject & object as rows, predicate inside axiom)
            gid = _glyph_id_fn(f"{subj}|{pred}|{obj}".encode())
            with _db_lock:
                with _ptdb_connection:                                  # transaction
                    _ptdb_connection.execute("INSERT OR IGNORE INTO term(term,glyph) VALUES(?,?)", (subj, gid))
                    _ptdb_connection.execute("INSERT OR IGNORE INTO term(term,glyph) VALUES(?,?)", (obj, gid))
                    _ptdb_connection.execute(
                      "INSERT OR IGNORE INTO axiom(glyph,title,latex,definition)"
                      "VALUES(?,?,?,?)",
                      (gid, pred, pred, f"{subj} {pred} {obj}")
                    )

            # 2) optional console feedback
            logger.info(f"[FACT] {subj} ▸{pred}▸ {obj}  → {gid}")

            # 3) feed into RBY cycle once so ENERGY / DNA reflect it
            _trifecta_fn(f"{subj} {pred} {obj}", weight=0.2)
            
            # Update metrics
            _metrics["facts_extracted"] += 1
            _metrics["facts_persisted"] += 1
            
            return True                     # stop after the first successful pattern
        except Exception as e:
            logger.error(f"Error persisting fact: {e}")
            _metrics["errors"] += 1
            return False
    
    return False

def learn_fact(line: str) -> bool:
    """
    Try to parse *line* and insert a fact if pattern matches into the knowledge database.
    
    Args:
        line: Text line to analyze
        
    Returns:
        True if a fact was successfully parsed and stored
    """
    if not _initialized:
        logger.error("Fact extractor not initialized")
        return False
    
    _verify_connections()
    
    for rx, builder in _pattern_list:
        m = rx.match(line)
        if m:
            try:
                subj, pred, obj = builder(m)
                with _db_lock:
                    _kdb_connection.execute("INSERT OR IGNORE INTO fact(subj,pred,obj) VALUES(?,?,?)",
                                 (subj.lower(), pred.lower(), obj))
                    _kdb_connection.commit()
                
                # Update metrics
                _metrics["facts_extracted"] += 1
                
                return True
            except Exception as e:
                logger.error(f"Knowledge-insert failed: {e}")
                _metrics["errors"] += 1
                return False
    
    return False

def learn_fact_tuple(subject: str, predicate: str, object_val: str, confidence: float = 1.0) -> bool:
    """
    Directly store a fact tuple into the knowledge database.
    
    Args:
        subject: Subject of the fact
        predicate: Predicate/relation
        object_val: Object of the fact
        confidence: Confidence score (0.0-1.0)
    
    Returns:
        True if the fact was successfully stored
    """
    if not _initialized:
        logger.error("Fact extractor not initialized")
        return False
    
    _verify_connections()
    
    try:
        with _db_lock:
            _kdb_connection.execute(
                "INSERT OR IGNORE INTO fact(subj,pred,obj,confidence) VALUES(?,?,?,?)",
                (subject.lower(), predicate.lower(), object_val, confidence)
            )
            _kdb_connection.commit()
        
        # Also persist to periodic table DB for comprehensiveness
        gid = _glyph_id_fn(f"{subject}|{predicate}|{object_val}".encode())
        with _db_lock:
            with _ptdb_connection:
                _ptdb_connection.execute("INSERT OR IGNORE INTO term(term,glyph) VALUES(?,?)", 
                               (subject, gid))
                _ptdb_connection.execute("INSERT OR IGNORE INTO term(term,glyph) VALUES(?,?)", 
                               (object_val, gid))
                _ptdb_connection.execute(
                    "INSERT OR IGNORE INTO axiom(glyph,title,latex,definition) VALUES(?,?,?,?)",
                    (gid, predicate, predicate, f"{subject} {predicate} {object_val}")
                )
        
        # Feed into RBY cycle with confidence as weight
        _trifecta_fn(f"{subject} {predicate} {object_val}", weight=confidence)
        
        # Update metrics
        _metrics["facts_persisted"] += 1
        
        return True
    except Exception as e:
        logger.error(f"Error storing fact tuple: {e}")
        _metrics["errors"] += 1
        return False

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Simple QA System
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def answer(question: str) -> Optional[str]:
    """
    Very small deterministic QA engine.
    
    Args:
        question: Question to answer
        
    Returns:
        Answer if found, None otherwise
    """
    if not _initialized:
        logger.error("Fact extractor not initialized")
        return None
    
    _verify_connections()
    
    q = question.lower().strip().rstrip("?")
    
    try:
        # Check for identity questions
        if q in {"who am i", "what am i"}:
            with _db_lock:
                row = _kdb_connection.execute(
                    "SELECT obj FROM fact WHERE subj='⟂self' AND pred='name'"
                ).fetchone()
                
            if row:
                return f"You are {row[0]}."
        
        # Check for "who is X" questions
        m = re.match(r"who is (.+)", q)
        if m:
            subj = m.group(1).strip()
            with _db_lock:
                row = _kdb_connection.execute(
                    "SELECT obj FROM fact WHERE subj=? AND pred='is'", (subj,)
                ).fetchone()
                
            if row:
                return f"{subj} is {row[0]}."
        
        # Check for "what is X" questions
        m = re.match(r"what is (.+)", q)
        if m:
            subj = m.group(1).strip()
            with _db_lock:
                row = _kdb_connection.execute(
                    "SELECT obj FROM fact WHERE subj=? AND pred='is'", (subj,)
                ).fetchone()
                
            if row:
                return f"{subj} is {row[0]}."
                
        # Extended queries for other predicates
        m = re.match(r"(?:what|who) (?:is|are) the (\w+) of (.+)", q)
        if m:
            pred = m.group(1).strip()
            subj = m.group(2).strip()
            with _db_lock:
                row = _kdb_connection.execute(
                    "SELECT obj FROM fact WHERE subj=? AND pred=?", (subj, pred)
                ).fetchone()
                
            if row:
                return f"The {pred} of {subj} is {row[0]}."
                
    except Exception as e:
        logger.error(f"Error in answer generation: {e}")
        _metrics["errors"] += 1
    
    return None

def enhanced_answer(question: str) -> Optional[str]:
    """
    Enhanced QA engine that searches more broadly through facts.
    
    Args:
        question: Question to answer
        
    Returns:
        Answer if found, None otherwise
    """
    # First try the basic deterministic QA
    basic_answer = answer(question)
    if basic_answer:
        return basic_answer
    
    # If not found, try a more flexible approach
    q = question.lower().strip().rstrip("?")
    words = set(re.findall(r'\b\w+\b', q))
    
    try:
        with _db_lock:
            # Look for facts where subject contains any word from the question
            results = []
            for word in words:
                if len(word) < 3:  # Skip short words
                    continue
                    
                rows = _kdb_connection.execute(
                    "SELECT subj, pred, obj FROM fact WHERE subj LIKE ?", (f"%{word}%",)
                ).fetchall()
                
                results.extend(rows)
                
                # Also try object field
                rows = _kdb_connection.execute(
                    "SELECT subj, pred, obj FROM fact WHERE obj LIKE ?", (f"%{word}%",)
                ).fetchall()
                
                results.extend(rows)
            
            if results:
                # Simple relevance ranking - prioritize facts with more question words
                def relevance_score(fact):
                    subj, pred, obj = fact
                    text = f"{subj} {pred} {obj}".lower()
                    return sum(1 for word in words if word in text)
                
                results.sort(key=relevance_score, reverse=True)
                
                # Construct response using the most relevant fact
                subj, pred, obj = results[0]
                return f"I know that {subj} {pred} {obj}."
                
    except Exception as e:
        logger.error(f"Error in enhanced answer generation: {e}")
        _metrics["errors"] += 1
    
    return None

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics() -> Dict[str, Union[int, float]]:
    """Get metrics about fact extraction operations."""
    with _db_lock:
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """Perform a health check on the fact extractor subsystem."""
    status = "healthy"
    details = {}
    
    # Check for initialization
    if not _initialized:
        status = "error"
        details["initialization"] = "Module not initialized"
        return {
            "status": status,
            "metrics": _metrics,
            "details": details,
            "timestamp": time.time()
        }
    
    # Check database connections
    try:
        _verify_connections()
        details["connections"] = "OK"
    except Exception as e:
        status = "error"
        details["connections"] = f"Failed: {e}"
    
    # Check error metrics
    if _metrics["errors"] > 0:
        status = "warning" if status == "healthy" else status
        details["errors"] = f"{_metrics['errors']} errors encountered"
    
    # Check fact extraction efficiency
    if _metrics["facts_extracted"] > 0:
        persistence_rate = _metrics["facts_persisted"] / _metrics["facts_extracted"]
        details["persistence_rate"] = f"{persistence_rate:.2%}"
        
        if persistence_rate < 0.5:  # Less than 50% persistence rate is concerning
            status = "warning" if status == "healthy" else status
            details["low_persistence"] = f"Only {persistence_rate:.1%} of extracted facts were persisted"
    
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_persist_fact": persist_fact,
        "_learn_fact": learn_fact,
        "_answer": answer
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_fact_extractors instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'persist_fact',
    'learn_fact',
    'learn_fact_tuple',
    'answer',
    'enhanced_answer',
    'get_metrics',
    'health_check'
]

# Module self-test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"=== Fact Extractor Module Self-Test ===")
    print("Note: This module requires initialization before use.")
    print("Use the initialize() function with database connections and required functions.")
