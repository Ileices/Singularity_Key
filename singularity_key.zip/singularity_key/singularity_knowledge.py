#!/usr/bin/env python3
"""
Singularity Knowledge Module
---------------------------
Manages knowledge database, fact patterns, and semantic triple extraction.

Features:
- Thread-safe database operations for knowledge facts
- Pattern-based fact extraction from text
- Entity linking and reference resolution
- Knowledge graph querying and exploration
- Cross-platform SQLite access with proper locking
- Integration with RBY scoring system

This module serves as the semantic memory and knowledge management system
for the Singularity organism.
"""
import os
import re
import json
import time
import sqlite3
import logging
import hashlib
import threading
import pathlib
from typing import Dict, List, Tuple, Set, Optional, Union, Any
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.knowledge")

# Thread safety
_knowledge_lock = threading.RLock()
_connections = {}  # Thread-local connections
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "facts_stored": 0,
    "facts_retrieved": 0,
    "queries_executed": 0,
    "pattern_matches": 0,
    "errors": 0
}

# Import from other Singularity modules with proper fallback handling
try:
    from singularity_config import CFG, BASE, ECO
except ImportError:
    # Fallback for standalone testing
    import yaml
    BASE = pathlib.Path(__file__).parent.resolve()
    ECO = BASE / "ecosystem"
    ECO.mkdir(exist_ok=True, parents=True)
    
    config_path = BASE / "singularity_config.yml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            CFG = yaml.safe_load(f)
    else:
        CFG = {}

# Setup knowledge database path
KNOWDB = ECO / "knowledge.db"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Database Connection Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_connection() -> sqlite3.Connection:
    """Get a thread-local SQLite connection with proper settings."""
    thread_id = threading.get_ident()
    
    if thread_id not in _connections:
        conn = sqlite3.connect(KNOWDB, isolation_level=None, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        _connections[thread_id] = conn
        
    return _connections[thread_id]

def close_all_connections():
    """Close all database connections."""
    with _knowledge_lock:
        for thread_id, conn in list(_connections.items()):
            try:
                conn.close()
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
            _connections.pop(thread_id, None)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Schema Initialization and Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def initialize_schema() -> bool:
    """Create database schema if it doesn't exist."""
    global _initialized, _metrics
    
    with _knowledge_lock:
        if _initialized:
            return True
            
        start_time = time.time()
        conn = get_connection()
        
        try:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS fact(
              id INTEGER PRIMARY KEY,
              subj TEXT, 
              pred TEXT, 
              obj TEXT,
              confidence REAL DEFAULT 1.0,
              source TEXT,
              timestamp TEXT,
              UNIQUE(subj, pred, obj)
            );
            
            CREATE INDEX IF NOT EXISTS idx_fact_subj ON fact(subj);
            CREATE INDEX IF NOT EXISTS idx_fact_pred ON fact(pred);
            CREATE INDEX IF NOT EXISTS idx_fact_obj ON fact(obj);
            
            CREATE TABLE IF NOT EXISTS entity(
              id INTEGER PRIMARY KEY,
              name TEXT UNIQUE,
              type TEXT,
              canonical_id TEXT,
              data TEXT
            );
            
            CREATE INDEX IF NOT EXISTS idx_entity_name ON entity(name);
            CREATE INDEX IF NOT EXISTS idx_entity_type ON entity(type);
            """)
            
            # Count items for metrics
            _metrics["facts_stored"] = conn.execute("SELECT COUNT(*) FROM fact").fetchone()[0]
            
            _initialized = True
            _metrics["init_time_ms"] = (time.time() - start_time) * 1000
            
            logger.info(f"Knowledge DB initialized with {_metrics['facts_stored']} facts")
            return True
            
        except Exception as e:
            _metrics["errors"] += 1
            logger.error(f"Error initializing schema: {e}")
            return False

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Fact Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def add_fact(subject: str, predicate: str, object_val: str, 
             confidence: float = 1.0, source: str = "manual") -> bool:
    """
    Add a fact triple to the knowledge database.
    
    Args:
        subject: The subject entity
        predicate: The relationship predicate
        object_val: The object entity or value
        confidence: Confidence score (0.0-1.0)
        source: Source of the fact
        
    Returns:
        True if successful, False otherwise
    """
    initialize_schema()
    
    with _knowledge_lock:
        conn = get_connection()
        try:
            # Normalize the inputs
            subject = subject.strip().lower()
            predicate = predicate.strip().lower()
            object_val = object_val.strip()
            timestamp = datetime.now().isoformat()
            
            conn.execute("""
            INSERT OR IGNORE INTO fact(subj, pred, obj, confidence, source, timestamp) 
            VALUES(?, ?, ?, ?, ?, ?)
            """, (subject, predicate, object_val, confidence, source, timestamp))
            
            # Only update metrics if a row was actually inserted
            cursor = conn.execute("""
            SELECT changes() as changes
            """)
            changes = cursor.fetchone()["changes"]
            if changes > 0:
                _metrics["facts_stored"] += 1
                
            _metrics["queries_executed"] += 1
            return True
        except Exception as e:
            _metrics["errors"] += 1
            logger.error(f"Error adding fact: {e}")
            return False

def get_facts_by_subject(subject: str) -> List[Dict[str, Any]]:
    """
    Get all facts for a given subject.
    
    Args:
        subject: The subject to query
        
    Returns:
        List of fact dictionaries
    """
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        result = []
        for row in conn.execute(
            "SELECT * FROM fact WHERE subj = ? ORDER BY confidence DESC", 
            (subject.lower(),)
        ):
            result.append({
                "id": row["id"],
                "subject": row["subj"],
                "predicate": row["pred"],
                "object": row["obj"],
                "confidence": row["confidence"],
                "source": row["source"],
                "timestamp": row["timestamp"]
            })
            
        _metrics["facts_retrieved"] += len(result)
        return result
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error querying facts by subject: {e}")
        return []

def search_facts(query: str) -> List[Dict[str, Any]]:
    """
    Search facts by subject, predicate, or object.
    
    Args:
        query: The text to search for
        
    Returns:
        List of matching fact dictionaries
    """
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        pattern = f"%{query.lower()}%"
        
        sql = """
        SELECT * FROM fact 
        WHERE subj LIKE ? 
           OR pred LIKE ? 
           OR obj LIKE ? 
        ORDER BY confidence DESC
        LIMIT 50
        """
        
        result = []
        for row in conn.execute(sql, (pattern, pattern, pattern)):
            result.append({
                "id": row["id"],
                "subject": row["subj"],
                "predicate": row["pred"],
                "object": row["obj"],
                "confidence": row["confidence"],
                "source": row["source"],
                "timestamp": row["timestamp"]
            })
            
        _metrics["facts_retrieved"] += len(result)
        return result
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error searching facts: {e}")
        return []

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Fact Pattern Extraction - Import new advanced patterns
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
try:
    from singularity_patterns import (
        _FACT_PATTERNS, extract_facts as pattern_extract_facts,
        extract_and_store as pattern_extract_and_store
    )
    _advanced_patterns_available = True
    logger.info("Advanced pattern recognition system loaded")
except ImportError:
    _advanced_patterns_available = False
    logger.warning("Advanced pattern recognition not available, using basic patterns")
    # Fallback to the basic patterns that were originally in this file
    _FACT_PATTERNS = [
        # Subject is/are Object
        (re.compile(r"([A-Z][a-zA-Z0-9_\s]+) is ([a-zA-Z0-9_\s]+)"), 
         lambda m: (m.group(1).strip(), "is", m.group(2).strip())),
        
        # Subject are Object
        (re.compile(r"([A-Z][a-zA-Z0-9_\s]+) are ([a-zA-Z0-9_\s]+)"), 
         lambda m: (m.group(1).strip(), "are", m.group(2).strip())),
         
        # Subject has Object
        (re.compile(r"([A-Z][a-zA-Z0-9_\s]+) has ([a-zA-Z0-9_\s]+)"), 
         lambda m: (m.group(1).strip(), "has", m.group(2).strip())),
         
        # Subject contains Object
        (re.compile(r"([A-Z][a-zA-Z0-9_\s]+) contains ([a-zA-Z0-9_\s]+)"), 
         lambda m: (m.group(1).strip(), "contains", m.group(2).strip())),
         
        # Subject consists of Object
        (re.compile(r"([A-Z][a-zA-Z0-9_\s]+) consists of ([a-zA-Z0-9_\s]+)"), 
         lambda m: (m.group(1).strip(), "consists_of", m.group(2).strip())),
         
        # Subject Predicate Object
        (re.compile(r"([A-Z][a-zA-Z0-9_\s]+) ([a-z]+s) ([a-zA-Z0-9_\s]+)"), 
         lambda m: (m.group(1).strip(), m.group(2).strip(), m.group(3).strip())),
    ]

def extract_facts_from_text(text: str, source: str = "auto") -> List[Tuple[str, str, str]]:
    """
    Extract facts from plain text using regex patterns.
    Enhanced to use the advanced pattern system if available.
    
    Args:
        text: The text to analyze
        source: Source identifier
        
    Returns:
        List of (subject, predicate, object) tuples
    """
    # Use advanced pattern system if available
    if _advanced_patterns_available:
        return [(s, p, o) for s, p, o, _ in pattern_extract_and_store(text, source)]
    
    # Original implementation as fallback
    facts = []
    
    # Split by sentences to improve pattern matching
    sentences = re.split(r'[.!?]+', text)
    
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
            
        for pattern, extractor in _FACT_PATTERNS:
            matches = pattern.finditer(sentence)
            for match in matches:
                try:
                    subject, predicate, obj = extractor(match)
                    
                    # Filter out low-quality matches
                    if len(subject) < 2 or len(predicate) < 2 or len(obj) < 2:
                        continue
                        
                    # Add the fact
                    add_fact(subject, predicate, obj, 
                             confidence=0.8,  # Lower confidence for auto-extraction
                             source=source)
                    
                    facts.append((subject, predicate, obj))
                    _metrics["pattern_matches"] += 1
                except Exception as e:
                    logger.debug(f"Fact extraction error: {e}")
                    _metrics["errors"] += 1
    
    return facts

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Knowledge Graph Utilities
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_related_entities(entity: str, max_distance: int = 2) -> Dict[str, List[Dict[str, Any]]]:
    """
    Get entities related to the given entity up to max_distance hops away.
    
    Args:
        entity: The starting entity
        max_distance: Maximum number of relationship hops
        
    Returns:
        Dictionary of entity -> list of facts
    """
    initialize_schema()
    
    with _knowledge_lock:
        visited = set()
        result = {}
        frontier = {entity.lower()}
        
        for distance in range(max_distance):
            if not frontier:
                break
                
            new_frontier = set()
            
            for current in frontier:
                if current in visited:
                    continue
                    
                visited.add(current)
                
                # Get facts where current is the subject
                subj_facts = get_facts_by_subject(current)
                if current not in result:
                    result[current] = []
                result[current].extend(subj_facts)
                
                # Add objects to the frontier
                for fact in subj_facts:
                    new_frontier.add(fact["object"].lower())
                
                # Get facts where current is the object
                conn = get_connection()
                obj_facts = []
                try:
                    for row in conn.execute(
                        "SELECT * FROM fact WHERE obj LIKE ? ORDER BY confidence DESC",
                        (f"%{current}%",)
                    ):
                        fact = {
                            "id": row["id"],
                            "subject": row["subj"],
                            "predicate": row["pred"],
                            "object": row["obj"],
                            "confidence": row["confidence"],
                            "source": row["source"],
                            "timestamp": row["timestamp"],
                            "direction": "incoming"
                        }
                        obj_facts.append(fact)
                        new_frontier.add(fact["subject"].lower())
                except Exception as e:
                    _metrics["errors"] += 1
                    logger.error(f"Error querying facts by object: {e}")
                
                result[current].extend(obj_facts)
            
            frontier = new_frontier
        
        return result

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Learning Functions for Integration with Singularity Boot
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def learn_fact(subject: str, predicate: str, obj: str, confidence: float = 0.75) -> bool:
    """Learn a fact from components (called from lecture processor)."""
    return add_fact(subject, predicate, obj, confidence=confidence, source="lecture")

def learn_facts_from_text(text: str, source: str = "text") -> List[Tuple[str, str, str]]:
    """Extract and learn facts from a text block."""
    return extract_facts_from_text(text, source)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_knowledge_metrics() -> Dict[str, Union[int, float]]:
    """Get metrics about knowledge database usage."""
    with _knowledge_lock:
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """Perform a health check on the knowledge subsystem."""
    initialize_schema()
    
    status = "healthy"
    details = {}
    
    # Check if database exists
    if not KNOWDB.exists():
        status = "degraded"
        details["missing_database"] = f"Database file not found: {KNOWDB}"
    
    # Check if we can read from the database
    try:
        conn = get_connection()
        fact_count = conn.execute("SELECT COUNT(*) FROM fact").fetchone()[0]
        details["fact_count"] = fact_count
    except Exception as e:
        status = "critical" 
        details["database_error"] = str(e)
    
    # Check for database integrity
    try:
        conn = get_connection()
        integrity_check = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity_check != "ok":
            status = "degraded"
            details["integrity_check"] = integrity_check
    except Exception as e:
        status = "degraded"
        details["integrity_check_error"] = str(e)
    
    # Check if we've seen any errors
    if _metrics["errors"] > 0:
        status = "warning" if status == "healthy" else status
        details["error_count"] = _metrics["errors"]
    
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "KNOWDB": KNOWDB,
        "kcon": get_connection(),  # Provide a connection instance
        "_FACT_PATTERNS": _FACT_PATTERNS,
        "learn_fact": learn_fact,
        "add_fact": add_fact,
        "search_facts": search_facts
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_knowledge instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Clean Shutdown
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """Perform cleanup operations on shutdown."""
    logger.info("Running knowledge module cleanup")
    close_all_connections()

# Register cleanup handler
import atexit
atexit.register(cleanup)

# Initialize module when imported
initialize_schema()

# Export public API
__all__ = [
    'KNOWDB',
    'add_fact', 'get_facts_by_subject', 'search_facts',
    'extract_facts_from_text', 'learn_fact', 'learn_facts_from_text',
    'get_related_entities', 'get_knowledge_metrics', 'health_check'
]

# Module self-test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"=== Knowledge Module Self-Test ===")
    print(f"Database location: {KNOWDB}")
    
    # Add a test fact
    test_subject = "Python"
    test_pred = "is"
    test_object = "a programming language"
    
    success = add_fact(test_subject, test_pred, test_object, source="test")
    print(f"Added test fact: {success}")
    
    # Retrieve and verify
    facts = get_facts_by_subject(test_subject)
    print(f"Retrieved {len(facts)} facts for '{test_subject}'")
    for fact in facts:
        print(f"  {fact['subject']} {fact['predicate']} {fact['object']}")
    
    # Extract facts from text
    test_text = """
    Python is a high-level programming language. 
    Python supports multiple programming paradigms.
    Languages like Python are interpreted.
    """
    
    extracted = extract_facts_from_text(test_text, "test")
    print(f"\nExtracted {len(extracted)} facts from test text:")
    for subj, pred, obj in extracted:
        print(f"  {subj} {pred} {obj}")
    
    # Health check
    health = health_check()
    print(f"\nHealth status: {health['status']}")
    print(f"Metrics: {health['metrics']}")
