#!/usr/bin/env python3
# Inference Integration - Connects RBY weights to neural inference pipeline
# ========================================================================
"""
Inference Integration Module
---------------------------
This module connects the RBY (Red-Blue-Yellow) weights system to all inference tasks,
ensuring that weights properly influence inference parameters and results across
the entire codebase.

Features:
- Unified inference dispatcher that routes requests to appropriate backends
- Dynamic parameter adjustment based on RBY weights
- Feedback loop for weight adjustments based on inference quality
- Performance monitoring and optimization for inference tasks
- Integration with cluster capabilities for distributed inference
"""
import os
import sys
import time
import json
import logging
import threading
import pathlib
from typing import Dict, Any, Optional, Union, Tuple, List
from decimal import Decimal

# Make sure base paths exist
BASE_PATH = pathlib.Path(__file__).parent.resolve()
ECO_PATH = BASE_PATH / "ecosystem"
ECO_PATH.mkdir(exist_ok=True)
STATS_PATH = ECO_PATH / "inference_stats"
STATS_PATH.mkdir(exist_ok=True)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("inference_integration")

# Import core components - with fallbacks for testing purposes
try:
    from singularity_boot import (
        trifecta, perception, cognition, execution,
        glyph_id, log_excretion, rby, _FNUM, R0, B0, Y0,
        _DYNAMIC_W
    )
except ImportError:
    logger.warning("Running in standalone mode - using mock RBY functions")
    # Mock functions for standalone testing
    def trifecta(text, weight=1.0): return (0.33, 0.33, 0.34)
    def perception(t): return 0.33
    def cognition(t): return 0.33
    def execution(t): return 0.34
    def log_excretion(msg): print(f"EXCRETION: {msg}")
    def glyph_id(b): return f"⟐{hash(b)}"
    def rby(tok): return (0.33, 0.33, 0.34)
    _FNUM = float
    R0, B0, Y0 = 0.33, 0.33, 0.34
    _DYNAMIC_W = {}

try:
    from organism_inference import (
        infer as base_infer,
        infer_with_metadata,
        get_inference_stats,
        _map_rby_to_params,
        _adjust_weights
    )
    ORGANISM_INFERENCE_AVAILABLE = True
except ImportError:
    logger.warning("organism_inference not available - using fallbacks")
    ORGANISM_INFERENCE_AVAILABLE = False
    # Mock functions
    def base_infer(query, context=None, mode="auto"): return f"Fallback response to: {query}"
    def infer_with_metadata(query, context=None, mode="auto"):
        return {
            "result": f"Fallback response to: {query}",
            "metadata": {"mode": mode, "rby": (0.33, 0.33, 0.34)}
        }
    def get_inference_stats(): return {"total_inferences": 0}
    def _map_rby_to_params(r, b, y): 
        return {"temperature": 0.7, "top_p": 0.9, "max_tokens": 256}
    def _adjust_weights(query, success, latency_ms): pass

try:
    from organism_neuro import (
        CUDA_OK, DEVICE, GPU_NAME,
        query as neuro_query, 
        embed_and_store
    )
    NEURO_AVAILABLE = True
except ImportError:
    logger.warning("organism_neuro not available - using fallbacks")
    NEURO_AVAILABLE = False
    import torch
    CUDA_OK = torch.cuda.is_available()
    DEVICE = torch.device("cuda" if CUDA_OK else "cpu")
    GPU_NAME = torch.cuda.get_device_name(0) if CUDA_OK else "CPU"
    def neuro_query(q, k=5, temperature=0.7, max_new=256):
        return f"Mock neuro response to: {q}"
    def embed_and_store(text, source): pass

try:
    from organism_cluster import (
        remote_call, best_peer, llm_generate
    )
    CLUSTER_AVAILABLE = True
except ImportError:
    logger.warning("organism_cluster not available - using fallbacks")
    CLUSTER_AVAILABLE = False
    # Mock functions
    def remote_call(call_str, *args, **kwargs): 
        return f"Mock remote call to {call_str}"
    def best_peer(): return {"id": "local", "gpu": "localhost"}
    def llm_generate(prompt, max_new=256, temp=0.7):
        return f"Mock LLM response to: {prompt}"

# ============================================================================
# Core Integration Layer - Connects RBY weights to inference
# ============================================================================

class RbyInferenceIntegration:
    """
    Main integration class that connects RBY weights with inference tasks.
    Serves as the primary interface for all inference operations.
    """
    def __init__(self):
        self.stats = {
            "total_calls": 0,
            "rby_influenced_calls": 0,
            "start_time": time.time(),
            "last_latency_ms": 0,
            "avg_latency_ms": 0,
            "success_rate": 1.0
        }
        self.inference_queue = []
        self.last_inference_result = None
        self._running = False
        self._lock = threading.Lock()

    def adjust_parameters_from_rby(self, 
                                   r: Union[float, Decimal], 
                                   b: Union[float, Decimal], 
                                   y: Union[float, Decimal]) -> Dict[str, Any]:
        """
        Adjust inference parameters based on RBY values:
        - R (perception) influences creativity/temperature
        - B (cognition) influences coherence/top_p
        - Y (execution) influences response length/max_tokens
        """
        try:
            # Convert to float for calculations
            r_val, b_val, y_val = float(r), float(b), float(y)
            
            # Calculate inference parameters with sensible bounds
            temperature = min(1.2, max(0.1, 0.1 + r_val))  # 0.1 to 1.2
            top_p = min(0.95, max(0.1, b_val))  # 0.1 to 0.95
            max_tokens = int(min(1024, max(32, y_val * 512)))  # 32 to 1024
            
            # More parameters based on RBY balance
            repetition_penalty = 1.0 + (0.2 * (1.0 - b_val))  # Higher for lower cognition
            
            # Strategy selection based on dominant RBY
            if r_val > max(b_val, y_val):
                strategy = "creative"  # Perception-dominant: more creative
            elif b_val > max(r_val, y_val):
                strategy = "logical"   # Cognition-dominant: more structured
            else:
                strategy = "action"    # Execution-dominant: action-oriented
                
            return {
                "temperature": temperature,
                "top_p": top_p,
                "max_tokens": max_tokens,
                "repetition_penalty": repetition_penalty,
                "strategy": strategy
            }
        except Exception as e:
            logger.error(f"Error in adjust_parameters_from_rby: {e}")
            # Fallback to safe defaults
            return {
                "temperature": 0.7,
                "top_p": 0.9,
                "max_tokens": 256,
                "repetition_penalty": 1.1,
                "strategy": "balanced"
            }

    def update_weights_from_inference(self, query: str, result: str, 
                                     success: bool, latency_ms: float) -> None:
        """
        Update RBY weights based on inference performance.
        This creates a feedback loop where successful inferences strengthen weights.
        """
        try:
            # Only adjust if we have dynamic weights system
            if not _DYNAMIC_W:
                return
                
            # Extract tokens from query
            query_tokens = query.split()
            
            # Calculate adjustment factor - positive for fast, successful inferences
            base_factor = 0.05 * (1.0 if success else -0.5)
            speed_factor = max(-0.025, min(0.025, (1000 - latency_ms) / 20000))
            adjustment = base_factor + speed_factor
            
            # Apply to dynamic weights
            for token in query_tokens:
                if token in _DYNAMIC_W:
                    r, b, y = _DYNAMIC_W[token]
                    
                    if success:
                        # Strengthen current weights for successful inference
                        _DYNAMIC_W[token] = (
                            r * (1 + adjustment),
                            b * (1 + adjustment),
                            y * (1 + adjustment)
                        )
                    else:
                        # Move toward baseline for unsuccessful inference
                        _DYNAMIC_W[token] = (
                            r + (R0 - r) * abs(adjustment),
                            b + (B0 - b) * abs(adjustment),
                            y + (Y0 - y) * abs(adjustment)
                        )
                    
            # Log significant weight adjustments
            if abs(adjustment) > 0.03:
                logger.debug(f"Weight adjustment: {adjustment:.4f} for inference")
                
        except Exception as e:
            logger.error(f"Error updating weights from inference: {e}")

    def infer(self, query: str, context: Optional[str] = None, 
             mode: str = "auto", use_rby: bool = True) -> str:
        """
        Main inference function that applies RBY weights to the process.
        This is the primary entry point for all inference tasks.
        """
        start_time = time.time()
        with self._lock:
            self.stats["total_calls"] += 1
        
        try:
            # Get RBY values for this query
            r, b, y = perception(query), cognition(query), execution(query)
            
            # Record the attempted inference
            trifecta(query, weight=0.2)
            
            # Calculate parameters based on RBY
            if use_rby:
                params = self.adjust_parameters_from_rby(r, b, y)
                with self._lock:
                    self.stats["rby_influenced_calls"] += 1
            else:
                params = {"temperature": 0.7, "top_p": 0.9, "max_tokens": 256}
            
            # Select inference mode if not specified
            if mode == "auto":
                # Let RBY balance determine the mode
                if b > max(r, y):
                    mode = "neural"  # Cognition-heavy: use neural
                elif y > max(r, b):
                    mode = "hybrid"  # Execution-heavy: hybrid approach
                else:
                    mode = "rby"     # Perception-heavy: RBY-based
            
            # Try organism_inference first (most comprehensive)
            result = ""
            if ORGANISM_INFERENCE_AVAILABLE:
                try:
                    result = base_infer(query, context, mode)
                except Exception as e:
                    logger.warning(f"organism_inference.infer failed: {e}, trying fallbacks")
            
            # Fallback to direct neural query
            if not result and NEURO_AVAILABLE:
                try:
                    result = neuro_query(
                        query, 
                        temperature=params["temperature"],
                        max_new=params["max_tokens"]
                    )
                except Exception as e:
                    logger.warning(f"neuro_query failed: {e}, trying cluster")
            
            # Final fallback to cluster
            if not result and CLUSTER_AVAILABLE:
                try:
                    result = llm_generate(
                        query,
                        max_new=params["max_tokens"],
                        temp=params["temperature"]
                    )
                except Exception as e:
                    logger.warning(f"llm_generate failed: {e}, using basic response")
            
            # Ultimate fallback
            if not result:
                result = f"I processed your query: {query}\n\nHowever, I couldn't generate a full response. Please try a different query."
            
            # Record the result
            trifecta(result, weight=0.3)
            
            # Calculate stats
            end_time = time.time()
            latency_ms = (end_time - start_time) * 1000
            success = len(result) > len(query)  # Simple heuristic for success
            
            # Update weights based on inference quality
            self.update_weights_from_inference(query, result, success, latency_ms)
            
            # Update statistics
            with self._lock:
                self.stats["last_latency_ms"] = latency_ms
                self.stats["avg_latency_ms"] = (
                    (self.stats["avg_latency_ms"] * (self.stats["total_calls"] - 1) + latency_ms) /
                    self.stats["total_calls"]
                )
                self.stats["success_rate"] = (
                    self.stats["success_rate"] * 0.95 + (0.05 if success else 0)
                )
            
            self.last_inference_result = {
                "result": result,
                "query": query,
                "rby": (float(r), float(b), float(y)),
                "params": params,
                "mode": mode,
                "latency_ms": latency_ms,
                "timestamp": time.time()
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error in infer: {e}")
            # Return a safe fallback response
            return f"I encountered an error processing your query. Technical details: {str(e)}"
    
    def infer_with_metadata(self, query: str, context: Optional[str] = None, 
                           mode: str = "auto", use_rby: bool = True) -> Dict[str, Any]:
        """
        Enhanced inference that returns both the result and metadata.
        """
        result = self.infer(query, context, mode, use_rby)
        return {
            "result": result,
            "metadata": self.last_inference_result
        }
    
    def save_stats(self) -> None:
        """Save inference statistics to disk"""
        try:
            # Create a timestamped stats file
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            stats_file = STATS_PATH / f"inference_stats_{timestamp}.json"
            
            # Add derived statistics
            stats = dict(self.stats)
            stats["uptime_s"] = time.time() - stats["start_time"]
            stats["rby_influence_pct"] = (
                100 * stats["rby_influenced_calls"] / max(1, stats["total_calls"])
            )
            
            # Generate a glyph ID for these stats
            stats_json = json.dumps(stats)
            stats_glyph = glyph_id(stats_json.encode())
            
            # Write the stats file
            with open(stats_file, "w") as f:
                json.dump(stats, f, indent=2)
                
            # Log the stats glyph
            log_excretion(f"INFERENCE-STATS {stats_glyph} success={stats['success_rate']:.2f}")
            logger.info(f"Saved inference stats to {stats_file}")
            
        except Exception as e:
            logger.error(f"Error saving inference stats: {e}")

# Create a singleton instance for global use
inference_integration = RbyInferenceIntegration()

# Start periodic stats saving
def _stats_saver():
    while True:
        try:
            time.sleep(3600)  # Save every hour
            inference_integration.save_stats()
        except Exception as e:
            logger.error(f"Error in stats_saver: {e}")

threading.Thread(target=_stats_saver, daemon=True).start()

# ============================================================================
# Public API Functions
# ============================================================================

def integrated_infer(query: str, context: Optional[str] = None, 
                   mode: str = "auto", use_rby: bool = True) -> str:
    """
    Public API: Run inference with RBY integration.
    This is the main function that should be called by other modules.
    """
    return inference_integration.infer(query, context, mode, use_rby)

def integrated_infer_with_metadata(query: str, context: Optional[str] = None, 
                                 mode: str = "auto", use_rby: bool = True) -> Dict[str, Any]:
    """
    Public API: Run inference with RBY integration and return metadata.
    """
    return inference_integration.infer_with_metadata(query, context, mode, use_rby)

def get_integrated_stats() -> Dict[str, Any]:
    """
    Get current inference statistics.
    """
    return dict(inference_integration.stats)

# ============================================================================
# CLI Commands for integration with META dictionary
# ============================================================================

def cmd_integrated_infer(args: str = None):
    """
    Command-line function for META integration.
    Usage: /integrated-infer [query]
    """
    if not args:
        query = input("Enter your query: ")
    else:
        query = args
        
    print("\nProcessing with RBY integration...\n")
    result = integrated_infer(query)
    print(f"Result:\n{result}\n")

def cmd_integrated_stats():
    """
    Command-line function to show inference stats.
    Usage: /integrated-stats
    """
    stats = get_integrated_stats()
    print("\nIntegrated Inference Statistics:")
    print(f"Total calls: {stats['total_calls']}")
    print(f"RBY-influenced calls: {stats.get('rby_influenced_calls', 0)}")
    print(f"RBY influence: {stats.get('rby_influence_pct', 0):.1f}%")
    print(f"Success rate: {stats['success_rate']:.2f}")
    print(f"Last latency: {stats['last_latency_ms']:.1f} ms")
    print(f"Average latency: {stats['avg_latency_ms']:.1f} ms")
    print(f"Uptime: {(time.time() - stats['start_time']) / 3600:.1f} hours\n")

# Register commands in META if available
try:
    import sys
    if 'singularity_boot' in sys.modules:
        sys.modules['singularity_boot'].META["/integrated-infer"] = cmd_integrated_infer
        sys.modules['singularity_boot'].META["/integrated-stats"] = cmd_integrated_stats
except Exception:
    pass

# ============================================================================
# Test function when run directly
# ============================================================================

if __name__ == "__main__":
    print("Testing RBY-Inference Integration")
    test_queries = [
        "What is the speed of light?",
        "Write a function to calculate Fibonacci numbers.",
        "Tell me about neural networks."
    ]
    
    for query in test_queries:
        print(f"\nQuery: {query}")
        result = integrated_infer(query)
        print(f"Result: {result[:100]}...")
    
    print("\nInference Statistics:")
    print(json.dumps(get_integrated_stats(), indent=2))
