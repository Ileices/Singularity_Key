# ───────────────────────── organism_reflex.py ──────────────────────────
import os, subprocess, threading, time, json
from pathlib import Path
from organism_neuro import query as neuro_query

# Import needed modules with proper error handling
try:
    from singularity_boot import glyph_id, log_excretion
except ImportError:
    # Fallback implementations if imports fail
    import hashlib as _h
    def glyph_id(b): return f"⟐{_h.blake2b(b,digest_size=8).hexdigest()}"
    def log_excretion(msg): print(f"EXCRETION: {msg}")

DRAFTS_DIR = Path("ecosystem") / "drafts"
DRAFTS_DIR.mkdir(exist_ok=True, parents=True)

class ReflexSupervisor:
    @staticmethod
    def start():
        threading.Thread(target=ReflexSupervisor._watch_drafts, daemon=True).start()
        print("[ReflexSupervisor] Started watching drafts folder")

    @staticmethod
    def _watch_drafts():
        if not DRAFTS_DIR.exists():
            DRAFTS_DIR.mkdir(parents=True, exist_ok=True)
            
        seen = set()
        while True:
            try:
                current = {f for f in DRAFTS_DIR.iterdir() if f.is_file()}
                new_files = current - seen
                
                for file in new_files:
                    if file.suffix.lower() == ".py":
                        ReflexSupervisor._process_draft(file)
                seen = current
            except Exception as e:
                print(f"[ReflexSupervisor] Error scanning drafts: {e}")
                
            time.sleep(5)

    @staticmethod
    def _process_draft(file):
        """Process a Python draft file, attempting to fix it if compilation fails"""
        try:
            print(f"[ReflexSupervisor] Processing draft: {file}")
            
            # Run Python compile to check for syntax errors
            result = subprocess.run(
                ["python", "-m", "py_compile", str(file)], 
                capture_output=True, 
                text=True
            )
            
            # If compilation fails, use neuro to fix it
            if result.returncode != 0:
                print(f"[ReflexSupervisor] Compilation failed for {file}: {result.stderr}")
                
                # Read the file content
                try:
                    file_content = file.read_text(encoding="utf-8", errors="ignore")
                except Exception as read_error:
                    print(f"[ReflexSupervisor] Error reading file: {read_error}")
                    return

                # Generate a prompt for the neural model
                prompt = f"""Fix this Python code that has errors:
```python
{file_content}
```
Error message:
{result.stderr}

Please provide the complete corrected code without any explanations."""

                # Get the fix from the neural model
                try:
                    fix = neuro_query(prompt)
                    
                    # Extract code if the response contains markdown code blocks
                    if "```python" in fix and "```" in fix.split("```python", 1)[1]:
                        fix = fix.split("```python", 1)[1].split("```", 1)[0].strip()
                    elif "```" in fix:
                        # Try without language specifier
                        fix = fix.split("```", 1)[1].split("```", 1)[0].strip()
                        
                    # Write the fixed code to a new file
                    fixed_file = file.with_name(f"{file.stem}_fix1{file.suffix}")
                    fixed_file.write_text(fix)
                    
                    # Log the fix as a glyph
                    try:
                        fix_glyph = glyph_id(fix.encode())
                        log_excretion(f"REFLEX-FIX {fix_glyph} {file.name}")
                    except Exception as glyph_err:
                        print(f"[ReflexSupervisor] Error generating glyph: {glyph_err}")
                    
                    print(f"[ReflexSupervisor] Generated fix: {fixed_file}")
                    
                    # Verify the fix works
                    verify_result = subprocess.run(
                        ["python", "-m", "py_compile", str(fixed_file)], 
                        capture_output=True, 
                        text=True
                    )
                    
                    if verify_result.returncode == 0:
                        print(f"[ReflexSupervisor] Fix verified successfully!")
                    else:
                        print(f"[ReflexSupervisor] Fix still has issues: {verify_result.stderr}")
                        
                except Exception as neuro_error:
                    print(f"[ReflexSupervisor] Error using neuro_query: {neuro_error}")
            else:
                print(f"[ReflexSupervisor] Draft {file} compiled successfully.")
        except Exception as e:
            print(f"[ReflexSupervisor] Error processing draft: {e}")