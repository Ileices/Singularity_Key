#!/usr/bin/env python3
"""
Singularity Memory Management Module
-----------------------------------
Handles organism memory, excretion logging, and state persistence

Features:
- Thread-safe excretion logging
- DNA memory buffer with configurable size
- Historical state tracking
- High-precision energy state variable
- Cross-platform file path handling
- Memory usage monitoring and optimization

This module implements the core memory structures required for the Singularity organism's
DNA memory deque, history buffer, energy state tracking, and excretion logging system.
"""

import datetime as _dt
import threading
import os
import logging
import time
import json
import hashlib
from pathlib import Path
from collections import deque
from typing import Dict, List, Any, Deque, Optional, Union, Callable

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.memory")

# Thread safety
_memory_lock = threading.RLock()
_excretion_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "excretions_logged": 0,
    "dna_entries": 0,
    "history_entries": 0,
    "errors": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Dependencies
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False
_fnum_func = None  # Will be set to _FNUM from singularity_precision
_config = None     # Will be set to CFG from singularity_config

# Default parameters
_DEFAULT_PARAMS = {
    "dna_maxlen": 10_000,
    "hist_maxlen": 4_096,
    "default_energy": 1,
    "excretion_log_rotation_bytes": 10_000_000  # 10MB
}

# Memory structures (initialized during init)
ENERGY = None  # Energy state variable (high-precision float)
DNA = None     # DNA memory buffer (deque)
_HIST = None   # History buffer (deque)

# Paths
ECO_DIR = Path()  # Will be set during initialization
EXC = None        # Excretion log path

def initialize(fnum_function=None, config=None, eco_dir=None, excretion_log_path=None):
    """
    Initialize the memory module with required functions, configuration, and paths.
    
    Args:
        fnum_function: Function to convert to high-precision numeric type
        config: Configuration dictionary
        eco_dir: Ecosystem directory path
        excretion_log_path: Path to excretion log file
    """
    global _fnum_func, _config, _initialized, ENERGY, DNA, _HIST, ECO_DIR, EXC
    
    with _memory_lock:
        # Store dependencies
        _fnum_func = fnum_function or (lambda x: float(x))
        _config = config or {}
        
        # Set up paths
        if eco_dir:
            ECO_DIR = Path(eco_dir) if not isinstance(eco_dir, Path) else eco_dir
        else:
            ECO_DIR = Path("ecosystem")
            
        # Create ecosystem directory if it doesn't exist
        ECO_DIR.mkdir(exist_ok=True, parents=True)
        
        # Set up excretion log path
        if excretion_log_path:
            EXC = Path(excretion_log_path) if not isinstance(excretion_log_path, Path) else excretion_log_path
        else:
            EXC = ECO_DIR / "excretions.log"
        
        # If excretion log doesn't exist, create it with headers
        if not EXC.exists():
            try:
                with open(EXC, "w", encoding="utf-8") as f:
                    f.write(f"{_dt.datetime.utcnow().isoformat()} | SINGULARITY MEMORY INITIALIZATION\n")
            except Exception as e:
                logger.error(f"Failed to create excretion log: {e}")
                _metrics["errors"] += 1
        
        # Set up memory structures
        try:
            # Get parameters from config or use defaults
            memory_cfg = _config.get("memory", {})
            dna_maxlen = memory_cfg.get("dna_maxlen", _DEFAULT_PARAMS["dna_maxlen"])
            hist_maxlen = memory_cfg.get("hist_maxlen", _DEFAULT_PARAMS["hist_maxlen"])
            default_energy = memory_cfg.get("default_energy", _DEFAULT_PARAMS["default_energy"])
            
            # Initialize core memory structures
            ENERGY = _fnum_func(default_energy)
            DNA = deque(maxlen=dna_maxlen)
            _HIST = deque(maxlen=hist_maxlen)
            
            logger.info(f"Memory structures initialized: DNA[{dna_maxlen}], HIST[{hist_maxlen}], ENERGY={ENERGY}")
        except Exception as e:
            logger.error(f"Error initializing memory structures: {e}")
            _metrics["errors"] += 1
            
            # Use defaults on error
            ENERGY = _fnum_func(_DEFAULT_PARAMS["default_energy"])
            DNA = deque(maxlen=_DEFAULT_PARAMS["dna_maxlen"])
            _HIST = deque(maxlen=_DEFAULT_PARAMS["hist_maxlen"])
        
        # Check and set file permissions for excretion log (mode 600)
        try:
            os.chmod(EXC, 0o600)
        except Exception as e:
            logger.warning(f"Could not set permissions on excretion log: {e}")
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info(f"Memory module initialized successfully")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Excretion Logging Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def log_excretion(msg: str):
    """
    Log an excretion message to the excretion log file.
    
    Args:
        msg: Message to log
    """
    if not _initialized:
        logger.warning("Memory module not initialized, excretion not logged")
        return
    
    with _excretion_lock:
        try:
            # Check if log rotation is needed
            try:
                if EXC.exists() and EXC.stat().st_size > _DEFAULT_PARAMS["excretion_log_rotation_bytes"]:
                    rotate_excretion_log()
            except Exception as e:
                logger.error(f"Error checking log size: {e}")
            
            # Write the log entry
            with open(EXC, "a", encoding="utf-8") as f:
                f.write(f"{_dt.datetime.utcnow().isoformat()} | {msg}\n")
                
            _metrics["excretions_logged"] += 1
        except Exception as e:
            logger.error(f"Failed to log excretion: {e}")
            _metrics["errors"] += 1

def rotate_excretion_log():
    """
    Rotate the excretion log file to prevent excessive size.
    Creates a timestamped backup of the current log and starts a new one.
    """
    if not EXC.exists():
        return
        
    try:
        # Create a timestamped backup
        timestamp = _dt.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        backup_path = EXC.with_name(f"excretions_{timestamp}.log")
        
        # Copy the existing log to the backup
        with open(EXC, "r", encoding="utf-8") as src, open(backup_path, "w", encoding="utf-8") as dst:
            dst.write(src.read())
        
        # Create a new empty log with a header
        with open(EXC, "w", encoding="utf-8") as f:
            f.write(f"{_dt.datetime.utcnow().isoformat()} | LOG ROTATED - PREVIOUS LOG AT {backup_path.name}\n")
            
        logger.info(f"Excretion log rotated, backup at {backup_path}")
    except Exception as e:
        logger.error(f"Failed to rotate excretion log: {e}")
        _metrics["errors"] += 1

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Memory Management Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def add_to_dna(entry):
    """
    Add an entry to the DNA memory buffer.
    
    Args:
        entry: Data to add to the DNA buffer
    """
    if not _initialized:
        logger.warning("Memory module not initialized, DNA update skipped")
        return
        
    with _memory_lock:
        DNA.append(entry)
        _metrics["dna_entries"] += 1

def add_to_history(entry):
    """
    Add an entry to the history buffer.
    
    Args:
        entry: Data to add to the history buffer
    """
    if not _initialized:
        logger.warning("Memory module not initialized, history update skipped")
        return
        
    with _memory_lock:
        _HIST.append(entry)
        _metrics["history_entries"] += 1

def update_energy(value):
    """
    Update the ENERGY state variable.
    
    Args:
        value: New energy value
        
    Returns:
        Updated energy value
    """
    global ENERGY
    
    if not _initialized:
        logger.warning("Memory module not initialized, energy update skipped")
        return ENERGY
        
    with _memory_lock:
        ENERGY = _fnum_func(value)
        return ENERGY

def get_energy():
    """
    Get the current ENERGY state value.
    
    Returns:
        Current energy value
    """
    if not _initialized:
        logger.warning("Memory module not initialized, returning default energy")
        return _fnum_func(_DEFAULT_PARAMS["default_energy"])
        
    with _memory_lock:
        return ENERGY

def get_dna_snapshot():
    """
    Get a snapshot of the current DNA buffer.
    
    Returns:
        List containing DNA buffer contents
    """
    if not _initialized:
        logger.warning("Memory module not initialized, returning empty DNA")
        return []
        
    with _memory_lock:
        return list(DNA)

def get_history_snapshot():
    """
    Get a snapshot of the current history buffer.
    
    Returns:
        List containing history buffer contents
    """
    if not _initialized:
        logger.warning("Memory module not initialized, returning empty history")
        return []
        
    with _memory_lock:
        return list(_HIST)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Monitoring and Health Check
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics():
    """
    Get memory performance metrics.
    
    Returns:
        Dictionary of metrics
    """
    with _memory_lock:
        result = _metrics.copy()
        
        # Add current memory usage stats
        if _initialized:
            result["dna_length"] = len(DNA)
            result["dna_capacity"] = DNA.maxlen
            result["dna_utilization"] = len(DNA) / DNA.maxlen if DNA.maxlen else 0
            
            result["hist_length"] = len(_HIST)
            result["hist_capacity"] = _HIST.maxlen
            result["hist_utilization"] = len(_HIST) / _HIST.maxlen if _HIST.maxlen else 0
            
            result["energy"] = str(ENERGY)
            
            # Add excretion log stats
            try:
                if EXC.exists():
                    result["excretion_log_size_bytes"] = EXC.stat().st_size
                    result["excretion_log_rotation_threshold"] = _DEFAULT_PARAMS["excretion_log_rotation_bytes"]
            except Exception:
                pass
                
        return result

def health_check():
    """
    Check health of memory systems.
    
    Returns:
        Dictionary with health status and details
    """
    if not _initialized:
        return {
            "status": "error",
            "message": "Memory module not initialized",
            "metrics": {},
            "timestamp": time.time()
        }
    
    metrics = get_metrics()
    
    # Check if any buffer is nearing capacity
    warnings = []
    if metrics["dna_utilization"] > 0.9:
        warnings.append(f"DNA buffer at {metrics['dna_utilization']:.1%} capacity")
    
    if metrics["hist_utilization"] > 0.9:
        warnings.append(f"History buffer at {metrics['hist_utilization']:.1%} capacity")
    
    if metrics.get("excretion_log_size_bytes", 0) > metrics.get("excretion_log_rotation_threshold", 0) * 0.9:
        warnings.append("Excretion log nearing rotation threshold")
    
    # Determine overall status
    if metrics["errors"] > 0:
        status = "warning"
        message = f"Encountered {metrics['errors']} errors in memory operations"
    elif warnings:
        status = "warning"
        message = "; ".join(warnings)
    else:
        status = "healthy"
        message = "Memory systems operating normally"
    
    return {
        "status": status,
        "message": message,
        "metrics": metrics,
        "warnings": warnings,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Persistence and Restoration
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def save_memory_state(path=None):
    """
    Save the current memory state (DNA, history, energy) to disk.
    
    Args:
        path: Optional path to save state to (defaults to ecosystem/memory_state.json)
        
    Returns:
        Path the state was saved to, or None if failed
    """
    if not _initialized:
        logger.warning("Memory module not initialized, state not saved")
        return None
    
    save_path = path or (ECO_DIR / "memory_state.json")
    
    try:
        # Create a serializable state object
        with _memory_lock:
            state = {
                "timestamp": _dt.datetime.utcnow().isoformat(),
                "dna": list(DNA),
                "history": list(_HIST),
                "energy": str(ENERGY),
                "metrics": get_metrics()
            }
        
        # Calculate a state checksum for integrity verification
        state_json = json.dumps(state, sort_keys=True)
        state["checksum"] = hashlib.sha256(state_json.encode('utf-8')).hexdigest()
        
        # Write the state file
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
            f.flush()
            os.fsync(f.fileno())  # Ensure data is written to disk
            
        # Set secure permissions
        try:
            os.chmod(save_path, 0o600)
        except Exception as e:
            logger.warning(f"Could not set permissions on state file: {e}")
            
        logger.info(f"Memory state saved to {save_path}")
        return save_path
    
    except Exception as e:
        logger.error(f"Failed to save memory state: {e}")
        _metrics["errors"] += 1
        return None

def load_memory_state(path=None):
    """
    Restore memory state from disk.
    
    Args:
        path: Optional path to load state from (defaults to ecosystem/memory_state.json)
        
    Returns:
        True if successful, False otherwise
    """
    if not _initialized:
        logger.warning("Memory module not initialized, state not loaded")
        return False
        
    load_path = path or (ECO_DIR / "memory_state.json")
    
    if not load_path.exists():
        logger.warning(f"Memory state file not found: {load_path}")
        return False
        
    try:
        # Read the state file
        with open(load_path, "r", encoding="utf-8") as f:
            state = json.load(f)
            
        # Verify checksum if available
        if "checksum" in state:
            checksum = state.pop("checksum")
            state_json = json.dumps(state, sort_keys=True)
            calculated_checksum = hashlib.sha256(state_json.encode('utf-8')).hexdigest()
            
            if calculated_checksum != checksum:
                logger.error(f"Memory state checksum mismatch, file may be corrupted")
                _metrics["errors"] += 1
                return False
                
        # Restore memory state
        with _memory_lock:
            global ENERGY
            
            # Clear existing state
            DNA.clear()
            _HIST.clear()
            
            # Restore DNA and history
            for entry in state.get("dna", []):
                DNA.append(entry)
                
            for entry in state.get("history", []):
                _HIST.append(entry)
                
            # Restore energy
            ENERGY = _fnum_func(state.get("energy", _DEFAULT_PARAMS["default_energy"]))
            
        logger.info(f"Memory state restored from {load_path}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to load memory state: {e}")
        _metrics["errors"] += 1
        return False

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Memory Optimization
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def optimize_memory():
    """
    Perform memory optimization to reduce footprint.
    This is useful for long-running instances.
    """
    if not _initialized:
        return
        
    with _memory_lock:
        # Memory optimization strategies can be implemented here
        # For now, just log that optimization was attempted
        logger.info("Memory optimization requested")
        
        # Compact DNA and history buffers if they're significantly under capacity
        if len(DNA) < DNA.maxlen * 0.5:
            new_dna = deque(list(DNA), maxlen=DNA.maxlen)
            DNA.clear()
            DNA.extend(new_dna)
            logger.info(f"Compacted DNA buffer ({len(DNA)} entries)")
            
        if len(_HIST) < _HIST.maxlen * 0.5:
            new_hist = deque(list(_HIST), maxlen=_HIST.maxlen)
            _HIST.clear()
            _HIST.extend(new_hist)
            logger.info(f"Compacted history buffer ({len(_HIST)} entries)")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Cleanup and Resource Release
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """
    Clean up resources used by the memory module.
    Should be called during application shutdown.
    """
    global _initialized
    
    if _initialized:
        try:
            # Save current memory state before shutdown
            save_memory_state()
            
            # Clean up resources
            with _memory_lock:
                DNA.clear()
                _HIST.clear()
                
            _initialized = False
            logger.info("Memory module resources cleaned up")
        except Exception as e:
            logger.error(f"Error during memory cleanup: {e}")

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'log_excretion',
    'rotate_excretion_log',
    'add_to_dna',
    'add_to_history',
    'update_energy',
    'get_energy',
    'get_dna_snapshot',
    'get_history_snapshot',
    'get_metrics',
    'health_check',
    'save_memory_state',
    'load_memory_state',
    'optimize_memory',
    'cleanup',
    'ENERGY',
    'DNA',
    '_HIST',
    'EXC'
]

# Module self-test
if __name__ == "__main__":
    # Basic test of memory functions
    from decimal import Decimal
    
    # Mock FNUM function
    def mock_fnum(s):
        return Decimal(str(s))
    
    # Initialize with mock functions
    initialize(mock_fnum, {})
    
    # Test excretion logging
    log_excretion("SELF-TEST: Memory module initialization")
    
    # Test DNA and history
    add_to_dna({"type": "test", "value": 42})
    add_to_history({"action": "self-test", "timestamp": _dt.datetime.utcnow().isoformat()})
    
    # Test energy updates
    old_energy = get_energy()
    new_energy = update_energy(1.5)
    print(f"Energy updated: {old_energy} → {new_energy}")
    
    # Test memory snapshots
    dna_snapshot = get_dna_snapshot()
    hist_snapshot = get_history_snapshot()
    print(f"DNA entries: {len(dna_snapshot)}")
    print(f"History entries: {len(hist_snapshot)}")
    
    # Test health check and metrics
    health = health_check()
    print(f"Health check: {health['status']}")
    print(f"Message: {health['message']}")
    
    metrics = get_metrics()
    print("\nMetrics:")
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    
    # Test persistence
    save_path = save_memory_state()
    print(f"State saved to {save_path}")
    
    # Test cleanup
    cleanup()
    print("Memory module self-test completed successfully")
