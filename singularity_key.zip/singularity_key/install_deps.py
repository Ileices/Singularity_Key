#!/usr/bin/env python3
"""
Singularity Dependencies Installer
---------------------------------
Installs all required packages for the Singularity framework.
"""
import subprocess
import sys
import os

def install_requirements(req_file):
    """Install requirements from the specified file."""
    print(f"Installing dependencies from {req_file}...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", req_file],
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        print(f"✓ Successfully installed dependencies from {req_file}")
    else:
        print(f"✗ Failed to install dependencies from {req_file}")
        print(f"Error: {result.stderr}")

def main():
    # Get the directory of this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Find all requirements files
    req_files = [
        os.path.join(base_dir, f) 
        for f in os.listdir(base_dir) 
        if f.startswith("requirements") and f.endswith(".txt")
    ]
    
    if not req_files:
        print("No requirements files found.")
        return
    
    # Install main requirements first
    main_req = os.path.join(base_dir, "requirements.txt")
    if os.path.exists(main_req):
        install_requirements(main_req)
        req_files.remove(main_req)
    
    # Install the rest of requirements
    for req_file in req_files:
        install_requirements(req_file)
    
    print("\nAll dependencies installed. Singularity is ready to run!")

if __name__ == "__main__":
    main()
