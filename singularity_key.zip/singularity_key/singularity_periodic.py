#!/usr/bin/env python3
"""
Singularity Periodic Table Module
---------------------------------
Manages the axiom database and knowledge representation system.

Features:
- Thread-safe database operations
- Automatic schema creation and verification
- Axiom management (add, query, update)
- Term linking and reference resolution
- Cross-platform SQLite access with proper locking

This module provides storage and retrieval of foundational knowledge axioms
that serve as the base reference system for the Singularity organism.
"""
import os
import sqlite3
import threading
import logging
import time
import json
import hashlib
import pathlib
from typing import Dict, List, Optional, Tuple, Any, Union

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.periodic")

# Thread safety
_pt_lock = threading.RLock()
_connections = {}  # Thread-local connections
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "axioms_loaded": 0,
    "terms_loaded": 0,
    "queries_executed": 0,
    "writes_performed": 0,
    "errors": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Path Resolution and Configuration
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Base path is derived from this module's location
BASE = pathlib.Path(__file__).parent.resolve()

# Try to import configuration module with fallback handling
try:
    from singularity_config import CFG, ECO
    from singularity_storage import PTDB
    use_custom_cfg = True
except ImportError:
    logger.warning("Could not import singularity_config or singularity_storage, using default paths")
    import yaml
    CFG = {}
    try:
        config_path = BASE / "singularity_config.yml"
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                CFG = yaml.safe_load(f)
    except Exception as e:
        logger.error(f"Error loading config: {e}")
    
    ECO = BASE / "ecosystem"
    ECO.mkdir(exist_ok=True)
    PTDB = ECO / "periodic_table.db"
    use_custom_cfg = False

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Database Connection Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_connection() -> sqlite3.Connection:
    """Get a thread-local SQLite connection with proper settings."""
    thread_id = threading.get_ident()
    
    if thread_id not in _connections:
        conn = sqlite3.connect(PTDB, isolation_level=None, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        _connections[thread_id] = conn
        
    return _connections[thread_id]

def close_all_connections():
    """Close all database connections."""
    with _pt_lock:
        for thread_id, conn in list(_connections.items()):
            try:
                conn.close()
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
            _connections.pop(thread_id, None)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Schema Initialization and Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def initialize_schema() -> bool:
    """Create database schema if it doesn't exist."""
    global _initialized, _metrics
    
    with _pt_lock:
        if _initialized:
            return True
            
        start_time = time.time()
        conn = get_connection()
        
        try:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS axiom(
                id INTEGER PRIMARY KEY,
                glyph TEXT UNIQUE, 
                title TEXT, 
                latex TEXT, 
                definition TEXT);
                
            CREATE TABLE IF NOT EXISTS term(
                id INTEGER PRIMARY KEY,
                term TEXT UNIQUE, 
                glyph TEXT);
                
            CREATE INDEX IF NOT EXISTS idx_axiom_glyph ON axiom(glyph);
            CREATE INDEX IF NOT EXISTS idx_term_term ON term(term);
            CREATE INDEX IF NOT EXISTS idx_term_glyph ON term(glyph);
            """)
            
            # Load axioms from config
            for ax in CFG.get("axioms", []):
                conn.execute("""
                INSERT OR IGNORE INTO axiom(glyph, title, latex, definition) 
                VALUES(?, ?, ?, ?)
                """, (
                    ax.get("glyph", ""),
                    ax.get("title", ""), 
                    ax.get("latex", ""), 
                    ax.get("definition", "")
                ))
            
            conn.commit()
            
            # Count loaded items
            _metrics["axioms_loaded"] = conn.execute("SELECT COUNT(*) FROM axiom").fetchone()[0]
            _metrics["terms_loaded"] = conn.execute("SELECT COUNT(*) FROM term").fetchone()[0]
            
            _initialized = True
            _metrics["init_time_ms"] = (time.time() - start_time) * 1000
            
            logger.info(f"Periodic table initialized with {_metrics['axioms_loaded']} axioms and {_metrics['terms_loaded']} terms")
            return True
            
        except Exception as e:
            _metrics["errors"] += 1
            logger.error(f"Error initializing schema: {e}")
            return False

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Axiom Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def add_axiom(glyph: str, title: str, latex: str, definition: str) -> bool:
    """Add a new axiom to the periodic table."""
    initialize_schema()
    
    with _pt_lock:
        conn = get_connection()
        try:
            conn.execute("""
            INSERT OR IGNORE INTO axiom(glyph, title, latex, definition) 
            VALUES(?, ?, ?, ?)
            """, (glyph, title, latex, definition))
            
            _metrics["writes_performed"] += 1
            return True
        except Exception as e:
            _metrics["errors"] += 1
            logger.error(f"Error adding axiom: {e}")
            return False

def get_axiom(glyph: str) -> Optional[Dict[str, Any]]:
    """Get an axiom by its glyph."""
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        row = conn.execute("SELECT * FROM axiom WHERE glyph = ?", (glyph,)).fetchone()
        
        if row:
            return {
                "id": row["id"],
                "glyph": row["glyph"],
                "title": row["title"],
                "latex": row["latex"],
                "definition": row["definition"]
            }
        return None
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error getting axiom: {e}")
        return None

def get_all_axioms() -> List[Dict[str, Any]]:
    """Get all axioms from the periodic table."""
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        result = []
        for row in conn.execute("SELECT * FROM axiom ORDER BY id"):
            result.append({
                "id": row["id"],
                "glyph": row["glyph"],
                "title": row["title"],
                "latex": row["latex"],
                "definition": row["definition"]
            })
        return result
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error getting axioms: {e}")
        return []

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Term Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def add_term(term: str, glyph: str) -> bool:
    """Add a new term linked to a glyph."""
    initialize_schema()
    
    with _pt_lock:
        conn = get_connection()
        try:
            conn.execute("""
            INSERT OR REPLACE INTO term(term, glyph) 
            VALUES(?, ?)
            """, (term, glyph))
            
            _metrics["writes_performed"] += 1
            return True
        except Exception as e:
            _metrics["errors"] += 1
            logger.error(f"Error adding term: {e}")
            return False

def get_term(term: str) -> Optional[Dict[str, Any]]:
    """Get a term and its linked glyph."""
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        row = conn.execute("SELECT * FROM term WHERE term = ?", (term,)).fetchone()
        
        if row:
            return {
                "id": row["id"],
                "term": row["term"],
                "glyph": row["glyph"]
            }
        return None
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error getting term: {e}")
        return None

def get_terms_by_glyph(glyph: str) -> List[str]:
    """Get all terms linked to a specific glyph."""
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        rows = conn.execute("SELECT term FROM term WHERE glyph = ?", (glyph,)).fetchall()
        return [row["term"] for row in rows]
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error getting terms by glyph: {e}")
        return []

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Search and Discovery
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def search_axioms(query: str) -> List[Dict[str, Any]]:
    """Search axioms by title, latex, or definition."""
    initialize_schema()
    
    conn = get_connection()
    try:
        _metrics["queries_executed"] += 1
        pattern = f"%{query}%"
        
        sql = """
        SELECT * FROM axiom 
        WHERE title LIKE ? 
           OR definition LIKE ? 
           OR latex LIKE ? 
        ORDER BY id
        """
        
        result = []
        for row in conn.execute(sql, (pattern, pattern, pattern)):
            result.append({
                "id": row["id"],
                "glyph": row["glyph"],
                "title": row["title"],
                "latex": row["latex"],
                "definition": row["definition"]
            })
        return result
    except Exception as e:
        _metrics["errors"] += 1
        logger.error(f"Error searching axioms: {e}")
        return []

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def health_check() -> Dict[str, Any]:
    """Perform a health check on the periodic table system."""
    initialize_schema()
    
    status = "healthy"
    details = {}
    
    # Check if database exists and is readable
    if not os.path.exists(PTDB):
        status = "degraded"
        details["missing_database"] = f"Database file not found: {PTDB}"
    
    # Verify we can read from the database
    try:
        conn = get_connection()
        conn.execute("SELECT COUNT(*) FROM axiom").fetchone()
    except Exception as e:
        status = "critical" 
        details["database_error"] = str(e)
    
    # Check for database integrity
    try:
        conn = get_connection()
        integrity_check = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity_check != "ok":
            status = "degraded"
            details["integrity_check"] = integrity_check
    except Exception as e:
        status = "degraded"
        details["integrity_check_error"] = str(e)
        
    # Get statistics
    try:
        conn = get_connection()
        axiom_count = conn.execute("SELECT COUNT(*) FROM axiom").fetchone()[0]
        term_count = conn.execute("SELECT COUNT(*) FROM term").fetchone()[0]
        
        # Update metrics
        _metrics["axioms_loaded"] = axiom_count
        _metrics["terms_loaded"] = term_count
    except Exception as e:
        status = "degraded"
        details["stats_error"] = str(e)
        
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Cleanup and Shutdown
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """Perform cleanup operations on shutdown."""
    logger.info("Running periodic table module cleanup")
    close_all_connections()

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialize Module
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialize schema when module is imported
initialize_schema()

# Export public API
__all__ = [
    'add_axiom', 'get_axiom', 'get_all_axioms',
    'add_term', 'get_term', 'get_terms_by_glyph',
    'search_axioms', 'health_check'
]

# Module self-test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"=== Periodic Table Module Self-Test ===")
    print(f"Database location: {PTDB}")
    
    # Basic health check
    health = health_check()
    print(f"Health status: {health['status']}")
    print(f"Axiom count: {_metrics['axioms_loaded']}")
    print(f"Term count: {_metrics['terms_loaded']}")
    
    # List all axioms
    axioms = get_all_axioms()
    if axioms:
        print("\nAxioms:")
        for ax in axioms:
            print(f"  {ax['glyph']} - {ax['title']}")
    
    # Test search
    if axioms and len(axioms) > 0:
        search_term = axioms[0]['title'].split()[0]
        print(f"\nSearching for '{search_term}':")
        results = search_axioms(search_term)
        for res in results:
            print(f"  {res['glyph']} - {res['title']}")
