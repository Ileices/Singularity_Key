# ───────────────────────── organism_autonomous.py ──────────────────────────
import os, time, threading, shutil, json as _json, csv, yaml
from collections import deque
from pathlib import Path
from datetime import datetime as _dt
from organism_neuro import neuro_ingest
from singularity_boot import glyph_id, trifecta, _consume_block, _learn_fact, _persist_fact
from singularity_boot import R0, B0, Y0
import hashlib as _h
from organism_inference import infer_with_metadata

PROJECTS_DIR  = Path("ecosystem") / "projects"; PROJECTS_DIR.mkdir(exist_ok=True)
CAPSULE_DIR   = Path("ecosystem") / "capsules"; CAPSULE_DIR.mkdir(exist_ok=True)
SCRATCH_DIR   = Path("ecosystem") / "scratch"; SCRATCH_DIR.mkdir(exist_ok=True)

# 1. Capsule structure → *.gph.json
def _mk_capsule(src_path: Path, r_tot, b_tot, y_tot, notes="") -> Path:
    raw = src_path.read_bytes()
    gid = glyph_id(raw)
    capsule = {
        "glyph": gid,
        "size_bytes": len(raw),
        "rby_digest": (str(r_tot), str(r_tot), str(y_tot)),
        "sha256": _h.sha256(raw).hexdigest(),
        "filename": src_path.name,
        "notes": notes,
        "created_utc": _dt.utcnow().isoformat(),
        "recipe": ["restore >>", src_path.name]
    }
    cfile = CAPSULE_DIR / f"{gid}.gph.json"
    cfile.write_text(_json.dumps(capsule, indent=2))
    src_path.unlink(missing_ok=True)
    return cfile

# 2. Background worker A – continuous seed-asset ingestion
def _auto_ingest_seed_assets():
    ASSET_QUEUE: deque[Path] = deque()
    SEED_DIR = Path("seed_assets")

    def _scan():
        for p in SEED_DIR.glob("**/*"):
            if p.is_file() and p.suffix.lower() not in {".gph.json", ".pyc"}:
                ASSET_QUEUE.append(p)

    _scan()
    seq = 10_000
    while True:
        if not ASSET_QUEUE:
            time.sleep(30)
            _scan()
            continue

        path = ASSET_QUEUE.popleft()
        try:
            txt = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        print(f"[seed_asset] ingesting {path.name}")
        _consume_block(txt, seq)
        seq += 1
        _mk_capsule(path, *_last_rby)

threading.Thread(target=_auto_ingest_seed_assets, daemon=True).start()

# 3. Background worker B – mutate / test / evolve projects
class _ProjectForge(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)

    def run(self):
        while True:
            picks = list(_FACTS_CACHE)[:3] if _FACTS_CACHE else []
            brief = " & ".join(f"{s} {p} {o}" for s, p, o in picks)
            
            # Calculate RBY weights for this generation task
            if picks:
                prompt = f"Generate Python code that implements or demonstrates: {brief}"
                
                # Use the unified inference system with RBY weighting
                result = infer_with_metadata(prompt, mode="hybrid")
                code = result["result"]
                
                # Extract code if the result contains markdown code blocks
                if "```python" in code and "```" in code.split("```python", 1)[1]:
                    code = code.split("```python", 1)[1].split("```", 1)[0]
                elif "```" in code:
                    # Try without language specifier
                    code = code.split("```", 1)[1].split("```", 1)[0]
            else:
                code = f"# autogen experiment\n# brief: {brief}\n\nprint({len(picks)} + 1)\n"
            
            tmp = SCRATCH_DIR / f"exp_{int(time.time())}.py"
            tmp.write_text(code)

            ok = False
            try:
                import subprocess, sys
                subprocess.check_output([sys.executable, tmp], timeout=3)
                ok = True
            except Exception as e:
                print(f"PROJECT-FAIL {tmp.name} {e}")

            if ok:
                dst = PROJECTS_DIR / tmp.name
                tmp.replace(dst)
                print(f"PROJECT-OK   {dst.name}")
            else:
                _mk_capsule(tmp, R0, B0, Y0, notes="auto-forge failure")

            time.sleep(45)

_FACTS_CACHE: deque[tuple[str, str, str]] = deque(maxlen=500)
_last_rby = (0, 0, 0)
_ProjectForge().start()

# 4. Background worker C – periodic bloat compression
def _compress_bloat():
    while True:
        total, used, free = shutil.disk_usage("ecosystem")
        if free / total < 0.05:
            for p in Path("ecosystem").rglob("*"):
                if p.is_file() and p.suffix != ".gph.json" and p.stat().st_size > 1_000_000:
                    _mk_capsule(p, R0, B0, Y0, notes="auto-compression")
        time.sleep(600)

threading.Thread(target=_compress_bloat, daemon=True).start()

# 5. Program-of-Understanding reconstruction
def _cmd_program(arg: str | None):
    if not arg:
        print("usage: /program <glyph>")
        return
    cfile = CAPSULE_DIR / f"{arg}.gph.json"
    if not cfile.exists():
        print("capsule not found")
        return
    cap = _json.loads(cfile.read_text())
    proj_path = PROJECTS_DIR / cap["filename"]
    raw_bytes = _json.dumps(cap, indent=2).encode()
    proj_path.write_bytes(raw_bytes)
    print(f"restored → {proj_path}")

META = {}
META["/program"] = lambda arg=None: _cmd_program(arg)