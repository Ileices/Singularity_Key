#!/usr/bin/env python3
# Inference Integration Entry Point
# =================================

"""
Inference Integration Entry Point
--------------------------------
This script integrates all inference capabilities of the codebase,
ensuring that RBY weights and inference systems work together.

Just import this file in singularity_boot.py to activate all integrations.
"""

import sys
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s'
)
logger = logging.getLogger("integrate_inference")

# Import integration module
try:
    from inference_integration import (
        integrated_infer,
        integrated_infer_with_metadata,
        get_integrated_stats,
        cmd_integrated_infer,
        cmd_integrated_stats
    )
    INTEGRATION_LOADED = True
except ImportError:
    logger.warning("Could not load inference_integration module")
    INTEGRATION_LOADED = False

# Register commands with META
def register_commands():
    """Register inference commands with META dictionary"""
    try:
        if 'singularity_boot' in sys.modules:
            meta = sys.modules['singularity_boot'].META
            
            # Register integrated commands
            if INTEGRATION_LOADED:
                meta["/integrated-infer"] = cmd_integrated_infer
                meta["/integrated-stats"] = cmd_integrated_stats
                
                # Add an alias for backward compatibility
                if "/infer" not in meta:
                    meta["/infer"] = cmd_integrated_infer
                if "/infer-stats" not in meta:
                    meta["/infer-stats"] = cmd_integrated_stats
                    
                logger.info("Registered integrated inference commands in META")
            else:
                logger.warning("Integrated inference commands not available")
    except Exception as e:
        logger.error(f"Error registering commands: {e}")

# Function to test if RBY is correctly integrated with inference
def test_rby_inference_integration():
    """
    Test if RBY weights properly influence inference parameters.
    Returns True if integration is working correctly.
    """
    if not INTEGRATION_LOADED:
        logger.warning("Cannot test RBY integration - module not loaded")
        return False
        
    try:
        # Import necessary functions
        from singularity_boot import perception, cognition, execution
        
        # Test queries with different expected RBY profiles
        test_cases = [
            # Query expected to have high perception (R)
            ("Imagine a world where gravity works in reverse", "perception"),
            # Query expected to have high cognition (B)
            ("Analyze the logical structure of the Pythagorean theorem", "cognition"),
            # Query expected to have high execution (Y)
            ("Execute the following steps to sort a list in Python", "execution")
        ]
        
        results = []
        for query, dominant in test_cases:
            # Get RBY values
            r = perception(query)
            b = cognition(query)
            y = execution(query)
            
            # Check if expected dominance is present
            if dominant == "perception" and r > max(b, y):
                results.append(True)
            elif dominant == "cognition" and b > max(r, y):
                results.append(True)
            elif dominant == "execution" and y > max(r, b):
                results.append(True)
            else:
                results.append(False)
                
            # Run a test inference to see how RBY affects parameters
            result = integrated_infer_with_metadata(query)
            logger.info(f"Test query '{query[:20]}...' - RBY: ({r:.2f}, {b:.2f}, {y:.2f})")
            logger.info(f"Inference params: {result.get('metadata', {}).get('params', {})}")
        
        integration_ok = all(results)
        if integration_ok:
            logger.info("RBY-Inference integration test passed")
        else:
            logger.warning("RBY-Inference integration test failed - check weights")
            
        return integration_ok
        
    except Exception as e:
        logger.error(f"Error testing RBY integration: {e}")
        return False

# Main function to run all integration tasks
def integrate_all():
    """
    Run all integration tasks to ensure RBY and inference are properly connected.
    """
    logger.info("Starting inference integration...")
    
    # Register commands
    register_commands()
    
    # Test RBY integration
    integration_ok = test_rby_inference_integration()
    
    # Report overall status
    if integration_ok:
        logger.info("Inference integration complete - all systems connected")
    else:
        logger.warning("Inference integration partially complete - some connections may be missing")

# Run integration when imported
integrate_all()

# If run directly, provide more detailed testing
if __name__ == "__main__":
    print("Testing Inference Integration")
    
    # Test with some example queries
    if INTEGRATION_LOADED:
        test_queries = [
            "What is the relationship between mass and energy?",
            "Write a Python function to calculate prime numbers.",
            "Describe the process of photosynthesis."
        ]
        
        for query in test_queries:
            print(f"\nQuery: {query}")
            result = integrated_infer(query)
            print(f"Result: {result[:150]}...")
            
        print("\nIntegrated Inference Statistics:")
        stats = get_integrated_stats()
        for key, value in stats.items():
            print(f"{key}: {value}")
    else:
        print("Inference integration module not available - run setup first")
