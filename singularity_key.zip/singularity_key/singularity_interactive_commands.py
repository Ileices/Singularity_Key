#!/usr/bin/env python3
"""
Singularity Interactive Commands Module
---------------------------------------
Provides interactive command line commands for querying and interacting with the knowledge base.

Features:
- /ask command for natural language queries
- /why command for explanation retrieval
- /recall command for glyph-based information retrieval
- Thread-safe operations with proper locking
- Comprehensive logging and error handling
- Performance metrics for monitoring
"""

import os
import sys
import threading
import time
import json
import logging
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Callable

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.interactive_commands")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "ask_queries": 0,
    "why_queries": 0,
    "recall_queries": 0,
    "cache_hits": 0,
    "cache_misses": 0,
    "errors": 0
}

# Thread safety
_stats_lock = threading.RLock()
_query_lock = threading.RLock()

# Global references to required components - populated during initialization
_vector_index = None
_kv_store = None
_db_connection = None
_neuro_query = None
_knowledge_api = None

class InteractiveCommandsSystem:
    """
    Handles interactive commands for querying and interacting with the knowledge base.
    
    Provides implementation for:
    - /ask command for natural language queries
    - /why command for explanation retrieval 
    - /recall command for glyph-based information retrieval
    """
    
    def __init__(self, 
                 neuro_query_func=None, 
                 vector_index=None, 
                 kv_store=None, 
                 db_connection=None,
                 knowledge_api=None):
        """
        Initialize the InteractiveCommandsSystem.
        
        Args:
            neuro_query_func: Function to query the neural system
            vector_index: Vector index for similarity search
            kv_store: Key-value store
            db_connection: SQLite database connection
            knowledge_api: Knowledge API instance
        """
        self.neuro_query = neuro_query_func
        self.vector_index = vector_index
        self.kv_store = kv_store
        self.db = db_connection
        self.cursor = db_connection.cursor() if db_connection else None
        self.knowledge_api = knowledge_api
        self.lock = threading.RLock()
        self.cache = {}
        
        logger.info("InteractiveCommandsSystem initialized")
    
    def ask_command(self) -> None:
        """
        Implementation of the /ask command.
        Prompts the user for a question and returns a response using the neural query system.
        """
        try:
            with self.lock:
                question = input("question> ").strip()
                if not question:
                    print("Please enter a question.")
                    return
                
                if self.neuro_query:
                    answer = self.neuro_query(question)
                    print(f"\n{answer}\n")
                    
                    with _stats_lock:
                        _STATS["ask_queries"] += 1
                else:
                    print("Neural query system not available.")
                    with _stats_lock:
                        _STATS["errors"] += 1
                
        except KeyboardInterrupt:
            print("\nOperation cancelled.")
        except Exception as e:
            logger.error(f"Error in ask_command: {e}")
            print(f"Error processing question: {str(e)}")
            with _stats_lock:
                _STATS["errors"] += 1
    
    def why_command(self) -> None:
        """
        Implementation of the /why command.
        Prompts the user for a term to explain and retrieves a matching explanation.
        """
        try:
            with self.lock:
                query = input("explain › ").strip()
                if not query:
                    print("Please enter a term to explain.")
                    return
                
                if self.vector_index and self.db:
                    # Search for the term in the vector index
                    glyph_ids = self.vector_index.search(query, k=1)
                    
                    if not glyph_ids:
                        print("No causal data.")
                        return
                    
                    glyph_id = glyph_ids[0]
                    
                    # Retrieve the explanation from the database
                    row = self.cursor.execute(
                        "SELECT definition FROM axiom WHERE glyph=?", 
                        (glyph_id,)
                    ).fetchone()
                    
                    if row:
                        print(f"Because {row[0]}")
                    else:
                        print("No explanation stored.")
                    
                    with _stats_lock:
                        _STATS["why_queries"] += 1
                else:
                    print("Vector index or database not available.")
                    with _stats_lock:
                        _STATS["errors"] += 1
                
        except KeyboardInterrupt:
            print("\nOperation cancelled.")
        except Exception as e:
            logger.error(f"Error in why_command: {e}")
            print(f"Error retrieving explanation: {str(e)}")
            with _stats_lock:
                _STATS["errors"] += 1
    
    def recall_command(self) -> None:
        """
        Implementation of the /recall command.
        Prompts the user for a glyph or key and retrieves the corresponding value.
        """
        try:
            with self.lock:
                key = input("glyph or key › ").strip()
                if not key:
                    print("Please enter a glyph or key.")
                    return
                
                if self.kv_store:
                    blob = self.kv_store.get(key)
                    
                    if not blob:
                        print("Nothing stored.")
                        return
                    
                    # Try to decode the blob as UTF-8
                    try:
                        decoded = blob.decode('utf-8')
                        print(f"Value: {decoded}")
                    except UnicodeDecodeError:
                        print(f"Binary data, {len(blob)} bytes")
                    
                    with _stats_lock:
                        _STATS["recall_queries"] += 1
                else:
                    print("Key-value store not available.")
                    with _stats_lock:
                        _STATS["errors"] += 1
                
        except KeyboardInterrupt:
            print("\nOperation cancelled.")
        except Exception as e:
            logger.error(f"Error in recall_command: {e}")
            print(f"Error retrieving value: {str(e)}")
            with _stats_lock:
                _STATS["errors"] += 1

# Global instance
interactive_commands = None

# ──────────────────────────────────────────────────────────────────────────
# Legacy compatibility implementation for the original meta-commands
# ──────────────────────────────────────────────────────────────────────────
def _cmd_ask() -> None:
    """
    Legacy implementation of the /ask command.
    """
    global interactive_commands
    
    if interactive_commands:
        interactive_commands.ask_command()
    else:
        logger.warning("Interactive commands system not initialized - using legacy implementation")
        
        try:
            from singularity_boot import neuro_query
            
            q = input("question> ")
            print("\n" + neuro_query(q) + "\n")
        except ImportError as e:
            logger.error(f"Legacy implementation failed: {e}")
            print("Error: Neural query system not available.")

def _cmd_why() -> None:
    """
    Legacy implementation of the /why command.
    """
    global interactive_commands
    
    if interactive_commands:
        interactive_commands.why_command()
    else:
        logger.warning("Interactive commands system not initialized - using legacy implementation")
        
        try:
            from singularity_boot import con, β_vdx
            
            q = input("explain › ").strip()
            # just choose the first match for demo
            gids = β_vdx.search(q, 1)
            if not gids: 
                print("No causal data.")
                return
            
            gid = gids[0]
            row = con.execute("SELECT definition FROM axiom WHERE glyph=?", (gid,)).fetchone()
            if row: 
                print(f"Because {row[0]}")
            else:   
                print("No explanation stored.")
        except ImportError as e:
            logger.error(f"Legacy implementation failed: {e}")
            print("Error: Vector index or database not available.")

def _cmd_recall() -> None:
    """
    Legacy implementation of the /recall command.
    """
    global interactive_commands
    
    if interactive_commands:
        interactive_commands.recall_command()
    else:
        logger.warning("Interactive commands system not initialized - using legacy implementation")
        
        try:
            from singularity_boot import β_kv
            
            k = input("glyph or key › ").strip()
            blob = β_kv.get(k)
            if not blob:
                print("Nothing stored.")
                return
                
            # Try to decode the blob as UTF-8
            try:
                decoded = blob.decode('utf-8')
                print(f"Value: {decoded}")
            except UnicodeDecodeError:
                print(f"Binary data, {len(blob)} bytes")
                
        except ImportError as e:
            logger.error(f"Legacy implementation failed: {e}")
            print("Error: Key-value store not available.")

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(neuro_query_func=None, vector_index=None, kv_store=None, 
               db_connection=None, knowledge_api=None) -> InteractiveCommandsSystem:
    """
    Initialize the interactive commands system.
    
    Args:
        neuro_query_func: Function to query the neural system
        vector_index: Vector index for similarity search
        kv_store: Key-value store
        db_connection: SQLite database connection
        knowledge_api: Knowledge API instance
        
    Returns:
        Initialized InteractiveCommandsSystem
    """
    global interactive_commands
    global _neuro_query, _vector_index, _kv_store, _db_connection, _knowledge_api
    
    logger.info("Initializing interactive commands system")
    
    # Store references to required components
    _neuro_query = neuro_query_func
    _vector_index = vector_index
    _kv_store = kv_store
    _db_connection = db_connection
    _knowledge_api = knowledge_api
    
    # Create interactive commands system
    interactive_commands = InteractiveCommandsSystem(
        neuro_query_func=neuro_query_func,
        vector_index=vector_index,
        kv_store=kv_store,
        db_connection=db_connection,
        knowledge_api=knowledge_api
    )
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Interactive commands system initialized in {_STATS['init_time_ms']} ms")
    
    return interactive_commands

def health_check() -> dict:
    """
    Perform a health check on the interactive commands system.
    
    Returns:
        Dictionary with health status information
    """
    global interactive_commands
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not interactive_commands:
        status = "error"
        warnings.append("Interactive commands system not initialized")
    else:
        try:
            # Check dependencies
            dependencies = {
                "neuro_query": interactive_commands.neuro_query is not None,
                "vector_index": interactive_commands.vector_index is not None,
                "kv_store": interactive_commands.kv_store is not None,
                "db_connection": interactive_commands.db is not None,
                "knowledge_api": interactive_commands.knowledge_api is not None,
            }
            
            details["dependencies"] = dependencies
            
            # Check if any dependencies are missing
            missing_deps = [name for name, present in dependencies.items() if not present]
            if missing_deps:
                if status != "error":
                    status = "warning"
                warnings.append(f"Missing dependencies: {', '.join(missing_deps)}")
            
        except Exception as e:
            status = "error"
            warnings.append(f"Interactive commands system error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "interactive_commands",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the interactive commands system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown() -> None:
    """
    Perform clean shutdown of interactive commands system resources.
    """
    global interactive_commands
    
    if interactive_commands:
        logger.info("Shutting down interactive commands system")
        # Nothing to clean up for now

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_interactive_commands_status() -> None:
    """
    Command handler for /interactive-commands-status
    """
    if not interactive_commands:
        print("Interactive commands system not initialized")
        return
    
    health = health_check()
    
    print("\nInteractive Commands System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    print("\nDependencies:")
    for name, status in health["details"].get("dependencies", {}).items():
        status_symbol = "✓" if status else "✗"
        print(f"  {name}: {status_symbol}")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'InteractiveCommandsSystem',
    '_cmd_ask',
    '_cmd_why',
    '_cmd_recall',
    'interactive_commands',
    '_cmd_interactive_commands_status'
]
