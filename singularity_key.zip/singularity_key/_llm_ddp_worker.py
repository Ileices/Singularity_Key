# ─────────────────────────── _llm_ddp_worker.py ───────────────────────────
#!/usr/bin/env python3
import argparse, os, torch, math, json
from transformers import (AutoTokenizer, AutoModelForCausalLM,
                          Trainer, TrainingArguments,
                          DataCollatorForLanguageModeling)
from datasets import Dataset
from torch.distributed import init_process_group, destroy_process_group

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--gpus", type=int, required=True)
    p.add_argument("--model_dir", required=True)
    p.add_argument("--data", required=True)
    args = p.parse_args()

    os.environ["WORLD_SIZE"] = str(args.gpus)
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    torch.cuda.set_device(local_rank)
    init_process_group(backend="nccl")

    tok   = AutoTokenizer.from_pretrained(args.model_dir)
    tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(args.model_dir).to(local_rank)

    text = open(args.data, encoding="utf-8").read()
    samples = [ {"text": blk.strip()}
                for blk in text.split("\n") if blk.strip() ]
    ds = Dataset.from_list(samples)
    ds = ds.map(lambda ex: tok(ex["text"]), batched=True, remove_columns=["text"])

    collator = DataCollatorForLanguageModeling(tok, mlm=False)
    steps = math.ceil(len(ds)/8)

    tr_args = TrainingArguments(
        output_dir = args.model_dir,
        per_device_train_batch_size = 1,
        gradient_accumulation_steps = 8,
        learning_rate = 2e-5,
        num_train_epochs = 1,
        max_steps = steps,
        fp16 = True,
        ddp_find_unused_parameters=False,
        logging_steps = 10,
        save_strategy = "no",
        report_to = []
    )

    Trainer(model=model, args=tr_args,
            train_dataset=ds,
            data_collator=collator).train()

    if local_rank == 0:
        model.save_pretrained(args.model_dir)

    destroy_process_group()

if __name__ == "__main__":
    main()