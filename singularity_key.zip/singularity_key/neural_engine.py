#!/usr/bin/env python3
# neural_engine.py  –  self-training + compression companion for Singularity Seed
# ══════════════════════════════════════════════════════════════════════════════
import os, json, time, textwrap, shutil, subprocess, random, logging, pathlib, hashlib as _h
from datetime import datetime as _dt
import torch, pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer
# ----------------------------------------------------------------------------- 
BASE   = pathlib.Path(__file__).parent.resolve()
ECO    = BASE / "ecosystem"
CORPUS = ECO  / "corpus"          ;  CORPUS.mkdir(exist_ok=True)
MODELS = ECO  / "models"          ;  MODELS.mkdir(exist_ok=True)
GLYPHS = ECO  / "glyph_archive"   ;  GLYPHS.mkdir(exist_ok=True)

TOKENIZER_NAME = "gpt2"           # tiny & licence-permissive
MODEL_NAME     = "gpt2"           # replace with Eleuther… if you like
BLOCK_SIZE     = 256

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
_log = logging.getLogger("neural-engine")

# == 1.  corpus append =========================================================
def push_into_corpus(text:str, source:str):
    """Append one text sample into a daily parquet shard."""
    shard = CORPUS / f"day_{_dt.utcnow().strftime('%Y%m%d')}.parquet"
    df    = pd.DataFrame([{"utc":_dt.utcnow().isoformat(),
                           "src":source, "text":textwrap.shorten(text, 20000, " […]")}])
    table = pa.Table.from_pandas(df)
    if shard.exists():
        pq.write_table(table, shard, append=True)
    else:
        pq.write_table(table, shard)
    _log.debug(f"[corpus] +1 sample ({source})")

# == 2.  nightly fine-tune job =================================================
def _latest_corpus_paths(max_days:int=14):
    files = sorted(CORPUS.glob("day_*.parquet"))[-max_days:]
    return [str(p) for p in files]

def _prepare_dataset():
    import datasets
    tokenizer = AutoTokenizer.from_pretrained(TOKENIZER_NAME)
    def _gen():
        for path in _latest_corpus_paths():
            for batch in pq.read_table(path).to_pandas()["text"].tolist():
                yield {"text":batch}
    ds = datasets.Dataset.from_generator(_gen)
    def tok(batch):
        return tokenizer(batch["text"], truncation=True,
                         padding="max_length", max_length=BLOCK_SIZE)
    return ds.map(tok, batched=True, remove_columns=["text"])

def train_once(max_steps:int=600):
    """Run one fine-tune pass on the freshest shards (single process)."""
    ds   = _prepare_dataset()
    tok  = AutoTokenizer.from_pretrained(TOKENIZER_NAME)
    mod  = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
    ta   = TrainingArguments(output_dir="checkpoints",
                             overwrite_output_dir=True,
                             per_device_train_batch_size=2,
                             learning_rate=2e-5,
                             logging_steps=50,
                             save_steps=max_steps//2,
                             max_steps=max_steps,
                             fp16=torch.cuda.is_available())
    Trainer(model=mod, args=ta, train_dataset=ds).train()
    stamp = _dt.utcnow().strftime('%Y%m%d_%H%M%S')
    targ  = MODELS / f"gpt_{stamp}"
    mod.save_pretrained(targ)
    tok.save_pretrained(targ)
    _log.info(f"[neural] model saved → {targ}")
    _prune_models(keep=3)

# == 3.  multi-GPU / multi-box launcher =======================================
def launch_distributed(nodes:int=1, gpus:int=None, steps:int=800):
    """Fire a torch-DDP job (assumes password-less ssh among nodes)."""
    gpus = gpus or torch.cuda.device_count()
    cmd  = ["torchrun",
            f"--nproc_per_node={gpus}",
            "--standalone",
            "neural_engine.py", "--train", str(steps)]
    if nodes>1:
        cmd.insert(1, f"--nnodes={nodes}")
    _log.info("[neural] spawning: "+" ".join(cmd))
    subprocess.Popen(cmd)

def prepare_corpus_for_ddp(max_days:int=14):
    """Prepares corpus data for DDP training by creating a consolidated text file"""
    corpus_files = _latest_corpus_paths(max_days)
    if not corpus_files:
        _log.error("No corpus files found for DDP training")
        return None
        
    # Create a temporary file with concatenated text data
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt', encoding='utf-8')
    
    try:
        total_samples = 0
        for path in corpus_files:
            try:
                table = pq.read_table(path)
                df = table.to_pandas()
                for text in df["text"].tolist():
                    if text and isinstance(text, str):
                        temp_file.write(text + "\n\n")
                        total_samples += 1
            except Exception as e:
                _log.error(f"Error processing corpus file {path}: {e}")
                
        temp_file.close()
        _log.info(f"Prepared corpus with {total_samples} samples for DDP training: {temp_file.name}")
        return temp_file.name
    except Exception as e:
        _log.error(f"Error preparing corpus for DDP: {e}")
        if temp_file:
            temp_file.close()
            try:
                os.unlink(temp_file.name)
            except:
                pass
        return None

def run_ddp_worker(model_dir=None, gpus=None):
    """Run the DDP worker script for distributed training on the corpus data."""
    if model_dir is None:
        # Use latest model or default to gpt2
        model_dir = find_latest_model()
        if model_dir is None:
            model_dir = "gpt2"
    
    gpus = gpus or torch.cuda.device_count()
    if gpus < 1:
        _log.error("No GPUs available for DDP training")
        return False
        
    # Prepare corpus data
    data_file = prepare_corpus_for_ddp()
    if not data_file:
        _log.error("Failed to prepare corpus data for DDP training")
        return False
    
    # Launch the DDP worker
    try:
        cmd = [
            sys.executable,  # Current Python executable
            str(BASE / "_llm_ddp_worker.py"),
            "--gpus", str(gpus),
            "--model_dir", str(model_dir),
            "--data", data_file
        ]
        
        _log.info(f"Starting DDP worker: {' '.join(cmd)}")
        process = subprocess.Popen(cmd)
        
        # Add the process to META commands so it can be monitored/managed
        return process
    except Exception as e:
        _log.error(f"Error launching DDP worker: {e}")
        return False

# == 4.  glyph compression =====================================================
def _prune_models(keep:int=3):
    """Keep N newest snapshots, SHA-compress older ones into glyph store."""
    snaps = sorted(MODELS.glob("gpt_*"))
    for old in snaps[:-keep]:
        payload = shutil.make_archive(str(old), "zip", old)
        sha = _h.sha256(open(payload,"rb").read()).hexdigest()[:16]
        glyph_path = GLYPHS / f"⟐{sha}.zip"
        shutil.move(payload, glyph_path)
        shutil.rmtree(old, ignore_errors=True)
        _log.info(f"[neural] compressed → {glyph_path}")

def find_latest_model():
    """Find the latest trained model for use in inference"""
    models = sorted(MODELS.glob("gpt_*"))
    return models[-1] if models else None

# == 5.  CLI helper when file executed stand-alone ============================
if __name__ == "__main__":
    import argparse; ap=argparse.ArgumentParser()
    ap.add_argument("--train", type=int, help="run a local fine-tune for N steps")
    args=ap.parse_args()
    if args.train: train_once(args.train)
