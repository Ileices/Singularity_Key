#!/usr/bin/env python3
"""
Singularity Glyphs Module
-------------------------
Handles all glyph-related operations for the Singularity system.

Features:
- Thread-safe glyph creation and validation
- Cryptographic hashing with configurable algorithms
- Glyph verification and pattern matching
- Integrity checking for glyph references
- Cross-platform storage and retrieval

This module is designed to work seamlessly with the rest of the Singularity codebase
while maintaining backward compatibility with older code.
"""
import re
import hashlib
import threading
import logging
import time
import pathlib
import json
import os
import stat
from typing import Dict, Any, Optional, Union, List, Tuple, Callable, BinaryIO

# Configure logging
_log = logging.getLogger("singularity.glyphs")

# Thread safety
_glyph_lock = threading.RLock()
_startup_time = time.time()

# Import configuration with fallback handling
try:
    from singularity_config import CFG, ECO
except ImportError:
    # Fallback implementation for standalone usage
    import yaml
    _BASE = pathlib.Path(__file__).parent.resolve()
    _CONFIG_PATH = _BASE / "singularity_config.yml"
    
    # Default configuration
    CFG = {"glyph_regex": "^⟐[0-9a-f]{16}$"}
    ECO = _BASE / "ecosystem"
    ECO.mkdir(exist_ok=True)
    
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            CFG = yaml.safe_load(f)
    except Exception as e:
        _log.error(f"Error loading config for glyph module: {e}")

# Performance metrics
_metrics = {
    "glyphs_generated": 0,
    "glyph_validations": 0,
    "glyph_errors": 0,
    "init_time_ms": 0
}

# Setup glyph storage paths
GLYPH_STORE = ECO / "glyphs"
GLYPH_STORE.mkdir(exist_ok=True, parents=True)
GLYPH_INDEX = ECO / "glyph_index.json"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Core Glyph functionality
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Compile regex pattern from configuration
try:
    _GLY_RE = re.compile(CFG["glyph_regex"])
except (KeyError, re.error) as e:
    _log.warning(f"Error compiling glyph regex: {e}")
    # Default pattern as fallback
    _GLY_RE = re.compile(r"^⟐[0-9a-f]{16}$")
    
# Regular expressions for validation
_CONTENT_TYPES = {
    "text": re.compile(r"^[\x20-\x7E\n\r\t]*$"),  # Basic ASCII
    "binary": re.compile(r".*")  # Anything
}

def valid_glyph(text: str) -> Optional[re.Match]:
    """
    Validate if a string matches the glyph pattern.
    
    Args:
        text: String to validate
        
    Returns:
        Match object if valid, None otherwise
    """
    with _glyph_lock:
        _metrics["glyph_validations"] += 1
        
    return _GLY_RE.fullmatch(text)

def glyph_id(data: bytes, algorithm: str = "blake2b", digest_size: int = 8) -> str:
    """
    Generate a glyph ID for binary data.
    
    Args:
        data: Binary data to hash
        algorithm: Hash algorithm to use (default: blake2b)
        digest_size: Size of digest in bytes (default: 8)
        
    Returns:
        Glyph string with format ⟐{hexdigest}
    """
    with _glyph_lock:
        _metrics["glyphs_generated"] += 1
        
        try:
            if algorithm == "blake2b":
                h = hashlib.blake2b(data, digest_size=digest_size)
            elif algorithm == "sha256":
                h = hashlib.sha256(data)
                h.digest()  # Full calculation
                # Truncate the hexdigest to match digest_size
                return f"⟐{h.hexdigest()[:digest_size*2]}"
            else:
                # Fallback to blake2b if unknown algorithm
                h = hashlib.blake2b(data, digest_size=digest_size)
            
            return f"⟐{h.hexdigest()}"
        except Exception as e:
            _metrics["glyph_errors"] += 1
            _log.error(f"Error generating glyph: {e}")
            # Fallback to basic hash in case of error
            return f"⟐{hashlib.md5(data).hexdigest()[:16]}"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Glyph storage and retrieval
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_glyph_index = {}
_index_loaded = False

def _load_glyph_index() -> Dict[str, Dict[str, Any]]:
    """Load the glyph index from disk with proper error handling."""
    global _glyph_index, _index_loaded
    
    with _glyph_lock:
        if _index_loaded:
            return _glyph_index
            
        if GLYPH_INDEX.exists():
            try:
                with open(GLYPH_INDEX, "r", encoding="utf-8") as f:
                    _glyph_index = json.load(f)
                _index_loaded = True
            except Exception as e:
                _log.error(f"Error loading glyph index: {e}")
                _glyph_index = {}
        else:
            _glyph_index = {}
            _index_loaded = True
            
        return _glyph_index

def _save_glyph_index():
    """Save the glyph index to disk with atomicity and error handling."""
    with _glyph_lock:
        try:
            # Create temp file
            temp_path = GLYPH_INDEX.with_suffix(".tmp")
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(_glyph_index, f, indent=2)
                
            # Ensure file is fully written to disk
            f.flush()
            os.fsync(f.fileno())
            
            # Atomic rename
            temp_path.replace(GLYPH_INDEX)
            
            # Set permissions (Unix systems only)
            if os.name == "posix":
                os.chmod(GLYPH_INDEX, stat.S_IRUSR | stat.S_IWUSR)
                
        except Exception as e:
            _log.error(f"Error saving glyph index: {e}")

def store_glyph(glyph_id: str, content: bytes, metadata: Optional[Dict[str, Any]] = None) -> bool:
    """
    Store content associated with a glyph.
    
    Args:
        glyph_id: The glyph identifier
        content: Binary content to store
        metadata: Optional metadata dictionary
        
    Returns:
        True if stored successfully, False otherwise
    """
    if not valid_glyph(glyph_id):
        _log.error(f"Invalid glyph format: {glyph_id}")
        return False
        
    # Load index if not loaded
    _load_glyph_index()
    
    glyph_path = GLYPH_STORE / f"{glyph_id}.bin"
    
    with _glyph_lock:
        try:
            # Write content
            with open(glyph_path, "wb") as f:
                f.write(content)
            
            # Update index
            _glyph_index[glyph_id] = {
                "size": len(content),
                "timestamp": time.time(),
                "metadata": metadata or {}
            }
            
            # Save index
            _save_glyph_index()
            return True
        except Exception as e:
            _log.error(f"Error storing glyph {glyph_id}: {e}")
            return False

def retrieve_glyph(glyph_id: str) -> Optional[bytes]:
    """
    Retrieve content associated with a glyph.
    
    Args:
        glyph_id: The glyph identifier
        
    Returns:
        Binary content if found, None otherwise
    """
    if not valid_glyph(glyph_id):
        _log.error(f"Invalid glyph format: {glyph_id}")
        return None
        
    # Load index if not loaded
    _load_glyph_index()
    
    glyph_path = GLYPH_STORE / f"{glyph_id}.bin"
    
    if not glyph_path.exists():
        _log.warning(f"Glyph not found: {glyph_id}")
        return None
        
    try:
        with open(glyph_path, "rb") as f:
            return f.read()
    except Exception as e:
        _log.error(f"Error retrieving glyph {glyph_id}: {e}")
        return None

def get_glyph_metadata(glyph_id: str) -> Optional[Dict[str, Any]]:
    """
    Get metadata associated with a glyph.
    
    Args:
        glyph_id: The glyph identifier
        
    Returns:
        Metadata dictionary if found, None otherwise
    """
    # Load index if not loaded
    _load_glyph_index()
    
    with _glyph_lock:
        glyph_info = _glyph_index.get(glyph_id)
        if glyph_info:
            return glyph_info.get("metadata", {})
        return None

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Advanced glyph operations
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def find_glyphs_by_metadata(key: str, value: Any) -> List[str]:
    """Find all glyphs with matching metadata key/value pairs."""
    _load_glyph_index()
    
    with _glyph_lock:
        results = []
        for gid, info in _glyph_index.items():
            metadata = info.get("metadata", {})
            if metadata.get(key) == value:
                results.append(gid)
        return results

def update_glyph_metadata(glyph_id: str, metadata_updates: Dict[str, Any]) -> bool:
    """Update metadata for a glyph."""
    _load_glyph_index()
    
    with _glyph_lock:
        if glyph_id not in _glyph_index:
            return False
            
        current = _glyph_index[glyph_id].get("metadata", {})
        current.update(metadata_updates)
        _glyph_index[glyph_id]["metadata"] = current
        _save_glyph_index()
        return True

def get_all_glyphs() -> List[str]:
    """Get a list of all stored glyphs."""
    _load_glyph_index()
    
    with _glyph_lock:
        return list(_glyph_index.keys())

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Utility functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_glyph_metrics() -> Dict[str, Any]:
    """Get metrics about glyph usage."""
    _load_glyph_index()
    
    with _glyph_lock:
        return {
            **_metrics,
            "total_glyphs": len(_glyph_index),
            "total_size_bytes": sum(info.get("size", 0) for info in _glyph_index.values()),
            "oldest_glyph_timestamp": min(
                (info.get("timestamp", float("inf")) for info in _glyph_index.values()),
                default=None
            ),
            "newest_glyph_timestamp": max(
                (info.get("timestamp", 0) for info in _glyph_index.values()),
                default=None
            )
        }

def health_check() -> Dict[str, Any]:
    """Perform a health check on the glyph system."""
    _load_glyph_index()
    
    status = "healthy"
    details = {}
    
    # Check if glyph store is writeable
    test_path = GLYPH_STORE / f"test_{time.time()}.tmp"
    try:
        test_path.touch()
        test_path.unlink()
    except Exception as e:
        status = "degraded"
        details["storage_error"] = str(e)
    
    # Check if index matches actual files
    indexed_glyphs = set(_glyph_index.keys())
    stored_files = {p.stem for p in GLYPH_STORE.glob("⟐*.bin")}
    
    missing_from_index = stored_files - indexed_glyphs
    missing_from_storage = indexed_glyphs - stored_files
    
    if missing_from_index:
        status = "degraded"
        details["unindexed_glyphs"] = list(missing_from_index)
        
    if missing_from_storage:
        status = "degraded"
        details["missing_glyph_files"] = list(missing_from_storage)
    
    return {
        "status": status,
        "glyph_count": len(_glyph_index),
        "details": details
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Cleanup and initialization
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _shutdown():
    """Perform cleanup operations during shutdown."""
    with _glyph_lock:
        if _index_loaded and _glyph_index:
            _save_glyph_index()

# Register shutdown handler
import atexit
atexit.register(_shutdown)

# Backward compatibility support
def provide_backward_compatibility(target_module):
    """Inject symbols into another module for backward compatibility."""
    # Export the core glyph helpers
    setattr(target_module, '_GLY_RE', _GLY_RE)
    setattr(target_module, 'valid_glyph', valid_glyph)
    setattr(target_module, 'glyph_id', glyph_id)

    # Add warning for direct access
    import warnings
    
    def warn_wrapper(func):
        warned = False
        def wrapper(*args, **kwargs):
            nonlocal warned
            if not warned:
                warnings.warn(
                    f"Direct access to glyph functions from {target_module.__name__} is deprecated. "
                    "Import from singularity_glyphs instead.",
                    DeprecationWarning, 2
                )
                warned = True
            return func(*args, **kwargs)
        return wrapper
    
    # Replace with warning-wrapped versions
    setattr(target_module, 'valid_glyph', warn_wrapper(valid_glyph))
    setattr(target_module, 'glyph_id', warn_wrapper(glyph_id))

# Initialize module
_metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
_log.debug(f"Glyph module initialized in {_metrics['init_time_ms']:.2f}ms")

# Export public API
__all__ = [
    '_GLY_RE', 'valid_glyph', 'glyph_id',
    'store_glyph', 'retrieve_glyph', 
    'get_glyph_metadata', 'update_glyph_metadata',
    'find_glyphs_by_metadata', 'get_all_glyphs',
    'get_glyph_metrics', 'health_check'
]

# Self-test when run directly
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Basic test
    test_data = b"Hello, world!"
    gid = glyph_id(test_data)
    print(f"Generated glyph: {gid}")
    print(f"Valid: {valid_glyph(gid) is not None}")
    
    # Store and retrieve
    store_glyph(gid, test_data, {"description": "Test glyph"})
    retrieved = retrieve_glyph(gid)
    print(f"Retrieved correctly: {retrieved == test_data}")
    
    # Metadata
    meta = get_glyph_metadata(gid)
    print(f"Metadata: {meta}")
    
    # Health check
    health = health_check()
    print(f"Health status: {health['status']}")
    print(f"Details: {health['details']}")
