# ─────────────────────────── organism_cluster.py ───────────────────────────
"""
Zero-config LAN discovery ➊   •   node benchmarking ➋   •   job RPC ➌
drop-in for the Singularity organism                           ─ RLM 2025
"""
import json, os, socket, struct, subprocess, sys, tempfile, threading, time, uuid
from   pathlib import Path
import shutil
import hashlib as _h

# ───────────────────────────────────────────────────────────────────────────
UDP_PORT      = 42424            # broadcast beacons
TCP_PORT      = 42425            # job channel
BEACON_EVERY  =  15              # seconds
PEER_TIMEOUT  =  45              # seconds without beacon ⇒ dead
JOB_DIR       = Path("ecosystem") / "jobs"; JOB_DIR.mkdir(exist_ok=True)

# ➊ ── Beacon: “who am I, what can I do?”
def _probe_gpu():
    try:
        import torch
        if torch.cuda.is_available():
            name  = torch.cuda.get_device_name(0)
            vram  = torch.cuda.get_device_properties(0).total_memory // 1_048_576
            return f"{name}:{vram}MB"
    except Exception: pass
    return "cpu"

NODE_ID  = f"{socket.gethostname()}-{uuid.uuid4().hex[:6]}"
PROFILE  = {
    "id"      : NODE_ID,
    "cpu"     : os.cpu_count(),
    "gpu"     : _probe_gpu(),
    "diskGB"  : (shutil.disk_usage(".").free // 1_073_741_824),
    "ts"      : time.time()
}

peers      = {}                 # id → profile
peers_lock = threading.Lock()

def _beacon_loop():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    blob = json.dumps(PROFILE).encode()
    while True:
        sock.sendto(blob, ("255.255.255.255", UDP_PORT))
        time.sleep(BEACON_EVERY)

def _listen_loop():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("", UDP_PORT))
    while True:
        data, _ = sock.recvfrom(2048)
        try:
            prof = json.loads(data.decode())
            with peers_lock:
                peers[prof["id"]] = prof | {"ts": time.time()}
        except Exception: pass

threading.Thread(target=_beacon_loop ,daemon=True).start()
threading.Thread(target=_listen_loop ,daemon=True).start()

# ───────────────────────────────────────────────────────────────────────────
# ➋ ── Pick the CURRENT “capacity leader”
def best_peer():
    with peers_lock:
        # drop stale
        for pid in list(peers):
            if time.time() - peers[pid]["ts"] > PEER_TIMEOUT:
                peers.pop(pid)
        everyone = list(peers.values()) + [PROFILE]
    # simple score = cpu + diskGB/10 + (gpu_vram_MB / 4096)
    def score(p):
        gpu_vram = 0
        if ":" in p["gpu"]:
            try: gpu_vram = int(p["gpu"].split(":")[1][:-2])
            except: pass
        return p["cpu"] + p["diskGB"]/10 + gpu_vram/4096
    return max(everyone, key=score)

# ───────────────────────────────────────────────────────────────────────────
# ➌ ── Minimal RPC: send python-callable + kwargs, receive result / error
def _job_server():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("", TCP_PORT)); srv.listen()
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=_handle, args=(conn,), daemon=True).start()

def _handle(conn):
    try:
        size = struct.unpack("!I", conn.recv(4))[0]
        blob = conn.recv(size)
        job  = json.loads(blob.decode())
        mod, fn = job["call"].rsplit(".",1)
        sys.path.append(job["cwd"])
        result = getattr(__import__(mod), fn)(*job["args"], **job["kwargs"])
        resp   = json.dumps({"ok": True, "result": result}).encode()
    except Exception as e:
        resp   = json.dumps({"ok": False,"err":repr(e)}).encode()
    conn.send(struct.pack("!I",len(resp))+resp); conn.close()

threading.Thread(target=_job_server, daemon=True).start()

# client side
def remote_call(call:str,*args,**kwargs):
    leader = best_peer()
    if leader["id"]==NODE_ID:                       # we *are* the leader
        mod,fn=call.rsplit(".",1)
        return getattr(__import__(mod),fn)(*args,**kwargs)
    addr = leader["id"].split("-")[0]               # crude hostname
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.settimeout(5)
    try:
        sock.connect((addr, TCP_PORT))
        payload = json.dumps({
            "call" : call,
            "args" : args,
            "kwargs": kwargs,
            "cwd"  : os.getcwd()
        }).encode()
        sock.send(struct.pack("!I",len(payload))+payload)
        size = struct.unpack("!I", sock.recv(4))[0]
        resp = json.loads(sock.recv(size).decode())
        if resp["ok"]: return resp["result"]
        raise RuntimeError(resp["err"])
    except Exception as e:
        print(f"[cluster] RPC to {addr} failed → fallback local ({e})")
        mod,fn=call.rsplit(".",1)
        return getattr(__import__(mod),fn)(*args,**kwargs)

# helper: run heavy torch on best GPU box
def llm_generate(prompt, max_new=256, temp=0.7):
    from organism_neuro import _LLM, _TOKEN, DEVICE
    def _gen(p,mn,tm):
        input_ids = _TOKEN(p,return_tensors="pt").to(DEVICE)
        out = _LLM.generate(**input_ids,max_new_tokens=mn,temperature=tm)
        return _TOKEN.decode(out[0],skip_special_tokens=True)
    return remote_call(__name__+"._gen", prompt, max_new, temp)

# small CLI
if __name__=="__main__":
    while True:
        cmd=input("cluster> ").strip()
        if cmd=="peers":
            print(best_peer()); print(json.dumps(list(peers.values()),indent=2))
        elif cmd.startswith("ask "):
            from organism_neuro import query
            q=cmd[4:]; print(llm_generate(q))
        else: print("peers | ask …")

def _save_index():
    """No-op function to maintain symmetry with organism_neuro."""
    pass