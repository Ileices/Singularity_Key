#!/usr/bin/env python3
"""
Singularity Knowledge API Module
-------------------------------
Unified knowledge interface that integrates various knowledge storage and retrieval mechanisms.

Features:
- KVStore for ultra-light persistent key-value storage over SQLite
- Integration with existing vector index for similarity searches
- Unified API for knowledge operations
- Thread-safe operations
- Proper error handling and recovery

This module ties together different knowledge systems within the Singularity organism
for a consistent and simplified interface.
"""

import os
import hashlib as _h
import json
import pickle as _pkl
import re
import sqlite3
import threading
import time
import logging
import pathlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import warnings
from collections import defaultdict as _dd

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.knowledge_api")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "facts_stored": 0,
    "facts_retrieved": 0,
    "cache_hits": 0,
    "cache_misses": 0,
    "errors": 0
}

# Thread safety
_kv_lock = threading.RLock()
_stats_lock = threading.RLock()

# Base paths
_BASE = Path(__file__).parent.resolve()
_ECO = _BASE / "ecosystem"
_ECO.mkdir(exist_ok=True)
_KV_DIR = _ECO / "kv_store"
_KV_DIR.mkdir(exist_ok=True)

# ──────────────────────────────────────────────────────────────────────────
# 1. Ultra-light persistent KVStore over SQLite
# ──────────────────────────────────────────────────────────────────────────
class KVStore:
    """
    Persistent key-value store using SQLite.
    
    Provides a simple dictionary-like interface with persistent storage.
    Thread-safe operations.
    """
    _CREATE = """CREATE TABLE IF NOT EXISTS kvstore(
                   key TEXT PRIMARY KEY, value BLOB)"""
    
    def __init__(self, db_path: Path = None):
        """Initialize the key-value store.
        
        Args:
            db_path: Path to SQLite database file. If None, uses default location.
        """
        if db_path is None:
            db_path = _KV_DIR / "kvstore.db"
        
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.db_path = db_path
        self.con = sqlite3.connect(str(db_path), check_same_thread=False)
        self.cur = self.con.cursor()
        self.cur.execute(self._CREATE)
        self.con.commit()
        self.lock = threading.RLock()
        self.cache = {}
        self.cache_size = 10000  # Maximum cache size
        
    def __getitem__(self, key: str) -> Optional[bytes]:
        """Get value for key."""
        with self.lock:
            # Check cache first
            if key in self.cache:
                with _stats_lock:
                    _STATS["cache_hits"] += 1
                return self.cache[key]
            
            with _stats_lock:
                _STATS["cache_misses"] += 1
            
            try:
                row = self.cur.execute("SELECT value FROM kvstore WHERE key=?", (key,)).fetchone()
                if row:
                    self.cache[key] = row[0]
                    return row[0]
                return None
            except Exception as e:
                logger.error(f"Error retrieving key '{key}': {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return None
    
    def __setitem__(self, key: str, value: bytes) -> bool:
        """Set value for key."""
        with self.lock:
            try:
                self.cur.execute(
                    "INSERT OR REPLACE INTO kvstore VALUES(?,?)",
                    (key, value)
                )
                self.con.commit()
                self.cache[key] = value
                
                # Prune cache if too large
                if len(self.cache) > self.cache_size:
                    self._prune_cache()
                
                return True
            except Exception as e:
                logger.error(f"Error setting key '{key}': {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return False
    
    def get(self, key: str, default=None) -> Optional[bytes]:
        """Get value for key with default fallback."""
        value = self[key]
        return value if value is not None else default
    
    def keys(self) -> List[str]:
        """Get all keys in the store."""
        with self.lock:
            try:
                rows = self.cur.execute("SELECT key FROM kvstore").fetchall()
                return [row[0] for row in rows]
            except Exception as e:
                logger.error(f"Error retrieving keys: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return []
    
    def delete(self, key: str) -> bool:
        """Delete a key-value pair."""
        with self.lock:
            try:
                self.cur.execute("DELETE FROM kvstore WHERE key=?", (key,))
                self.con.commit()
                if key in self.cache:
                    del self.cache[key]
                return True
            except Exception as e:
                logger.error(f"Error deleting key '{key}': {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return False
    
    def count(self) -> int:
        """Get the number of key-value pairs."""
        with self.lock:
            try:
                return self.cur.execute("SELECT COUNT(*) FROM kvstore").fetchone()[0]
            except Exception as e:
                logger.error(f"Error counting keys: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return 0
    
    def close(self) -> None:
        """Close the database connection."""
        with self.lock:
            try:
                self.con.close()
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
    
    def _prune_cache(self) -> None:
        """Prune the cache to the specified size."""
        if len(self.cache) > self.cache_size:
            # Remove approximately 10% of items
            to_remove = int(self.cache_size * 0.1)
            for key in list(self.cache.keys())[:to_remove]:
                del self.cache[key]

# ──────────────────────────────────────────────────────────────────────────
# 4. Knowledge API – ties everything together
# ──────────────────────────────────────────────────────────────────────────
class KnowledgeAPI:
    """
    Unified Knowledge API that integrates various knowledge storage and retrieval systems.
    
    This class ties together the KVStore, VectorIndex, and other knowledge components
    into a single coherent interface.
    """
    
    def __init__(self, db_con):
        """
        Initialize the Knowledge API.
        
        Args:
            db_con: SQLite database connection
        """
        self.db = db_con
        self.cur = db_con.cursor()
        self.lock = threading.RLock()
        
        # Cache for performance optimization
        self.query_cache = {}
        self.query_cache_size = 1000
        
        logger.info("Knowledge API initialized")
    
    # --- ingestion -----------------------------------------------------------
    def ingest_fact(self, subj: str, pred: str, obj: str, src: str) -> bool:
        """
        Ingest a fact into the knowledge system.
        
        Args:
            subj: Subject of the fact
            pred: Predicate relating subject to object
            obj: Object of the fact
            src: Source of the fact
        
        Returns:
            True if ingestion succeeded, False otherwise
        """
        try:
            with self.lock:
                # Generate a unique ID for this fact
                from singularity_glyphs import glyph_id
                gid = glyph_id(f"{subj}|{pred}|{obj}".encode())
                
                # Check if this fact is already known
                if kv_store.get(gid):
                    return True  # Already have it
                
                # Store in KV store
                kv_store[gid] = src.encode()
                
                # Store in vector index for similarity search
                from singularity_vector_index import vector_index
                vector_index.add_doc(gid, f"{subj} {pred} {obj}")
                
                with _stats_lock:
                    _STATS["facts_stored"] += 1
                
                logger.debug(f"Ingested fact: {subj} {pred} {obj}")
                return True
        
        except Exception as e:
            logger.error(f"Error ingesting fact: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False
    
    # --- retrieval -----------------------------------------------------------
    def query(self, text: str) -> str:
        """
        Query the knowledge system for facts similar to the provided text.
        
        Args:
            text: Query text
        
        Returns:
            String response with relevant facts or a message indicating no facts found
        """
        try:
            # Check cache first
            cache_key = hashlib.md5(text.encode()).hexdigest()
            with self.lock:
                if cache_key in self.query_cache:
                    with _stats_lock:
                        _STATS["cache_hits"] += 1
                    return self.query_cache[cache_key]
            
            with _stats_lock:
                _STATS["cache_misses"] += 1
                _STATS["facts_retrieved"] += 1
            
            # Search the vector index
            from singularity_vector_index import vector_index
            gids = vector_index.search(text, k=5)
            
            if not gids:
                return "I don't have any facts like that yet."
            
            rows = []
            for gid in gids:
                # First try to find it in the axiom table
                ax = self.cur.execute(
                    "SELECT definition FROM axiom WHERE glyph=?", (gid,)
                ).fetchone()
                if ax:
                    rows.append(ax[0])
            
            response = " ‖ ".join(rows[:3]) if rows else "I found glyphs but no verbal facts."
            
            # Cache the response
            with self.lock:
                self.query_cache[cache_key] = response
                if len(self.query_cache) > self.query_cache_size:
                    # Remove oldest entries
                    for k in list(self.query_cache.keys())[:100]:
                        del self.query_cache[k]
            
            return response
        
        except Exception as e:
            logger.error(f"Error querying knowledge: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return f"Error processing query: {str(e)}"
    
    def get_fact_by_glyph(self, glyph: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a fact by its glyph ID.
        
        Args:
            glyph: Glyph ID to retrieve
        
        Returns:
            Dictionary with fact details or None if not found
        """
        try:
            with self.lock:
                # Check KV store first
                src_bytes = kv_store.get(glyph)
                if not src_bytes:
                    return None
                
                # Try getting from axiom table
                ax = self.cur.execute(
                    "SELECT * FROM axiom WHERE glyph=?", (glyph,)
                ).fetchone()
                if ax:
                    return {
                        "glyph": ax[0],
                        "title": ax[1],
                        "definition": ax[2],
                        "latex": ax[3],
                        "source": src_bytes.decode('utf-8', errors='ignore')
                    }
                
                return {
                    "glyph": glyph,
                    "source": src_bytes.decode('utf-8', errors='ignore')
                }
        
        except Exception as e:
            logger.error(f"Error retrieving fact by glyph {glyph}: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return None

    def list_recent_facts(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        List the most recently added facts.
        
        Args:
            limit: Maximum number of facts to return
        
        Returns:
            List of fact dictionaries
        """
        try:
            with self.lock:
                # We'll get the most recent facts from KV store timestamps
                keys = kv_store.keys()
                facts = []
                for key in keys[-limit:]:
                    fact = self.get_fact_by_glyph(key)
                    if fact:
                        facts.append(fact)
                return facts
        except Exception as e:
            logger.error(f"Error listing recent facts: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return []
    
    def search_facts(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Search for facts matching the query.
        
        Args:
            query: Search query
            limit: Maximum number of facts to return
        
        Returns:
            List of matching fact dictionaries
        """
        try:
            with self.lock:
                from singularity_vector_index import vector_index
                gids = vector_index.search(query, limit)
                
                facts = []
                for gid in gids:
                    fact = self.get_fact_by_glyph(gid)
                    if fact:
                        facts.append(fact)
                return facts
        except Exception as e:
            logger.error(f"Error searching facts: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return []

# Global instances placeholder
kv_store = None
knowledge_api = None

# ──────────────────────────────────────────────────────────────────────────
# Legacy compatibility wrapper for β_KVStore
# ──────────────────────────────────────────────────────────────────────────
class β_KVStore:
    """Legacy compatibility wrapper for the original β_KVStore."""
    
    def __init__(self):
        warnings.warn(
            "β_KVStore is deprecated and will be removed in a future version. "
            "Use singularity_knowledge_api.KVStore instead.",
            DeprecationWarning,
            stacklevel=2
        )
    
    def __getitem__(self, key):
        return kv_store[key]
    
    def __setitem__(self, key, value):
        kv_store[key] = value
    
    def get(self, key, default=None):
        return kv_store.get(key, default)

# ──────────────────────────────────────────────────────────────────────────
# Legacy compatibility wrapper for β_KnowledgeAPI
# ──────────────────────────────────────────────────────────────────────────
class β_KnowledgeAPI:
    """Legacy compatibility wrapper for the original β_KnowledgeAPI."""
    
    def __init__(self, dbcon):
        warnings.warn(
            "β_KnowledgeAPI is deprecated and will be removed in a future version. "
            "Use singularity_knowledge_api.KnowledgeAPI instead.",
            DeprecationWarning,
            stacklevel=2
        )
        self.db = dbcon
        self.cur = dbcon.cursor()
    
    def ingest_fact(self, subj, pred, obj, src:str):
        return knowledge_api.ingest_fact(subj, pred, obj, src)
    
    def query(self, text:str):
        return knowledge_api.query(text)

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(db_connection=None, config=None):
    """
    Initialize the Knowledge API system.
    
    Args:
        db_connection: SQLite database connection
        config: Configuration dictionary
    
    Returns:
        Initialized KnowledgeAPI instance
    """
    global kv_store, knowledge_api, β_kv, β_kn
    
    logger.info("Initializing Knowledge API system")
    
    # Initialize KV store
    kv_store = KVStore()
    
    # Initialize Knowledge API
    knowledge_api = KnowledgeAPI(db_connection)
    
    # Initialize legacy compatibility objects
    β_kv = β_KVStore()
    β_kn = β_KnowledgeAPI(db_connection)
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Knowledge API system initialized in {_STATS['init_time_ms']} ms")
    
    return knowledge_api

def health_check() -> dict:
    """
    Perform a health check on the Knowledge API system.
    
    Returns:
        Dictionary with health status information
    """
    global knowledge_api, kv_store
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not knowledge_api or not kv_store:
        status = "error"
        warnings.append("Knowledge API system not initialized")
    else:
        try:
            # Get KV store stats
            kv_count = kv_store.count()
            details["kv_count"] = kv_count
            
            # Check if store is empty
            if kv_count == 0:
                warnings.append("KV store is empty")
                if status != "error":
                    status = "warning"
        except Exception as e:
            status = "error"
            warnings.append(f"Knowledge API error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "knowledge_api",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the Knowledge API system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown():
    """
    Perform clean shutdown of Knowledge API resources.
    """
    global kv_store, knowledge_api
    
    if kv_store:
        logger.info("Shutting down Knowledge API system")
        kv_store.close()

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_kapi_status():
    """Command handler for /kapi-status"""
    if not knowledge_api:
        print("Knowledge API system not initialized")
        return
    
    health = health_check()
    
    print("\nKnowledge API System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    if "kv_count" in health["details"]:
        print(f"\nKV Store: {health['details']['kv_count']} entries")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

def _cmd_kapi_search():
    """Command handler for /kapi-search"""
    if not knowledge_api:
        print("Knowledge API system not initialized")
        return
    
    query = input("Search query> ")
    if not query.strip():
        print("Please enter a search query")
        return
    
    result = knowledge_api.query(query)
    print(f"\nResult: {result}")

def _cmd_kapi_add_fact():
    """Command handler for /kapi-add-fact"""
    if not knowledge_api:
        print("Knowledge API system not initialized")
        return
    
    subject = input("Subject> ")
    predicate = input("Predicate> ")
    object_value = input("Object> ")
    source = input("Source> ")
    
    if not subject.strip() or not predicate.strip() or not object_value.strip():
        print("Subject, predicate, and object are required")
        return
    
    if knowledge_api.ingest_fact(subject, predicate, object_value, source or "user"):
        print("Fact added successfully")
    else:
        print("Failed to add fact")

def _cmd_kapi_list_recent():
    """Command handler for /kapi-recent"""
    if not knowledge_api:
        print("Knowledge API system not initialized")
        return
    
    try:
        limit = int(input("Number of facts to list (default: 10)> ") or "10")
    except ValueError:
        limit = 10
        print("Invalid number, using default: 10")
    
    facts = knowledge_api.list_recent_facts(limit)
    
    if not facts:
        print("No facts found")
        return
    
    print(f"\nRecent Facts ({len(facts)}):")
    for i, fact in enumerate(facts, 1):
        print(f"\n{i}. Glyph: {fact.get('glyph', 'N/A')}")
        if "title" in fact:
            print(f"   Title: {fact['title']}")
        if "definition" in fact:
            print(f"   Definition: {fact['definition']}")
        print(f"   Source: {fact.get('source', 'N/A')}")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'KVStore',
    'KnowledgeAPI',
    'β_KVStore',
    'β_KnowledgeAPI',
    'β_kv',
    'β_kn',
    '_cmd_kapi_status',
    '_cmd_kapi_search',
    '_cmd_kapi_add_fact',
    '_cmd_kapi_list_recent'
]
