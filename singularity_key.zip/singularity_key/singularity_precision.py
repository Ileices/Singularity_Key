#!/usr/bin/env python3
"""
Singularity Precision Module
---------------------------
Handles high-precision numeric operations and RBY baseline calculations.

Features:
- Configurable precision settings (Decimal vs float)
- Thread-safe config access
- Cross-platform precision initialization
- Automatic integration with singularity_config

This module is designed to work seamlessly with the rest of the Singularity codebase
while maintaining backward compatibility with older code.
"""
import os
import sys
import math
import time
import threading
import logging
from decimal import Decimal, getcontext
from typing import Dict, Any, Union, Callable, TypeVar, Optional, Tuple
from pathlib import Path

# Configure logging
_log = logging.getLogger("singularity.precision")

# Import config module with fallback handling
try:
    from singularity_config import CFG, save_config, load_config
except ImportError:
    # Fallback implementation for standalone usage
    import yaml
    _BASE = Path(__file__).parent.resolve()
    _CONFIG_PATH = _BASE / "singularity_config.yml"
    
    # Default configuration
    CFG = {
        "high_precision_mode": True,
        "rby_baseline": {
            "R0": "0.333333333333333333333333333333333333333333333333333333333333",
            "B0": "0.333333333333333333333333333333333333333333333333333333333333",
            "Y0": "0.333333333333333333333333333333333333333333333333333333333333"
        },
        "TOKEN_W": {}
    }
    
    def load_config():
        global CFG
        try:
            with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
                CFG = yaml.safe_load(f)
        except Exception as e:
            _log.error(f"Error loading config: {e}")
        return CFG
    
    def save_config():
        try:
            with open(_CONFIG_PATH, "w", encoding="utf-8") as f:
                yaml.dump(CFG, f, default_flow_style=False)
        except Exception as e:
            _log.error(f"Error saving config: {e}")

# Thread safety
_precision_lock = threading.RLock()
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "decimal_ops_count": 0,
    "error_count": 0
}

# Type variable for generic number handling
T = TypeVar('T', float, Decimal)

class PrecisionError(Exception):
    """Exception raised for precision-related errors."""
    pass

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Precision Initialization
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def initialize_precision() -> Tuple[Callable, Decimal, Decimal, Decimal, Union[Decimal, float]]:
    """
    Initialize precision settings based on configuration.
    
    Returns:
        Tuple containing:
            _FNUM: Function to create numbers with appropriate precision
            R0, B0, Y0: RBY baseline values
            PHI: Golden ratio with appropriate precision
    """
    global _initialized, _metrics
    
    start_time = time.time()
    
    with _precision_lock:
        if _initialized:
            return _FNUM, R0, B0, Y0, PHI
        
        # Ensure config is loaded
        load_config()
        
        if CFG.get("high_precision_mode"):
            getcontext().prec = 60
            _fnum_func = Decimal
            _log.info("Decimal-60 precision active.")
        else:
            _fnum_func = float
            _log.info("Standard floating-point precision active.")
        
        # Calculate PHI (golden ratio) with appropriate precision
        try:
            if CFG.get("high_precision_mode"):
                _phi = (_fnum_func(1) + _fnum_func(5).sqrt()) / 2
            else:
                _phi = (1 + 5 ** 0.5) / 2
        except Exception as e:
            _log.error(f"Error calculating PHI: {e}")
            _metrics["error_count"] += 1
            # Fallback to pre-calculated value
            _phi = _fnum_func("1.618033988749895")
        
        # Get RBY baseline values
        try:
            rby_baseline = CFG.get("rby_baseline", {})
            r0 = _fnum_func(rby_baseline.get("R0", "0.333333333333333333333333333333333333333333333333333333333333"))
            b0 = _fnum_func(rby_baseline.get("B0", "0.333333333333333333333333333333333333333333333333333333333333"))
            y0 = _fnum_func(rby_baseline.get("Y0", "0.333333333333333333333333333333333333333333333333333333333333"))
        except Exception as e:
            _log.error(f"Error loading RBY baseline: {e}")
            _metrics["error_count"] += 1
            # Fallback to default values
            r0 = _fnum_func("0.33333333333333333")
            b0 = _fnum_func("0.33333333333333333")
            y0 = _fnum_func("0.33333333333333334")
        
        _initialized = True
        end_time = time.time()
        _metrics["init_time_ms"] = (end_time - start_time) * 1000
        
        # Log initialization metrics
        _log.debug(f"Precision module initialized in {_metrics['init_time_ms']:.2f}ms")
        
        return _fnum_func, r0, b0, y0, _phi

# Initialize global variables
_FNUM, R0, B0, Y0, PHI = initialize_precision()

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Token Weight Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
try:
    from singularity_lexical import get_token_weight as _lexical_get_weight
    _has_lexical_module = True
except ImportError:
    _has_lexical_module = False

def get_token_weights():
    """Get the complete token weight dictionary."""
    return CFG.get("TOKEN_W", {}).copy()

def get_token_weight(token, token_class=None):
    """
    Get the RBY weight for a token, with advanced lexical support if available.
    
    Args:
        token: The actual token text
        token_class: Optional class hint (e.g., "noun", "verb")
        
    Returns:
        Tuple of (r, b, y) weights as Decimal or float
    """
    # Try the lexical module first, if available
    if _has_lexical_module:
        result = _lexical_get_weight(token, None)
        if result is not None:
            return result
    
    # Fall back to traditional class-based lookup
    if token_class and token_class in CFG.get("TOKEN_W", {}):
        return CFG["TOKEN_W"][token_class]
    
    # Final fallback: balanced weights
    return (R0, B0, Y0)

def update_token_weight(token, token_class, r_delta, b_delta, y_delta, learning_rate=0.1):
    """
    Update token weights with deltas.
    
    Args:
        token: Token text
        token_class: Token class (e.g., "noun")
        r_delta, b_delta, y_delta: Weight adjustments
        learning_rate: How strongly to apply the update
        
    Returns:
        New (r, b, y) weights
    """
    # Try to use lexical module if available
    if _has_lexical_module and token:
        from singularity_lexical import update_token_weight as _lexical_update
        return _lexical_update(token, r_delta, b_delta, y_delta, learning_rate)
    
    # Otherwise update the class weights (legacy behavior)
    if token_class in CFG.get("TOKEN_W", {}):
        r, b, y = CFG["TOKEN_W"][token_class]
        
        # Apply deltas with learning rate
        new_r = r + _FNUM(str(r_delta * learning_rate))
        new_b = b + _FNUM(str(b_delta * learning_rate))
        new_y = y + _FNUM(str(y_delta * learning_rate))
        
        # Normalize to ensure sum = 1.0
        total = new_r + new_b + new_y
        new_r = new_r / total
        new_b = new_b / total
        new_y = new_y / total
        
        # Store updated weights
        CFG["TOKEN_W"][token_class] = (new_r, new_b, new_y)
        
        # Also update config
        try:
            save_config()
        except Exception as e:
            _log.error(f"Error saving updated token weights: {e}")
        
        return new_r, new_b, new_y
    
    return R0, B0, Y0

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Utility Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def is_high_precision() -> bool:
    """Check if high precision mode is active."""
    return CFG.get("high_precision_mode", True)

def convert_to_decimal(value: Any) -> Decimal:
    """Convert a value to Decimal with proper error handling."""
    try:
        return Decimal(str(value))
    except Exception as e:
        _log.error(f"Error converting to Decimal: {e}")
        _metrics["error_count"] += 1
        raise PrecisionError(f"Could not convert {value} to Decimal: {e}")

def safe_numeric_op(func: Callable, *args, **kwargs) -> Any:
    """Execute a numeric operation with proper error handling and metric tracking."""
    try:
        with _precision_lock:
            _metrics["decimal_ops_count"] += 1
            return func(*args, **kwargs)
    except Exception as e:
        _log.error(f"Error in precision operation: {e}")
        _metrics["error_count"] += 1
        raise PrecisionError(f"Operation failed: {e}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_precision_metrics() -> Dict[str, Any]:
    """Get metrics related to precision operations."""
    with _precision_lock:
        # Calculate uptime
        uptime_ms = (time.time() - _startup_time) * 1000
        
        return {
            **_metrics,
            "uptime_ms": uptime_ms,
            "high_precision_active": is_high_precision(),
            "decimal_context_precision": getcontext().prec
        }

def check_precision_health() -> Dict[str, Any]:
    """Perform health check on precision system."""
    status = "healthy"
    details = {}
    
    # Test basic operations
    try:
        test_decimal = Decimal("1.1") + Decimal("2.2")
        test_result = abs(test_decimal - Decimal("3.3")) < Decimal("0.0000001")
        if not test_result:
            status = "degraded"
            details["decimal_test_failed"] = f"1.1 + 2.2 = {test_decimal}"
    except Exception as e:
        status = "degraded"
        details["decimal_error"] = str(e)
    
    # Check if RBY values sum to 1
    rby_sum = R0 + B0 + Y0
    if abs(rby_sum - _FNUM("1.0")) > _FNUM("0.0000001"):
        status = "degraded"
        details["rby_sum_error"] = f"R0 + B0 + Y0 = {rby_sum} ≠ 1.0"
    
    return {
        "status": status,
        "metrics": get_precision_metrics(),
        "details": details
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Migration utilities to ease transition
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Export our symbols to another module for backward compatibility.
    
    Args:
        target_module: The module to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_FNUM": _FNUM,
        "R0": R0, 
        "B0": B0, 
        "Y0": Y0,
        "PHI": PHI
    }
    
    # Add deprecation warnings for direct imports
    class DeprecatedAccessor:
        def __init__(self, real_value, symbol_name):
            self.real_value = real_value
            self.symbol_name = symbol_name
            self.warning_shown = False
            
        def __call__(self, *args, **kwargs):
            self._show_warning()
            return self.real_value(*args, **kwargs)
            
        def __getattr__(self, name):
            self._show_warning()
            return getattr(self.real_value, name)
            
        def _show_warning(self):
            if not self.warning_shown:
                warnings.warn(
                    f"Direct access to {self.symbol_name} from {target_module.__name__} is deprecated. "
                    f"Import from singularity_precision instead.",
                    DeprecationWarning, 2
                )
                self.warning_shown = True
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if callable(value):
            setattr(target_module, name, DeprecatedAccessor(value, name))
        else:
            setattr(target_module, name, value)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Clean shutdown
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """Perform cleanup operations during shutdown."""
    _log.info("Precision module cleanup")
    # Any cleanup specific to precision module

# Register cleanup on exit
import atexit
atexit.register(cleanup)

# Export public API
__all__ = [
    '_FNUM', 'R0', 'B0', 'Y0', 'PHI',
    'initialize_precision', 'is_high_precision', 'convert_to_decimal',
    'get_precision_metrics', 'check_precision_health',
    'get_token_weights', 'get_token_weight', 'update_token_weight'
]

if __name__ == "__main__":
    # Configure logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Run health check
    health = check_precision_health()
    print(f"Precision Health: {health['status']}")
    print(f"Metrics: {health['metrics']}")
    
    if health['details']:
        print("Issues detected:")
        for issue, detail in health['details'].items():
            print(f"  - {issue}: {detail}")
