#!/usr/bin/env python3
"""
Singularity Cluster - High Performance Distributed Computing Module
------------------------------------------------------------------
Provides automatic resource discovery, task distribution, and storage management
for creating a seamless computing mesh across multiple machines.

Features:
- Zero-configuration peer discovery
- Automatic resource scoring and leader election
- Cross-machine task distribution with local fallbacks
- Distributed storage management
- Thread-safe communication and resource sharing
"""
from __future__ import annotations
import json, os, socket, struct, threading, time, queue, pathlib, shutil, subprocess
from typing import Dict, Any, Optional, Tuple, List, Union
import logging as _log
import uuid
import stat
import platform
import traceback
import hashlib

# Configure logging
_log.basicConfig(level=_log.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = _log.getLogger('singularity.cluster')

# Performance monitoring
_startup_time = time.time()

# ===== 0. CONSTANTS =========================================================
_CL_PORT     = 39401
_PROTO_ID    = b'\xE2\x9F\x90CLU'  # 4-byte magic, ignore foreign traffic
_AD, _REQ, _ACK, _DEN, _RPC     = range(1,6)

_TASK_TIMEOUT = 30              # sec – if no response, run locally
_BROADCAST    = ('255.255.255.255', _CL_PORT)

_BASE  = pathlib.Path(__file__).parent.resolve()
_NETFS = _BASE / "net_mounts"    # local dir where remote shares are mounted
_NETFS.mkdir(exist_ok=True, parents=True)

# Thread safety
_cluster_lock = threading.RLock()
_peers_lock = threading.RLock()
_mount_lock = threading.RLock()
_job_lock = threading.RLock()

# Module stats
_STATS = {
    'startup_ms': 0,
    'jobs_sent': 0,
    'jobs_received': 0,
    'jobs_completed': 0,
    'jobs_failed': 0,
    'peers_discovered': 0,
    'messages_sent': 0,
    'messages_received': 0,
    'errors': 0,
    'storage_operations': 0
}

def _update_stat(key: str, value: int = 1):
    """Thread-safe stat update."""
    with _cluster_lock:
        _STATS[key] = _STATS.get(key, 0) + value

# ===== 1. helpers ===========================================================
def _profile() -> Dict[str,Any]:
    """Live hardware & capacity report"""
    try:
        import torch
        cuda = torch.cuda.is_available()
        rocm = torch.version.hip is not None and torch.version.hip != ""
        
        # Collect GPU details if available
        if cuda:
            try:
                vram = torch.cuda.get_device_properties(0).total_memory//2**30
            except Exception:
                vram = 0
        else:
            vram = 0
    except ImportError:
        cuda = rocm = False
        vram = 0
    
    # Get disk space on all mounted volumes
    disks = {}
    try:
        import psutil
        for disk in psutil.disk_partitions(all=False):
            try:
                if os.access(disk.mountpoint, os.W_OK):
                    disks[disk.mountpoint] = psutil.disk_usage(disk.mountpoint).free//2**30
            except Exception:
                pass
    except ImportError:
        # Fallback for basic disk info
        for path in [_BASE, pathlib.Path.home(), pathlib.Path('/tmp')]:
            try:
                if path.exists():
                    total, used, free = shutil.disk_usage(path)
                    disks[str(path)] = free//2**30
            except Exception:
                pass
    
    # Get CPU information
    try:
        import psutil
        cpu_cores = psutil.cpu_count(logical=False)
        ram_gb = psutil.virtual_memory().total//2**30
    except ImportError:
        cpu_cores = os.cpu_count() or 1
        ram_gb = 8  # Fallback value
    
    return dict(
        host   = socket.gethostname(),
        pid    = os.getpid(),
        cores  = cpu_cores,
        ram    = ram_gb,
        cuda   = cuda,
        rocm   = rocm,
        vram   = vram,
        free_gb= sum(disks.values()),
        disks  = disks,
        ts     = time.time(),
        platform = platform.system()
    )

def _score(p:Dict)->int:        # bigger = better
    s  = p["cores"]*10 + p["ram"]
    s += p["free_gb"]//10
    s += p["vram"]*5
    if p["cuda"]: s += 500
    elif p["rocm"]: s += 300
    return s

# ===== 2.  Cluster object ===================================================
class ClusterPlus:
    """
    Main cluster management system that handles distributed computing
    across multiple machines.
    
    Provides automatic peer discovery, job distribution, and storage management.
    All operations are thread-safe and include fallback mechanisms.
    """
    ME        = _profile()
    PEERS: Dict[str,Dict] = {}        # ip -> profile
    AUTO      = True
    LEADER    = ME["host"]
    _jobs     = queue.Queue()         # local tasks waiting for peer
    _pending  : Dict[str,queue.Queue] = {}   # job-id -> return-Queue
    
    # Private state management
    _initialized = False
    _threads = []

    # -----------------------------------------------------------------
    @classmethod
    def start(cls, auto_accept:bool=True):
        """
        Start cluster services.
        
        Args:
            auto_accept: Whether to automatically accept connections from peers
        
        Returns:
            bool: True if started successfully
        """
        with _cluster_lock:
            if cls._initialized:
                logger.info("Cluster already running")
                return True
                
            cls.AUTO = auto_accept
            
            # Create and start threads
            cls._threads = [
                threading.Thread(target=cls._udp_beacon, daemon=True),
                threading.Thread(target=cls._udp_listener, daemon=True),
                threading.Thread(target=cls._tcp_listener, daemon=True),
                threading.Thread(target=cls._arbiter, daemon=True)
            ]
            
            try:
                # Start all threads
                for t in cls._threads:
                    t.start()
                
                cls._initialized = True
                _STATS['startup_ms'] = int((time.time() - _startup_time) * 1000)
                logger.info("Cluster services started successfully")
                
                # Initial leader election
                cls._elect_leader()
                
                return True
            except Exception as e:
                logger.error(f"Error starting cluster services: {e}")
                _update_stat('errors')
                return False

    @classmethod
    def stop(cls):
        """
        Stop all cluster services gracefully.
        """
        with _cluster_lock:
            cls._initialized = False
            logger.info("Cluster services stopped")
            
            # Clear all pending jobs and peers
            with _peers_lock:
                cls.PEERS.clear()
            
            with _job_lock:
                cls._pending.clear()
                
                # Clear the job queue
                try:
                    while True:
                        cls._jobs.get_nowait()
                except queue.Empty:
                    pass
            
            logger.info("Cluster state cleared")

    # ===== PUBLIC API ==================================================
    @classmethod
    def put_job(cls, kind:str, fn:str, args:tuple=(), kw:dict|None=None):
        """
        Execute *fn* on best peer (kind=gpu/cpu) or fall back to local.
        
        Args:
            kind: "gpu" or "cpu" - type of resource needed
            fn: Function name to execute (must be in global scope)
            args: Positional arguments for the function
            kw: Keyword arguments for the function
            
        Returns:
            Result from the function execution
        """
        if not cls._initialized:
            logger.warning("Cluster not initialized, executing locally")
            return cls._local_exec(fn, args, kw or {})
            
        kw = kw or {}
        target = cls._choose_worker(kind)
        
        _update_stat('jobs_sent')
            
        if target == "local":
            return cls._local_exec(fn, args, kw)
          
        # Send to remote peer
        j_id = str(uuid.uuid4())
        
        with _job_lock:
            qret = queue.Queue()
            cls._pending[j_id] = qret
            
        payload = dict(id=j_id, kind=kind, fn=fn, args=args, kw=kw)
        cls._rpc(target, "run", payload)
        
        try:
            # Wait for response with timeout
            return qret.get(timeout=_TASK_TIMEOUT)
        except queue.Empty:
            logger.warning(f"Remote job {j_id} timed out - falling back to local execution")
            _update_stat('jobs_failed')
            return cls._local_exec(fn, args, kw)

    @classmethod
    def _local_exec(cls, fn:str, args:tuple, kw:dict):
        """Execute a function locally."""
        try:
            # Try to find in globals first (backwards compatibility)
            if fn in globals():
                func = globals()[fn]
            else:
                # Split into module.function
                module_name, func_name = fn.rsplit(".", 1)
                module = __import__(module_name, fromlist=[func_name])
                func = getattr(module, func_name)
                
            return func(*args, **kw)
        except Exception as e:
            logger.error(f"Error in local execution of {fn}: {e}")
            _update_stat('errors')
            _update_stat('jobs_failed')
            traceback.print_exc()
            raise

    @classmethod
    def best_path(cls, size_MiB:int) -> pathlib.Path:
        """
        Return a path (possibly mounted) guaranteed to have free space.
        
        Args:
            size_MiB: Minimum required free space in MiB
            
        Returns:
            Path object pointing to suitable directory
        """
        _update_stat('storage_operations')
        
        # Make sure we have the freshest profile data
        cls.ME = _profile()
        
        size_B = size_MiB * 2**20
        candidates = []
        
        # Check local disks first
        for mp, free in cls.ME["disks"].items():
            free_bytes = free * 2**30
            if free_bytes >= size_B:
                path = pathlib.Path(mp) / "singularity_scratch"
                path.mkdir(exist_ok=True, parents=True)
                candidates.append((free_bytes, path))
                
        # Then check peers for suitable disks
        with _peers_lock:
            for peer_host, peer_data in cls.PEERS.items():
                for mp, free in peer_data.get("disks", {}).items():
                    free_bytes = free * 2**30
                    if free_bytes >= size_B:
                        try:
                            mount_path = cls._ensure_mount(peer_host, mp)
                            candidates.append((free_bytes, mount_path))
                        except Exception as e:
                            logger.warning(f"Failed to mount {peer_host}:{mp}: {e}")
        
        # If we have candidates, pick the one with most free space
        if candidates:
            best_path = max(candidates, key=lambda t: t[0])[1]
            logger.debug(f"Selected path {best_path} with enough space")
            return best_path
        
        # If no suitable paths were found, create a temporary directory
        import tempfile
        fallback = pathlib.Path(tempfile.mkdtemp(prefix="singularity_"))
        logger.warning(f"No paths with {size_MiB} MiB free, using temporary directory: {fallback}")
        return fallback

    # ===== NETWORK THREADS =============================================
    @classmethod
    def _udp_beacon(cls):
        """Continuously broadcast node profile to discover peers."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        
        while cls._initialized:
            try:
                # Update profile before each broadcast
                cls.ME = _profile()
                
                # Create and send packet
                pkt = _PROTO_ID + struct.pack("!B", _AD) + json.dumps(cls.ME).encode()
                sock.sendto(pkt, _BROADCAST)
                _update_stat('messages_sent')
            except Exception as e:
                logger.error(f"Error in UDP beacon: {e}")
                _update_stat('errors')
                
            # Sleep between broadcasts
            time.sleep(10)
            
        sock.close()

    @classmethod
    def _udp_listener(cls):
        """Listen for peer broadcast messages."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('', _CL_PORT))
            
            while cls._initialized:
                try:
                    data, addr = sock.recvfrom(16384)
                    _update_stat('messages_received')
                    
                    if not data.startswith(_PROTO_ID):
                        continue
                        
                    # Check message type
                    t = data[4]
                    if t != _AD:
                        continue
                        
                    # Process profile information
                    try:
                        prof = json.loads(data[5:].decode())
                        
                        # Skip our own broadcasts
                        if prof["pid"] == cls.ME["pid"]:
                            continue
                            
                        # Store peer info
                        with _peers_lock:
                            is_new = addr[0] not in cls.PEERS
                            cls.PEERS[addr[0]] = prof
                            
                            # Track discovery metrics
                            if is_new:
                                _update_stat('peers_discovered')
                            
                        # Initiate handshake if needed
                        if prof.get("status") != "linked":
                            threading.Thread(target=cls._handshake, args=(addr[0],), daemon=True).start()
                    except Exception as e:
                        logger.warning(f"Error processing broadcast from {addr[0]}: {e}")
                except Exception as e:
                    logger.error(f"Error in UDP listener: {e}")
                    _update_stat('errors')
        except Exception as e:
            logger.error(f"Fatal error in UDP listener: {e}")
            _update_stat('errors')
        finally:
            try:
                sock.close()
            except:
                pass

    @classmethod
    def _handshake(cls, ip:str):
        """Perform initial handshake with newly discovered peer."""
        s = socket.socket()
        s.settimeout(5)
        try:
            s.connect((ip, _CL_PORT))
            s.send(json.dumps({"type": _REQ, "prof": cls.ME}).encode())
            resp = json.loads(s.recv(4096).decode())
            
            if resp.get("type") == _ACK:
                with _peers_lock:
                    if ip in cls.PEERS:
                        cls.PEERS[ip]["status"] = "linked"
                logger.info(f"Handshake successful with {ip}")
        except Exception as e:
            logger.warning(f"Handshake failed with {ip}: {e}")
        finally:
            s.close()

    @classmethod
    def _tcp_listener(cls):
        """Listen for TCP connections from peers."""
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(('', _CL_PORT))
            srv.listen(10)
            srv.settimeout(1)  # Allow checking _initialized periodically
            
            while cls._initialized:
                try:
                    conn, addr = srv.accept()
                    threading.Thread(target=cls._tcp_handle, args=(conn, addr), daemon=True).start()
                except socket.timeout:
                    continue
                except Exception as e:
                    logger.error(f"Error in TCP listener: {e}")
                    _update_stat('errors')
        except Exception as e:
            logger.error(f"Fatal error in TCP listener: {e}")
            _update_stat('errors')
        finally:
            try:
                srv.close()
            except:
                pass

    @classmethod
    def _tcp_handle(cls, conn, addr):
        """Handle incoming TCP connection."""
        try:
            data = conn.recv(16384)
            msg = json.loads(data.decode())
            
            if msg["type"] == _REQ:
                # Peer wants to connect - check auto-accept
                ok = cls.AUTO or _yes_no(f"Accept node {addr[0]}?", True)
                conn.send(json.dumps({"type": _ACK if ok else _DEN}).encode())
                
                if ok:
                    with _peers_lock:
                        cls.PEERS[addr[0]] = msg["prof"] | {"status": "linked"}
                        _update_stat('peers_discovered')
                    logger.info(f"Accepted peer connection from {addr[0]}")
                else:
                    logger.info(f"Rejected peer connection from {addr[0]}")
                    
            elif msg["type"] == _RPC:
                # Remote procedure call
                action, payload = msg["call"]
                
                if action == "run":
                    _update_stat('jobs_received')
                    
                # Execute RPC and send response
                out = cls._exec_rpc(msg["call"])
                conn.send(json.dumps({"ok": out}).encode())
        except Exception as e:
            logger.error(f"Error handling TCP connection: {e}")
            _update_stat('errors')
            try:
                conn.send(json.dumps({"error": str(e)}).encode())
            except:
                pass
        finally:
            conn.close()

    # ===== RPC =========================================================
    @classmethod
    def _rpc(cls, host:str, action:str, payload:Any) -> Any:
        """Send RPC to remote host and return result."""
        try:
            with socket.create_connection((host, _CL_PORT), timeout=8) as s:
                s.send(json.dumps({"type": _RPC, "call": [action, payload]}).encode())
                data = s.recv(16384)
                resp = json.loads(data.decode())
                
                if "error" in resp:
                    logger.warning(f"RPC error from {host}: {resp['error']}")
                    return None
                    
                return resp.get("ok")
        except Exception as e:
            logger.error(f"RPC to {host} failed: {e}")
            _update_stat('errors')
            return None

    @classmethod
    def _exec_rpc(cls, call):
        """Execute RPC request locally."""
        action, payload = call
        
        if action == "run":
            return cls._do_remote_job(payload)
        elif action == "ret":
            return cls._handle_job_result(payload)
            
        logger.warning(f"Unknown RPC action: {action}")
        return None

    @classmethod
    def _do_remote_job(cls, p:Dict):
        """Execute a job that was sent from another peer."""
        try:
            # Add origin info if not present
            if "origin" not in p.get("kw", {}):
                p["kw"] = p.get("kw", {}) | {"origin": cls.ME["host"]}
            
            try:
                # Find the function to call
                fn_name = p["fn"]
                
                # Try to find in globals first (backwards compatibility)
                if fn_name in globals():
                    fn = globals()[fn_name]
                else:
                    # Split into module.function
                    module_name, func_name = fn_name.rsplit(".", 1)
                    module = __import__(module_name, fromlist=[func_name])
                    fn = getattr(module, func_name)
                
                # Execute the function
                res = fn(*p["args"], **p["kw"])
                
                # Send back result
                cls._rpc(p["kw"].get("origin", ""), "ret", {"id": p["id"], "res": res})
                _update_stat('jobs_completed')
                
                return "ok"
            except Exception as e:
                logger.error(f"Error executing remote job: {e}")
                _update_stat('jobs_failed')
                traceback.print_exc()
                return str(e)
        except Exception as e:
            logger.error(f"Error processing remote job: {e}")
            _update_stat('errors')
            return str(e)

    @classmethod
    def _handle_job_result(cls, payload:Dict):
        """Handle result of a job that was sent to another peer."""
        job_id = payload.get("id")
        result = payload.get("res")
        
        if not job_id:
            logger.warning("Received job result without ID")
            return None
            
        with _job_lock:
            if job_id in cls._pending:
                # Put result in the waiting queue
                cls._pending[job_id].put(result)
                _update_stat('jobs_completed')
                
                # Clean up
                cls._pending.pop(job_id)
            else:
                logger.warning(f"Received result for unknown job {job_id}")
                
        return "ok"

    # ===== OTHER HELPERS ==============================================
    @classmethod
    def _choose_worker(cls, kind:str)->str:
        """
        Find best worker for a job based on type and resources.
        
        Returns:
            IP address of best peer or 'local'
        """
        if kind == "gpu":
            # Check if we have a suitable GPU
            if cls.ME["cuda"] or cls.ME["rocm"]:
                return "local"
                
            # Find peers with GPUs
            with _peers_lock:
                gpu_peers = [(ip, p) for ip, p in cls.PEERS.items()
                             if p.get("cuda") or p.get("rocm")]
                             
                if gpu_peers:
                    ip, _ = max(gpu_peers, key=lambda t: _score(t[1]))
                    return ip
        
        # For CPU jobs or no suitable GPU peers, compare overall scores
        best = None
        max_score = _score(cls.ME)
        
        with _peers_lock:
            for ip, p in cls.PEERS.items():
                peer_score = _score(p)
                if peer_score > max_score:
                    max_score = peer_score
                    best = ip
        
        # If no better peer was found, use local
        return best if best else "local"

    @classmethod
    def _ensure_mount(cls, host:str, remote_mp:str)->pathlib.Path:
        """
        Mount remote filesystem if not already mounted.
        
        Args:
            host: Remote hostname or IP
            remote_mp: Remote mount point
            
        Returns:
            Local path to access the remote files
        """
        # Generate safe local directory name
        safe_host = host.replace(".", "_")
        safe_path = hashlib.md5(remote_mp.encode()).hexdigest()[:8]
        local_path = _NETFS / f"{safe_host}_{safe_path}"
        
        # Check if already mounted
        with _mount_lock:
            if local_path.exists():
                # Check if mount is still valid
                test_file = local_path / ".mount_test"
                try:
                    with test_file.open("w") as f:
                        f.write("test")
                    test_file.unlink()
                    return local_path
                except:
                    # Mount is stale, try to remount
                    pass
            
            # Create mount point
            local_path.mkdir(parents=True, exist_ok=True)
            
            # Try to mount
            if platform.system() == "Windows":
                # Windows - attempt to map network drive
                net_path = f"\\\\{host}\\{os.path.basename(remote_mp)}"
                cmd = ["net", "use", str(local_path), net_path]
            else:
                # Unix-like - use sshfs
                cmd = ["sshfs", f"{host}:{remote_mp}", str(local_path), "-o", "ro"]
                
            try:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                logger.info(f"Mounted {host}:{remote_mp} at {local_path}")
                return local_path
            except Exception as e:
                logger.warning(f"Mount failed: {e}")
                # Return path anyway - it might work later
                return local_path

    @classmethod
    def _arbiter(cls):
        """
        Periodic tasks: refresh profile, elect leader, clean up stale peers.
        """
        while cls._initialized:
            try:
                # Update our profile
                cls.ME = _profile()
                
                # Clean up stale peers
                cls._prune_stale_peers()
                
                # Elect leader
                cls._elect_leader()
            except Exception as e:
                logger.error(f"Error in arbiter: {e}")
                _update_stat('errors')
                
            time.sleep(60)

    @classmethod
    def _prune_stale_peers(cls):
        """Remove peers that haven't been seen in a while."""
        now = time.time()
        stale_threshold = 120  # 2 minutes
        
        with _peers_lock:
            stale_peers = []
            
            for ip, data in cls.PEERS.items():
                last_seen = data.get("ts", 0)
                if now - last_seen > stale_threshold:
                    stale_peers.append(ip)
            
            for ip in stale_peers:
                logger.info(f"Removing stale peer: {ip}")
                cls.PEERS.pop(ip, None)

    @classmethod
    def _elect_leader(cls):
        """Elect the best node as leader based on resource scores."""
        candidates = [cls.ME]
        
        with _peers_lock:
            candidates.extend(cls.PEERS.values())
            
        best = max(candidates, key=_score)
        cls.LEADER = best["host"]

    # ===== MONITORING AND DIAGNOSTICS ==================================
    @classmethod
    def get_status(cls) -> Dict:
        """
        Get comprehensive cluster status report.
        
        Returns:
            Dictionary with cluster status information
        """
        status = {
            "initialized": cls._initialized,
            "auto_accept": cls.AUTO,
            "leader": cls.LEADER,
            "local_profile": cls.ME.copy(),
            "stats": _STATS.copy(),
            "timestamp": time.time()
        }
        
        # Add peer info
        with _peers_lock:
            status["peers"] = {ip: data.copy() for ip, data in cls.PEERS.items()}
            status["peer_count"] = len(cls.PEERS)
        
        # Add job info
        with _job_lock:
            status["pending_jobs"] = len(cls._pending)
        
        return status
    
    @classmethod
    def health_check(cls) -> Dict:
        """
        Perform health check for monitoring systems.
        
        Returns:
            Dictionary with health status
        """
        if not cls._initialized:
            return {
                "status": "offline",
                "message": "Cluster services not initialized",
                "timestamp": time.time()
            }
        
        # Get current status
        status = cls.get_status()
        
        # Determine health status
        if _STATS.get('errors', 0) > 0:
            health = "warning"
            message = f"Cluster has encountered {_STATS.get('errors', 0)} errors"
        elif status["peer_count"] == 0:
            health = "isolated"
            message = "No peers discovered - node is isolated"
        else:
            health = "healthy"
            message = f"Cluster operating with {status['peer_count']} peers"
        
        return {
            "status": health,
            "message": message,
            "node_count": status["peer_count"] + 1,
            "leader": cls.LEADER,
            "is_leader": cls.LEADER == cls.ME["host"],
            "jobs_processed": _STATS.get('jobs_completed', 0),
            "jobs_failed": _STATS.get('jobs_failed', 0),
            "timestamp": time.time()
        }
    
# ===== Helpers ============================================================
def _yes_no(q:str, default=False) -> bool:
    """
    Ask user a yes/no question.
    
    Args:
        q: Question to ask
        default: Default answer if user just presses Enter
        
    Returns:
        True for yes, False for no
    """
    if not sys.__stdin__.isatty():
        return default
        
    try:
        prompt = f"{q} [{'Y/n' if default else 'y/N'}] "
        ans = input(prompt).strip().lower()
        if not ans:
            return default
        return ans.startswith("y")
    except KeyboardInterrupt:
        return default

# ===== Module Initialization ==============================================
def initialize(auto_accept=True):
    """
    Initialize the cluster module.
    
    Args:
        auto_accept: Whether to automatically accept connections from peers
        
    Returns:
        bool: True if initialized successfully
    """
    return ClusterPlus.start(auto_accept)

def shutdown():
    """Gracefully shut down cluster services."""
    return ClusterPlus.stop()

# Automatic cleanup
import atexit
atexit.register(shutdown)

# Export public API
__all__ = [
    'ClusterPlus',
    'initialize',
    'shutdown'
]

# Run standalone test if executed directly
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Singularity Cluster Management")
    parser.add_argument("--auto", action="store_true", help="Auto-accept peer connections")
    parser.add_argument("--monitor", action="store_true", help="Run continuous status monitoring")
    args = parser.parse_args()
    
    print("Starting Singularity Cluster services...")
    ClusterPlus.start(args.auto)
    
    try:
        if args.monitor:
            print("Monitoring cluster status (Ctrl+C to exit)...")
            while True:
                status = ClusterPlus.get_status()
                health = ClusterPlus.health_check()
                
                print("\n" + "=" * 60)
                print(f"Status: {health['status'].upper()} - {health['message']}")
                print(f"Leader: {status['leader']} {'(this node)' if status['leader'] == status['local_profile']['host'] else ''}")
                print(f"Peers: {status['peer_count']}")
                print(f"Jobs: {status['stats'].get('jobs_completed', 0)} completed, {status['stats'].get('jobs_failed', 0)} failed")
                print("-" * 60)
                
                time.sleep(5)
        else:
            print("Cluster services running. Press Ctrl+C to exit.")
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        ClusterPlus.stop()
