"""
Singularity Utility Functions
----------------------------
Helper functions and definitions for the Singularity framework.
"""
import os
import shutil
from pathlib import Path

# LLM model location helpers
_LLM_LOCAL = Path("ecosystem") / "models" / "llm_cache"
def _ensure_model_downloaded():
    """Ensure the LLM model directory exists."""
    os.makedirs(_LLM_LOCAL, exist_ok=True)
    return _LLM_LOCAL

def safe_execute(func, *args, **kwargs):
    """Safe execution wrapper to catch exceptions."""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        import traceback
        print(f"Error executing {func.__name__}: {e}")
        print(traceback.format_exc())
        return None

def check_dependencies():
    """Check if all required dependencies are installed."""
    missing = []
    try:
        import torch
    except ImportError:
        missing.append("torch")
    
    try:
        import transformers
    except ImportError:
        missing.append("transformers")
        
    try:
        import pyarrow
    except ImportError:
        missing.append("pyarrow")
    
    try:
        import datasets  # type: ignore
    except ImportError:
        missing.append("datasets")
        
    try:
        import accelerate
    except ImportError:
        missing.append("accelerate")
        
    try:
        import watchdog
    except ImportError:
        missing.append("watchdog")
        
    if missing:
        print(f"Missing dependencies: {', '.join(missing)}")
        print("Run 'python install_deps.py' to install all dependencies")
        return False
    return True
