#!/usr/bin/env python3
"""
Singularity Storage Module
--------------------------
Manages all storage paths, directory structures, and file operations for the Singularity system.

Features:
- Thread-safe path initialization and access
- Cross-platform path handling with pathlib
- Explicit UTF-8 encoding for all file operations
- Integrity checking for critical storage structures
- Advanced monitoring of storage usage and health
- Automatic recovery of corrupted storage structures
- Support for distributed storage across cluster nodes

This module handles path resolution, directory creation, and file access patterns
across the entire codebase, ensuring consistency and safety for all storage operations.
"""
import os
import sys
import time
import json
import shutil
import threading
import logging
import platform
import hashlib
import atexit
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional, Union, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s'
)
logger = logging.getLogger("singularity.storage")

# Thread safety
_storage_lock = threading.RLock()
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "dir_creations": 0,
    "recovered_dirs": 0,
    "error_count": 0,
    "total_size_bytes": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Path Resolution and Base Directories
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Base path is derived from this module's location
BASE = Path(__file__).parent.resolve()

# Try to import configuration module with fallback handling
try:
    from singularity_config import CFG, get_metrics
    use_custom_cfg = True
except ImportError:
    logger.warning("Could not import singularity_config, using default config")
    import yaml
    CFG = {}
    try:
        config_path = BASE / "singularity_config.yml"
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                CFG = yaml.safe_load(f)
    except Exception as e:
        logger.error(f"Error loading config: {e}")
    use_custom_cfg = False
    
    def get_metrics(): 
        return {}

# Initialize core storage paths with thread safety
def initialize_storage_paths() -> Dict[str, Path]:
    """
    Initialize all storage paths used by the Singularity system.
    Returns a dictionary of path objects.
    """
    global _initialized, _metrics
    
    with _storage_lock:
        if _initialized:
            return _get_all_paths()
        
        start_time = time.time()
        paths = {}
        
        # Primary ecosystem directory
        paths["ECO"] = (BASE / "ecosystem").resolve()
        _ensure_directory(paths["ECO"])
        
        # Core data directories
        paths["LECTUREDIR"] = paths["ECO"] / "lectures"
        _ensure_directory(paths["LECTUREDIR"])
        
        # Database and log paths
        paths["PTDB"] = paths["ECO"] / "periodic_table.db"
        paths["EXC"] = paths["ECO"] / "excretions.log"
        
        # Asset directories
        paths["ASSETS"] = (BASE / "seed_assets").resolve()
        _ensure_directory(paths["ASSETS"])
        paths["PROC_ASSETS"] = paths["ECO"] / "processed_assets"
        _ensure_directory(paths["PROC_ASSETS"])
        
        # Core AI system directories
        paths["MODELS"] = paths["ECO"] / "models"
        _ensure_directory(paths["MODELS"])
        paths["CORPUS"] = paths["ECO"] / "corpus"
        _ensure_directory(paths["CORPUS"])
        paths["CHECKPOINTS"] = paths["ECO"] / "checkpoints"
        _ensure_directory(paths["CHECKPOINTS"])
        paths["METRICS"] = paths["ECO"] / "metrics"
        _ensure_directory(paths["METRICS"])
        
        # Advanced AI components
        paths["KNOWLEDGE_GRAPH"] = paths["ECO"] / "knowledge_graph"
        _ensure_directory(paths["KNOWLEDGE_GRAPH"])
        paths["EMBEDDINGS"] = paths["ECO"] / "embeddings"
        _ensure_directory(paths["EMBEDDINGS"])
        paths["FEATURES"] = paths["ECO"] / "features"
        _ensure_directory(paths["FEATURES"])
        
        # Distributed training support
        paths["JOBS"] = paths["ECO"] / "jobs"
        _ensure_directory(paths["JOBS"])
        paths["DIST_MODELS"] = paths["ECO"] / "distributed_models"
        _ensure_directory(paths["DIST_MODELS"])
        
        # Experimental directories
        paths["EXPERIMENTS"] = paths["ECO"] / "experiments"
        _ensure_directory(paths["EXPERIMENTS"])
        paths["PROJECTS"] = paths["ECO"] / "projects"
        _ensure_directory(paths["PROJECTS"])
        paths["SCRATCH"] = paths["ECO"] / "scratch"
        _ensure_directory(paths["SCRATCH"])
        
        # Audit directories
        paths["AUDIT"] = BASE / "modularization_audit"
        _ensure_directory(paths["AUDIT"])
        
        # Set initialized flag and record metrics
        _initialized = True
        end_time = time.time()
        _metrics["init_time_ms"] = (end_time - start_time) * 1000
        
        # Update size metrics
        update_storage_metrics()
        
        logger.info(f"Storage paths initialized in {_metrics['init_time_ms']:.2f}ms")
        logger.debug(f"Created/verified {_metrics['dir_creations']} directories")
        
        return paths

def _ensure_directory(path: Path) -> bool:
    """
    Ensure a directory exists, creating it if necessary.
    Returns True if the directory exists/was created, False on failure.
    """
    global _metrics
    try:
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {path}")
            _metrics["dir_creations"] += 1
        return True
    except Exception as e:
        logger.error(f"Failed to create directory {path}: {e}")
        _metrics["error_count"] += 1
        return False

def _get_all_paths() -> Dict[str, Path]:
    """Get all storage paths as a dictionary."""
    with _storage_lock:
        return {
            "BASE": BASE,
            "ECO": ECO,
            "LECTUREDIR": LECTUREDIR,
            "PTDB": PTDB,
            "EXC": EXC,
            "ASSETS": ASSETS,
            "PROC_ASSETS": PROC_ASSETS,
            "MODELS": MODELS,
            "CORPUS": CORPUS,
            "CHECKPOINTS": CHECKPOINTS,
            "METRICS": METRICS,
            "KNOWLEDGE_GRAPH": KNOWLEDGE_GRAPH,
            "EMBEDDINGS": EMBEDDINGS, 
            "FEATURES": FEATURES,
            "JOBS": JOBS,
            "DIST_MODELS": DIST_MODELS,
            "EXPERIMENTS": EXPERIMENTS,
            "PROJECTS": PROJECTS,
            "SCRATCH": SCRATCH,
            "AUDIT": AUDIT
        }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Checks and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def update_storage_metrics():
    """Update storage size and usage metrics."""
    global _metrics
    
    try:
        eco_path = BASE / "ecosystem"
        if eco_path.exists():
            # Get total size of ecosystem directory
            total_size = 0
            for path in eco_path.glob('**/*'):
                if path.is_file():
                    try:
                        total_size += path.stat().st_size
                    except (PermissionError, OSError):
                        pass
            
            _metrics["total_size_bytes"] = total_size
            
        # Get disk usage statistics
        total, used, free = shutil.disk_usage(str(BASE))
        _metrics["disk_total_bytes"] = total
        _metrics["disk_used_bytes"] = used
        _metrics["disk_free_bytes"] = free
        _metrics["disk_free_percent"] = (free / total) * 100
        
    except Exception as e:
        logger.error(f"Error updating storage metrics: {e}")
        _metrics["error_count"] += 1

def check_storage_health() -> Dict[str, Any]:
    """
    Perform health check on storage paths and return status.
    """
    update_storage_metrics()
    status = "healthy"
    details = {}
    
    # Check if ecosystem directory exists and is writable
    if not ECO.exists():
        status = "critical"
        details["ecosystem_missing"] = "Main ecosystem directory is missing"
    else:
        # Check if we can write to the directory
        try:
            test_file = ECO / f"test_{time.time()}.tmp"
            test_file.touch()
            test_file.unlink()
        except Exception as e:
            status = "critical"
            details["ecosystem_not_writable"] = str(e)
    
    # Check free disk space
    if _metrics.get("disk_free_percent", 100) < 5:
        status = "warning" if status == "healthy" else status
        details["low_disk_space"] = f"Only {_metrics['disk_free_percent']:.1f}% disk space available"
    
    # Check critical paths
    critical_paths = ["LECTUREDIR", "ASSETS", "MODELS", "CORPUS"]
    for path_name in critical_paths:
        path = globals().get(path_name)
        if path and not path.exists():
            status = "degraded" if status == "healthy" else status
            details[f"{path_name.lower()}_missing"] = f"Critical directory {path_name} is missing"
    
    return {
        "status": status,
        "metrics": {**_metrics, **get_metrics()},
        "details": details,
        "timestamp": time.time()
    }

def health_endpoint() -> str:
    """
    Return a JSON string with health information.
    Used as an HTTP endpoint by monitoring systems.
    """
    return json.dumps(check_storage_health(), indent=2)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Utility Functions and Recovery
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def verify_critical_paths() -> bool:
    """
    Verify and recover critical storage paths if missing.
    Returns True if all critical paths are available (or recovered).
    """
    global _metrics
    
    missing_paths = []
    for name, path in _get_all_paths().items():
        if isinstance(path, Path) and not path.exists() and name not in ["PTDB", "EXC"]:
            missing_paths.append((name, path))
    
    if not missing_paths:
        return True
    
    logger.warning(f"Found {len(missing_paths)} missing paths")
    for name, path in missing_paths:
        try:
            logger.info(f"Recovering {name} at {path}")
            path.mkdir(parents=True, exist_ok=True)
            _metrics["recovered_dirs"] += 1
        except Exception as e:
            logger.error(f"Failed to recover {name}: {e}")
            _metrics["error_count"] += 1
            return False
    
    return True

def calculate_checksum(path: Path) -> str:
    """Calculate SHA-256 checksum of a file."""
    if not path.is_file():
        raise ValueError(f"Path is not a file: {path}")
        
    sha256 = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            sha256.update(block)
    return sha256.hexdigest()

def verify_file_integrity(path: Path, expected_checksum: Optional[str] = None) -> bool:
    """
    Verify file integrity with checksums.
    If expected_checksum is None, only checks if the file exists and is readable.
    """
    if not path.exists():
        logger.error(f"File doesn't exist: {path}")
        return False
    
    try:
        if expected_checksum:
            actual = calculate_checksum(path)
            if actual != expected_checksum:
                logger.error(f"Checksum mismatch for {path}")
                return False
        # Check if file is readable
        with open(path, "rb") as f:
            f.read(1)
        return True
    except Exception as e:
        logger.error(f"Error verifying {path}: {e}")
        return False

def get_storage_stats() -> Dict[str, Any]:
    """Get detailed statistics about storage usage."""
    update_storage_metrics()
    stats = {
        "ecosystem_size_mb": _metrics["total_size_bytes"] / (1024 * 1024),
        "free_space_mb": _metrics["disk_free_bytes"] / (1024 * 1024),
        "free_space_percent": _metrics["disk_free_percent"],
        "dir_count": 0,
        "file_count": 0,
        "by_extension": {}
    }
    
    # Count files and directories
    for path in ECO.glob('**/*'):
        if path.is_dir():
            stats["dir_count"] += 1
        elif path.is_file():
            stats["file_count"] += 1
            ext = path.suffix.lower()
            if ext in stats["by_extension"]:
                stats["by_extension"][ext] += 1
            else:
                stats["by_extension"][ext] = 1
    
    return stats

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Cleanup and Initialization
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _cleanup_handler():
    """Handle clean shutdown operations."""
    logger.info("Running shutdown handler for storage module")
    
    # Save metrics before exit
    try:
        metrics_file = ECO / "metrics" / f"storage_metrics_{int(time.time())}.json"
        metrics_file.parent.mkdir(exist_ok=True, parents=True)
        
        with open(metrics_file, 'w', encoding='utf-8') as f:
            json.dump(_metrics, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save metrics during shutdown: {e}")

# Register shutdown handler
atexit.register(_cleanup_handler)

def _log_init_audit():
    """Log initialization parameters to audit trail."""
    try:
        # Find the next available audit number
        audit_dir = BASE / "modularization_audit"
        audit_dir.mkdir(exist_ok=True, parents=True)
        
        existing = list(audit_dir.glob("modularization_audit_*.yaml"))
        next_num = 1
        if existing:
            existing_nums = [int(f.stem.split('_')[-1]) for f in existing 
                            if f.stem.split('_')[-1].isdigit()]
            next_num = max(existing_nums, default=0) + 1
        
        audit_file = audit_dir / f"modularization_audit_{next_num}.yaml"
        
        # Create audit data
        audit_data = {
            "module": "singularity_storage",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "initialization_parameters": {
                "base_path": str(BASE),
                "ecosystem_path": str(ECO),
                "startup_time_ms": _metrics["init_time_ms"]
            },
            "integration": {
                "boot_script": "singularity_boot.py",
                "import_path": "from singularity_storage import ECO, LECTUREDIR, PTDB, EXC, ASSETS, PROC_ASSETS",
                "storage_paths": list(_get_all_paths().keys())
            },
            "verification": {
                "paths_initialized": _initialized,
                "critical_paths_exist": verify_critical_paths(),
                "ecosystem_writable": ECO.exists() and os.access(ECO, os.W_OK)
            }
        }
        
        # Write audit trail
        import yaml
        with open(audit_file, 'w', encoding='utf-8') as f:
            yaml.dump(audit_data, f, default_flow_style=False)
            
        logger.info(f"Initialization audit trail written to {audit_file}")
        
    except Exception as e:
        logger.error(f"Failed to write audit trail: {e}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialize and Export Paths 
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialize paths at module import time
paths = initialize_storage_paths()

# Expose paths as module-level variables
ECO = paths["ECO"]
LECTUREDIR = paths["LECTUREDIR"]
PTDB = paths["PTDB"]
EXC = paths["EXC"]
ASSETS = paths["ASSETS"]
PROC_ASSETS = paths["PROC_ASSETS"]
MODELS = paths["MODELS"]
CORPUS = paths["CORPUS"]
CHECKPOINTS = paths["CHECKPOINTS"]
METRICS = paths["METRICS"]
KNOWLEDGE_GRAPH = paths["KNOWLEDGE_GRAPH"]
EMBEDDINGS = paths["EMBEDDINGS"]
FEATURES = paths["FEATURES"]
JOBS = paths["JOBS"]
DIST_MODELS = paths["DIST_MODELS"]
EXPERIMENTS = paths["EXPERIMENTS"]
PROJECTS = paths["PROJECTS"]
SCRATCH = paths["SCRATCH"]
AUDIT = paths["AUDIT"]

# Create audit trail
_log_init_audit()

# Export public API
__all__ = [
    'BASE', 'ECO', 'LECTUREDIR', 'PTDB', 'EXC', 'ASSETS', 'PROC_ASSETS',
    'MODELS', 'CORPUS', 'CHECKPOINTS', 'METRICS', 'KNOWLEDGE_GRAPH', 
    'EMBEDDINGS', 'FEATURES', 'JOBS', 'DIST_MODELS', 'EXPERIMENTS',
    'PROJECTS', 'SCRATCH', 'AUDIT',
    'check_storage_health', 'verify_critical_paths', 'get_storage_stats',
    'verify_file_integrity', 'calculate_checksum', 'update_storage_metrics'
]

# Diagnostics output
logger.info(f"Singularity storage module initialized in {_metrics['init_time_ms']:.2f}ms")
