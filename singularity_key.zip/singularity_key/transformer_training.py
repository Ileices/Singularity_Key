# ╭────────── transformer_training.py  (≈350 lines incl. helpers) ──────────╮
import os, json, math, random, socket, subprocess, sys, time, pathlib, shutil
from datetime import datetime
from multiprocessing import cpu_count
from typing     import List, Dict, Tuple
import threading

import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from transformers import (AutoTokenizer, GPT2Config, GPT2LMHeadModel,
                          get_linear_schedule_with_warmup)
from accelerate import Accelerator

# Import CFG from singularity_boot if running standalone
if "CFG" not in globals():
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    try:
        from singularity_boot import CFG
    except ImportError:
        # Fallback default if we can't import
        CFG = {"primary_port": 31415}

# ---------------------------------------------------------------------------
# Small util: discover how many peers are "training ready".
# Uses the same UDP port already configured by singularity_boot.py
# ---------------------------------------------------------------------------
UDP_PORT =  CFG.get("primary_port", 31415)
DISCOVERY_TIMEOUT = 3          # seconds

def _discover_peers() -> List[str]:
    """Return list of IPv4 strings of peers that answer 'TRAIN_READY' ping."""
    peers = set()
    sock  = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(0.7)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(b"TRAIN_PING", ("255.255.255.255", UDP_PORT))
        t0=time.time()
        while time.time()-t0<DISCOVERY_TIMEOUT:
            try:
                data, addr = sock.recvfrom(256)
                if data==b"TRAIN_READY":
                    peers.add(addr[0])
            except socket.timeout:
                pass
    finally:
        sock.close()
    return sorted(peers)

# ---------------------------------------------------------------------------
# Dataset built from excretion *.json files
# ---------------------------------------------------------------------------
class ExcretionDataset(Dataset):
    def __init__(self, eco_dir: pathlib.Path, tokenizer, max_length=256):
        self.samples: List[str] = []
        for f in eco_dir.glob("**/excretion_*.json"):
            try:
                with f.open(encoding="utf-8") as fp:
                    obj=json.load(fp)
                # Flatten every leaf value to string lines
                stack=[obj]
                while stack:
                    cur=stack.pop()
                    if isinstance(cur,dict):
                        stack.extend(cur.values())
                    elif isinstance(cur,(list,tuple,set)):
                        stack.extend(cur)
                    else:
                        s=str(cur).strip()
                        if s:
                            self.samples.append(s)
            except Exception:
                continue
        
        # Also collect data from excretions.log
        excretions_log = eco_dir / "excretions.log"
        if excretions_log.exists():
            try:
                with excretions_log.open(encoding="utf-8") as fp:
                    for line in fp:
                        # Skip timestamp part and keep the message
                        parts = line.split(" | ", 1)
                        if len(parts) > 1:
                            s = parts[1].strip()
                            if s:
                                self.samples.append(s)
            except Exception:
                pass
                
        random.shuffle(self.samples)
        self.tok = tokenizer
        self.max_length=max_length
    def __len__(self): return len(self.samples)
    def __getitem__(self, idx):
        enc=self.tok(self.samples[idx],
                     truncation=True,
                     max_length=self.max_length,
                     padding="max_length",
                     return_tensors="pt")
        ids=enc["input_ids"].squeeze(0)
        return ids, ids   # labels == inputs (language modelling)

# ---------------------------------------------------------------------------
# Dataset built from Parquet corpus files (added for neural_engine integration)
# ---------------------------------------------------------------------------
class ParquetDataset(Dataset):
    def __init__(self, corpus_dir: pathlib.Path, tokenizer, max_length=256, max_days=14):
        import pandas as pd
        import pyarrow.parquet as pq
        
        self.samples: List[str] = []
        # Get the latest Parquet files, limited by max_days
        files = sorted(corpus_dir.glob("day_*.parquet"))[-max_days:]
        
        for file in files:
            try:
                table = pq.read_table(file)
                df = table.to_pandas()
                # Extract text column from each file
                self.samples.extend(df["text"].tolist())
            except Exception as e:
                print(f"Error loading {file}: {e}")
                continue
                
        print(f"Loaded {len(self.samples)} samples from {len(files)} corpus files")
        random.shuffle(self.samples)
        self.tok = tokenizer
        self.max_length = max_length
        
    def __len__(self): return len(self.samples)
    def __getitem__(self, idx):
        enc=self.tok(self.samples[idx],
                     truncation=True,
                     max_length=self.max_length,
                     padding="max_length",
                     return_tensors="pt")
        ids=enc["input_ids"].squeeze(0)
        return ids, ids   # labels == inputs (language modelling)

# ---------------------------------------------------------------------------
# Single-process training (Accelerate handles GPU / CPU / multi-GPU).
# ---------------------------------------------------------------------------
def _train_one_process(dataset, save_dir, epochs=1, batch=8, lr=5e-5):
    accelerator = Accelerator()
    device      = accelerator.device
    tokenizer   = dataset.tok
    cfg = GPT2Config(
        vocab_size=len(tokenizer),
        n_embd = 512,
        n_layer= 6,
        n_head = 8,
    )
    model = GPT2LMHeadModel(cfg).to(device)

    dl = DataLoader(dataset,
                    batch_size=batch,
                    shuffle=True,
                    num_workers=min(4, cpu_count()//2))
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    sched = get_linear_schedule_with_warmup(
        opt,
        num_warmup_steps=len(dl)//10,
        num_training_steps=len(dl)*epochs)

    model, opt, dl, sched = accelerator.prepare(model,opt,dl,sched)

    model.train()
    for ep in range(epochs):
        tot_loss=0
        for step,(x,y) in enumerate(dl,1):
            opt.zero_grad()
            out = model(x, labels=y)
            accelerator.backward(out.loss)
            opt.step(); sched.step()
            tot_loss += out.loss.item()
            if step%50==0 and accelerator.is_local_main_process:
                print(f"[ep {ep+1}] step {step}/{len(dl)} loss {tot_loss/step:.3f}")
        accelerator.wait_for_everyone()

    if accelerator.is_main_process:
        save_dir.mkdir(parents=True, exist_ok=True)
        model.save_pretrained(save_dir)
        tokenizer.save_pretrained(save_dir)
        print(f"🌱 transformer saved → {save_dir}")

# ---------------------------------------------------------------------------
# Helper: if the user has multiple machines they can call this script
# via torchrun automatically. We expose a convenience wrapper.
# ---------------------------------------------------------------------------
def launch_ddp_if_needed():
    """If torchrun env not set → relaunch self with torchrun (multi-GPU)."""
    if os.getenv("LOCAL_RANK") is not None:
        print("[transformer] already under torchrun.")
        return
    world_size=torch.cuda.device_count()
    if world_size<=1:
        print("[transformer] single GPU or CPU → run in-process.")
        return
    # relaunch with torchrun
    cmd=[
        "torchrun",
        "--standalone",
        f"--nproc_per_node={world_size}",
        sys.argv[0],  # singularity_boot.py
        "/ddp_main"
    ]
    print("⏩  Launching DDP:", " ".join(cmd))
    subprocess.Popen(cmd)
    sys.exit(0)

# ---------------------------------------------------------------------------
# New helper: train on corpus data (used by neural_engine)
# ---------------------------------------------------------------------------
def train_on_corpus(ECO_DIR: pathlib.Path, 
                    epochs:int=1, batch:int=8, lr:float=5e-5, 
                    max_days:int=14, max_length:int=256,
                    save_subdir="models/transformer"):
    """Train on corpus Parquet files directly"""
    
    print("🔍  Setting up corpus training...")
    corpus_dir = ECO_DIR / "corpus"
    if not corpus_dir.exists() or not list(corpus_dir.glob("day_*.parquet")):
        print("⚠️  No corpus data found. Please ingest data first.")
        return

    if torch.cuda.device_count()>1:
        launch_ddp_if_needed()    # may exit & relaunch

    tok = AutoTokenizer.from_pretrained("gpt2")      # tiny start point
    tok.pad_token = tok.eos_token

    ds = ParquetDataset(corpus_dir, tok, max_length=max_length, max_days=max_days)
    if len(ds) < 200:
        print("⚠️  Not enough corpus samples for training; feed more first.")
        return

    out_dir = ECO_DIR/save_subdir/datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    _train_one_process(ds, out_dir, epochs=epochs, batch=batch, lr=lr)
    return out_dir

# ---------------------------------------------------------------------------
# Public entry
# ---------------------------------------------------------------------------
def train_transformer(ECO_DIR: pathlib.Path,
                      epochs:int=1, batch:int=8, lr:float=5e-5,
                      save_subdir="models/transformer"):
    """
    Called from CLI or GUI button.
      • Automatically discovers peers (LAN broadcast)  
      • If peers respond and `torch.cuda.device_count()>0`, runs DDP
      • Otherwise trains locally on CPU/GPU
    """

    print("🔍  Discovering training peers …")
    peers=_discover_peers()
    print(f"👥  peers ready: {peers or 'none'}")

    if torch.cuda.device_count()>1:
        launch_ddp_if_needed()    # may exit & relaunch

    tok = AutoTokenizer.from_pretrained("gpt2")      # tiny start point
    tok.pad_token = tok.eos_token

    ds  = ExcretionDataset(ECO_DIR, tok)
    if len(ds)<200:
        print("⚠️  Not enough excretion lines for training; feed more first.")
        return

    out_dir = ECO_DIR/save_subdir/datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    _train_one_process(ds, out_dir, epochs=epochs, batch=batch, lr=lr)
    return out_dir

# reply PINGs (run automatically)
def _reply_ready():
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock.bind(("",UDP_PORT))
    while True:
        try:
            data,addr=sock.recvfrom(256)
            if data==b"TRAIN_PING":
                sock.sendto(b"TRAIN_READY",addr)
        except Exception:
            pass
threading.Thread(target=_reply_ready,daemon=True).start()

# New utility to prune older models, keeping only a specified number
def prune_models(ECO_DIR: pathlib.Path, models_subdir="models/transformer", keep=3):
    """Keep only the most recent models, delete or archive older ones."""
    models_dir = ECO_DIR / models_subdir
    if not models_dir.exists():
        return
    
    models = sorted(models_dir.glob("*"))
    for old_model in models[:-keep]:
        if old_model.is_dir():
            print(f"🗑️  Pruning old model: {old_model}")
            shutil.rmtree(old_model)

# Auto-GUI helper
def _auto_gui_meta(frame):
    """
    Automatically create buttons for all META commands in the given frame.
    To be called after META is fully populated.
    """
    import tkinter as tk
    from tkinter import ttk
    for label, fn in globals().get('META', {}).items():
        if callable(fn):
            ttk.Button(frame, text=label, command=fn).pack(fill=tk.X, pady=1)

# If this module is run directly, provide some basic testing
if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "discover":
            print("Discovering peers:")
            peers = _discover_peers()
            print(f"Found {len(peers)} peers: {peers}")
        elif sys.argv[1] == "train":
            eco_path = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else pathlib.Path(".")
            print(f"Training on data from {eco_path}")
            train_transformer(eco_path)
        elif sys.argv[1] == "/ddp_main":
            # Handle torchrun relaunch
            eco_path = pathlib.Path(".") 
            train_transformer(eco_path)
        else:
            print("Unknown command. Use 'discover' or 'train'")
    else:
        print("Usage: python transformer_training.py [discover|train] [eco_path]")
# ╰──────────────────────────────────────────────────────────────────────────╯