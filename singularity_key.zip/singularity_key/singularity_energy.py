#!/usr/bin/env python3
"""
Singularity Energy Dynamics Module
---------------------------------
Manages energy states, apical pulse calculations, and homeostatic mechanisms.

Features:
- Thread-safe energy state calculations
- Circadian rhythm simulation via apical pulse
- Configurable amplitude, period, and damping parameters
- High-precision numerical handling with Decimal
- Performance metrics and monitoring
- Automatic recovery from configuration errors

This module implements the core energy management system for the Singularity organism,
simulating natural energy oscillations based on configurable parameters.
"""
import datetime as _dt
import math as _m
import logging
import threading
import time
from decimal import Decimal, getcontext
from pathlib import Path
from typing import Dict, Optional, Union, Callable

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.energy")

# Thread safety
_energy_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "energy_calculations": 0,
    "config_reloads": 0,
    "errors": 0,
    "last_energy_value": "0.0",
    "energy_min": "0.0",
    "energy_max": "0.0"
}

# Default parameters (fallbacks if config is corrupted)
_DEFAULT_PARAMS = {
    "amplitude": "0.025",
    "period_seconds": "43200",  # 12 hours
    "damping_beta": "0.000001157407407407407"  # e-fold in 10 days
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Dependencies
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False
_fnum_func = None  # Will be set to _FNUM from singularity_precision
_config = None     # Will be set to CFG from singularity_config

# Energy state variables
_t0 = None  # Start time - initialized when module is initialized
A = None    # Amplitude
T = None    # Period (seconds)
BETA = None # Damping factor
_2π_over_T = None  # Precomputed constant for optimization

# Energy bounds tracking
_energy_min = Decimal('0.0')
_energy_max = Decimal('0.0')

def initialize(fnum_function=None, config=None):
    """
    Initialize the energy module with required functions and configuration.
    
    Args:
        fnum_function: Function to convert to high-precision numeric type
        config: Configuration dictionary containing apical pulse parameters
    """
    global _fnum_func, _config, _initialized, _t0
    global A, T, BETA, _2π_over_T
    global _energy_min, _energy_max
    
    with _energy_lock:
        _fnum_func = fnum_function or (lambda x: Decimal(str(x)))
        _config = config or {}
        
        # Load parameters from config or use defaults
        try:
            pulse_config = _config.get("apical_pulse", {})
            A = _fnum_func(pulse_config.get("amplitude", _DEFAULT_PARAMS["amplitude"]))
            T = _fnum_func(pulse_config.get("period_seconds", _DEFAULT_PARAMS["period_seconds"]))
            BETA = _fnum_func(pulse_config.get("damping_beta", _DEFAULT_PARAMS["damping_beta"]))
            
            # Reset start time and precompute constant
            _t0 = _dt.datetime.utcnow()
            _2π_over_T = 2 * _m.pi / float(T)
            
            # Initialize bounds tracking
            _energy_min = _fnum_func('0.0')
            _energy_max = _fnum_func('0.0')
            
            logger.info(f"Energy system initialized with A={A}, T={T}, β={BETA}")
        except Exception as e:
            logger.error(f"Error initializing energy system: {e}. Using defaults.")
            _metrics["errors"] += 1
            # Use defaults as fallback
            A = _fnum_func(_DEFAULT_PARAMS["amplitude"])
            T = _fnum_func(_DEFAULT_PARAMS["period_seconds"])
            BETA = _fnum_func(_DEFAULT_PARAMS["damping_beta"])
            _t0 = _dt.datetime.utcnow()
            _2π_over_T = 2 * _m.pi / float(T)
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info(f"Energy module initialized successfully (t0={_t0.isoformat()})")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Energy Calculation Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def delta_E(now=None):
    """
    Calculate the energy delta based on the apical pulse formula.
    
    Args:
        now: Optional datetime to calculate energy at a specific time
             (defaults to current time)
    
    Returns:
        The energy delta as a Decimal (or float if _fnum_func not available)
    """
    if not _initialized:
        logger.warning("Energy module not initialized, using default value 0.0")
        return Decimal('0.0') if _fnum_func is None else _fnum_func('0.0')
    
    with _energy_lock:
        _metrics["energy_calculations"] += 1
        
        try:
            # Calculate time elapsed since initialization
            current_time = now or _dt.datetime.utcnow()
            t = (current_time - _t0).total_seconds()
            
            # Calculate energy delta using the apical pulse formula
            # ΔE(t) = A·sin(2πt/T)·e^(-βt)
            result = _fnum_func(float(A) * _m.sin(_2π_over_T * t) * _m.exp(-float(BETA) * t))
            
            # Update min/max tracking
            if result < _energy_min:
                _energy_min = result
            if result > _energy_max:
                _energy_max = result
            
            _metrics["last_energy_value"] = str(result)
            _metrics["energy_min"] = str(_energy_min)
            _metrics["energy_max"] = str(_energy_max)
            
            return result
        except Exception as e:
            logger.error(f"Error calculating energy delta: {e}")
            _metrics["errors"] += 1
            return Decimal('0.0') if _fnum_func is None else _fnum_func('0.0')

def get_energy_parameters():
    """
    Get the current energy calculation parameters.
    
    Returns:
        Dictionary with amplitude, period, and damping parameters
    """
    with _energy_lock:
        return {
            "amplitude": A,
            "period_seconds": T,
            "damping_beta": BETA,
            "start_time": _t0.isoformat() if _t0 else None,
            "precomputed_constant": _2π_over_T
        }

def reset_energy_cycle(new_amplitude=None, new_period=None, new_damping=None):
    """
    Reset the energy cycle with optional new parameters.
    Useful for phase shifts or parameter adjustments.
    
    Args:
        new_amplitude: Optional new amplitude value
        new_period: Optional new period value (seconds)
        new_damping: Optional new damping factor
    """
    global _t0, A, T, BETA, _2π_over_T
    
    with _energy_lock:
        # Update parameters if provided
        if new_amplitude is not None:
            A = _fnum_func(new_amplitude)
        if new_period is not None:
            T = _fnum_func(new_period)
            _2π_over_T = 2 * _m.pi / float(T)
        if new_damping is not None:
            BETA = _fnum_func(new_damping)
        
        # Reset start time
        _t0 = _dt.datetime.utcnow()
        logger.info(f"Energy cycle reset at {_t0.isoformat()} with A={A}, T={T}, β={BETA}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Monitoring and Health Check
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics():
    """
    Get performance metrics for energy calculations.
    
    Returns:
        Dictionary of metrics
    """
    with _energy_lock:
        return _metrics.copy()

def health_check():
    """
    Perform health check for the energy module.
    
    Returns:
        Dictionary with health status and metrics
    """
    if not _initialized:
        return {
            "status": "error",
            "message": "Energy module not initialized",
            "metrics": {},
            "timestamp": time.time()
        }
    
    metrics = get_metrics()
    
    # Calculate time elapsed since initialization for uptime
    uptime_seconds = (_dt.datetime.utcnow() - _t0).total_seconds()
    
    # Check if we've completed at least one energy cycle
    cycle_completeness = (uptime_seconds % float(T)) / float(T)
    
    # Determine overall status
    if metrics["errors"] > 0:
        status = "warning"
        message = f"Encountered {metrics['errors']} errors in energy calculations"
    else:
        status = "healthy"
        message = f"Energy module healthy, current ΔE: {metrics['last_energy_value']}"
    
    return {
        "status": status,
        "message": message,
        "metrics": metrics,
        "cycle_completeness": cycle_completeness,
        "uptime_seconds": uptime_seconds,
        "energy_bounds": {
            "min": metrics["energy_min"],
            "max": metrics["energy_max"]
        },
        "parameters": {
            "amplitude": str(A),
            "period_seconds": str(T),
            "damping_beta": str(BETA)
        },
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Visualization utilities
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def generate_energy_preview(hours=24, points=100):
    """
    Generate energy values for the next N hours for visualization.
    
    Args:
        hours: Number of hours to preview
        points: Number of data points to generate
    
    Returns:
        List of (time_offset, energy_value) tuples
    """
    if not _initialized:
        return []
    
    with _energy_lock:
        result = []
        now = _dt.datetime.utcnow()
        
        seconds_interval = hours * 3600 / points
        for i in range(points):
            time_offset_seconds = i * seconds_interval
            future_time = now + _dt.timedelta(seconds=time_offset_seconds)
            energy_value = delta_E(future_time)
            result.append((time_offset_seconds / 3600, float(energy_value)))
        
        return result

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Clean-up and Other Utilities
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def reload_config(config=None):
    """
    Reload configuration from the provided config or attempt to reload from file.
    
    Args:
        config: Optional new configuration to use
    """
    global _config
    
    with _energy_lock:
        try:
            if config:
                _config = config
            else:
                # If no config provided but we have access to singularity_config, try reloading
                try:
                    import singularity_config
                    _config = singularity_config.load_config()
                except ImportError:
                    logger.warning("Could not import singularity_config to reload")
                    return False
            
            # Reinitialize with new config
            pulse_config = _config.get("apical_pulse", {})
            reset_energy_cycle(
                new_amplitude=pulse_config.get("amplitude"),
                new_period=pulse_config.get("period_seconds"),
                new_damping=pulse_config.get("damping_beta")
            )
            
            _metrics["config_reloads"] += 1
            return True
        except Exception as e:
            logger.error(f"Error reloading config: {e}")
            _metrics["errors"] += 1
            return False

def cleanup():
    """Clean up any resources used by the energy module."""
    # Currently nothing to clean up, but function included for API consistency
    logger.info("Energy module resources cleaned up")

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'delta_E',
    'get_energy_parameters',
    'reset_energy_cycle',
    'get_metrics',
    'health_check',
    'generate_energy_preview',
    'reload_config',
    'cleanup'
]

# Module self-test
if __name__ == "__main__":
    # Basic test of energy calculation
    from decimal import Decimal
    
    # Mock config and init function
    mock_config = {
        "apical_pulse": {
            "amplitude": "0.025",
            "period_seconds": "43200",
            "damping_beta": "0.000001157407407407407"
        }
    }
    
    def mock_fnum(s):
        return Decimal(str(s))
    
    # Initialize with mock functions
    initialize(mock_fnum, mock_config)
    
    # Test energy calculation
    now = _dt.datetime.utcnow()
    energy = delta_E(now)
    print(f"Initial energy delta: {energy}")
    
    # Test energy preview
    preview = generate_energy_preview(hours=24, points=10)
    print("\nEnergy preview for next 24 hours:")
    for hour, value in preview:
        print(f"  Hour {hour:.1f}: {value:.6f}")
    
    # Test health check
    health = health_check()
    print(f"\nHealth check: {health['status']}")
    print(f"Message: {health['message']}")
    
    # Print parameters
    params = get_energy_parameters()
    print("\nEnergy parameters:")
    for key, value in params.items():
        print(f"  {key}: {value}")
    
    print("\nEnergy module self-test completed successfully.")
