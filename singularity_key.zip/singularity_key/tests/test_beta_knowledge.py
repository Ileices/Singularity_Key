#!/usr/bin/env python3
"""
Test suite for Beta Knowledge module
-----------------------------------
Tests key-value store, vector indexing, and knowledge API
"""
import sys
import os
import unittest
import sqlite3
import tempfile
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

class MockEmbeddingModel:
    """Mock embedding model for testing."""
    def encode(self, text):
        import hashlib
        import numpy as np
        # Generate a deterministic embedding based on the text
        hash_obj = hashlib.md5(text.encode())
        hash_bytes = hash_obj.digest()
        # Create a 12-dimensional vector from the hash
        return np.array([float(b)/255.0 for b in hash_bytes[:12]])

class BetaKnowledgeTests(unittest.TestCase):
    """Test cases for Beta Knowledge module."""
    
    def setUp(self):
        """Set up test environment."""
        from singularity_beta_knowledge import (
            β_KVStore, β_VectorIndex, β_NLG, β_KnowledgeAPI
        )
        
        # Create temporary database
        self.temp_db = tempfile.NamedTemporaryFile(delete=False)
        self.conn = sqlite3.connect(self.temp_db.name)
        
        # Create mock embedding model
        self.model = MockEmbeddingModel()
        
        # Set up test objects
        self.kv = β_KVStore(self.conn)
        self.vector = β_VectorIndex(vector_dir=None, embedding_model=self.model)
        self.nlg = β_NLG()
        self.api = β_KnowledgeAPI(self.kv, self.vector, self.nlg, self.model)
    
    def tearDown(self):
        """Clean up after tests."""
        self.conn.close()
        os.unlink(self.temp_db.name)
    
    def test_kv_store(self):
        """Test KV store operations."""
        # Test setting and getting values
        self.kv["test_key"] = b"test_value"
        self.assertEqual(self.kv["test_key"], b"test_value")
        
        # Test default value
        self.assertEqual(self.kv.get("nonexistent", b"default"), b"default")
        
        # Test keys method
        self.assertIn("test_key", self.kv.keys())
    
    def test_vector_index(self):
        """Test vector indexing and search."""
        # Add some texts
        idx1 = self.vector.add_text("Python is a programming language", {"category": "language"})
        idx2 = self.vector.add_text("JavaScript runs in browsers", {"category": "language"})
        idx3 = self.vector.add_text("Cats are furry animals", {"category": "animals"})
        
        # Search for programming languages
        results = self.vector.search("programming languages", 2)
        
        # Should find Python first, then JavaScript
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0][0], idx1)  # First result should be Python
    
    def test_nlg(self):
        """Test natural language generation."""
        # Test definition template
        definition = self.nlg.generate("definition", subject="Python", definition="a programming language")
        self.assertIn("Python", definition)
        self.assertIn("programming language", definition)
        
        # Test unknown template
        unknown = self.nlg.generate("unknown", query="quantum teleportation")
        self.assertIn("quantum teleportation", unknown)
        
        # Test custom template
        self.nlg.add_template("custom", "This is a {custom} template with {vars}")
        custom = self.nlg.generate("custom", custom="special", vars="variables")
        self.assertEqual(custom, "This is a special template with variables")
    
    def test_knowledge_api(self):
        """Test the unified knowledge API."""
        # Store and retrieve
        success = self.api.store("test_item", {"data": "test data"})
        self.assertTrue(success)
        retrieved = self.api.retrieve("test_item")
        self.assertEqual(retrieved, {"data": "test data"})
        
        # Store text and search
        self.api.store("python", "Python is a high-level programming language", {"category": "language"})
        self.api.store("javascript", "JavaScript is a scripting language for web browsers", {"category": "language"})
        
        results = self.api.search_similar("programming languages")
        self.assertEqual(len(results), 2)  # Should find both Python and JavaScript
        self.assertIn("Python", results[0]["text"])
        
        # Test answering
        answer = self.api.answer("What is Python?")
        self.assertIn("Python", answer)
        
        # Test explanation
        explanation = self.api.explain("What is Python?")
        self.assertEqual(explanation["method"], "definition")
        self.assertEqual(len(explanation["context"]), 1)
        
        # Test recall
        self.api.answer("What is JavaScript?")
        recall = self.api.recall()
        self.assertEqual(len(recall), 2)
        self.assertEqual(recall[0]["query"], "What is Python?")
        self.assertEqual(recall[1]["query"], "What is JavaScript?")

def run_tests():
    """Run the tests."""
    print("Testing Beta Knowledge module...")
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
