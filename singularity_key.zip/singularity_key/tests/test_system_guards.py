#!/usr/bin/env python3
"""
Test script for singularity_system_guards module
----------------------------------------------
Tests peer broadcasting, disk monitoring, and compression functions
"""
import sys
import os
import tempfile
import time
from pathlib import Path
from collections import deque

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run tests for the system guards module."""
    print("Testing singularity_system_guards module...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_system_guards import (
            initialize, get_peers, force_compression, check_disk_space,
            get_metrics, health_check
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize the module with mock dependencies
    try:
        # Create a temporary directory for testing
        with tempfile.TemporaryDirectory() as tmp_dir:
            # Create mock dependencies
            mock_config = {
                "max_outbound_kbit": 10,  # Enable broadcasting but limit bandwidth
                "primary_port": 44444,    # Use a non-standard port for testing
                "peer_broadcast_period_s": 5,
                "disk_collapse_free_percent": 10
            }
            
            mock_dna = deque(maxlen=100)
            mock_dna.extend(range(50))  # Add some test data
            
            # Simple test data for glyph generation
            def mock_glyph_id(data):
                return f"⟐test_{len(data)}"
                
            # Track excretion logs
            global excretion_logs
            excretion_logs = []
            def mock_log_excretion(msg):
                excretion_logs.append(msg)
            
            # Initialize the module
            result = initialize(
                config=mock_config,
                glyph_id_function=mock_glyph_id,
                log_excretion_function=mock_log_excretion,
                dna=mock_dna,
                eco_dir=tmp_dir
            )
            
            if result:
                print("✅ Module initialization successful")
            else:
                print("❌ Module initialization failed")
                return False
            
            # Test 3: Check disk space monitoring
            try:
                disk_status = check_disk_space()
                
                print("\nDisk status:")
                for k, v in disk_status.items():
                    print(f"  {k}: {v}")
                
                assert "total_bytes" in disk_status, "Missing total_bytes in disk status"
                assert "free_bytes" in disk_status, "Missing free_bytes in disk status"
                assert "free_percent" in disk_status, "Missing free_percent in disk status"
                assert "threshold_percent" in disk_status, "Missing threshold_percent in disk status"
                
                print("✅ Disk space monitoring working correctly")
            except Exception as e:
                print(f"❌ Disk space monitoring error: {e}")
                success = False
            
            # Test 4: Test DNA compression
            try:
                # Check DNA before compression
                original_dna_len = len(mock_dna)
                assert original_dna_len == 50, f"Expected DNA length 50, got {original_dna_len}"
                
                # Force compression
                glyph = force_compression()
                
                # Check that DNA was cleared
                assert len(mock_dna) == 0, f"DNA should be empty after compression, but has {len(mock_dna)} items"
                
                # Check that compression was logged
                assert any("COMPRESSION-BEGIN" in log for log in excretion_logs), "Compression start not logged"
                assert any("DNA-COMPRESS" in log for log in excretion_logs), "Compression glyph not logged"
                
                print("✅ DNA compression working correctly")
            except Exception as e:
                print(f"❌ DNA compression error: {e}")
                success = False
                
            # Test 5: Get metrics and health check
            try:
                metrics = get_metrics()
                health = health_check()
                
                print("\nMetrics:")
                for k, v in metrics.items():
                    print(f"  {k}: {v}")
                
                print(f"\nHealth check: {health['status']}")
                print(f"Message: {health['message']}")
                
                # Verify health check structure
                assert "status" in health, "Missing status in health check"
                assert "message" in health, "Missing message in health check"
                assert "metrics" in health, "Missing metrics in health check"
                assert "disk_status" in health, "Missing disk_status in health check"
                assert "peer_info" in health, "Missing peer_info in health check"
                
                print("✅ Metrics and health check working correctly")
            except Exception as e:
                print(f"❌ Metrics and health check error: {e}")
                success = False
                
    except Exception as e:
        print(f"❌ Module testing error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nTesting {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
