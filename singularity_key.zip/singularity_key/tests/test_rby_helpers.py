#!/usr/bin/env python3
"""
Test script for singularity_rby_helpers module
---------------------------------------------
Tests perception, cognition, execution, and trifecta functions
"""
import sys
import os
from pathlib import Path
from collections import deque

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run tests for the RBY helpers module."""
    print("Testing singularity_rby_helpers module...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_rby_helpers import (
            initialize, perception, cognition, execution, trifecta,
            get_metrics, health_check
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize the module with mock functions
    try:
        # Define mock functions
        def mock_fnum(n):
            return float(n)
        
        def mock_rby(token):
            # Simple mock that returns different weights based on first letter
            if token.startswith(('a', 'e', 'i', 'o', 'u')):
                return (0.6, 0.3, 0.1)  # Perception-heavy
            elif token.startswith(('t', 'd', 's', 'c')):
                return (0.3, 0.6, 0.1)  # Cognition-heavy
            else:
                return (0.1, 0.2, 0.7)  # Execution-heavy
        
        def mock_glyph_id(b):
            import hashlib
            return f"⟐{hashlib.md5(b).hexdigest()[:16]}"
        
        def mock_valid_glyph(gid):
            return gid.startswith("⟐")
        
        def mock_log_excretion(msg):
            global excretion_logs
            excretion_logs.append(msg)
        
        def mock_delta_e():
            return 0.01
        
        # Mock memory structures
        mock_dna = deque(maxlen=100)
        mock_hist = deque(maxlen=100)
        mock_energy = 1.0
        
        # Initialize with mocks
        initialize(
            fnum_function=mock_fnum,
            rby_function=mock_rby,
            glyph_id_function=mock_glyph_id,
            valid_glyph_function=mock_valid_glyph,
            log_excretion_function=mock_log_excretion,
            delta_e_function=mock_delta_e,
            dna=mock_dna,
            hist=mock_hist,
            energy=mock_energy
        )
        
        health = health_check()
        if health["status"] in ("healthy", "warning"):
            print("✅ Module initialization successful")
        else:
            print(f"❌ Module initialization failed: {health['message']}")
            success = False
    except Exception as e:
        print(f"❌ Module initialization error: {e}")
        success = False
        return False
    
    # Test 3: Basic R, B, Y functions
    try:
        # Test perception
        p_vowel = perception("apple")
        p_consonant = perception("table")
        p_other = perception("xyz")
        
        # Test cognition
        c_vowel = cognition("apple")
        c_consonant = cognition("table")
        c_other = cognition("xyz")
        
        # Test execution
        e_vowel = execution("apple")
        e_consonant = execution("table")
        e_other = execution("xyz")
        
        # Verification
        print("\nBasic RBY function tests:")
        print(f"Perception:  vowel={p_vowel:.2f}, consonant={p_consonant:.2f}, other={p_other:.2f}")
        print(f"Cognition:   vowel={c_vowel:.2f}, consonant={c_consonant:.2f}, other={c_other:.2f}")
        print(f"Execution:   vowel={e_vowel:.2f}, consonant={e_consonant:.2f}, other={e_other:.2f}")
        
        # Ensure vowel words are perception-heavy
        assert p_vowel > c_vowel and p_vowel > e_vowel, "Vowel words should be perception-heavy"
        
        # Ensure consonant words like "table" are cognition-heavy
        assert c_consonant > p_consonant and c_consonant > e_consonant, "Consonant words should be cognition-heavy"
        
        # Ensure other words like "xyz" are execution-heavy
        assert e_other > p_other and e_other > c_other, "Other words should be execution-heavy"
        
        print("✅ Basic RBY functions working correctly")
    except Exception as e:
        print(f"❌ Basic RBY function error: {e}")
        success = False
    
    # Test 4: Trifecta function
    try:
        # Global for tracking excretion logs
        global excretion_logs
        excretion_logs = []
        
        # Test with different texts
        r1, b1, y1 = trifecta("apple banana")
        r2, b2, y2 = trifecta("thought discussion")
        r3, b3, y3 = trifecta("perform work operation")
        
        # Test with weight
        r4, b4, y4 = trifecta("apple", weight=2.0)
        
        print("\nTrifecta function tests:")
        print(f"'apple banana':             R={r1:.2f}, B={b1:.2f}, Y={y1:.2f}")
        print(f"'thought discussion':       R={r2:.2f}, B={b2:.2f}, Y={y2:.2f}")
        print(f"'perform work operation':   R={r3:.2f}, B={b3:.2f}, Y={y3:.2f}")
        print(f"'apple' (weight=2.0):       R={r4:.2f}, B={b4:.2f}, Y={y4:.2f}")
        
        # Check that weight is applied correctly
        assert r4 == 2.0 * r1 / 2, "Weight should be applied correctly to R value"
        assert b4 == 2.0 * b1 / 2, "Weight should be applied correctly to B value"
        assert y4 == 2.0 * y1 / 2, "Weight should be applied correctly to Y value"
        
        # Check DNA and history updates
        assert len(mock_dna) == 4, f"DNA should contain 4 entries, has {len(mock_dna)}"
        assert len(mock_hist) == 4, f"History should contain 4 entries, has {len(mock_hist)}"
        
        print("✅ Trifecta function working correctly")
    except Exception as e:
        print(f"❌ Trifecta function error: {e}")
        success = False
    
    # Test 5: Glyph excretion
    try:
        # Execute something that should trigger a glyph excretion
        execution("⟐TEST_GLYPH")
        
        print(f"\nExcretion logs: {excretion_logs}")
        assert any("GLYPH" in log for log in excretion_logs), "Glyph excretion should occur"
        print("✅ Glyph excretion working correctly")
    except Exception as e:
        print(f"❌ Glyph excretion error: {e}")
        success = False
    
    # Test 6: Metrics and monitoring
    try:
        metrics = get_metrics()
        health = health_check()
        
        print("\nMetrics:")
        for key, value in metrics.items():
            print(f"  {key}: {value}")
            
        print(f"\nHealth check: {health['status']}")
        print(f"Message: {health['message']}")
        
        assert metrics["trifecta_calls"] >= 4, "Trifecta calls should be tracked"
        assert metrics["perception_calls"] >= 3, "Perception calls should be tracked"
        assert metrics["cognition_calls"] >= 3, "Cognition calls should be tracked"
        assert metrics["execution_calls"] >= 4, "Execution calls should be tracked"
        assert metrics["glyph_excretions"] >= 1, "Glyph excretions should be tracked"
        
        print("✅ Metrics and monitoring working correctly")
    except Exception as e:
        print(f"❌ Metrics and monitoring error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nTesting {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
