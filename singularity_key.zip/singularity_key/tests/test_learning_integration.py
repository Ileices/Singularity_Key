#!/usr/bin/env python3
"""
Test suite for Learning Integration module
-----------------------------------------
Tests the enhanced _consume_block functionality that integrates all learning mechanisms
"""
import sys
import os
import unittest
import time
import logging
from pathlib import Path
from unittest.mock import patch, MagicMock, call

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_learning_integration import (
    initialize, health_check, _γ_consume_block,
    LearningIntegrationSystem
)

class LearningIntegrationTests(unittest.TestCase):
    """Test cases for LearningIntegrationSystem."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock all required functions
        self.mock_original_consume = MagicMock()
        self.mock_trifecta = MagicMock()
        self.mock_neuro_ingest = MagicMock()
        self.mock_remote_call = MagicMock()
        self.mock_push_into_corpus = MagicMock()
        self.mock_learn_fact = MagicMock()
        
        # Initialize the system with mocks
        self.system = initialize(
            original_consume_block=self.mock_original_consume,
            trifecta_function=self.mock_trifecta,
            neuro_ingest_function=self.mock_neuro_ingest,
            remote_call_function=self.mock_remote_call,
            push_into_corpus_function=self.mock_push_into_corpus,
            learn_fact_function=self.mock_learn_fact,
            logger=logging.getLogger("test")
        )
    
    def test_consume_block_calls_all_functions(self):
        """Test that consume_block calls all required functions."""
        # Prepare test data
        test_lines = "Line 1\nLine 2\nLine 3"
        test_seq = 42
        
        # Call consume_block
        self.system.consume_block(test_lines, test_seq)
        
        # Verify original consume was called
        self.mock_original_consume.assert_called_once_with(test_lines, test_seq)
        
        # Verify neural ingestion was called
        self.mock_neuro_ingest.assert_called_once_with(test_lines, tag=f"lecture_{test_seq:04d}")
        
        # Verify remote call was made
        self.mock_remote_call.assert_called_once_with("organism_neuro.embed_and_store", test_lines, f"lecture_{test_seq:04d}")
        
        # Verify push into corpus was called
        self.mock_push_into_corpus.assert_called_once_with(test_lines, source=f"lecture_{test_seq}")
        
        # Verify learn fact was called for each line
        self.assertEqual(self.mock_learn_fact.call_count, 3)
        self.mock_learn_fact.assert_has_calls([
            call("Line 1"),
            call("Line 2"),
            call("Line 3")
        ])
    
    def test_consume_block_handles_empty_lines(self):
        """Test that consume_block properly handles empty lines."""
        # Prepare test data with empty lines
        test_lines = "Line 1\n\nLine 2\n\n\nLine 3"
        test_seq = 42
        
        # Call consume_block
        self.system.consume_block(test_lines, test_seq)
        
        # Verify learn fact was called only for non-empty lines
        self.assertEqual(self.mock_learn_fact.call_count, 3)
        self.mock_learn_fact.assert_has_calls([
            call("Line 1"),
            call("Line 2"),
            call("Line 3")
        ])
    
    def test_consume_block_handles_errors(self):
        """Test that consume_block properly handles errors in component functions."""
        # Make one of the functions raise an error
        self.mock_neuro_ingest.side_effect = Exception("Test error")
        
        # Prepare test data
        test_lines = "Line 1\nLine 2"
        test_seq = 42
        
        # Call consume_block (should not raise exception)
        self.system.consume_block(test_lines, test_seq)
        
        # Verify that other functions were still called
        self.mock_original_consume.assert_called_once()
        self.mock_remote_call.assert_called_once()
        self.mock_push_into_corpus.assert_called_once()
        self.assertEqual(self.mock_learn_fact.call_count, 2)
    
    def test_global_consume_block_function(self):
        """Test that the global _γ_consume_block function calls the system method."""
        # Prepare test data
        test_lines = "Test line"
        test_seq = 42
        
        # Call global function
        _γ_consume_block(test_lines, test_seq)
        
        # Verify system method was called
        self.mock_original_consume.assert_called_once_with(test_lines, test_seq)
        self.mock_neuro_ingest.assert_called_once()
    
    def test_health_check(self):
        """Test health check functionality."""
        # Perform a consume operation to update metrics
        self.system.consume_block("Test line", 1)
        
        # Check health
        health = health_check()
        
        # Verify structure
        self.assertIn("status", health)
        self.assertIn("metrics", health)
        self.assertIn("details", health)
        
        # Verify status
        self.assertEqual(health["status"], "healthy")
        
        # Verify metrics
        self.assertGreaterEqual(health["metrics"]["blocks_consumed"], 1)
        self.assertGreaterEqual(health["metrics"]["neural_ingests"], 1)
        
        # Verify dependencies
        dependencies = health["details"]["dependencies"]
        self.assertTrue(dependencies["original_consume"])
        self.assertTrue(dependencies["neuro_ingest"])
        self.assertTrue(dependencies["remote_call"])
        self.assertTrue(dependencies["push_into_corpus"])
        self.assertTrue(dependencies["learn_fact"])

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
