#!/usr/bin/env python3
"""
Test suite for Vector Index module
----------------------------------
Tests document indexing and similarity search functionality
"""
import sys
import os
import unittest
import sqlite3
import tempfile
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_vector_index import VectorIndex, β_VectorIndex

class VectorIndexTests(unittest.TestCase):
    """Test cases for vector index module."""
    
    def setUp(self):
        """Set up test environment."""
        # Create temporary database
        self.temp_db = tempfile.NamedTemporaryFile(delete=False)
        self.conn = sqlite3.connect(self.temp_db.name)
        
        # Set up test object
        self.index = VectorIndex(self.conn)
        
        # Add some test documents
        self.index.add_doc("doc1", "Python is a programming language")
        self.index.add_doc("doc2", "JavaScript runs in browsers")
        self.index.add_doc("doc3", "Cats are furry animals")
    
    def tearDown(self):
        """Clean up after tests."""
        self.conn.close()
        os.unlink(self.temp_db.name)
    
    def test_add_doc(self):
        """Test adding documents to the index."""
        # Verify document count
        self.assertEqual(self.index.count(), 3)
        
        # Add another document
        self.index.add_doc("doc4", "Dogs are loyal companions")
        self.assertEqual(self.index.count(), 4)
    
    def test_search(self):
        """Test searching the index."""
        # Search for programming languages
        results = self.index.search("programming languages", 2)
        
        # Should find Python first, then JavaScript
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0][1], "doc1")  # First result should be Python
        self.assertEqual(results[1][1], "doc2")  # Second result should be JavaScript
        
        # Search for animals
        results = self.index.search("animals", 2)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0][1], "doc3")  # Should find cats
    
    def test_remove_doc(self):
        """Test removing documents from the index."""
        # Remove a document
        self.index.remove_doc("doc1")
        self.assertEqual(self.index.count(), 2)
        
        # Verify it's no longer in search results
        results = self.index.search("Python", 2)
        for _, gid, _ in results:
            self.assertNotEqual(gid, "doc1")
    
    def test_optimize(self):
        """Test optimizing the index."""
        # Just verify it doesn't crash
        self.assertTrue(self.index.optimize())
    
    def test_clear(self):
        """Test clearing the index."""
        self.index.clear()
        self.assertEqual(self.index.count(), 0)
        self.assertEqual(self.index.search("any query"), [])
    
    def test_legacy_compatibility(self):
        """Test backward compatibility with β_VectorIndex."""
        legacy_index = β_VectorIndex(self.conn)
        
        # Add a document
        legacy_index.add_doc("legacy1", "This is a legacy document")
        
        # Search
        results = legacy_index.search("legacy", 1)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0], "legacy1")

def run_tests():
    """Run the tests."""
    unittest.main()

if __name__ == "__main__":
    run_tests()
