#!/usr/bin/env python3
"""
Test script for singularity_energy module
-----------------------------------------
Tests energy dynamics and apical pulse calculations
"""
import sys
import os
import datetime as _dt
from pathlib import Path
from decimal import Decimal

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run tests for the energy module."""
    print("Testing singularity_energy module...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_energy import (
            initialize, delta_E, get_energy_parameters,
            reset_energy_cycle, get_metrics, health_check,
            generate_energy_preview
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize the module
    try:
        def mock_fnum(s):
            return Decimal(str(s))
        
        mock_config = {
            "apical_pulse": {
                "amplitude": "0.025",
                "period_seconds": "43200",
                "damping_beta": "0.000001157407407407407"
            }
        }
        
        initialize(mock_fnum, mock_config)
        
        health = health_check()
        if health["status"] in ("healthy", "warning"):
            print("✅ Module initialization successful")
        else:
            print(f"❌ Module initialization failed: {health['message']}")
            success = False
    except Exception as e:
        print(f"❌ Module initialization error: {e}")
        success = False
        return False
    
    # Test 3: Energy calculation
    try:
        now = _dt.datetime.utcnow()
        energy = delta_E(now)
        print(f"Energy delta at current time: {energy}")
        
        # Future time test
        future = now + _dt.timedelta(hours=6)
        future_energy = delta_E(future)
        print(f"Energy delta at +6 hours: {future_energy}")
        
        print("✅ Energy calculation successful")
    except Exception as e:
        print(f"❌ Energy calculation error: {e}")
        success = False
    
    # Test 4: Parameter retrieval
    try:
        params = get_energy_parameters()
        print("\nEnergy parameters:")
        for key, value in params.items():
            print(f"  {key}: {value}")
            
        if "amplitude" in params and "period_seconds" in params and "damping_beta" in params:
            print("✅ Parameter retrieval successful")
        else:
            print("❌ Missing required parameters")
            success = False
    except Exception as e:
        print(f"❌ Parameter retrieval error: {e}")
        success = False
    
    # Test 5: Reset energy cycle
    try:
        # Change period to 1 hour for testing
        reset_energy_cycle(new_period="3600")
        params = get_energy_parameters()
        
        if float(params["period_seconds"]) == 3600:
            print("✅ Energy cycle reset successful")
        else:
            print(f"❌ Energy cycle reset failed, period={params['period_seconds']}")
            success = False
    except Exception as e:
        print(f"❌ Energy cycle reset error: {e}")
        success = False
    
    # Test 6: Generate energy preview
    try:
        preview = generate_energy_preview(hours=12, points=5)
        print("\nEnergy preview:")
        for hour, value in preview:
            print(f"  Hour {hour:.1f}: {value:.6f}")
            
        if len(preview) == 5:
            print("✅ Energy preview generation successful")
        else:
            print(f"❌ Energy preview incorrect length: {len(preview)}")
            success = False
    except Exception as e:
        print(f"❌ Energy preview error: {e}")
        success = False
    
    # Test 7: Metrics collection
    try:
        metrics = get_metrics()
        print("\nMetrics:")
        for key, value in metrics.items():
            print(f"  {key}: {value}")
            
        if "energy_calculations" in metrics and int(metrics["energy_calculations"]) > 0:
            print("✅ Metrics collection successful")
        else:
            print("❌ Energy calculation count not tracked correctly")
            success = False
    except Exception as e:
        print(f"❌ Metrics collection error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nTesting {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
