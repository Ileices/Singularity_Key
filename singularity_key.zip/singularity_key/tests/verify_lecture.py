#!/usr/bin/env python3
"""
Verification script for singularity_lecture module
-------------------------------------------------
Tests basic functionality and integration with singularity_boot
"""
import sys
import os
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_lecture...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_lecture import process_lecture_text, _γ_consume_block, is_lecture_start
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Process a simple lecture
    test_text = "This is a test lecture about Python programming."
    try:
        r, b, y = process_lecture_text(test_text, seq=999)
        print(f"✅ Lecture processed: R={r}, B={b}, Y={y}")
    except Exception as e:
        print(f"❌ Lecture processing failed: {e}")
        success = False
    
    # Test 3: Check lecture marker detection
    if is_lecture_start("<BEGIN LECTURE>"):
        print("✅ Lecture start detection working")
    else:
        print("❌ Lecture start detection failed")
        success = False
    
    # Test 4: Check function equivalence in boot
    try:
        import singularity_boot
        if singularity_boot._γ_consume_block is _γ_consume_block:
            print("✅ Integration with singularity_boot successful")
        else:
            print("❌ Function reference mismatch between modules")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    # Test 5: Check metrics
    try:
        from singularity_lecture import get_lecture_metrics
        metrics = get_lecture_metrics()
        if metrics["lectures_processed"] > 0:
            print(f"✅ Metrics collection working: {metrics['lectures_processed']} lectures processed")
        else:
            print("❓ No lectures recorded in metrics yet")
    except Exception as e:
        print(f"❌ Metrics check failed: {e}")
        success = False
    
    # Test 6: Check health
    try:
        from singularity_lecture import health_check
        health = health_check()
        print(f"✅ Health check returned status: {health['status']}")
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
