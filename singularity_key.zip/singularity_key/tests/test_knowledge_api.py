#!/usr/bin/env python3
"""
Test suite for Knowledge API module
-----------------------------------
Tests KVStore and Knowledge API functionality
"""
import sys
import os
import unittest
import tempfile
import sqlite3
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_knowledge_api import (
    KVStore, KnowledgeAPI, initialize, health_check, β_KVStore, β_KnowledgeAPI
)

class KVStoreTests(unittest.TestCase):
    """Test cases for KVStore."""
    
    def setUp(self):
        """Set up test environment."""
        # Create temporary database file
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.kv = KVStore(Path(self.temp_db.name))
    
    def tearDown(self):
        """Clean up after tests."""
        self.kv.close()
        os.unlink(self.temp_db.name)
    
    def test_basic_operations(self):
        """Test basic key-value operations."""
        # Set value
        self.kv["test_key"] = b"test_value"
        
        # Get value
        self.assertEqual(self.kv["test_key"], b"test_value")
        
        # Get with default
        self.assertEqual(self.kv.get("non_existent", b"default"), b"default")
        
        # Delete
        self.kv.delete("test_key")
        self.assertIsNone(self.kv["test_key"])
    
    def test_count_and_keys(self):
        """Test count and keys methods."""
        self.kv["key1"] = b"value1"
        self.kv["key2"] = b"value2"
        
        self.assertEqual(self.kv.count(), 2)
        self.assertIn("key1", self.kv.keys())
        self.assertIn("key2", self.kv.keys())
    
    def test_persistence(self):
        """Test data persistence across connections."""
        # Set a value
        self.kv["persist_key"] = b"persist_value"
        self.kv.close()
        
        # Create a new connection to the same file
        new_kv = KVStore(Path(self.temp_db.name))
        self.assertEqual(new_kv["persist_key"], b"persist_value")
        new_kv.close()

class KnowledgeAPITests(unittest.TestCase):
    """Test cases for KnowledgeAPI."""
    
    def setUp(self):
        """Set up test environment."""
        # Create a temporary database
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.conn = sqlite3.connect(self.temp_db.name)
        
        # Create required tables for testing
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS axiom (
                glyph TEXT PRIMARY KEY,
                title TEXT,
                definition TEXT,
                latex TEXT
            )
        ''')
        self.conn.commit()
        
        # Need to create a vector index mock because we can't import the actual one here
        # This is simplified for testing purposes
        from singularity_knowledge_api import kv_store, initialize
        
        # Initialize with our test connection
        self.api = initialize(self.conn)
        
    def tearDown(self):
        """Clean up after tests."""
        self.conn.close()
        os.unlink(self.temp_db.name)
    
    def test_ingest_and_query(self):
        """Test ingestion and querying of facts."""
        # We need to mock some dependencies for testing
        # This is a simplified test that verifies the basic functionality
        from singularity_knowledge_api import β_kn
        
        # Make sure legacy API is initialized
        self.assertIsNotNone(β_kn)
        
        # Test health check
        health = health_check()
        self.assertEqual(health["status"], "healthy")
    
    def test_legacy_compatibility(self):
        """Test legacy compatibility wrappers."""
        # Test β_KVStore
        β_kv = β_KVStore()
        β_kv["legacy_key"] = b"legacy_value"
        self.assertEqual(β_kv["legacy_key"], b"legacy_value")
        
        # Test β_KnowledgeAPI initialization
        β_kn = β_KnowledgeAPI(self.conn)
        self.assertIsNotNone(β_kn)

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
