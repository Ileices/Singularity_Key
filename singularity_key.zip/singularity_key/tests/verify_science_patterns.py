#!/usr/bin/env python3
"""
Verification script for singularity_science_patterns module
---------------------------------------------------------
Tests basic functionality and integration with other modules
"""
import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_science_patterns...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_science_patterns import (
            extract_scientific_facts, extract_latex_definitions, 
            get_all_patterns, add_pattern
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Extract scientific facts
    test_sentences = [
        "Let x be the variable representing time.",
        "The function f is continuous on [0,1].",
        "E = mc^2 is Einstein's famous equation.",
        "The derivative of x^2 with respect to x is 2x."
    ]
    
    total_facts = 0
    for sentence in test_sentences:
        try:
            facts = extract_scientific_facts(sentence)
            total_facts += len(facts)
            print(f"✅ Extracted {len(facts)} facts from: '{sentence}'")
            for subj, pred, obj, conf in facts:
                print(f"  • {subj} {pred} {obj} (confidence: {conf:.2f})")
        except Exception as e:
            success = False
            print(f"❌ Error extracting facts from '{sentence}': {e}")
    
    if total_facts == 0:
        print("❌ No facts extracted from test sentences")
        success = False
    
    # Test 3: Extract LaTeX definitions
    try:
        latex_text = r"""
        \documentclass{article}
        \begin{document}
        
        \newcommand{\deriv}{\frac{d}{dx}}
        
        \begin{theorem}[Fundamental Theorem of Calculus]
        If $f$ is continuous on $[a,b]$ and $F$ is an antiderivative of $f$, then
        $\int_a^b f(x) dx = F(b) - F(a)$.
        \end{theorem}
        
        \end{document}
        """
        
        definitions = extract_latex_definitions(latex_text)
        if definitions:
            print("✅ Successfully extracted LaTeX definitions:")
            for cmd, defn in definitions.items():
                print(f"  • {cmd}: {defn}")
        else:
            print("❓ No LaTeX definitions extracted")
    except Exception as e:
        print(f"❌ LaTeX extraction error: {e}")
        success = False
    
    # Test 4: Adding custom pattern
    try:
        def custom_extractor(match):
            return (match.group(1), "temperature_in", match.group(2))
        
        pattern_added = add_pattern(
            r"the temperature of (\w+) is ([0-9.]+\s*[CF])", 
            custom_extractor, 
            "Temperature pattern"
        )
        
        if pattern_added:
            print("✅ Custom scientific pattern added successfully")
            
            # Test the custom pattern
            custom_text = "The temperature of water is 100 C."
            custom_facts = extract_scientific_facts(custom_text)
            
            if custom_facts:
                print("✅ Custom pattern works correctly:")
                for subj, pred, obj, conf in custom_facts:
                    print(f"  • {subj} {pred} {obj} (confidence: {conf:.2f})")
            else:
                print("❌ Custom pattern not working as expected")
                success = False
        else:
            print("❌ Failed to add custom pattern")
            success = False
    except Exception as e:
        print(f"❌ Custom pattern test error: {e}")
        success = False
    
    # Test 5: Check integration with patterns module
    try:
        from singularity_patterns import _FACT_PATTERNS
        from singularity_science_patterns import _SCI_MATH_PATTERNS
        
        # Check if scientific patterns are in the main patterns list
        sci_pattern_count = sum(1 for p in _FACT_PATTERNS if p in _SCI_MATH_PATTERNS)
        
        if sci_pattern_count > 0:
            print(f"✅ Integration with patterns module successful: {sci_pattern_count} patterns shared")
        else:
            print("❓ No scientific patterns found in main pattern list")
    except Exception as e:
        print(f"❌ Patterns module integration error: {e}")
        success = False
    
    # Test 6: Check integration with boot module
    try:
        import singularity_boot
        
        if "/extract-science" in singularity_boot.META and "/process-latex" in singularity_boot.META:
            print("✅ Integration with singularity_boot successful")
        else:
            print("❌ META commands not found in singularity_boot")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    # Test 7: Check health monitoring
    try:
        from singularity_science_patterns import health_check, get_science_metrics
        
        health = health_check()
        metrics = get_science_metrics()
        
        print(f"✅ Health check returned status: {health['status']}")
        print(f"✅ Metrics collection working: {metrics['successful_extractions']} successful extractions")
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
