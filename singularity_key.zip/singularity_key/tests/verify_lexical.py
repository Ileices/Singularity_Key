#!/usr/bin/env python3
"""
Verification script for singularity_lexical module
-------------------------------------------------
Tests lexical classification and token weight functionality
"""
import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run a series of tests on the lexical module."""
    print("Running verification tests for singularity_lexical...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_lexical import (
            initialize, classify_token, get_token_weight, learn_token_weight,
            update_token_weight, learn_from_context, health_check
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize the module
    try:
        # Mock _FNUM function for testing
        def mock_fnum(s):
            from decimal import Decimal
            return Decimal(s)
        
        # Mock token weights
        mock_weights = {
            "imperative": (0.05, 0.15, 0.8),
            "modal": (0.15, 0.7, 0.15),
            "noun": (0.6, 0.35, 0.05)
        }
        
        initialize(mock_fnum, mock_weights)
        print("✅ Module initialization successful")
    except Exception as e:
        print(f"❌ Module initialization failed: {e}")
        success = False
        return False
    
    # Test 3: Token classification
    test_tokens = ["the", "but", "why", "does", "empty", "42", "run", "can", "not", "?", "python"]
    try:
        print("\nToken classification:")
        for token in test_tokens:
            cls = classify_token(token)
            print(f"  '{token}' → {cls}")
        print("✅ Token classification successful")
    except Exception as e:
        print(f"❌ Token classification error: {e}")
        success = False
    
    # Test 4: Weight lookup
    try:
        print("\nToken weights:")
        for token in test_tokens:
            r, b, y = get_token_weight(token)
            print(f"  '{token}' → R={r}, B={b}, Y={y}")
        print("✅ Weight lookup successful")
    except Exception as e:
        print(f"❌ Weight lookup error: {e}")
        success = False
    
    # Test 5: Weight learning
    try:
        learn_token_weight("test", 0.2, 0.5, 0.3)
        r, b, y = get_token_weight("test")
        print(f"\nLearned weight for 'test': R={r}, B={b}, Y={y}")
        print("✅ Weight learning successful")
    except Exception as e:
        print(f"❌ Weight learning error: {e}")
        success = False
    
    # Test 6: Weight updating
    try:
        update_token_weight("test", 0.1, -0.1, 0.0, learning_rate=0.5)
        r, b, y = get_token_weight("test")
        print(f"Updated weight for 'test': R={r}, B={b}, Y={y}")
        print("✅ Weight updating successful")
    except Exception as e:
        print(f"❌ Weight updating error: {e}")
        success = False
    
    # Test 7: Context learning
    try:
        test_contexts = [
            "I can see the mountain from here.",
            "Let me think about the problem carefully.",
            "Please run this program immediately."
        ]
        
        print("\nLearning from context:")
        for i, context in enumerate(test_contexts):
            test_token = f"contextword{i}"
            r, b, y = learn_from_context(test_token, context)
            print(f"  '{test_token}' in '{context}' → R={r}, B={b}, Y={y}")
        print("✅ Context learning successful")
    except Exception as e:
        print(f"❌ Context learning error: {e}")
        success = False
    
    # Test 8: Health check
    try:
        health = health_check()
        status = health["status"]
        vocab_size = health["vocabulary"]["total_vocabulary"]
        print(f"\nHealth check status: {status}, Vocabulary size: {vocab_size}")
        print("✅ Health check successful")
    except Exception as e:
        print(f"❌ Health check error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
