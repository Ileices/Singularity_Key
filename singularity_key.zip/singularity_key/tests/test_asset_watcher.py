#!/usr/bin/env python3
"""
Test suite for Asset Watcher module
-----------------------------------------
Tests the asset monitoring and consumption functionality
"""
import sys
import os
import unittest
import time
import logging
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock, call

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_asset_watcher import (
    initialize, health_check, _γ_asset_watch,
    AssetWatcherSystem, rescan_all
)

class AssetWatcherTests(unittest.TestCase):
    """Test cases for AssetWatcherSystem."""
    
    def setUp(self):
        """Set up test environment."""
        # Create a temporary directory for test assets
        self.temp_dir = Path(tempfile.mkdtemp())
        self.seed_assets_dir = self.temp_dir / "seed_assets"
        self.seed_assets_dir.mkdir(exist_ok=True)
        
        # Mock the consume_block function
        self.mock_consume_block = MagicMock()
        
        # Initialize the system with mocks
        self.system = initialize(
            base_dir=self.temp_dir,
            consume_block_function=self.mock_consume_block,
            scan_interval=0.1,  # Fast scanning for tests
            logger=logging.getLogger("test"),
            autostart=False  # Don't start automatically for controlled testing
        )
    
    def tearDown(self):
        """Clean up test environment."""
        # Remove the temporary directory
        shutil.rmtree(self.temp_dir)
    
    def test_initialize_detects_existing_files(self):
        """Test that initialize correctly detects existing files."""
        # Create some initial files
        for i in range(3):
            file_path = self.seed_assets_dir / f"existing_file_{i}.txt"
            file_path.write_text(f"This is existing file {i}")
        
        # Re-initialize with the existing files
        system = initialize(
            base_dir=self.temp_dir,
            consume_block_function=self.mock_consume_block,
            scan_interval=0.1,
            logger=logging.getLogger("test"),
            autostart=False
        )
        
        # Check if the existing files are in the seen files set
        self.assertEqual(len(system._seen_files), 3)
        for i in range(3):
            self.assertIn(f"existing_file_{i}.txt", system._seen_files)
    
    def test_watch_assets_processes_new_files(self):
        """Test that watch_assets processes new files."""
        # Start watching
        self.system.start_watching()
        
        # Create a new file
        file_path = self.seed_assets_dir / "test_file.txt"
        file_path.write_text("This is a test file")
        
        # Wait for the file to be processed
        time.sleep(0.2)  # More than scan_interval
        
        # Stop watching
        self.system.stop_watching()
        
        # Check if the consume_block function was called
        self.mock_consume_block.assert_called_once()
        args, _ = self.mock_consume_block.call_args
        self.assertEqual(args[0], "This is a test file")
        
        # Check metrics
        metrics = self.system._STATS
        self.assertEqual(metrics["files_processed"], 1)
        self.assertEqual(metrics["bytes_processed"], len("This is a test file"))
    
    def test_health_check(self):
        """Test health check functionality."""
        # Start watching
        self.system.start_watching()
        
        # Create a new file to trigger processing
        file_path = self.seed_assets_dir / "health_check_test.txt"
        file_path.write_text("Testing health check")
        
        # Wait for the file to be processed
        time.sleep(0.2)
        
        # Check health
        health = health_check()
        
        # Stop watching
        self.system.stop_watching()
        
        # Verify structure
        self.assertIn("status", health)
        self.assertIn("metrics", health)
        self.assertIn("details", health)
        
        # Verify status
        self.assertEqual(health["status"], "healthy")
        
        # Verify metrics
        self.assertGreaterEqual(health["metrics"]["files_processed"], 1)
        self.assertGreaterEqual(health["metrics"]["bytes_processed"], 18)  # Length of "Testing health check"
        
        # Verify dependencies
        dependencies = health["details"]["dependencies"]
        self.assertTrue(dependencies["consume_block"])
    
    def test_rescan_all(self):
        """Test that rescan_all clears the seen files set to force reprocessing."""
        # Start watching
        self.system.start_watching()
        
        # Create a file and wait for processing
        file_path = self.seed_assets_dir / "first_scan.txt"
        file_path.write_text("First scan")
        time.sleep(0.2)
        
        # Check that the file was processed
        self.mock_consume_block.assert_called_once()
        self.mock_consume_block.reset_mock()
        
        # Initiate rescan
        success = rescan_all()
        self.assertTrue(success)
        
        # Wait for rescan to complete
        time.sleep(0.2)
        
        # Check that the file was processed again
        self.mock_consume_block.assert_called_once()
        args, _ = self.mock_consume_block.call_args
        self.assertEqual(args[0], "First scan")
        
        # Stop watching
        self.system.stop_watching()
    
    def test_error_handling(self):
        """Test that errors in processing files are handled gracefully."""
        # Make consume_block raise an exception
        self.mock_consume_block.side_effect = Exception("Test error")
        
        # Start watching
        self.system.start_watching()
        
        # Create a new file
        file_path = self.seed_assets_dir / "error_test.txt"
        file_path.write_text("This will cause an error")
        
        # Wait for the file to be processed
        time.sleep(0.2)
        
        # Stop watching
        self.system.stop_watching()
        
        # Check that consume_block was called
        self.mock_consume_block.assert_called_once()
        
        # Check that the error was recorded
        metrics = self.system._STATS
        self.assertGreaterEqual(metrics["errors"], 1)
        
        # Check health status
        health = health_check()
        self.assertIn("warning", health["status"])
        self.assertTrue(any("errors" in warning for warning in health["warnings"]))
    
    def test_global_asset_watch_function(self):
        """Test that the global _γ_asset_watch function calls the system method."""
        with patch('singularity_asset_watcher.asset_watcher') as mock_watcher:
            # Call global function
            _γ_asset_watch()
            
            # Verify system method was called
            mock_watcher.start_watching.assert_called_once()

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
