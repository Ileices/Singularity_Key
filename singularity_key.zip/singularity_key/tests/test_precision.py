#!/usr/bin/env python3
"""
Test script to verify precision module integration
"""
import sys
import os
from pathlib import Path
import unittest

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

# Import both modules to test integration
from singularity_precision import (_FNUM, R0, B0, Y0, PHI,
                                  is_high_precision, check_precision_health)
from singularity_boot import _FNUM as boot_FNUM, R0 as boot_R0, B0 as boot_B0, Y0 as boot_Y0

class PrecisionIntegrationTests(unittest.TestCase):
    """Tests to verify precision module is properly integrated"""
    
    def test_precision_module_loaded(self):
        """Verify precision module can be loaded independently"""
        self.assertIsNotNone(_FNUM)
        self.assertIsNotNone(R0)
        self.assertIsNotNone(B0)
        self.assertIsNotNone(Y0)
        self.assertIsNotNone(PHI)
        
    def test_singularity_boot_integration(self):
        """Verify singularity_boot receives the correct values"""
        self.assertEqual(boot_FNUM, _FNUM)
        self.assertEqual(boot_R0, R0)
        self.assertEqual(boot_B0, B0)
        self.assertEqual(boot_Y0, Y0)
        
    def test_rby_baseline_sum_to_one(self):
        """Verify RBY baseline values sum to 1"""
        rby_sum = R0 + B0 + Y0
        self.assertAlmostEqual(float(rby_sum), 1.0)
        
    def test_high_precision_consistency(self):
        """Verify high precision behavior is consistent"""
        if is_high_precision():
            # Check Decimal precision
            from decimal import Decimal
            self.assertEqual(type(_FNUM("1.0")), Decimal)
            # Test a calculation
            result = _FNUM("1") / _FNUM("3")
            self.assertGreater(len(str(result)), 10)  # Should have many decimal places
        else:
            # In float mode, should be regular Python float
            self.assertEqual(type(_FNUM(1.0)), float)
            
    def test_health_check(self):
        """Verify health check functionality"""
        health = check_precision_health()
        self.assertIn("status", health)
        self.assertEqual(health["status"], "healthy")

if __name__ == "__main__":
    unittest.main()
