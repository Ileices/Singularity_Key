#!/usr/bin/env python3
"""
Verification script for singularity_periodic module
--------------------------------------------------
Tests basic functionality and integration with singularity_boot
"""
import sys
import os
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_periodic...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_periodic import (
            add_axiom, get_axiom, get_all_axioms, search_axioms, health_check
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Check health status
    try:
        health = health_check()
        if health["status"] in ["healthy", "degraded"]:
            print(f"✅ Health check returned status: {health['status']}")
            print(f"   Axiom count: {health['metrics']['axioms_loaded']}")
        else:
            print(f"❌ Health check returned critical status: {health['status']}")
            for key, value in health["details"].items():
                print(f"   - {key}: {value}")
            success = False
    except Exception as e:
        print(f"❌ Health check error: {e}")
        success = False
    
    # Test 3: Test axiom operations
    try:
        # Add a test axiom
        test_glyph = "⟁TEST"
        test_title = "Test Axiom"
        test_latex = "E=mc^2"
        test_def = "This is a test axiom"
        
        add_result = add_axiom(test_glyph, test_title, test_latex, test_def)
        if add_result:
            print("✅ Successfully added test axiom")
        else:
            print("❌ Failed to add test axiom")
            success = False
            
        # Retrieve it
        axiom = get_axiom(test_glyph)
        if axiom and axiom["title"] == test_title:
            print("✅ Successfully retrieved test axiom")
        else:
            print("❌ Failed to retrieve test axiom")
            success = False
            
        # Search for it
        results = search_axioms("test")
        if any(ax["glyph"] == test_glyph for ax in results):
            print("✅ Search functionality working")
        else:
            print("❌ Search failed to find test axiom")
            success = False
    except Exception as e:
        print(f"❌ Axiom operations error: {e}")
        success = False
    
    # Test 4: Check singularity_boot integration
    try:
        import singularity_boot
        
        # Check if the META commands were added
        if "/axioms" in getattr(singularity_boot, "META", {}):
            print("✅ Integration with singularity_boot successful")
        else:
            print("❌ META commands not found in singularity_boot")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
