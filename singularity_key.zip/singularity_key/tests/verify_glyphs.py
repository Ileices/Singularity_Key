#!/usr/bin/env python3
"""
Verification script for singularity_glyphs module
------------------------------------------------
Tests basic functionality and integration with singularity_boot
"""
import sys
import os
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_glyphs...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_glyphs import glyph_id, valid_glyph, store_glyph, retrieve_glyph
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Create a glyph ID
    test_data = b"Hello, Singularity!"
    try:
        gid = glyph_id(test_data)
        print(f"✅ Created glyph: {gid}")
    except Exception as e:
        print(f"❌ Glyph creation failed: {e}")
        success = False
        return False
    
    # Test 3: Validate glyph
    if valid_glyph(gid):
        print("✅ Glyph validation successful")
    else:
        print("❌ Glyph validation failed")
        success = False
    
    # Test 4: Store and retrieve
    try:
        metadata = {"test": True, "timestamp": time.time()}
        store_result = store_glyph(gid, test_data, metadata)
        if store_result:
            print("✅ Glyph storage successful")
        else:
            print("❌ Glyph storage failed")
            success = False
            
        retrieved = retrieve_glyph(gid)
        if retrieved == test_data:
            print("✅ Glyph retrieval successful")
        else:
            print("❌ Glyph retrieval failed or mismatched content")
            success = False
    except Exception as e:
        print(f"❌ Glyph storage/retrieval error: {e}")
        success = False
    
    # Test 5: Check singularity_boot integration
    try:
        import singularity_boot
        boot_glyph = singularity_boot.glyph_id(test_data)
        if boot_glyph == gid:
            print("✅ Integration with singularity_boot successful")
        else:
            print(f"❌ Integration mismatch: {boot_glyph} vs {gid}")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    # Test 6: Health check
    try:
        from singularity_glyphs import health_check
        health = health_check()
        if health["status"] == "healthy":
            print("✅ Health check reports system healthy")
        else:
            print(f"⚠️ Health check reports status: {health['status']}")
            for key, value in health.get("details", {}).items():
                print(f"  - {key}: {value}")
            success = False
    except Exception as e:
        print(f"❌ Health check error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
