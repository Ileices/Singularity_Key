#!/usr/bin/env python3
"""
Test script for singularity_cluster_plus module
----------------------------------------------
Tests peer discovery, job submission, and storage selection
"""
import sys
import os
import time
import threading
from pathlib import Path
import unittest

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

class ClusterPlusTests(unittest.TestCase):
    """Tests for the ClusterPlus functionality."""
    
    def setUp(self):
        """Set up test environment."""
        from singularity_cluster_plus import ClusterPlus
        self.ClusterPlus = ClusterPlus
    
    def test_01_startup(self):
        """Test that ClusterPlus can start up."""
        result = self.ClusterPlus.start()
        self.assertTrue(result, "ClusterPlus failed to start")
    
    def test_02_health_check(self):
        """Test health check functionality."""
        # Make sure ClusterPlus is running
        self.ClusterPlus.start()
        
        # Check health
        health = self.ClusterPlus.health_check()
        
        self.assertIn("status", health)
        self.assertIn("message", health)
        self.assertIn("metrics", health)
        self.assertIn("peer_count", health)
        self.assertIn("my_profile", health)
        self.assertIn("timestamp", health)
    
    def test_03_local_execution(self):
        """Test local execution fallback."""
        def test_func(a, b, c=0):
            return a + b + c
        
        # Add test function to globals so it can be imported
        globals()["test_func"] = test_func
        
        # Try to execute via ClusterPlus
        result = self.ClusterPlus._local_exec(
            f"{__name__}.test_func", 
            (1, 2), 
            {"c": 3}
        )
        
        self.assertEqual(result, 6, "Local execution failed")
    
    def test_04_best_path(self):
        """Test best path selection."""
        # Request a small amount of space that should be available locally
        path = self.ClusterPlus.best_path(1)  # 1 MiB
        
        self.assertIsInstance(path, Path)
        self.assertTrue(path.exists(), "Best path does not exist")
    
    def test_05_metrics(self):
        """Test metrics collection."""
        metrics = self.ClusterPlus.get_metrics()
        
        self.assertIn("init_time_ms", metrics)
        self.assertIn("jobs_submitted", metrics)
        self.assertIn("jobs_completed", metrics)
        self.assertIn("peers_discovered", metrics)
        self.assertIn("errors", metrics)
    
    def tearDown(self):
        """Clean up after tests."""
        self.ClusterPlus.stop()

def run_tests():
    """Run the tests."""
    print("Testing singularity_cluster_plus module...")
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
