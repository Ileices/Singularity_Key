#!/usr/bin/env python3
"""
Test suite for Natural Language Generation module
------------------------------------------------
Tests template-based response generation functionality
"""
import sys
import os
import unittest
import tempfile
import json
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_nlg import NLG, β_NLG, initialize, health_check

class NLGTests(unittest.TestCase):
    """Test cases for NLG module."""
    
    def setUp(self):
        """Set up test environment."""
        self.nlg = NLG()
        
        # Create a temporary template file
        self.temp_file = tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.json')
        json.dump({
            "test_template": "Test subject {subj} has {pred} {obj}.",
            "custom": "Custom template for {subj}."
        }, self.temp_file)
        self.temp_file.close()
    
    def tearDown(self):
        """Clean up after tests."""
        os.unlink(self.temp_file.name)
    
    def test_make_answer_basic(self):
        """Test basic answer generation."""
        result = self.nlg.make_answer("Python", "is", "a programming language")
        self.assertEqual(result, "Python is a programming language.")
    
    def test_template_selection(self):
        """Test template selection based on predicate."""
        result = self.nlg.make_answer("Python", "what", "a programming language")
        self.assertEqual(result, "«Python» is a programming language.")
        
        result = self.nlg.make_answer("John", "who", "a developer")
        self.assertEqual(result, "John is a developer.")
    
    def test_load_templates(self):
        """Test loading templates from file."""
        self.nlg.load_templates(Path(self.temp_file.name))
        
        # Test with custom template
        result = self.nlg.make_answer("Test", "test_template", "value")
        self.assertEqual(result, "Test subject Test has test_template value.")
    
    def test_add_template(self):
        """Test adding a new template."""
        self.nlg.add_template("new_template", "{subj} has new {obj}")
        result = self.nlg.make_answer("Item", "new_template", "property")
        self.assertEqual(result, "Item has new property")
    
    def test_generate_from_facts(self):
        """Test generating response from multiple facts."""
        facts = [
            ("Python", "is", "a programming language"),
            ("Python", "was created by", "Guido van Rossum"),
            ("Python", "is used for", "web development")
        ]
        
        result = self.nlg.generate_from_facts(facts)
        self.assertIn("Python is a programming language", result)
        self.assertIn("Guido van Rossum", result)
        self.assertIn("web development", result)
    
    def test_legacy_beta_nlg(self):
        """Test the legacy β_NLG compatibility wrapper."""
        beta_nlg = β_NLG()
        result = beta_nlg.make_answer("Python", "what", "a programming language")
        self.assertEqual(result, "«Python» is a programming language.")
    
    def test_initialization(self):
        """Test module initialization function."""
        # Create a temporary template file with new templates
        temp_file = tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.json')
        json.dump({
            "init_test": "Init test for {subj}."
        }, temp_file)
        temp_file.close()
        
        # Initialize with the template file
        engine = initialize(templates_file=Path(temp_file.name))
        
        # Test that templates were loaded
        result = engine.make_answer("Testing", "init_test", "value")
        self.assertEqual(result, "Init test for Testing.")
        
        # Clean up
        os.unlink(temp_file.name)
    
    def test_health_check(self):
        """Test health check functionality."""
        # Initialize first
        initialize()
        
        # Get health check
        health = health_check()
        
        # Verify health check structure
        self.assertIn("status", health)
        self.assertIn("metrics", health)
        self.assertIn("details", health)
        self.assertIn("template_count", health["details"])
        self.assertEqual(health["status"], "healthy")

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
