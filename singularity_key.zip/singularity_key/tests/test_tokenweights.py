#!/usr/bin/env python3
"""
Test script for singularity_tokenweights module
-----------------------------------------------
Tests token weight calculations with and without context
"""
import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run tests for the token weight module."""
    print("Testing singularity_tokenweights module...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_tokenweights import (
            initialize, rby, rby_with_context, get_metrics, health_check
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize the module with mock functions
    try:
        def mock_fnum(s):
            return float(s)
        
        def mock_get_token_weight(token):
            # Simple rules for testing
            if token.startswith(('a', 'e', 'i', 'o', 'u')):
                return 0.6, 0.3, 0.1
            elif token.startswith(('b', 'c', 'd')):
                return 0.2, 0.7, 0.1
            else:
                return 0.1, 0.2, 0.7
        
        initialize(mock_fnum, mock_get_token_weight)
        
        health = health_check()
        if health["status"] in ("healthy", "warning"):
            print("✅ Module initialization successful")
        else:
            print(f"❌ Module initialization failed: {health['message']}")
            success = False
    except Exception as e:
        print(f"❌ Module initialization error: {e}")
        success = False
        return False
    
    # Test 3: Basic RBY function
    test_tokens = [
        "apple",   # vowel - should be R-heavy
        "banana",  # consonant (b) - should be B-heavy
        "zebra"    # consonant (z) - should be Y-heavy
    ]
    
    try:
        print("\nTesting basic RBY calculation:")
        for token in test_tokens:
            r, b, y = rby(token)
            highest = max(r, b, y)
            if highest == r:
                component = "R"
            elif highest == b:
                component = "B"
            else:
                component = "Y"
                
            print(f"  '{token}' → R={r:.2f}, B={b:.2f}, Y={y:.2f} (highest: {component})")
            
            # Validate values sum to approximately 1.0
            total = r + b + y
            if abs(total - 1.0) > 0.001:
                print(f"  ❌ Warning: Values do not sum to 1.0 (sum={total:.4f})")
                success = False
        
        print("✅ Basic RBY calculation successful")
    except Exception as e:
        print(f"❌ Basic RBY calculation error: {e}")
        success = False
    
    # Test 4: Context-aware RBY function
    try:
        print("\nTesting context-aware RBY calculation:")
        
        # Test different contexts
        contexts = {
            "R-heavy": ['see', 'view', 'look'],
            "B-heavy": ['think', 'analyze', 'understand'],
            "Y-heavy": ['run', 'execute', 'perform']
        }
        
        for token in test_tokens:
            print(f"\n  Testing '{token}' with different contexts:")
            base_r, base_b, base_y = rby(token)
            
            for context_name, context_tokens in contexts.items():
                r, b, y = rby_with_context(token, context_tokens)
                print(f"    With {context_name}: R={r:.2f}, B={b:.2f}, Y={y:.2f}")
                
                # Validate values still sum to approximately 1.0
                total = r + b + y
                if abs(total - 1.0) > 0.001:
                    print(f"    ❌ Warning: Values do not sum to 1.0 (sum={total:.4f})")
                    success = False
        
        print("✅ Context-aware RBY calculation successful")
    except Exception as e:
        print(f"❌ Context-aware RBY calculation error: {e}")
        success = False
    
    # Test 5: Metrics collection
    try:
        metrics = get_metrics()
        print("\nMetrics:")
        for key, value in metrics.items():
            print(f"  {key}: {value}")
        
        # Verify that we have some weights calculated
        if metrics["weights_calculated"] > 0:
            print("✅ Metrics collection successful")
        else:
            print("❌ Metrics show no weights calculated")
            success = False
    except Exception as e:
        print(f"❌ Metrics collection error: {e}")
        success = False
    
    # Test 6: Health check
    try:
        health = health_check()
        print(f"\nHealth check status: {health['status']}")
        print(f"Message: {health['message']}")
        print("✅ Health check successful")
    except Exception as e:
        print(f"❌ Health check error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nTesting {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
