#!/usr/bin/env python3
"""
Verification script for singularity_storage module
--------------------------------------------------
Tests basic functionality and integration with singularity_boot
"""
import sys
import os
import time
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_storage...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_storage import ECO, LECTUREDIR, PTDB, EXC, ASSETS, PROC_ASSETS
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Check if paths are initialized correctly
    if ECO.exists() and LECTUREDIR.exists() and ASSETS.exists():
        print("✅ Storage paths initialized correctly")
    else:
        print("❌ Storage path initialization failed")
        success = False
    
    # Test 3: Check utility functions
    try:
        from singularity_storage import check_storage_health, verify_critical_paths
        health = check_storage_health()
        print(f"✅ Health check returned status: {health['status']}")
        
        paths_ok = verify_critical_paths()
        if paths_ok:
            print("✅ Critical paths verified")
        else:
            print("❌ Critical path verification failed")
            success = False
    except Exception as e:
        print(f"❌ Utility functions test failed: {e}")
        success = False
    
    # Test 4: Check singularity_boot integration
    try:
        import singularity_boot
        if singularity_boot.ECO is ECO:
            print("✅ Integration with singularity_boot successful")
        else:
            print(f"❌ ECO reference mismatch between modules")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    # Test 5: Check file operations
    try:
        from singularity_storage import calculate_checksum, verify_file_integrity
        import tempfile
        
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as f:
            f.write("Test content for checksum verification")
            temp_path = f.name
            
        try:
            checksum = calculate_checksum(Path(temp_path))
            integrity = verify_file_integrity(Path(temp_path))
            if integrity:
                print("✅ File operations working correctly")
            else:
                print("❌ File integrity check failed")
                success = False
        finally:
            os.unlink(temp_path)
    except Exception as e:
        print(f"❌ File operations test failed: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
