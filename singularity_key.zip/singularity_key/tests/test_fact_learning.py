#!/usr/bin/env python3
"""
Test suite for Fact Learning module
------------------------------------
Tests the enhanced fact learning functionality that integrates with multiple systems
"""
import sys
import os
import unittest
import tempfile
import sqlite3
import time
import re
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_fact_learning import (
    initialize, health_check, _learn_fact, 
    FactLearningSystem
)

class MockVectorIndex:
    """Mock implementation of Vector Index for testing"""
    def __init__(self):
        self.docs = {}
    
    def add_doc(self, gid, doc):
        self.docs[gid] = doc
        return True

class MockKnowledgeAPI:
    """Mock implementation of Knowledge API for testing"""
    def __init__(self):
        self.facts = []
    
    def ingest_fact(self, subj, pred, obj, src):
        self.facts.append((subj, pred, obj, src))
        return True

class FactLearningTests(unittest.TestCase):
    """Test cases for FactLearningSystem."""
    
    def setUp(self):
        """Set up test environment."""
        # Create temporary database file
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.conn = sqlite3.connect(self.temp_db.name)
        
        # Create required tables for testing
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS axiom (
                glyph TEXT PRIMARY KEY,
                title TEXT,
                definition TEXT,
                latex TEXT
            )
        ''')
        self.conn.commit()
        
        # Mock dependencies
        self.mock_vector_index = MockVectorIndex()
        self.mock_knowledge_api = MockKnowledgeAPI()
        self.trifecta_calls = []
        
        # Create fact patterns for testing
        self.fact_patterns = [
            (re.compile(r"(?P<subject>\w+) is (?P<object>.+)"), 
             lambda m: (m.group("subject"), "is", m.group("object"))),
            (re.compile(r"(?P<subject>\w+) has (?P<object>.+)"),
             lambda m: (m.group("subject"), "has", m.group("object")))
        ]
        
        # Initialize the system
        self.system = initialize(
            db_connection=self.conn,
            glyph_id_function=lambda x: f"glyph_{hash(x) % 1000}",
            trifecta_function=lambda x, weight=1.0: self.trifecta_calls.append((x, weight)),
            knowledge_api=self.mock_knowledge_api,
            vector_index=self.mock_vector_index,
            fact_patterns=self.fact_patterns
        )
    
    def tearDown(self):
        """Clean up after tests."""
        self.conn.close()
        os.unlink(self.temp_db.name)
    
    def test_learn_fact(self):
        """Test basic fact learning."""
        result = self.system.learn_fact("Earth is a planet")
        
        # Verify result
        self.assertTrue(result)
        
        # Verify fact was stored in axiom table
        count = self.conn.execute("SELECT COUNT(*) FROM axiom").fetchone()[0]
        self.assertEqual(count, 1)
        
        # Verify fact was ingested by knowledge API
        self.assertEqual(len(self.mock_knowledge_api.facts), 1)
        self.assertEqual(self.mock_knowledge_api.facts[0][0], "Earth")
        self.assertEqual(self.mock_knowledge_api.facts[0][1], "is")
        self.assertEqual(self.mock_knowledge_api.facts[0][2], "a planet")
        
        # Verify trifecta was called
        self.assertEqual(len(self.trifecta_calls), 1)
        self.assertEqual(self.trifecta_calls[0][0], "Earth is a planet")
        self.assertEqual(self.trifecta_calls[0][1], 0.15)
    
    def test_learn_fact_no_match(self):
        """Test learning with no matching pattern."""
        result = self.system.learn_fact("This doesn't match any pattern")
        
        # Verify result
        self.assertFalse(result)
        
        # Verify no fact was stored
        count = self.conn.execute("SELECT COUNT(*) FROM axiom").fetchone()[0]
        self.assertEqual(count, 0)
        
        # Verify knowledge API was not called
        self.assertEqual(len(self.mock_knowledge_api.facts), 0)
        
        # Verify trifecta was not called
        self.assertEqual(len(self.trifecta_calls), 0)
    
    def test_learn_facts_from_text(self):
        """Test learning facts from multi-line text."""
        text = """
        Earth is a planet
        Mars is red
        Humans have consciousness
        This doesn't match any pattern
        """
        
        count = self.system.learn_facts_from_text(text)
        
        # Verify count of learned facts
        self.assertEqual(count, 3)
        
        # Verify facts were stored
        count = self.conn.execute("SELECT COUNT(*) FROM axiom").fetchone()[0]
        self.assertEqual(count, 3)
        
        # Verify facts were ingested by knowledge API
        self.assertEqual(len(self.mock_knowledge_api.facts), 3)
    
    def test_learn_fact_tuple(self):
        """Test learning a fact from a tuple."""
        result = self.system.learn_fact_tuple("Python", "is", "a programming language", "test")
        
        # Verify result
        self.assertTrue(result)
        
        # Verify fact was stored
        count = self.conn.execute("SELECT COUNT(*) FROM axiom").fetchone()[0]
        self.assertEqual(count, 1)
        
        # Verify fact was ingested by knowledge API
        self.assertEqual(len(self.mock_knowledge_api.facts), 1)
        self.assertEqual(self.mock_knowledge_api.facts[0][0], "Python")
        self.assertEqual(self.mock_knowledge_api.facts[0][1], "is")
        self.assertEqual(self.mock_knowledge_api.facts[0][2], "a programming language")
        self.assertEqual(self.mock_knowledge_api.facts[0][3], "test")
    
    def test_health_check(self):
        """Test health check functionality."""
        # Learn a fact
        self.system.learn_fact("Earth is a planet")
        
        # Check health
        health = health_check()
        
        # Verify structure
        self.assertIn("status", health)
        self.assertIn("metrics", health)
        self.assertIn("details", health)
        
        # Verify status
        self.assertEqual(health["status"], "healthy")
        
        # Verify metrics
        self.assertGreaterEqual(health["metrics"]["facts_learned"], 1)

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
