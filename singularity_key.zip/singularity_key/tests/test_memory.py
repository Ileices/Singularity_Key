#!/usr/bin/env python3
"""
Test script for singularity_memory module
----------------------------------------
Tests memory management and excretion logging
"""
import sys
import os
import datetime as _dt
import json
import tempfile
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run tests for the memory module."""
    print("Testing singularity_memory module...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_memory import (
            initialize, log_excretion, add_to_dna, add_to_history,
            update_energy, get_energy, get_dna_snapshot, get_history_snapshot,
            get_metrics, health_check, save_memory_state, load_memory_state
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize the module with a temporary test directory
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Standard floating point conversion for testing
            def mock_fnum(s):
                return float(s)
            
            # Mock config
            mock_config = {
                "memory": {
                    "dna_maxlen": 100,
                    "hist_maxlen": 200,
                    "default_energy": 1.0
                }
            }
            
            # Initialize with temporary directory
            initialize(mock_fnum, mock_config, temp_path, temp_path / "excretions_test.log")
            
            print("✅ Module initialization successful")
    except Exception as e:
        print(f"❌ Module initialization error: {e}")
        success = False
        return False
    
    # Test 3: Excretion logging
    try:
        log_path = temp_path / "excretions_test.log"
        test_message = "TEST EXCRETION MESSAGE"
        log_excretion(test_message)
        
        # Verify log file was created and contains the message
        assert log_path.exists(), "Excretion log file not created"
        content = log_path.read_text(encoding="utf-8")
        assert test_message in content, "Test message not found in log"
        
        print("✅ Excretion logging successful")
    except Exception as e:
        print(f"❌ Excretion logging error: {e}")
        success = False
    
    # Test 4: DNA and History management
    try:
        # Add test entries
        test_dna_entry = {"type": "test", "value": 42}
        test_hist_entry = {"action": "test", "timestamp": _dt.datetime.utcnow().isoformat()}
        
        add_to_dna(test_dna_entry)
        add_to_history(test_hist_entry)
        
        # Get snapshots and verify
        dna = get_dna_snapshot()
        hist = get_history_snapshot()
        
        assert len(dna) == 1, f"Expected 1 DNA entry, got {len(dna)}"
        assert dna[0] == test_dna_entry, "DNA entry doesn't match"
        
        assert len(hist) == 1, f"Expected 1 history entry, got {len(hist)}"
        assert hist[0] == test_hist_entry, "History entry doesn't match"
        
        print("✅ DNA and history management successful")
    except Exception as e:
        print(f"❌ DNA/history management error: {e}")
        success = False
    
    # Test 5: Energy management
    try:
        # Update energy
        initial_energy = get_energy()
        updated_energy = update_energy(1.5)
        
        assert updated_energy == 1.5, f"Expected energy 1.5, got {updated_energy}"
        assert get_energy() == 1.5, f"get_energy() returned {get_energy()}, expected 1.5"
        
        print("✅ Energy management successful")
    except Exception as e:
        print(f"❌ Energy management error: {e}")
        success = False
    
    # Test 6: State persistence
    try:
        # Save state
        state_path = temp_path / "memory_state_test.json"
        save_path = save_memory_state(state_path)
        
        # Verify file was created
        assert state_path.exists(), "State file not created"
        
        # Modify memory to verify later restore
        update_energy(2.5)
        add_to_dna({"type": "modified", "value": 99})
        
        # Restore and verify
        assert load_memory_state(state_path), "State restoration returned False"
        
        # Check energy was restored
        assert get_energy() == 1.5, f"Expected restored energy 1.5, got {get_energy()}"
        
        # Check DNA was restored
        dna = get_dna_snapshot()
        assert len(dna) == 1, f"Expected 1 DNA entry after restore, got {len(dna)}"
        assert dna[0]["type"] == "test", f"Expected restored 'test' entry, got {dna[0]['type']}"
        
        print("✅ State persistence successful")
    except Exception as e:
        print(f"❌ State persistence error: {e}")
        success = False
    
    # Test 7: Metrics and health check
    try:
        metrics = get_metrics()
        health = health_check()
        
        print("\nMetrics:")
        for key, value in metrics.items():
            print(f"  {key}: {value}")
            
        print(f"\nHealth check: {health['status']}")
        print(f"Message: {health['message']}")
        
        # Check some metrics values
        assert "dna_length" in metrics, "dna_length metric missing"
        assert metrics["dna_length"] == 1, f"Expected DNA length 1, got {metrics['dna_length']}"
        
        assert "energy" in metrics, "energy metric missing"
        assert float(metrics["energy"]) == 1.5, f"Expected energy 1.5, got {metrics['energy']}"
        
        # Check health status
        assert health["status"] in ["healthy", "warning", "error"], f"Invalid health status: {health['status']}"
        
        print("✅ Metrics and health check successful")
    except Exception as e:
        print(f"❌ Metrics/health check error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nTesting {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
