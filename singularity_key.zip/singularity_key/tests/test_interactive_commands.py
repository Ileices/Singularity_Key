#!/usr/bin/env python3
"""
Test suite for Interactive Commands module
-----------------------------------------
Tests the interactive command functionality for querying and interacting with the knowledge base
"""
import sys
import os
import unittest
import tempfile
import sqlite3
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_interactive_commands import (
    initialize, health_check, _cmd_ask, _cmd_why, _cmd_recall,
    InteractiveCommandsSystem
)

class MockVectorIndex:
    """Mock implementation of Vector Index for testing"""
    def __init__(self):
        self.docs = {}
    
    def search(self, query, k=5):
        return ["glyph1"]

class MockKVStore:
    """Mock implementation of KV Store for testing"""
    def __init__(self):
        self.store = {}
    
    def get(self, key):
        return self.store.get(key)
    
    def __setitem__(self, key, value):
        self.store[key] = value

class InteractiveCommandsTests(unittest.TestCase):
    """Test cases for InteractiveCommandsSystem."""
    
    def setUp(self):
        """Set up test environment."""
        # Create temporary database file
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.conn = sqlite3.connect(self.temp_db.name)
        
        # Create required tables for testing
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS axiom (
                glyph TEXT PRIMARY KEY,
                title TEXT,
                definition TEXT,
                latex TEXT
            )
        ''')
        self.conn.execute('''
            INSERT INTO axiom (glyph, title, definition, latex)
            VALUES ('glyph1', 'Test Axiom', 'This is a test explanation', 'E=mc^2')
        ''')
        self.conn.commit()
        
        # Mock dependencies
        self.mock_vector_index = MockVectorIndex()
        self.mock_kv_store = MockKVStore()
        self.mock_kv_store["test_key"] = b"test_value"
        
        # Mock neuro_query function
        self.mock_neuro_query = MagicMock(return_value="Test answer")
        
        # Initialize the system
        self.system = initialize(
            neuro_query_func=self.mock_neuro_query,
            vector_index=self.mock_vector_index,
            kv_store=self.mock_kv_store,
            db_connection=self.conn
        )
    
    def tearDown(self):
        """Clean up after tests."""
        self.conn.close()
        os.unlink(self.temp_db.name)
    
    @patch('builtins.input', return_value="test question")
    @patch('builtins.print')
    def test_ask_command(self, mock_print, mock_input):
        """Test ask command functionality."""
        self.system.ask_command()
        
        # Verify neuro_query was called
        self.mock_neuro_query.assert_called_once_with("test question")
        
        # Verify result was printed
        mock_print.assert_any_call("\nTest answer\n")
    
    @patch('builtins.input', return_value="test query")
    @patch('builtins.print')
    def test_why_command(self, mock_print, mock_input):
        """Test why command functionality."""
        self.system.why_command()
        
        # Verify result was printed
        mock_print.assert_any_call("Because This is a test explanation")
    
    @patch('builtins.input', return_value="test_key")
    @patch('builtins.print')
    def test_recall_command(self, mock_print, mock_input):
        """Test recall command functionality."""
        self.system.recall_command()
        
        # Verify result was printed
        mock_print.assert_any_call("Value: test_value")
    
    def test_health_check(self):
        """Test health check functionality."""
        health = health_check()
        
        # Verify structure
        self.assertIn("status", health)
        self.assertIn("metrics", health)
        self.assertIn("details", health)
        
        # Verify status
        self.assertEqual(health["status"], "healthy")
        
        # Verify dependencies
        dependencies = health["details"]["dependencies"]
        self.assertTrue(dependencies["neuro_query"])
        self.assertTrue(dependencies["vector_index"])
        self.assertTrue(dependencies["kv_store"])
        self.assertTrue(dependencies["db_connection"])

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
