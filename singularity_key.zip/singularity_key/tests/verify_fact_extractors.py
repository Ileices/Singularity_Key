#!/usr/bin/env python3
"""
Verification script for singularity_fact_extractors module
---------------------------------------------------------
Tests basic functionality and integration with other modules
"""
import sys
import os
import sqlite3
import re
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def create_test_db():
    """Create temporary test databases for verification"""
    # Create periodic table test DB
    pt_con = sqlite3.connect(':memory:')
    pt_con.executescript("""
        CREATE TABLE term(term TEXT, glyph TEXT);
        CREATE TABLE axiom(glyph TEXT, title TEXT, latex TEXT, definition TEXT);
    """)
    
    # Create knowledge test DB
    k_con = sqlite3.connect(':memory:')
    k_con.executescript("""
        CREATE TABLE fact(subj TEXT, pred TEXT, obj TEXT, confidence REAL DEFAULT 1.0);
    """)
    
    return pt_con, k_con

def mock_glyph_id(data):
    """Mock glyph_id function for testing"""
    import hashlib
    return f"⟐{hashlib.sha256(data).hexdigest()[:16]}"

def mock_trifecta(text, weight=1.0):
    """Mock trifecta function for testing"""
    return (0.33, 0.33, 0.33)

def run_tests():
    print("Running verification tests for singularity_fact_extractors...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_fact_extractors import (
            initialize, persist_fact, learn_fact, learn_fact_tuple,
            answer, enhanced_answer, health_check
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Initialize with mock databases
    try:
        pt_con, k_con = create_test_db()
        test_patterns = [
            (re.compile(r"^(?P<subj>[\w\s]+?) is (?P<obj>.+)", re.I),
             lambda m: (m.group("subj").strip(), "is", m.group("obj").strip(".")))
        ]
        
        initialize(pt_con, k_con, mock_glyph_id, mock_trifecta, test_patterns)
        print("✅ Module initialization successful")
    except Exception as e:
        print(f"❌ Module initialization failed: {e}")
        success = False
        return False
    
    # Test 3: Extract and persist facts
    try:
        result = persist_fact("The sky is blue")
        if result:
            print("✅ Fact persistence successful")
            
            # Verify fact was stored in periodic table DB
            check1 = pt_con.execute("SELECT * FROM term WHERE term = ?", ("The sky",)).fetchone()
            check2 = pt_con.execute("SELECT * FROM axiom").fetchone()
            
            if check1 and check2:
                print("✅ Fact stored in periodic table DB")
            else:
                print("❌ Fact not stored in periodic table DB")
                success = False
        else:
            print("❌ Fact persistence failed")
            success = False
    except Exception as e:
        print(f"❌ Fact persistence error: {e}")
        success = False
    
    # Test 4: Learn facts
    try:
        result = learn_fact("Water is a liquid")
        if result:
            print("✅ Fact learning successful")
            
            # Verify fact was stored in knowledge DB
            check = k_con.execute("SELECT * FROM fact WHERE subj = ?", ("water",)).fetchone()
            
            if check:
                print("✅ Fact stored in knowledge DB")
            else:
                print("❌ Fact not stored in knowledge DB")
                success = False
        else:
            print("❌ Fact learning failed")
            success = False
    except Exception as e:
        print(f"❌ Fact learning error: {e}")
        success = False
    
    # Test 5: Direct fact storage
    try:
        result = learn_fact_tuple("Earth", "planet", "Solar System", 0.99)
        if result:
            print("✅ Direct fact tuple storage successful")
            
            # Verify fact was stored in knowledge DB
            check = k_con.execute("SELECT * FROM fact WHERE subj = ?", ("earth",)).fetchone()
            
            if check:
                print("✅ Direct fact tuple stored in knowledge DB")
            else:
                print("❌ Direct fact tuple not stored in knowledge DB")
                success = False
        else:
            print("❌ Direct fact tuple storage failed")
            success = False
    except Exception as e:
        print(f"❌ Direct fact tuple storage error: {e}")
        success = False
    
    # Test 6: Basic QA
    try:
        result = answer("What is water?")
        if result:
            print(f"✅ Question answering successful: {result}")
        else:
            # May be normal to have no answer if fact wasn't recognized
            print("⚠️  No answer found for question (may be normal)")
    except Exception as e:
        print(f"❌ Question answering error: {e}")
        success = False
    
    # Test 7: Health check
    try:
        health = health_check()
        if health and "status" in health:
            print(f"✅ Health check returned status: {health['status']}")
            print(f"✅ Metrics: {health['metrics']}")
        else:
            print("❌ Health check failed to return proper status")
            success = False
    except Exception as e:
        print(f"❌ Health check error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
