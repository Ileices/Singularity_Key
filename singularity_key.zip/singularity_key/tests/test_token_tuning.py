#!/usr/bin/env python3
"""
Test script for the enhanced token tuning functionality
"""
import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def test_token_tuning():
    """Test the enhanced token tuning functionality."""
    print("Testing enhanced token tuning functionality...")
    
    # Import the lexical module
    try:
        from singularity_lexical import tune_unknown_word, initialize
        from decimal import Decimal
        
        # Define a mock _FNUM function
        def mock_fnum(s): return Decimal(s)
        
        # Initialize the module with mock weights
        initialize(mock_fnum, {
            "imperative": (Decimal("0.05"), Decimal("0.15"), Decimal("0.80")),
            "modal": (Decimal("0.15"), Decimal("0.70"), Decimal("0.15")),
        })
        
        # Test cases with different contexts
        test_cases = [
            ("neuron", "I can see neurons firing in the brain scan.", "perception"),
            ("algorithm", "The algorithm computes the optimal solution.", "cognition"),
            ("execute", "Please execute this program immediately.", "execution"),
            ("philosophy", "Philosophy requires deep thinking and analysis.", "cognition"),
            ("sensation", "The sensation of touch occurs in nerve endings.", "perception"),
            ("implementation", "The implementation of the code runs quickly.", "execution")
        ]
        
        print("\nTesting token tuning with various contexts:")
        for token, context, expected_bias in test_cases:
            r, b, y = tune_unknown_word(token, context)
            print(f"\nToken: {token}")
            print(f"Context: {context}")
            print(f"Expected bias: {expected_bias}")
            print(f"Assigned weights: R={float(r):.3f}, B={float(b):.3f}, Y={float(y):.3f}")
            
            # Check if the expected bias is reflected in the weights
            if expected_bias == "perception" and float(r) > float(b) and float(r) > float(y):
                print("✓ Correct bias toward perception (R)")
            elif expected_bias == "cognition" and float(b) > float(r) and float(b) > float(y):
                print("✓ Correct bias toward cognition (B)")
            elif expected_bias == "execution" and float(y) > float(r) and float(y) > float(b):
                print("✓ Correct bias toward execution (Y)")
            else:
                print("✗ Unexpected bias distribution")
        
        # Test that certain word endings influence weights
        suffix_test_cases = [
            ("computing", "word with -ing suffix"),
            ("perception", "word with -tion suffix"),
            ("psychology", "word with -logy suffix"),
            ("readable", "word with -able suffix")
        ]
        
        print("\nTesting suffix-based weight assignment:")
        for token, desc in suffix_test_cases:
            r, b, y = tune_unknown_word(token, f"The {token} is important.")
            print(f"{token} ({desc}): R={float(r):.3f}, B={float(b):.3f}, Y={float(y):.3f}")
        
        # Test weight normalization
        print("\nTesting weight normalization:")
        for token, context, _ in test_cases:
            r, b, y = tune_unknown_word(token, context)
            total = float(r) + float(b) + float(y)
            print(f"{token}: R+B+Y = {total:.6f}")
            if abs(total - 1.0) < 1e-6:
                print("✓ Weights normalized correctly")
            else:
                print(f"✗ Weights not normalized: {total}")
        
        return True
    except Exception as e:
        print(f"Error testing token tuning: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_token_tuning()
    print(f"\nTest {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
