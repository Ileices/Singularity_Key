#!/usr/bin/env python3
"""
Verification script for singularity_config module
------------------------------------------------
Tests basic functionality and integration with singularity_boot
"""
import sys
import os
import time
import pathlib

# Add parent directory to path for imports
sys.path.append(str(pathlib.Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_config...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_config import CFG, R0, B0, Y0, _FNUM, health_check
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Check if config was loaded
    if isinstance(CFG, dict) and len(CFG) > 0:
        print("✅ Configuration loaded successfully")
    else:
        print("❌ Configuration loading failed")
        success = False
        
    # Test 3: Verify high precision mode
    from decimal import Decimal
    if isinstance(R0, Decimal if CFG.get("high_precision_mode", True) else float):
        print(f"✅ High precision mode working correctly (type={type(R0).__name__})")
    else:
        print(f"❌ High precision mode not properly applied (type={type(R0).__name__})")
        success = False
    
    # Test 4: Check singularity_boot integration
    try:
        import singularity_boot
        if singularity_boot.CFG is CFG:
            print("✅ Integration with singularity_boot successful")
        else:
            print("❌ CFG reference mismatch between modules")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    # Test 5: Check health status
    status = health_check()
    if status["status"] == "healthy":
        print("✅ Health check reports system healthy")
    else:
        print(f"⚠️ Health check reports status: {status['status']}")
        for key, value in status["checks"].items():
            if not value:
                print(f"  - Failed check: {key}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
