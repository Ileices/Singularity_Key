#!/usr/bin/env python3
"""
Test suite for CLI Handler module
-----------------------------------------
Tests the CLI input processing functionality
"""
import sys
import os
import unittest
import time
import logging
from pathlib import Path
from unittest.mock import patch, MagicMock, call

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from singularity_cli_handler import (
    initialize, health_check, _γ_process_cli,
    CLIHandlerSystem
)

class CLIHandlerTests(unittest.TestCase):
    """Test cases for CLIHandlerSystem."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock all required functions
        self.mock_trifecta = MagicMock(return_value=(0.33, 0.33, 0.33))
        self.mock_learn_fact = MagicMock()
        self.mock_energy = 0.5
        self.mock_trifecta_echo = MagicMock()
        
        # Initialize the system with mocks
        self.system = initialize(
            trifecta_function=self.mock_trifecta,
            learn_fact_function=self.mock_learn_fact,
            energy_variable=self.mock_energy,
            original_trifecta_echo=self.mock_trifecta_echo,
            logger=logging.getLogger("test")
        )
    
    def test_process_cli_calls_all_functions(self):
        """Test that process_cli calls all required functions."""
        # Prepare test data
        test_line = "This is a test command"
        
        # Call process_cli
        r, b, y = self.system.process_cli(test_line)
        
        # Verify learn_fact was called
        self.mock_learn_fact.assert_called_once_with(test_line)
        
        # Verify trifecta was called
        self.mock_trifecta.assert_called_once_with(test_line)
        
        # Verify echo function was called
        self.mock_trifecta_echo.assert_called_once_with(0.33, 0.33, 0.33)
        
        # Verify return values
        self.assertEqual((r, b, y), (0.33, 0.33, 0.33))
    
    def test_process_cli_handles_learn_fact_error(self):
        """Test that process_cli handles errors in learn_fact."""
        # Make learn_fact raise an error
        self.mock_learn_fact.side_effect = Exception("Test error")
        
        # Prepare test data
        test_line = "This is a test command"
        
        # Call process_cli (should not raise exception)
        r, b, y = self.system.process_cli(test_line)
        
        # Verify trifecta was still called
        self.mock_trifecta.assert_called_once_with(test_line)
        
        # Verify echo function was still called
        self.mock_trifecta_echo.assert_called_once_with(0.33, 0.33, 0.33)
    
    def test_process_cli_handles_trifecta_error(self):
        """Test that process_cli handles errors in trifecta."""
        # Make trifecta raise an error
        self.mock_trifecta.side_effect = Exception("Test error")
        
        # Prepare test data
        test_line = "This is a test command"
        
        # Call process_cli (should not raise exception)
        r, b, y = self.system.process_cli(test_line)
        
        # Verify learn_fact was still called
        self.mock_learn_fact.assert_called_once_with(test_line)
        
        # Verify echo function was still called with default values
        self.mock_trifecta_echo.assert_called_once_with(0.0, 0.0, 0.0)
        
        # Verify return values
        self.assertEqual((r, b, y), (0.0, 0.0, 0.0))
    
    def test_global_process_cli_function(self):
        """Test that the global _γ_process_cli function calls the system method."""
        # Prepare test data
        test_line = "This is a test command"
        
        # Call global function
        _γ_process_cli(test_line)
        
        # Verify system method was called
        self.mock_learn_fact.assert_called_once_with(test_line)
        self.mock_trifecta.assert_called_once_with(test_line)
    
    def test_health_check(self):
        """Test health check functionality."""
        # Process a command to update metrics
        self.system.process_cli("Test command")
        
        # Check health
        health = health_check()
        
        # Verify structure
        self.assertIn("status", health)
        self.assertIn("metrics", health)
        self.assertIn("details", health)
        
        # Verify status
        self.assertEqual(health["status"], "healthy")
        
        # Verify metrics
        self.assertGreaterEqual(health["metrics"]["cli_commands_processed"], 1)
        self.assertGreaterEqual(health["metrics"]["facts_learned"], 1)
        
        # Verify dependencies
        dependencies = health["details"]["dependencies"]
        self.assertTrue(dependencies["trifecta"])
        self.assertTrue(dependencies["learn_fact"])
        self.assertTrue(dependencies["energy"])
        self.assertTrue(dependencies["trifecta_echo"])

    def test_default_trifecta_echo(self):
        """Test that default trifecta echo works."""
        # Initialize system without echo function
        system = CLIHandlerSystem(
            trifecta_function=self.mock_trifecta,
            learn_fact_function=self.mock_learn_fact,
            energy_variable=self.mock_energy,
            original_trifecta_echo=None,
            logger=logging.getLogger("test")
        )
        
        # Patch print function
        with patch('builtins.print') as mock_print:
            # Process CLI input
            system.process_cli("Test command")
            
            # Verify print was called with expected format
            mock_print.assert_called_once()
            args = mock_print.call_args[0][0]
            self.assertIn("R=0.330", args)
            self.assertIn("B=0.330", args)
            self.assertIn("Y=0.330", args)
            self.assertIn("ENERGY=0.5", args)

def run_tests():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    run_tests()
