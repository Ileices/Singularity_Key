#!/usr/bin/env python3
"""
Verification script for singularity_patterns module
---------------------------------------------------
Tests basic functionality and integration with singularity_boot and singularity_knowledge
"""
import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    print("Running verification tests for singularity_patterns...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_patterns import (
            extract_facts, extract_and_store, add_pattern, get_all_patterns
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Check pattern extraction
    test_text = "The capital of France is Paris."
    try:
        facts = extract_facts(test_text)
        if facts:
            print(f"✅ Extracted {len(facts)} facts from test text:")
            for subj, pred, obj, conf in facts:
                print(f"  {subj} {pred} {obj} (confidence: {conf:.2f})")
        else:
            print("❌ No facts extracted from test text")
            success = False
    except Exception as e:
        print(f"❌ Fact extraction error: {e}")
        success = False
    
    # Test 3: Add a custom pattern
    try:
        def custom_extractor(match):
            return (match.group(1), "invented", match.group(2))
        
        pattern_added = add_pattern(
            r"([\w\s]+) invented ([\w\s]+)", 
            custom_extractor, 
            "Invention pattern"
        )
        
        if pattern_added:
            print("✅ Custom pattern added successfully")
            
            # Test the custom pattern
            custom_text = "Edison invented the light bulb."
            custom_facts = extract_facts(custom_text)
            
            if any(pred == "invented" for _, pred, _, _ in custom_facts):
                print("✅ Custom pattern works correctly")
            else:
                print("❌ Custom pattern not working as expected")
                success = False
        else:
            print("❌ Failed to add custom pattern")
            success = False
    except Exception as e:
        print(f"❌ Custom pattern test error: {e}")
        success = False
    
    # Test 4: Check integration with knowledge module
    try:
        from singularity_knowledge import extract_facts_from_text
        
        k_facts = extract_facts_from_text("The Eiffel Tower is in Paris.")
        if k_facts:
            print("✅ Integration with knowledge module successful")
            print(f"  Extracted via knowledge module: {k_facts}")
        else:
            print("❓ No facts extracted via knowledge module")
    except Exception as e:
        print(f"❌ Knowledge module integration error: {e}")
        success = False
    
    # Test 5: Check integration with boot module
    try:
        import singularity_boot
        
        if "/extract" in singularity_boot.META and "/add-pattern" in singularity_boot.META:
            print("✅ Integration with singularity_boot successful")
        else:
            print("❌ META commands not found in singularity_boot")
            success = False
    except Exception as e:
        print(f"❌ Failed to verify singularity_boot integration: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
