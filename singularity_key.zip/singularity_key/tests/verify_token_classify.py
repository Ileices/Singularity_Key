#!/usr/bin/env python3
"""
Verification script for singularity_token_classify module
--------------------------------------------------------
Tests token classification functions and their integration
"""
import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

def run_tests():
    """Run tests on the token classification module."""
    print("Running verification tests for singularity_token_classify...")
    success = True
    
    # Test 1: Import the module
    try:
        from singularity_token_classify import (
            initialize, classify, classify_morphological, 
            classify_with_confidence, health_check, get_metrics
        )
        print("✅ Module imports successful")
    except ImportError as e:
        print(f"❌ Module import failed: {e}")
        return False
    
    # Test 2: Module initialization
    try:
        initialize()
        health = health_check()
        if health["status"] in ("healthy", "warning"):
            print("✅ Module initialization successful")
        else:
            print(f"❌ Module initialization failed: {health['message']}")
            success = False
    except Exception as e:
        print(f"❌ Module initialization error: {e}")
        success = False
        return False
    
    # Test 3: Basic classification
    test_tokens = [
        ("run", "imperative"), 
        ("should", "modal"),
        ("not", "negation"),
        ("Hello", "proper_noun"),
        ("NASA", "acronym"),
        ("cat", "noun"),
        ("!", "punct_exec")
    ]
    
    try:
        print("\nTesting basic classification...")
        failures = []
        for token, expected in test_tokens:
            result = classify(token)
            if result == expected:
                print(f"  '{token}' → {result} ✓")
            else:
                print(f"  '{token}' → {result} ✗ (expected {expected})")
                failures.append(token)
        
        if not failures:
            print("✅ All basic classifications successful")
        else:
            print(f"❌ {len(failures)}/{len(test_tokens)} basic classifications failed")
            success = False
    except Exception as e:
        print(f"❌ Basic classification error: {e}")
        success = False
    
    # Test 4: Morphological classification
    morph_test_tokens = [
        "walking", "decided", "quickly", "creation", "teacher", "readable"
    ]
    
    try:
        print("\nTesting morphological classification...")
        for token in morph_test_tokens:
            result = classify_morphological(token)
            print(f"  '{token}' → {result}")
        print("✅ Morphological classification successful")
    except Exception as e:
        print(f"❌ Morphological classification error: {e}")
        success = False
    
    # Test 5: Classification with confidence
    try:
        print("\nTesting classification with confidence...")
        for token in ["run", "Hello", "NASA", "the", "42"]:
            cls, conf = classify_with_confidence(token)
            print(f"  '{token}' → {cls} ({conf:.2f})")
        print("✅ Classification with confidence successful")
    except Exception as e:
        print(f"❌ Classification with confidence error: {e}")
        success = False
    
    # Test 6: Metrics collection
    try:
        metrics = get_metrics()
        print("\nMetrics:")
        for key, value in metrics.items():
            print(f"  {key}: {value}")
        print("✅ Metrics collection successful")
    except Exception as e:
        print(f"❌ Metrics collection error: {e}")
        success = False
    
    # Test 7: Health check
    try:
        health = health_check()
        print(f"\nHealth check status: {health['status']}")
        print(f"Message: {health['message']}")
        print("✅ Health check successful")
    except Exception as e:
        print(f"❌ Health check error: {e}")
        success = False
    
    return success

if __name__ == "__main__":
    success = run_tests()
    print(f"\nVerification {'PASSED' if success else 'FAILED'}")
    sys.exit(0 if success else 1)
