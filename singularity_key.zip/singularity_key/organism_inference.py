"""
Unified inference engine for Singularity
----------------------------------------
Integrates all inference pathways and connects RBY weights to neural inference,
creating a cohesive system where:
- RBY weights influence inference priorities and parameters
- Inference quality feeds back to adjust weights
- All inference requests flow through a single optimized pipeline
"""

import os, time, json, threading, queue, pathlib
from typing import Dict, List, Tuple, Optional, Union, Any, Callable
import torch
from decimal import Decimal

# Import from existing modules
try:
    from singularity_boot import (
        trifecta, perception, cognition, execution, 
        log_excretion, glyph_id, rby, _FNUM, R0, B0, Y0
    )
except ImportError:
    # Mock implementations for standalone testing
    def trifecta(text, weight=1.0): return (0.33, 0.33, 0.34)
    def perception(t): return 0.33
    def cognition(t): return 0.33
    def execution(t): return 0.34
    def log_excretion(msg): print(f"EXCRETION: {msg}")
    def glyph_id(b): return f"⟐{hash(b)}"
    def rby(tok): return (0.33, 0.33, 0.34)
    _FNUM = float
    R0, B0, Y0 = 0.33, 0.33, 0.34

try:
    from organism_neuro import (
        query as neural_query, 
        _load_custom_model, _EMB_MODEL, _save_index,
        DEVICE, CUDA_OK
    )
except ImportError:
    import torch
    CUDA_OK = torch.cuda.is_available()
    DEVICE = torch.device("cuda" if CUDA_OK else "cpu")
    def neural_query(q, temperature=0.7, max_new=256): 
        return f"Mock response to: {q}"
    def _load_custom_model(): return None, None
    _EMB_MODEL = None
    def _save_index(): pass

try:
    from organism_cluster import remote_call, best_peer, llm_generate
except ImportError:
    def remote_call(call_str, *args, **kwargs): 
        return f"Mock remote call to {call_str}"
    def best_peer(): return {"id": "local", "gpu": "localhost"}
    def llm_generate(prompt, max_new=256, temp=0.7):
        return f"Mock LLM response to: {prompt}"

# Constants
BASE = pathlib.Path(__file__).parent.resolve()
ECO  = BASE / "ecosystem"
INFER_STATS_DIR = ECO / "inference_stats"
INFER_STATS_DIR.mkdir(exist_ok=True, parents=True)

# Stats tracking for inference quality
class InferenceStats:
    def __init__(self):
        self.total_inferences = 0
        self.rby_influenced = 0
        self.success_rate = 1.0
        self.latency_ms = []
        self.token_rates = []
        self.last_reset = time.time()
        self._lock = threading.Lock()
        
    def update(self, latency_ms: float, success: bool, tokens: int, 
               duration_s: float, rby_influenced: bool):
        with self._lock:
            self.total_inferences += 1
            self.latency_ms.append(latency_ms)
            if tokens > 0 and duration_s > 0:
                self.token_rates.append(tokens / duration_s)
            if rby_influenced:
                self.rby_influenced += 1
            
            # Update success rate with exponential smoothing
            alpha = 0.1  # Smoothing factor
            self.success_rate = alpha * (1.0 if success else 0.0) + (1-alpha) * self.success_rate
            
    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_inferences": self.total_inferences,
                "rby_influenced": self.rby_influenced,
                "rby_influence_pct": 100 * self.rby_influenced / max(1, self.total_inferences),
                "success_rate": self.success_rate,
                "avg_latency_ms": sum(self.latency_ms) / max(1, len(self.latency_ms)),
                "avg_tokens_per_sec": sum(self.token_rates) / max(1, len(self.token_rates)),
                "uptime_s": time.time() - self.last_reset
            }
    
    def periodic_save(self):
        """Save stats periodically to disk"""
        stats = self.get_stats()
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        stats_file = INFER_STATS_DIR / f"inference_stats_{timestamp}.json"
        with stats_file.open('w') as f:
            json.dump(stats, f, indent=2)
        
        # Log a glyph for the stats
        stats_glyph = glyph_id(json.dumps(stats).encode())
        log_excretion(f"INFERENCE-STATS {stats_glyph} success={stats['success_rate']:.2f}")
        
        # Reset certain stats
        with self._lock:
            self.latency_ms = self.latency_ms[-100:]  # Keep only recent entries
            self.token_rates = self.token_rates[-100:]

# Global stats tracker
_stats = InferenceStats()

# Start periodic stats saving
def _stats_saver():
    while True:
        time.sleep(3600)  # Save every hour
        _stats.periodic_save()
        
threading.Thread(target=_stats_saver, daemon=True).start()

# RBY to inference parameter mapping
def _map_rby_to_params(r: Union[float, Decimal], 
                       b: Union[float, Decimal], 
                       y: Union[float, Decimal]) -> Dict[str, float]:
    """
    Map RBY values to inference parameters:
    - R (perception) → temperature (higher R = more creative/divergent)
    - B (cognition) → top_p (higher B = more focused/coherent)
    - Y (execution) → max_tokens (higher Y = more output)
    """
    # Normalize to float for parameter usage
    r_norm, b_norm, y_norm = float(r), float(b), float(y)
    
    # Calculate parameters with sensible bounds
    temp = min(1.2, max(0.1, 0.1 + r_norm))  # 0.1 to 1.2
    top_p = min(0.95, max(0.1, b_norm))      # 0.1 to 0.95
    max_tokens = int(min(1024, max(32, y_norm * 512)))  # 32 to 1024
    
    return {
        "temperature": temp,
        "top_p": top_p,
        "max_tokens": max_tokens
    }

# Weight adjustment based on inference success
def _adjust_weights(query: str, success: bool, latency_ms: float):
    """
    Adjust RBY weights for tokens based on inference quality:
    - Successful, fast queries → strengthen current weights
    - Failed or slow queries → adjust weights toward baseline
    """
    # Actual implementation in inference_integration.py
    pass

# Core unified inference function
def unified_inference(
    query: str, 
    context: Optional[str] = None,
    mode: str = "auto",  # "neural", "rby", "hybrid", or "auto"
    remote: bool = True
) -> Dict[str, Any]:
    """
    Unified inference interface that connects RBY weights to neural inference
    
    Args:
        query: The query text
        context: Optional context to include
        mode: Inference mode (neural, rby, hybrid, auto)
        remote: Whether to use remote execution if available
        
    Returns:
        Dictionary with results and metadata
    """
    # Check if we have integrated inference available
    try:
        from inference_integration import integrated_infer_with_metadata
        return integrated_infer_with_metadata(query, context, mode)
    except ImportError:
        # Fall back to original implementation
        pass
    
    start_time = time.time()
    
    # Get RBY weights for the query
    r, b, y = perception(query), cognition(query), execution(query)
    
    # Determine if this should use neural or RBY dominant processing
    if mode == "auto":
        # Auto mode decides based on query characteristics
        # More cognitive (B) queries go to neural, more execution (Y) to RBY
        mode = "neural" if b > y else "hybrid"
    
    result = ""
    metadata = {
        "mode": mode,
        "rby": (float(r), float(b), float(y)),
        "remote_executed": False
    }
    
    try:
        if mode == "neural" or mode == "hybrid":
            # Map RBY values to inference parameters
            params = _map_rby_to_params(r, b, y)
            
            # Prepare context-enhanced query if needed
            if context:
                enhanced_query = f"Context: {context}\n\nQuery: {query}"
            else:
                enhanced_query = query
            
            # Use remote execution if available and requested
            if remote:
                try:
                    # Try cluster execution first
                    result = remote_call("organism_inference.local_inference", 
                                         enhanced_query, 
                                         params["temperature"], 
                                         params["top_p"], 
                                         params["max_tokens"])
                    metadata["remote_executed"] = True
                except Exception as e:
                    # Fall back to local
                    result = local_inference(enhanced_query, 
                                            params["temperature"],
                                            params["top_p"],
                                            params["max_tokens"])
            else:
                result = local_inference(enhanced_query, 
                                       params["temperature"],
                                       params["top_p"],
                                       params["max_tokens"])
        
        if mode == "rby" or (mode == "hybrid" and not result):
            # For pure RBY or hybrid fallback, use RBY mechanics
            r_weight = "High perception: " if r > 0.5 else "Low perception: "
            b_weight = "High cognition: " if b > 0.5 else "Low cognition: "
            y_weight = "High execution: " if y > 0.5 else "Low execution: "
            
            rby_result = f"{r_weight}{b_weight}{y_weight} {query}"
            
            if mode == "rby" or not result:
                result = rby_result
            else:
                # For hybrid mode, combine with neural result
                result = f"{result}\n\nRBY Analysis: {rby_result}"
        
        success = True
    except Exception as e:
        result = f"Inference error: {str(e)}"
        success = False
    
    # Calculate stats
    end_time = time.time()
    duration_s = end_time - start_time
    latency_ms = duration_s * 1000
    tokens = len(result.split())
    
    # Update stats
    _stats.update(latency_ms, success, tokens, duration_s, mode == "hybrid")
    
    # Record the inference in RBY system
    trifecta(result, weight=0.2)
    
    # If successful, adjust weights for future queries
    if success:
        _adjust_weights(query, True, latency_ms)
    
    # Complete the result package
    metadata.update({
        "latency_ms": latency_ms,
        "tokens": tokens,
        "success": success
    })
    
    return {
        "result": result,
        "metadata": metadata
    }

def local_inference(
    query: str, 
    temperature: float = 0.7,
    top_p: float = 0.95,
    max_tokens: int = 256
) -> str:
    """Local inference implementation"""
    # This is the actual local inference function that neural_query uses
    return neural_query(query, temperature=temperature, max_new=max_tokens)

# Public API for external modules
def infer(query: str, context: Optional[str] = None, mode: str = "auto") -> str:
    """Public API for inference, returns just the result string"""
    # Check if we have integrated inference available
    try:
        from inference_integration import integrated_infer
        return integrated_infer(query, context, mode)
    except ImportError:
        # Fall back to original implementation
        result = unified_inference(query, context, mode)
        return result["result"]

def infer_with_metadata(query: str, context: Optional[str] = None, mode: str = "auto") -> Dict:
    """Public API for inference with full metadata"""
    # Check if we have integrated inference available
    try:
        from inference_integration import integrated_infer_with_metadata
        return integrated_infer_with_metadata(query, context, mode)
    except ImportError:
        # Fall back to original implementation
        return unified_inference(query, context, mode)

def get_inference_stats() -> Dict[str, Any]:
    """Get current inference stats"""
    # Check if we have integrated inference available
    try:
        from inference_integration import get_integrated_stats
        return get_integrated_stats()
    except ImportError:
        # Fall back to original implementation
        return _stats.get_stats()

# Interactive command for the META system
def cmd_infer_stats():
    """Show current inference stats"""
    # Check if we have integrated inference available
    try:
        from inference_integration import cmd_integrated_stats
        return cmd_integrated_stats()
    except ImportError:
        # Fall back to original implementation
        stats = get_inference_stats()
        print("\nInference Engine Statistics:")
        print(f"Total inferences: {stats['total_inferences']}")
        print(f"RBY influence: {stats['rby_influence_pct']:.1f}%")
        print(f"Success rate: {stats['success_rate']:.2f}")
        print(f"Avg latency: {stats['avg_latency_ms']:.1f} ms")
        print(f"Avg tokens/sec: {stats['avg_tokens_per_sec']:.1f}")
        print(f"Uptime: {stats['uptime_s'] / 3600:.1f} hours\n")

def cmd_infer_custom():
    """Run custom inference with mode selection"""
    # Check if we have integrated inference available
    try:
        from inference_integration import cmd_integrated_infer
        return cmd_integrated_infer()
    except ImportError:
        # Fall back to original implementation
        query = input("Query: ")
        print("Mode options: neural, rby, hybrid, auto")
        mode = input("Mode [auto]: ").strip().lower() or "auto"
        
        if mode not in ["neural", "rby", "hybrid", "auto"]:
            print(f"Invalid mode: {mode}, using auto")
            mode = "auto"
        
        use_context = input("Use context? (y/n) [n]: ").strip().lower() == 'y'
        context = input("Context: ") if use_context else None
        
        print("\nProcessing...")
        result = infer_with_metadata(query, context, mode)
        
        print("\nResult:")
        print(result["result"])
        print("\nMetadata:")
        for k, v in result["metadata"].items():
            print(f"  {k}: {v}")

# Register commands in META if imported from main module
if __name__ != "__main__":
    try:
        # Try to register with META if available
        import sys
        if 'singularity_boot' in sys.modules:
            sys.modules['singularity_boot'].META["/infer-stats"] = cmd_infer_stats
            sys.modules['singularity_boot'].META["/infer"] = cmd_infer_custom
    except Exception:
        # Silently continue if META not available
        pass

# Test if run directly
if __name__ == "__main__":
    print("Testing unified inference system...")
    test_query = "Explain how neural networks process information"
    
    print(f"Query: {test_query}")
    result = infer_with_metadata(test_query)
    
    print("\nResult:")
    print(result["result"])
    
    print("\nMetadata:")
    for k, v in result["metadata"].items():
        print(f"  {k}: {v}")
