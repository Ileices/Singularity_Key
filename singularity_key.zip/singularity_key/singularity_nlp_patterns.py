#!/usr/bin/env python3
"""
Singularity NLP Pattern Recognition Module
-----------------------------------------
Advanced pattern matching and fact extraction for linguistic and NLP patterns.

Features:
- Specialized patterns for linguistic relationships (synonyms, antonyms, etc.)
- Thread-safe extraction operations with proper locking
- Integration with the knowledge database and core pattern system
- Support for multilingual patterns and translations
- Language family and part-of-speech recognition
- Confidence scoring based on linguistic specificity

This module extends the core pattern recognition capabilities with specialized
patterns for extracting structured knowledge from linguistic and NLP content.
"""
import re
import os
import time
import json
import logging
import threading
import warnings
import hashlib
from typing import List, Dict, Tuple, Callable, Optional, Any, Union, Pattern, Set
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.nlp_patterns")

# Thread safety
_pattern_lock = threading.RLock()
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "patterns_loaded": 0,
    "total_extractions": 0,
    "successful_extractions": 0,
    "errors": 0,
    "language_hits": {}  # Track hits by language
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# NLP and Linguistic Pattern Definitions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_NLP_PATTERNS: list[tuple[re.Pattern, callable]] = [

    # 24) Dictionary-style definition:  "serendipity means fortunate discovery"
    (re.compile(r"^(?P<subj>\w+)\s+(means|signifies|denotes)\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "means", m.group("obj"))),

    # 25) Synonymy:  "happy is synonymous with joyful"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(synonymous with|a synonym of)\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "synonym", m.group("obj"))),

    # 26) Antonymy:  "cold is the opposite of hot"
    (re.compile(r"^(?P<subj>\w+)\s+(is|'s)\s+the\s+opposite\s+of\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "antonym", m.group("obj"))),

    # 27) Hypernym / hyponym:  "A robin is a kind of bird"
    (re.compile(r"^(?P<subj>[\w\s]+?)\s+is\s+(a\s+kind|type)\s+of\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj").strip(), "hyponym_of", m.group("obj"))),

    # 28) Part-of-speech annotation:  "run is a verb"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(a|an)\s+(?P<obj>noun|verb|adjective|adverb|pronoun|preposition|conjunction|interjection)", re.I),
        lambda m: (m.group("subj"), "part_of_speech", m.group("obj"))),

    # 29) Morphological rule:  "plural of mouse is mice"
    (re.compile(r"^plural of (?P<subj>\w+)\s+is\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "plural", m.group("obj"))),

    # 30) Translation gloss:  "'hello' in French is 'bonjour'"
    (re.compile(r"[\"'""]?([\w\s]+)[\"'""]?\s+in\s+(?P<lang>\w+)\s+is\s+[\"'""]?(?P<obj>.+)[\"'""]?", re.I),
        lambda m: (m.group(1).strip(), f"translation_{m.group('lang').lower()}", m.group("obj").strip())),

    # 31) Pronunciation / IPA:  "queue is pronounced /kjuː/"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+pronounced\s+(?P<obj>/.*?/)", re.I),
        lambda m: (m.group("subj"), "pronunciation", m.group("obj"))),

    # 32) Language-family membership:  "Basque belongs to the language isolate family"
    (re.compile(r"^(?P<subj>\w+)\s+belongs to (the )?(?P<obj>.+?) family", re.I),
        lambda m: (m.group("subj"), "in_family", m.group("obj"))),
]

# Extended NLP patterns - additional linguistic patterns not in the original set
_EXTENDED_NLP_PATTERNS = [
    # Etymology patterns
    (re.compile(r"^(?P<subj>\w+)\s+comes from\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "etymology", m.group("obj"))),
        
    # Semantic field
    (re.compile(r"^(?P<subj>\w+)\s+is\s+related to\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "semantic_field", m.group("obj"))),
        
    # Collocations
    (re.compile(r"^(?P<subj>\w+)\s+collocates with\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "collocates_with", m.group("obj"))),
        
    # Word roots
    (re.compile(r"^(?P<subj>\w+)\s+has\s+the root\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "root", m.group("obj"))),
        
    # Irregular forms
    (re.compile(r"^past tense of (?P<subj>\w+)\s+is\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "past_tense", m.group("obj"))),
        
    # Language registers
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(?P<obj>formal|informal|slang|technical|colloquial)", re.I),
        lambda m: (m.group("subj"), "register", m.group("obj"))),
        
    # Compound word relationships
    (re.compile(r"^(?P<subj>\w+)\s+is\s+a compound of\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "compound_of", m.group("obj")))
]

# Combine all NLP patterns
_NLP_PATTERNS.extend(_EXTENDED_NLP_PATTERNS)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Integration with Core Pattern Systems
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
try:
    from singularity_patterns import _FACT_PATTERNS, add_pattern as _core_add_pattern
    _has_core_patterns = True
    _metrics["patterns_loaded"] = len(_FACT_PATTERNS)
except ImportError:
    _has_core_patterns = False
    _FACT_PATTERNS = []  # Use our own if core module not available
    logger.warning("Core pattern module not found, using NLP patterns only")

# Extend with our patterns
for pattern, handler in _NLP_PATTERNS:
    # Add to core patterns if available
    if _has_core_patterns:
        try:
            _core_add_pattern(pattern, handler, "NLP/Lexicon pattern")
        except Exception as e:
            logger.error(f"Failed to add pattern to core: {e}")
    
    # Add to our local list as well
    _FACT_PATTERNS.append((pattern, handler))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# User-defined and Dynamic Pattern Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_USER_PATTERNS = []  # User-defined patterns can be added at runtime

def add_pattern(regex_pattern: str, extractor_fn: Callable, description: str = "") -> bool:
    """
    Add a new NLP pattern to the extraction system.
    
    Args:
        regex_pattern: Regular expression pattern string
        extractor_fn: Function that takes a match object and returns (subj, pred, obj)
        description: Optional description of the pattern
        
    Returns:
        True if successfully added, False otherwise
    """
    with _pattern_lock:
        try:
            compiled_pattern = re.compile(regex_pattern, re.I)
            _USER_PATTERNS.append((compiled_pattern, extractor_fn))
            
            # Also add to core pattern system if available
            if _has_core_patterns:
                _core_add_pattern(regex_pattern, extractor_fn, description or "User NLP pattern")
                
            logger.info(f"Added new NLP pattern: {description or regex_pattern}")
            return True
        except Exception as e:
            logger.error(f"Failed to add pattern: {e}")
            _metrics["errors"] += 1
            return False

def get_all_patterns() -> List[Tuple[Pattern, Callable]]:
    """Get all available NLP patterns (built-in + user-defined)."""
    with _pattern_lock:
        return _NLP_PATTERNS + _USER_PATTERNS

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# NLP Fact Extraction Engine
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_nlp_facts(text: str, confidence_threshold: float = 0.6) -> List[Tuple[str, str, str, float]]:
    """
    Extract linguistic facts from text using specialized NLP patterns.
    
    Args:
        text: Input text to analyze
        confidence_threshold: Minimum confidence level for returned facts
        
    Returns:
        List of (subject, predicate, object, confidence) tuples
    """
    _metrics["total_extractions"] += 1
    facts = []
    
    # Split into sentences for better pattern matching
    sentences = [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]
    
    all_patterns = get_all_patterns()
    
    for sentence in sentences:
        for pattern, extractor in all_patterns:
            try:
                for match in pattern.finditer(sentence):
                    try:
                        # Extract the triple
                        subj, pred, obj = extractor(match)
                        
                        # Calculate confidence score based on pattern specificity
                        confidence = _calculate_confidence(subj, pred, obj, sentence, pattern)
                        
                        if confidence >= confidence_threshold:
                            facts.append((subj, pred, obj, confidence))
                            _metrics["successful_extractions"] += 1
                            
                            # Track language hits for translation patterns
                            if pred.startswith("translation_"):
                                lang = pred.split("_", 1)[1]
                                if lang not in _metrics["language_hits"]:
                                    _metrics["language_hits"][lang] = 0
                                _metrics["language_hits"][lang] += 1
                                
                    except Exception as e:
                        logger.debug(f"Extraction error: {e}")
            except Exception as e:
                logger.debug(f"Pattern matching error: {e}")
                _metrics["errors"] += 1
    
    return facts

def _calculate_confidence(subj: str, pred: str, obj: str, original_text: str, pattern: Pattern) -> float:
    """
    Calculate a confidence score for an extracted linguistic fact.
    
    Uses NLP-specific heuristics for scoring different types of linguistic patterns.
    """
    confidence = 0.7  # Base confidence
    
    # Higher confidence for very specific patterns
    if pred in ["pronunciation", "plural", "past_tense", "part_of_speech"]:
        confidence += 0.1
    
    # Translations are often more reliable when quoted
    if pred.startswith("translation_") and (obj.startswith('"') or obj.startswith("'") or obj.startswith("'")):
        confidence += 0.1
    
    # Adjust for subject length (single words are more reliable for linguistic facts)
    if len(subj.split()) == 1:
        confidence += 0.05
    elif len(subj.split()) > 3:
        confidence -= 0.1  # Multi-word subjects are less likely to be accurate linguistic facts
    
    # Adjust based on pattern specificity (more complex patterns are more reliable)
    pattern_complexity = len(pattern.pattern) / 100  # Normalize
    confidence += min(0.1, pattern_complexity * 0.5)  # Max 0.1 boost
    
    # Cap at 0.0-1.0 range
    return max(0.0, min(1.0, confidence))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Integration with Knowledge Database
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_and_store(text: str, source: str = "nlp_extraction") -> List[Tuple[str, str, str, float]]:
    """
    Extract linguistic facts from text and store them in the knowledge database.
    
    Args:
        text: Input text to analyze
        source: Source identifier for the extracted facts
        
    Returns:
        List of extracted and stored (subject, predicate, object, confidence) tuples
    """
    facts = extract_nlp_facts(text)
    stored_facts = []
    
    try:
        # Import knowledge module dynamically to avoid circular imports
        from singularity_knowledge import add_fact
        
        for subj, pred, obj, conf in facts:
            try:
                success = add_fact(subj, pred, obj, confidence=conf, source=source)
                if success:
                    stored_facts.append((subj, pred, obj, conf))
            except Exception as e:
                logger.error(f"Error storing fact: {e}")
                _metrics["errors"] += 1
    except ImportError:
        logger.warning("Knowledge module not available, facts not stored")
        _metrics["errors"] += 1
    
    return stored_facts

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# NLP Entity Utilities
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_language_families() -> Dict[str, List[str]]:
    """
    Retrieve known language family relationships from the knowledge database.
    
    Returns:
        Dictionary mapping families to lists of languages
    """
    families = {}
    
    try:
        # Import knowledge module dynamically to avoid circular imports
        from singularity_knowledge import search_facts
        
        results = search_facts("in_family")
        for fact in results:
            family = fact["object"]
            language = fact["subject"]
            
            if family not in families:
                families[family] = []
            families[family].append(language)
            
    except ImportError:
        logger.warning("Knowledge module not available")
        _metrics["errors"] += 1
    
    return families

def get_translations(word: str) -> Dict[str, str]:
    """
    Get all known translations of a word from the knowledge database.
    
    Args:
        word: The word to find translations for
        
    Returns:
        Dictionary of language -> translation
    """
    translations = {}
    
    try:
        from singularity_knowledge import get_facts_by_subject
        
        facts = get_facts_by_subject(word)
        for fact in facts:
            pred = fact["predicate"]
            if pred.startswith("translation_"):
                lang = pred[len("translation_"):]
                translations[lang] = fact["object"]
    except ImportError:
        logger.warning("Knowledge module not available")
        _metrics["errors"] += 1
    
    return translations

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_nlp_metrics() -> Dict[str, Union[int, float, Dict]]:
    """Get metrics about NLP pattern recognition operations."""
    with _pattern_lock:
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """Perform a health check on the NLP pattern recognition subsystem."""
    status = "healthy"
    details = {}
    
    # Check pattern counts
    total_patterns = len(_NLP_PATTERNS) + len(_USER_PATTERNS)
    _metrics["patterns_loaded"] = total_patterns
    details["total_patterns"] = total_patterns
    
    # Check extraction success rate
    if _metrics["total_extractions"] > 0:
        success_rate = _metrics["successful_extractions"] / _metrics["total_extractions"]
        details["extraction_success_rate"] = success_rate
        
        if success_rate < 0.3:  # Less than 30% success rate is concerning
            status = "warning" if status == "healthy" else status
            details["low_success_rate"] = f"Only {success_rate:.1%} of extractions succeed"
    
    # Check for errors
    if _metrics["errors"] > 0:
        status = "warning" if status == "healthy" else status
        details["error_count"] = _metrics["errors"]
    
    # Additional NLP-specific checks
    details["language_hits"] = _metrics["language_hits"]
    
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_NLP_PATTERNS": _NLP_PATTERNS,
        "_FACT_PATTERNS": _FACT_PATTERNS,
        "extract_nlp_facts": extract_nlp_facts,
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_nlp_patterns instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    '_NLP_PATTERNS',
    'extract_nlp_facts',
    'extract_and_store',
    'add_pattern',
    'get_all_patterns',
    'get_language_families',
    'get_translations',
    'get_nlp_metrics',
    'health_check'
]

# Register startup time
_metrics["init_time_ms"] = (time.time() - _startup_time) * 1000

# Module self-test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"=== NLP Pattern Recognition Module Self-Test ===")
    print(f"Total built-in patterns: {len(_NLP_PATTERNS)}")
    
    # Test with some example sentences
    test_sentences = [
        "Serendipity means a fortunate discovery by accident.",
        "Happy is synonymous with joyful.",
        "Cold is the opposite of hot.",
        "A robin is a kind of bird.",
        "Run is a verb.",
        "Plural of mouse is mice.",
        "'Hello' in French is 'bonjour'.",
        "Queue is pronounced /kjuː/.",
        "German belongs to the Germanic language family."
    ]
    
    print("\nExtracting facts from test sentences:")
    all_facts = []
    
    for sentence in test_sentences:
        print(f"\nFrom: '{sentence}'")
        facts = extract_nlp_facts(sentence)
        all_facts.extend(facts)
        
        for subj, pred, obj, conf in facts:
            print(f"  • {subj} {pred} {obj} (confidence: {conf:.2f})")
    
    print(f"\nSuccessfully extracted {len(all_facts)} facts from {len(test_sentences)} sentences")
    
    # Health check
    health = health_check()
    print(f"\nHealth status: {health['status']}")
    print(f"Metrics: {health['metrics']}")
