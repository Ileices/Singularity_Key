#!/usr/bin/env python3
"""
Singularity Vector Index Module
-------------------------------
Efficient in-database vector indexing for text similarity search.

Features:
- Term frequency-inverse document frequency (TF-IDF) vectorization
- Cosine similarity search for efficient document retrieval
- Thread-safe SQLite integration with the existing database
- Automatic index maintenance and optimization

This module provides a lightweight but powerful vector search capability
to complement the existing knowledge systems in the Singularity organism.
"""

import math as _m
import re
import pickle as _pkl
import threading as _threading
import time
import logging
import json
import hashlib
import os
import pathlib
from pathlib import Path
from typing import List, Dict, Tuple, Any, Set, Optional, Union, Callable
from collections import defaultdict as _dd
import sqlite3
import warnings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.vector_index")

# Module initialization time for performance metrics
_start_time = time.time()

# Module stats
_STATS = {
    "init_time_ms": 0,
    "documents_indexed": 0,
    "searches_performed": 0,
    "avg_search_time_ms": 0,
    "total_search_time_ms": 0,
    "cache_hits": 0,
    "cache_misses": 0,
    "errors": 0,
}

# Thread safety
_index_lock = _threading.RLock()
_stats_lock = _threading.RLock()

# Base paths
_BASE = Path(__file__).parent.resolve()
_ECO = _BASE / "ecosystem"
_ECO.mkdir(exist_ok=True)
_VECTOR_DIR = _ECO / "vector_index"
_VECTOR_DIR.mkdir(exist_ok=True)

# ──────────────────────────────────────────────────────────────────────────
# 1. Tiny in-DB vector index (TF-idf + cosine) for fast "what facts match X"
# ──────────────────────────────────────────────────────────────────────────
class VectorIndex:
    """
    Stores 512-d sparse vectors as pickled list[(token,tfidf)].
    
    Provides efficient text similarity search using TF-IDF vectorization
    and cosine similarity measures directly within an SQLite database.
    """
    # SQL to create the vector index table if it doesn't exist
    _CREATE = """CREATE TABLE IF NOT EXISTS vindex(
                   gid TEXT PRIMARY KEY, vec BLOB, doc TEXT)"""
    
    # SQL to create indexes for faster search
    _CREATE_INDEXES = """
        CREATE INDEX IF NOT EXISTS vindex_gid ON vindex(gid);
        """
    
    def __init__(self, dbcon):
        """
        Initialize a vector index with a database connection.
        
        Args:
            dbcon: SQLite database connection
        """
        self.cur = dbcon.cursor()
        self.cur.execute(self._CREATE)
        self.cur.execute(self._CREATE_INDEXES)
        
        # Inverse document frequency cache - lazy-loaded until finalize()
        self.idf = _dd(lambda: 1.0)
        
        # Search results cache
        self.cache = {}
        self.cache_size = 1000  # Maximum number of cached queries
        
        # Thread safety
        self.lock = _threading.RLock()
        
        # Stats
        self.doc_count = self._get_doc_count()
        
        with _stats_lock:
            _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
            
        logger.info(f"VectorIndex initialized with {self.doc_count} documents")

    # ------------- public API ------------------------------------------------
    def add_doc(self, gid: str, doc: str):
        """
        Add a document to the vector index.
        
        Args:
            gid: Global identifier for the document (unique)
            doc: Document text to index
        """
        try:
            with self.lock:
                # Generate vector for document
                vec = self._vectorize(doc)
                
                # Serialize vector
                blob = _pkl.dumps(vec, protocol=4)
                
                # Store in database
                with self.cur.connection:
                    self.cur.execute("INSERT OR REPLACE INTO vindex VALUES(?,?,?)",
                                  (gid, blob, doc))
                
                # Update document count
                self.doc_count += 1
                
                # Update stats
                with _stats_lock:
                    _STATS["documents_indexed"] += 1
                
                # Clear cache when adding new documents
                self._clear_cache()
                
                # Recalculate IDF if we've reached a document count threshold
                if self.doc_count % 100 == 0:
                    self._update_idf()
                    
                logger.debug(f"Added document with ID {gid}")
                
                return True
        except Exception as e:
            logger.error(f"Error adding document {gid}: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False

    def search(self, query: str, k: int = 5) -> List[Tuple[float, str, str]]:
        """
        Search for documents similar to the query.
        
        Args:
            query: Text to search for
            k: Number of results to return
            
        Returns:
            List of (similarity, gid, document) tuples sorted by similarity (highest first)
        """
        try:
            # Check if we have this query cached
            cache_key = f"{query}:{k}"
            
            with self.lock:
                if cache_key in self.cache:
                    with _stats_lock:
                        _STATS["cache_hits"] += 1
                    return self.cache[cache_key]
            
            with _stats_lock:
                _STATS["cache_misses"] += 1
                _STATS["searches_performed"] += 1
            
            start_time = time.time()
            
            # Generate query vector
            qv = self._vectorize(query)
            qn2 = sum(v*v for _, v in qv)
            
            # If no valid tokens were found, return empty list
            if not qn2:
                return []

            results = []
            # Execute search
            with self.lock:
                for gid, blob, doc in self.cur.execute("SELECT gid, vec, doc FROM vindex"):
                    try:
                        # Deserialize vector
                        dv = _pkl.loads(blob)
                        
                        # Calculate cosine similarity
                        dot = self._dot(qv, dv)
                        dn2 = sum(v*v for _, v in dv)
                        
                        if dot == 0 or dn2 == 0:
                            continue
                            
                        sim = dot / (_m.sqrt(qn2) * _m.sqrt(dn2))
                        results.append((sim, gid, doc))
                    except Exception as e:
                        logger.warning(f"Error processing document {gid}: {e}")
            
            # Sort by similarity (highest first) and take top k
            top_results = sorted(results, key=lambda x: x[0], reverse=True)[:k]
            
            # Update statistics
            search_time = time.time() - start_time
            with _stats_lock:
                _STATS["total_search_time_ms"] += int(search_time * 1000)
                _STATS["avg_search_time_ms"] = (_STATS["total_search_time_ms"] / 
                                              _STATS["searches_performed"])
            
            # Cache results
            with self.lock:
                self.cache[cache_key] = top_results
                self._prune_cache()
            
            return top_results
        
        except Exception as e:
            logger.error(f"Error searching for '{query}': {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return []

    def remove_doc(self, gid: str) -> bool:
        """
        Remove a document from the vector index.
        
        Args:
            gid: Document identifier to remove
            
        Returns:
            True if removed, False otherwise
        """
        try:
            with self.lock:
                with self.cur.connection:
                    self.cur.execute("DELETE FROM vindex WHERE gid = ?", (gid,))
                    if self.cur.rowcount > 0:
                        self.doc_count -= 1
                        self._clear_cache()
                        return True
            return False
        except Exception as e:
            logger.error(f"Error removing document {gid}: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False

    def optimize(self):
        """
        Optimize the vector index by updating IDF values and vacuum the database.
        """
        try:
            with self.lock:
                self._update_idf()
                with self.cur.connection:
                    self.cur.execute("VACUUM")
            logger.info("Vector index optimized")
            return True
        except Exception as e:
            logger.error(f"Error optimizing vector index: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False

    def count(self) -> int:
        """
        Return the number of documents in the index.
        
        Returns:
            Document count
        """
        return self.doc_count
        
    def clear(self):
        """
        Clear all documents from the vector index.
        """
        try:
            with self.lock:
                with self.cur.connection:
                    self.cur.execute("DELETE FROM vindex")
                self.doc_count = 0
                self.idf = _dd(lambda: 1.0)
                self._clear_cache()
            logger.info("Vector index cleared")
            return True
        except Exception as e:
            logger.error(f"Error clearing vector index: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False

    # ------------- helpers ---------------------------------------------------
    _TOK = re.compile(r"[A-Za-z0-9]+")

    def _vectorize(self, txt: str):
        """
        Convert text to a TF-IDF vector.
        
        Args:
            txt: Text to vectorize
            
        Returns:
            List of (token, weight) tuples
        """
        # Extract tokens from text
        tokens = [t.lower() for t in self._TOK.findall(txt)]
        if not tokens:
            return []
        
        # Calculate term frequency
        tf = _dd(int)
        for t in tokens:
            tf[t] += 1
        
        # Apply TF-IDF weighting
        vec = [(t, tf[t] * self.idf[t]) for t in tf]
        return vec

    @staticmethod
    def _dot(v1, v2):
        """
        Calculate dot product between two sparse vectors.
        
        Args:
            v1: First vector as list of (token, weight) tuples
            v2: Second vector as list of (token, weight) tuples
            
        Returns:
            Dot product value
        """
        d2 = dict(v2)
        return sum(val * d2.get(tok, 0) for tok, val in v1)
        
    def _update_idf(self):
        """
        Update inverse document frequency values from the indexed documents.
        """
        # Count documents containing each token
        doc_freq = _dd(int)
        total_docs = 0
        
        for _, blob, _ in self.cur.execute("SELECT gid, vec, doc FROM vindex"):
            total_docs += 1
            vec = _pkl.loads(blob)
            for token, _ in vec:
                doc_freq[token] += 1
        
        # Calculate IDF
        if total_docs > 0:
            self.idf = _dd(lambda: 1.0)
            for token, freq in doc_freq.items():
                self.idf[token] = _m.log(total_docs / freq + 1)
                
        logger.debug(f"Updated IDF values for {len(doc_freq)} tokens")
        
    def _clear_cache(self):
        """Clear the search results cache."""
        with self.lock:
            self.cache = {}
            
    def _prune_cache(self):
        """Prune the cache if it exceeds the maximum size."""
        if len(self.cache) > self.cache_size:
            # Remove oldest entries (approximation by using dictionary order)
            keys_to_remove = list(self.cache.keys())[:-self.cache_size]
            for key in keys_to_remove:
                del self.cache[key]
                
    def _get_doc_count(self) -> int:
        """Get the number of documents in the index."""
        try:
            count = self.cur.execute("SELECT COUNT(*) FROM vindex").fetchone()[0]
            return count
        except Exception:
            return 0

# Global instance placeholder - will be initialized during setup
vector_index = None

# ──────────────────────────────────────────────────────────────────────────
# 2. Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(db_connection=None, config=None):
    """
    Initialize the vector index system.
    
    Args:
        db_connection: SQLite connection to use
        config: Configuration dictionary
        
    Returns:
        Initialized VectorIndex instance
    """
    global vector_index
    
    logger.info("Initializing vector index system")
    
    # If no connection provided, create our own
    if not db_connection:
        index_db_path = _VECTOR_DIR / "vector_index.db"
        db_connection = sqlite3.connect(str(index_db_path), check_same_thread=False)
    
    # Initialize vector index
    vector_index = VectorIndex(db_connection)
    
    # Update initialization timing metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"Vector index system initialized in {_STATS['init_time_ms']} ms with {vector_index.count()} documents")
    
    return vector_index

def health_check() -> dict:
    """
    Perform a health check on the vector index system.
    
    Returns:
        Dictionary with health status information
    """
    global vector_index
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not vector_index:
        status = "error"
        warnings.append("Vector index not initialized")
    else:
        try:
            # Get document count
            doc_count = vector_index.count()
            details["document_count"] = doc_count
            
            # Check if index is empty
            if doc_count == 0:
                warnings.append("Vector index is empty")
                if status != "error":
                    status = "warning"
        except Exception as e:
            status = "error"
            warnings.append(f"Vector index error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "vector_index",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the vector index system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def optimize_index():
    """
    Optimize the vector index.
    
    Returns:
        True if successful, False otherwise
    """
    if not vector_index:
        logger.error("Vector index not initialized")
        return False
    
    return vector_index.optimize()

def shutdown():
    """
    Perform clean shutdown of vector index resources.
    """
    global vector_index
    
    if vector_index:
        logger.info("Shutting down vector index system")
        vector_index.optimize()

# Automatic cleanup
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# 3. Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_index_status():
    """Command handler for /index-status"""
    if not vector_index:
        print("Vector index system not initialized")
        return
    
    health = health_check()
    
    print("\nVector Index System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    if "document_count" in health.get("details", {}):
        print(f"\nDocuments indexed: {health['details']['document_count']}")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

def _cmd_vector_search():
    """Command handler for /index-search"""
    if not vector_index:
        print("Vector index system not initialized")
        return
    
    query = input("Search query> ")
    if not query.strip():
        print("Please enter a search query")
        return
    
    k = input("Number of results (default: 5)> ")
    try:
        k = int(k) if k.strip() else 5
    except ValueError:
        k = 5
        print("Invalid number, using default: 5")
    
    results = vector_index.search(query, k)
    
    print(f"\nFound {len(results)} results:")
    for i, (similarity, gid, doc) in enumerate(results, 1):
        print(f"\n{i}. Similarity: {similarity:.4f}")
        print(f"   ID: {gid}")
        print(f"   Text: {doc[:100]}..." if len(doc) > 100 else f"   Text: {doc}")

# ──────────────────────────────────────────────────────────────────────────
# 4. Compatibility layer for β_VectorIndex
# ──────────────────────────────────────────────────────────────────────────
class β_VectorIndex:
    """
    Legacy compatibility wrapper for the new VectorIndex.
    
    This class provides the same API as the original β_VectorIndex
    but uses the new implementation internally.
    """
    def __init__(self, dbcon):
        """
        Initialize with a database connection.
        
        Args:
            dbcon: SQLite database connection
        """
        warnings.warn(
            "β_VectorIndex is deprecated and will be removed in a future version. "
            "Use VectorIndex instead.",
            DeprecationWarning,
            stacklevel=2
        )
        self._index = VectorIndex(dbcon)
        self.idf = self._index.idf
        self.cur = self._index.cur

    def add_doc(self, gid: str, doc: str):
        """Add a document to the index."""
        return self._index.add_doc(gid, doc)

    def search(self, query: str, k: int = 5):
        """
        Search for similar documents.
        
        Returns just the gids for backward compatibility.
        """
        results = self._index.search(query, k)
        return [gid for _, gid, _ in results]

    # Include the original helper methods for full compatibility
    _TOK = re.compile(r"[A-Za-z0-9]+")

    def _vectorise(self, txt: str):
        """Original vectorize method for backward compatibility."""
        return self._index._vectorize(txt)

    @staticmethod
    def _dot(v1, v2):
        """Original dot product method for backward compatibility."""
        return VectorIndex._dot(v1, v2)

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'optimize_index',
    'shutdown',
    'VectorIndex',
    'β_VectorIndex',
    '_cmd_index_status',
    '_cmd_vector_search'
]
