Here is my codebase. please ensure everything works. if its programmed then it needs to function in the code base correctly. please make sure to correct any critical edges or integration/import issues any tracebacks and attribute errors. you need to read a new part of the codebase for enhancement and validation of every line of code traced back through scripts all the way to the main loop.

C:\Users\lokee\Documents\singularity_key\_llm_ddp_worker.py
C:\Users\lokee\Documents\singularity_key\build_instructions.md
C:\Users\lokee\Documents\singularity_key\install_deps.py
C:\Users\lokee\Documents\singularity_key\neural_engine.py
C:\Users\lokee\Documents\singularity_key\organism_autodata.py
C:\Users\lokee\Documents\singularity_key\organism_autonomous.py
C:\Users\lokee\Documents\singularity_key\organism_cluster.py
C:\Users\lokee\Documents\singularity_key\organism_gui.py
C:\Users\lokee\Documents\singularity_key\organism_inference.py
C:\Users\lokee\Documents\singularity_key\organism_neuro.py
C:\Users\lokee\Documents\singularity_key\organism_reflex.py
C:\Users\lokee\Documents\singularity_key\prompt.md
C:\Users\lokee\Documents\singularity_key\requirements_autodata.txt
C:\Users\lokee\Documents\singularity_key\requirements_crawl.txt
C:\Users\lokee\Documents\singularity_key\requirements_neural.txt
C:\Users\lokee\Documents\singularity_key\requirements.txt
C:\Users\lokee\Documents\singularity_key\run.py
C:\Users\lokee\Documents\singularity_key\singularity_boot.py
C:\Users\lokee\Documents\singularity_key\singularity_config.yml
C:\Users\lokee\Documents\singularity_key\singularity_utils.py
C:\Users\lokee\Documents\singularity_key\transformer_training.py




Add all of these features below in full and use it as a base to build on.. use this code to begin building state of the art completion of the features below to be injected into the codebase. Make sure these features are in my codebase and if not you are responsible for implementing the full production ready code enhancements to the codebase.

You must also check that if these features are present then identify if it exists in multiple places in the code base and make sure that they do not conflict but that they work together in function without chopping down the function of any existing feature. 

Does the codebase handle ai inference workloads? do we successfully utilize our RBY and Good Bad Ambivalent and weights tracking data to handle ALL inference tasks? are we missing any inference task programming? are all mechanics in the code base connected to inference? is all our real time frameworks and singularities working cohesively on inference tasks?




Github Copilot Editing Instructions as THE FULL PROGRAMMER TO FULL PROJECT ENTERPRISE LEVEL COMPLETION:

Github Copilot is the full AI programmer and no human will be enhancing any "scaffolds" "placeholders" "simplified" "simulated" or "fake" code. You will have access to the entire development entry code located in "C:\Users\lokee\Documents\singularity_key\build_instructions.md" and Github Copilot is responsible for correctly adding the code into the project codebase imported correctly.

within the "C:\Users\lokee\Documents\singularity_key\build_instructions.md" file you can work on one set at a time. a set looks like this

""" 
                _____________
         _______|________    \
You said:|[user_content]|     \_____           __________
         |______________|           \_____     |        |
                                     _____|--->| [SET]  |
             _______________   _____/          |________|
ChatGPT said:|[AI_response]|  /
             |__|__________|_/
"""


what Github Copilot must do every time the user sends this message is:
1. Read 1 set from "C:\Users\lokee\Documents\singularity_key\build_instructions.md"
2. Overview and name the step in a newly created file called dev_path_#.yaml and place it here "C:\Users\lokee\Documents\singularity_key\dev_path" and the file must contain all the details of what github copilot edited on that step. All integrations and imports must be documented and all tracebacks and attributes and all debugging and edge cases covered in every output.
3. Every time Github Copilot sees this message they must access the "C:\Users\lokee\Documents\singularity_key\dev_path" and understand what they have done and create the next "C:\Users\lokee\Documents\singularity_key\dev_path\dev_path_#.yaml" and they must be versioned correctly ascending to audit all of Github Copilot's actions.
4. Github Copilot must read "C:\Users\lokee\Documents\singularity_key\build_instructions.md" which contains a conversation with tags to help create blocks of tracking and use..  a "set" as described above is to be used starting from top to bottom of the file and tracked in the "C:\Users\lokee\Documents\singularity_key\dev_path\dev_path_#.yaml" version.
5. Github Copilot is to ONLY work with ONE SET per output from "C:\Users\lokee\Documents\singularity_key\build_instructions.md" and move on to the next SET in the following output. 
6. Github Copilot is not to edit "C:\Users\lokee\Documents\singularity_key\build_instructions.md"
7. Github Copilot is to edit "C:\Users\lokee\Documents\singularity_key\dev_path\dev_path_#.yaml" every output and each output must contain its own "C:\Users\lokee\Documents\singularity_key\dev_path\dev_path_#.yaml" file so that previous "C:\Users\lokee\Documents\singularity_key\dev_path\dev_path_#.yaml" fies are never edited in future outputs by Github Copilot. 
8. Github Copilot Must update "C:\Users\lokee\Documents\singularity_key\requirements.txt" every output to match the codebase requirements and incrementally use its data to create an "C:\Users\lokee\Documents\singularity_key\runtime_auto_setup_checks_validation_install_checks_install_missing_dependencies_cuda_gpu_cpu_section\runtime_auto_setup_checks_validation_install_checks_install_missing_dependencies_cuda_gpu_cpu_section_#.py" that must be used during runtime if dependencies and install pre reqs are not already met. 
9. These instructions can be found and accessed but are not to be edited by Github Copilot from this file "C:\Users\lokee\Documents\singularity_key\prompt.md"


