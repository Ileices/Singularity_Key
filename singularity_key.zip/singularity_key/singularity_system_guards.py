#!/usr/bin/env python3
"""
Singularity System Guards Module
-------------------------------
Provides system monitoring, peer discovery, and resource protection functions.

Features:
- Thread-safe peer broadcasting and discovery
- Disk usage monitoring with auto-compression trigger
- Cross-platform resource monitoring
- Configurable thresholds and timing
- Health check endpoint for monitoring
- Safe shutdown procedures

This module implements the peer broadcasting system and disk space monitoring
that protect the Singularity organism from resource exhaustion and enable
peer-to-peer communication within a network.
"""
import socket
import threading
import time
import json as _json
import shutil
import os
import logging
import hashlib as _h
from pathlib import Path
from typing import Dict, List, Optional, Union, Any, Set

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.system_guards")

# Thread safety
_guards_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "broadcasts_sent": 0,
    "peers_discovered": 0,
    "disk_checks": 0,
    "compression_events": 0,
    "errors": 0,
    "last_free_percent": 0.0,
}

# Discovered peers
_PEERS: Set[str] = set()
_peer_timestamps: Dict[str, float] = {}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Dependencies
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False

# These will be set during initialization
_config = None           # CFG from singularity_config
_glyph_id_func = None    # glyph_id from singularity_glyphs
_log_excretion_func = None  # log_excretion from singularity_memory
_dna = None              # DNA from singularity_memory
_eco_dir = None          # ECO from singularity_storage

# Thread references for management
_peer_thread = None
_disk_thread = None

def initialize(config=None, glyph_id_function=None, log_excretion_function=None, 
               dna=None, eco_dir=None):
    """
    Initialize the system guards module with required functions and references.
    
    Args:
        config: System configuration dictionary
        glyph_id_function: Function to generate glyph IDs
        log_excretion_function: Function to log excretions
        dna: Reference to DNA deque
        eco_dir: Path to ecosystem directory
    """
    global _config, _glyph_id_func, _log_excretion_func, _dna, _eco_dir, _initialized
    global _peer_thread, _disk_thread
    
    with _guards_lock:
        # Store dependencies
        _config = config
        _glyph_id_func = glyph_id_function
        _log_excretion_func = log_excretion_function
        _dna = dna
        _eco_dir = Path(eco_dir) if eco_dir is not None else None
        
        if not _config:
            logger.error("System guards initialization failed: No configuration provided")
            return False
        
        # Check required dependencies
        if not _glyph_id_func:
            logger.warning("System guards: glyph_id function not provided, using local fallback")
        if not _log_excretion_func:
            logger.warning("System guards: log_excretion function not provided, using local fallback")
        if not _dna:
            logger.warning("System guards: DNA reference not provided, compression will be limited")
        if not _eco_dir:
            logger.warning("System guards: ECO directory not provided, using current directory")
            _eco_dir = Path(".")
        
        # Start the guard threads if they're not already running
        if _config.get("max_outbound_kbit", 0) > 0 and _peer_thread is None:
            _peer_thread = threading.Thread(target=_peer_loop, daemon=True)
            _peer_thread.start()
            logger.info("Peer broadcast loop started")
        
        _disk_thread = threading.Thread(target=_disk_guard, daemon=True)
        _disk_thread.start()
        logger.info("Disk guard loop started")
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info("System guards module initialized successfully")
        return True

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Peer Broadcasting and Discovery
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _local_glyph_id(data):
    """Fallback glyph_id function if the real one is not provided."""
    if isinstance(data, str):
        data = data.encode()
    return f"⟐{_h.sha256(data).hexdigest()[:16]}"

def _local_log_excretion(msg: str):
    """Fallback log_excretion function if the real one is not provided."""
    logger.info(f"EXCRETION: {msg}")

def _get_glyph_id(data):
    """Use the provided glyph_id function or fall back to local implementation."""
    if _glyph_id_func is not None:
        return _glyph_id_func(data)
    return _local_glyph_id(data)

def _log_excretion(msg: str):
    """Use the provided log_excretion function or fall back to local implementation."""
    if _log_excretion_func is not None:
        return _log_excretion_func(msg)
    return _local_log_excretion(msg)

def _peer_loop():
    """
    Continuously broadcast presence to peers and listen for their broadcasts.
    Uses UDP broadcast on the configured port for simple peer discovery.
    """
    if not _initialized:
        logger.error("System guards not initialized, peer loop aborted")
        return
    
    if _config.get("max_outbound_kbit", 0) <= 0:
        logger.info("Peer broadcasting disabled (max_outbound_kbit ≤ 0)")
        return
    
    port = _config.get("primary_port", 31415)
    period = _config.get("peer_broadcast_period_s", 60)
    
    try:
        # Set up broadcast socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        
        # Try to bind for receiving too
        try:
            sock.bind(("", port))
            can_receive = True
        except Exception as e:
            logger.warning(f"Could not bind to receive broadcasts: {e}")
            can_receive = False
        
        # Set up non-blocking mode if we can receive
        if can_receive:
            sock.settimeout(0.1)
        
        while True:
            try:
                # Send our broadcast
                timestamp = time.time()
                packet = _json.dumps({
                    "t": timestamp,
                    "gid": _get_glyph_id(str(timestamp).encode())
                }).encode()
                
                sock.sendto(packet, ("255.255.255.255", port))
                
                with _guards_lock:
                    _metrics["broadcasts_sent"] += 1
                
                # Listen for other peers if we can
                if can_receive:
                    listen_until = time.time() + period
                    while time.time() < listen_until:
                        try:
                            data, addr = sock.recvfrom(1024)
                            peer_addr = addr[0]
                            
                            # Skip our own broadcasts
                            if peer_addr == socket.gethostbyname(socket.gethostname()):
                                continue
                                
                            try:
                                peer_data = _json.loads(data.decode())
                                # Store the peer with its timestamp
                                with _guards_lock:
                                    if peer_addr not in _PEERS:
                                        _PEERS.add(peer_addr)
                                        _metrics["peers_discovered"] += 1
                                    _peer_timestamps[peer_addr] = time.time()
                            except Exception:
                                pass
                        except (socket.timeout, BlockingIOError):
                            pass
                else:
                    # Just sleep if we can't receive
                    time.sleep(period)
            
            except Exception as e:
                logger.error(f"Error in peer broadcasting: {e}")
                with _guards_lock:
                    _metrics["errors"] += 1
                time.sleep(period)
                
    except Exception as e:
        logger.error(f"Critical error in peer loop: {e}")
        with _guards_lock:
            _metrics["errors"] += 1

def get_peers(max_age: float = 300.0) -> List[str]:
    """
    Get list of discovered peers, filtering out stale ones.
    
    Args:
        max_age: Maximum age in seconds to consider a peer as active
        
    Returns:
        List of active peer IP addresses
    """
    with _guards_lock:
        now = time.time()
        active_peers = [
            peer for peer in _PEERS 
            if peer in _peer_timestamps and now - _peer_timestamps[peer] <= max_age
        ]
        return active_peers

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Disk Space Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _disk_guard():
    """
    Monitor disk space and trigger compression when free space falls below threshold.
    Runs continuously in a background thread checking every 5 minutes by default.
    """
    if not _initialized:
        logger.error("System guards not initialized, disk guard aborted")
        return
    
    check_interval = _config.get("disk_check_interval_s", 300)  # Default: 5 minutes
    threshold_percent = _config.get("disk_collapse_free_percent", 5)
    
    while True:
        try:
            # Cross-platform disk space check using shutil
            if _eco_dir:
                total, used, free = shutil.disk_usage(str(_eco_dir))
                free_percent = 100 * free / total
                
                with _guards_lock:
                    _metrics["disk_checks"] += 1
                    _metrics["last_free_percent"] = free_percent
                    
                # Check if we're below threshold
                if free_percent < threshold_percent:
                    logger.warning(f"Disk space low: {free_percent:.1f}% free (threshold: {threshold_percent}%)")
                    _compress_dna()
            
        except Exception as e:
            logger.error(f"Error in disk monitoring: {e}")
            with _guards_lock:
                _metrics["errors"] += 1
                
        time.sleep(check_interval)

def _compress_dna():
    """
    Compress DNA to free up memory when disk space is low.
    Creates a glyph from the DNA hash and clears the DNA deque.
    """
    if not _dna:
        logger.warning("DNA reference not provided, can't compress")
        return
    
    try:
        _log_excretion("COMPRESSION-BEGIN")
        
        # Create a digest of the DNA
        digest = _h.sha256(_json.dumps(list(_dna)).encode()).hexdigest()
        glyph = _get_glyph_id(digest.encode())
        
        _log_excretion(f"DNA-COMPRESS {glyph}")
        
        # Clear the DNA
        _dna.clear()
        
        with _guards_lock:
            _metrics["compression_events"] += 1
            
        logger.info(f"DNA compressed successfully with glyph {glyph}")
        return glyph
        
    except Exception as e:
        logger.error(f"Error compressing DNA: {e}")
        with _guards_lock:
            _metrics["errors"] += 1
        return None

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Monitoring and Health Check
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics():
    """
    Get system guards performance metrics.
    
    Returns:
        Dictionary of metrics
    """
    with _guards_lock:
        return _metrics.copy()

def health_check():
    """
    Perform health check for system guards.
    
    Returns:
        Dictionary with health status and metrics
    """
    if not _initialized:
        return {
            "status": "error",
            "message": "System guards module not initialized",
            "metrics": {},
            "timestamp": time.time()
        }
    
    metrics = get_metrics()
    
    # Get current disk stats 
    disk_status = {}
    try:
        if _eco_dir:
            total, used, free = shutil.disk_usage(str(_eco_dir))
            disk_status = {
                "total_bytes": total,
                "used_bytes": used,
                "free_bytes": free,
                "free_percent": 100 * free / total,
            }
    except Exception as e:
        logger.error(f"Error getting disk status: {e}")
        disk_status = {"error": str(e)}
    
    # Get peer info
    peer_info = {
        "active_peers": get_peers(),
        "peer_broadcast_enabled": _config.get("max_outbound_kbit", 0) > 0,
        "broadcast_port": _config.get("primary_port", 31415),
    }
    
    # Determine overall status
    if metrics["errors"] > 0:
        status = "warning"
        message = f"Encountered {metrics['errors']} errors in system monitoring"
    elif disk_status.get("free_percent", 100) < _config.get("disk_collapse_free_percent", 5):
        status = "warning" 
        message = f"Disk space below threshold: {disk_status.get('free_percent', 0):.1f}%"
    else:
        status = "healthy"
        message = "System guards operating normally"
    
    return {
        "status": status,
        "message": message,
        "metrics": metrics,
        "disk_status": disk_status,
        "peer_info": peer_info,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Manual Control Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def force_compression():
    """
    Manually trigger DNA compression.
    
    Returns:
        Glyph ID of the compressed DNA, or None if compression failed
    """
    return _compress_dna()

def check_disk_space():
    """
    Check current disk space status.
    
    Returns:
        Dictionary with disk usage information
    """
    if not _eco_dir:
        return {"error": "ECO directory not specified"}
    
    try:
        total, used, free = shutil.disk_usage(str(_eco_dir))
        return {
            "total_bytes": total,
            "used_bytes": used,
            "free_bytes": free,
            "free_percent": 100 * free / total,
            "threshold_percent": _config.get("disk_collapse_free_percent", 5),
            "check_interval_s": _config.get("disk_check_interval_s", 300),
        }
    except Exception as e:
        logger.error(f"Error checking disk space: {e}")
        return {"error": str(e)}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Memory Management and Cleanup
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """
    Clean up resources used by the system guards module.
    Should be called during application shutdown.
    """
    logger.info("System guards module cleanup requested")
    # Nothing specific to clean up as threads are daemon threads

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'get_peers',
    'force_compression',
    'check_disk_space',
    'get_metrics',
    'health_check',
    'cleanup'
]

# Module self-test
if __name__ == "__main__":
    from collections import deque
    import tempfile
    
    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as tmp_dir:
        # Create mock dependencies
        mock_config = {
            "max_outbound_kbit": 10,  # Enable broadcasting but limit bandwidth
            "primary_port": 44444,    # Use a non-standard port for testing
            "peer_broadcast_period_s": 5,
            "disk_collapse_free_percent": 10
        }
        
        mock_dna = deque(maxlen=100)
        mock_dna.extend(range(50))  # Add some test data
        
        # Simple test data for glyph generation
        def mock_glyph_id(data):
            return f"⟐test_{len(data)}"
            
        # Track excretion logs
        excretion_logs = []
        def mock_log_excretion(msg):
            print(f"EXCRETION: {msg}")
            excretion_logs.append(msg)
        
        # Initialize the module
        initialize(
            config=mock_config,
            glyph_id_function=mock_glyph_id,
            log_excretion_function=mock_log_excretion,
            dna=mock_dna,
            eco_dir=tmp_dir
        )
        
        # Test peer loop (just a couple of iterations)
        print("\nSending peer broadcasts...")
        time.sleep(3)
        
        # Test disk space monitoring
        print("\nChecking disk space:")
        disk_status = check_disk_space()
        for k, v in disk_status.items():
            print(f"  {k}: {v}")
        
        # Test compression
        print("\nTesting DNA compression:")
        before_len = len(mock_dna)
        glyph = force_compression()
        after_len = len(mock_dna)
        print(f"  DNA length before: {before_len}")
        print(f"  DNA length after: {after_len}")
        print(f"  Compression glyph: {glyph}")
        
        # Test metrics and health
        print("\nSystem guard metrics:")
        metrics = get_metrics()
        for k, v in metrics.items():
            print(f"  {k}: {v}")
            
        health = health_check()
        print(f"\nHealth status: {health['status']}")
        print(f"Message: {health['message']}")
        
        print("\nSystem guards module self-test completed")
