#!/usr/bin/env python3
# ---------------------------------------------------------------------------
# Singularity Seed – Phase-1 organism  (deterministic, no-entropy)
# Roswan L. Miller        – block-paste / lecture-aware edition
# ---------------------------------------------------------------------------
import csv, datetime as _dt, functools as _ft, hashlib as _h, json as _json
import logging as _log, math as _m, os, pathlib, re, shutil, socket
import sqlite3, sys, threading, time, yaml
from   collections import deque
from   decimal      import Decimal, getcontext
from   typing       import Optional, Tuple

# Import from the configuration module
from singularity_config import (
    CFG, BASE, load_config, save_config, health_check as config_health_check, get_metrics
)

# Import from the precision module
from singularity_precision import (
    _FNUM, R0, B0, Y0, PHI, get_token_weights, update_token_weight
)

# Import from the lexical module with the expanded functionality
from singularity_lexical import (
    STATIC_TOKEN_W, _WORD_CLASS, classify_token, 
    get_token_weight as lexical_get_token_weight,
    update_token_weight as lexical_update_token_weight,
    tune_unknown_word, health_check as lexical_health_check,
    initialize as init_lexical
)

# Import from the glyphs module
from singularity_glyphs import (
    _GLY_RE, valid_glyph, glyph_id,
    store_glyph, retrieve_glyph, get_glyph_metadata
)

# Import from the storage module
from singularity_storage import (
    ECO, LECTUREDIR, PTDB, EXC, ASSETS, PROC_ASSETS,
    check_storage_health, verify_critical_paths
)

# Import from the periodic table module
from singularity_periodic import (
    add_axiom, get_axiom, get_all_axioms, 
    add_term, search_axioms
)

# Import from the lecture module
from singularity_lecture import (
    _γ_consume_block, process_lecture_text,
    is_lecture_start, is_lecture_end,
    _LECTURE_ON, _LECTURE_OFF
)

# Import from the knowledge module
from singularity_knowledge import (
    KNOWDB, learn_fact, add_fact, search_facts,
    learn_facts_from_text, get_facts_by_subject, 
    get_related_entities, health_check as knowledge_health_check
)

# Import from the patterns module
from singularity_patterns import (
    extract_facts, extract_and_store, add_pattern,
    health_check as patterns_health_check
)

# Import from the science patterns module
from singularity_science_patterns import (
    extract_scientific_facts, extract_latex_definitions,
    health_check as science_patterns_health_check
)

# Import from the NLP patterns module
from singularity_nlp_patterns import (
    extract_nlp_facts, get_language_families, get_translations,
    health_check as nlp_patterns_health_check
)

# Import from the fact extractors module
from singularity_fact_extractors import (
    initialize as init_fact_extractors,
    persist_fact, learn_fact, learn_fact_tuple, answer, enhanced_answer,
    health_check as fact_extractors_health_check
)

from organism_neuro import neuro_ingest, query as neuro_query
from organism_reflex import ReflexSupervisor
from organism_autonomous import _auto_ingest_seed_assets, _ProjectForge, _compress_bloat, _cmd_program
from organism_cluster import llm_generate, remote_call, best_peer
from transformer_training import train_transformer, launch_ddp_if_needed
from neural_engine import push_into_corpus, train_once, launch_distributed
from organism_inference import infer, infer_with_metadata, get_inference_stats, cmd_infer_stats, cmd_infer_custom

# Import the inference integration module
try:
    from inference_integration import integrated_infer, integrated_infer_with_metadata
    _inference_integration_available = True
except ImportError:
    _inference_integration_available = False

# Import from the token classification module
from singularity_token_classify import (
    classify, classify_morphological, classify_with_confidence,
    health_check as token_classify_health_check,
    initialize as init_token_classify
)

# Import from the token weight module
from singularity_tokenweights import (
    rby, rby_with_context, health_check as tokenweights_health_check,
    initialize as init_tokenweights
)

# Import from the vector index module
from singularity_vector_index import (
    initialize as init_vector_index,
    health_check as vector_index_health_check,
    _cmd_index_status, _cmd_vector_search, 
    vector_index, β_VectorIndex
)

# Import from the NLG module
from singularity_nlg import (
    initialize as init_nlg,
    health_check as nlg_health_check,
    _cmd_nlg_status, _cmd_add_template, _cmd_test_nlg, 
    nlg_engine, β_nlg, NLG
)

# Import from the Knowledge API module
from singularity_knowledge_api import (
    initialize as init_knowledge_api,
    health_check as knowledge_api_health_check,
    _cmd_kapi_status, _cmd_kapi_search, _cmd_kapi_add_fact, _cmd_kapi_list_recent,
    knowledge_api, β_kn, β_kv
)

# Import from the fact learning module
from singularity_fact_learning import (
    initialize as init_fact_learning,
    health_check as fact_learning_health_check,
    _learn_fact, _cmd_fact_learning_status, _cmd_add_fact,
    fact_learning_system
)

# Import from the interactive commands module
from singularity_interactive_commands import (
    initialize as init_interactive_commands,
    health_check as interactive_commands_health_check,
    _cmd_ask, _cmd_why, _cmd_recall, _cmd_interactive_commands_status
)

# Define META dictionary to store commands
META = {}

# Import from the energy module
from singularity_energy import (
    initialize as init_energy, delta_E, get_energy_parameters,
    reset_energy_cycle, health_check as energy_health_check
)

# Import from the memory module
from singularity_memory import (
    initialize as init_memory, log_excretion, ENERGY, DNA, _HIST,
    health_check as memory_health_check, get_metrics as get_memory_metrics,
    save_memory_state, load_memory_state
)

# Import from the RBY helpers module
from singularity_rby_helpers import (
    initialize as init_rby_helpers, perception, cognition, execution, trifecta,
    health_check as rby_helpers_health_check
)

# Import from the learning integration module
from singularity_learning_integration import (
    initialize as init_learning_integration,
    health_check as learning_integration_health_check,
    _γ_consume_block, _cmd_learning_integration_status, _cmd_learning_optimization
)

# Import from the Asset Watcher module
from singularity_asset_watcher import (
    initialize as init_asset_watcher,
    health_check as asset_watcher_health_check,
    _γ_asset_watch, _cmd_asset_watcher_status, _cmd_asset_rescan
)


# ── auto-data ingestion (drive watcher & GUI picker)
import organism_autodata      # side-effect: starts threads immediately

# ── high-throughput inference service
import organism_infer_engine       # spawns GPU worker + RPC


# Import from the system guards module
from singularity_system_guards import (
    initialize as init_system_guards, get_peers, force_compression, check_disk_space,
    health_check as system_guards_health_check
)

# Import from cluster plus module
from singularity_cluster_plus import ClusterPlus

# Import from Beta Knowledge module
from singularity_beta_knowledge import (
    initialize as init_beta_knowledge,
    health_check as beta_knowledge_health_check,
    _cmd_ask, _cmd_why, _cmd_recall, _cmd_beta_status
)

# Import from the CLI handler module
from singularity_cli_handler import (
    initialize as init_cli_handler,
    health_check as cli_handler_health_check,
    _γ_process_cli, _cmd_cli_handler_status
)

# ... after initializing other modules ...

# Initialize system guards module
init_system_guards(
    config=CFG,
    glyph_id_function=glyph_id,
    log_excretion_function=log_excretion,
    dna=DNA,
    eco_dir=ECO
)

# Initialize ClusterPlus after other modules
try:
    ClusterPlus.start(auto_accept=True)
    logger.info("ClusterPlus initialized successfully")
except Exception as e:
    logger.warning(f"ClusterPlus initialization failed: {e}")

# Initialize Beta Knowledge module
try:
    # If SentenceTransformer is available, use it for vector search
    from sentence_transformers import SentenceTransformer
    embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
    
    # Initialize with embedding model and KnowDB connection
    beta_knowledge = init_beta_knowledge(
        db_connection=KNOWDB,
        embedding_model=embedding_model,
        config=CFG
    )
    logger.info("Beta Knowledge module initialized with vector search capability")
except ImportError:
    # Fall back to basic mode without vector search
    beta_knowledge = init_beta_knowledge(
        db_connection=KNOWDB,
        config=CFG
    )
    logger.warning("SentenceTransformer not available, Beta Knowledge initialized without vector search")

# Initialize vector index module
try:
    beta_vector_index = init_vector_index(db_connection=KNOWDB, config=CFG)
    logger.info("Vector index module initialized with the knowledge database")
except Exception as e:
    logger.warning(f"Vector index initialization failed: {e}")

# Initialize NLG module
try:
    nlg = init_nlg(config=CFG)
    logger.info("NLG module initialized successfully")
except Exception as e:
    logger.warning(f"NLG module initialization failed: {e}")

# Initialize Knowledge API module
try:
    knowledge_api = init_knowledge_api(db_connection=KNOWDB, config=CFG)
    logger.info("Knowledge API module initialized with the knowledge database")
except Exception as e:
    logger.warning(f"Knowledge API initialization failed: {e}")

# Initialize fact learning module
try:
    # Get required components for initialization
    required_components = {
        "glyph_id_function": glyph_id,
        "trifecta_function": trifecta,
        "db_connection": PTDB,
        "knowledge_api": knowledge_api if 'knowledge_api' in globals() else None,
        "vector_index": vector_index if 'vector_index' in globals() else None,
        "fact_patterns": _FACT_PATTERNS if '_FACT_PATTERNS' in globals() else []
    }
    
    # Initialize fact learning system
    fact_learning = init_fact_learning(**required_components)
    logger.info("Fact learning module initialized successfully")
except Exception as e:
    logger.warning(f"Fact learning module initialization failed: {e}")

# Initialize interactive commands module
try:
    # Get required components for initialization
    required_components = {
        "neuro_query_func": neuro_query if 'neuro_query' in globals() else None,
        "vector_index": vector_index if 'vector_index' in globals() else None,
        "kv_store": β_kv if 'β_kv' in globals() else None,
        "db_connection": PTDB if 'PTDB' in globals() else None,
        "knowledge_api": knowledge_api if 'knowledge_api' in globals() else None
    }
    
    # Initialize interactive commands system
    interactive_commands = init_interactive_commands(**required_components)
    logger.info("Interactive commands module initialized successfully")
except Exception as e:
    logger.warning(f"Interactive commands module initialization failed: {e}")

# Redefine _consume_block to handle basic functionality (this will be extended by _γ_consume_block)
def _consume_block(lines: str, seq: int) -> None:
    """Basic consume block functionality for processing input text."""
    trifecta(lines, weight=1.0)
    _log.info(f"Processed lecture block {seq}.")

# Initialize learning integration module
try:
    # Get required components for initialization
    required_components = {
        "original_consume_block": _consume_block,
        "trifecta_function": trifecta if 'trifecta' in globals() else None,
        "neuro_ingest_function": neuro_ingest if 'neuro_ingest' in globals() else None,
        "remote_call_function": remote_call if 'remote_call' in globals() else None,
        "push_into_corpus_function": push_into_corpus if 'push_into_corpus' in globals() else None,
        "learn_fact_function": _learn_fact if '_learn_fact' in globals() else None,
        "logger": _log if '_log' in globals() else None
    }
    
    # Initialize learning integration system
    learning_integration = init_learning_integration(**required_components)
    logger.info("Learning integration module initialized successfully")
    
    # Replace the _consume_block function with the enhanced version
    _consume_block = _γ_consume_block
except Exception as e:
    logger.warning(f"Learning integration module initialization failed: {e}")

# Initialize CLI handler module
try:
    # Define the original trifecta echo function
    _original_trifecta_echo = lambda r, b, y: print(f"(R={r:.3f} B={b:.3f} Y={y:.3f}) ENERGY={ENERGY:.3f}")
    
    # Get required components for initialization
    required_components = {
        "trifecta_function": trifecta if 'trifecta' in globals() else None,
        "learn_fact_function": _learn_fact if '_learn_fact' in globals() else None,
        "energy_variable": ENERGY if 'ENERGY' in globals() else None,
        "original_trifecta_echo": _original_trifecta_echo,
        "logger": logger if 'logger' in globals() else logging.getLogger("singularity.boot")
    }
    
    # Initialize CLI handler system
    cli_handler = init_cli_handler(**required_components)
    logger.info("CLI handler module initialized successfully")
    
    # Set the CLI handler function for the REPL
    globals()['_cli_handler'] = _γ_process_cli
except Exception as e:
    logger.warning(f"CLI handler module initialization failed: {e}")
    # Fallback implementation
    globals()['_cli_handler'] = lambda line: (lambda r, b, y: (print(f"(R={r:.3f} B={b:.3f} Y={y:.3f}) ENERGY={ENERGY:.3f}"), (r, b, y))[-1])(trifecta(line))


# Initialize asset watcher module
try:
    # Get required components for initialization
    required_components = {
        "base_dir": BASE,
        "consume_block_function": _γ_consume_block if '_γ_consume_block' in globals() else _consume_block,
        "scan_interval": 15,  # Scan every 15 seconds
        "logger": _log if '_log' in globals() else logging.getLogger("singularity.boot"),
        "autostart": True  # Start watching immediately
    }
    
    # Initialize asset watcher system
    asset_watcher = init_asset_watcher(**required_components)
    logger.info("Asset watcher module initialized successfully")

except Exception as e:
    logger.warning(f"Asset watcher module initialization failed: {e}")
    # Fallback implementation
    _ASSET = (BASE / "seed_assets").resolve()
    _ASSET.mkdir(exist_ok=True)
    _seen = set(f.name for f in _ASSET.iterdir())
    
    def _legacy_asset_watch():
        while True:
            for fp in _ASSET.iterdir():
                if fp.name in _seen:
                                        continue
                _seen.add(fp.name)
                try:
                    data = fp.read_text(encoding="utf-8", errors="ignore")
                except UnicodeDecodeError:
                    continue
                _log.info("[seed_asset] NEW %s", fp.name)
                _γ_consume_block(data, seq=int(time.time())%10_000)
            time.sleep(15)
    
    threading.Thread(target=_legacy_asset_watch, daemon=True).start()
    logger.info("Legacy asset watcher started")

# Add asset watcher commands to META
META["/asset-status"] = _cmd_asset_watcher_status
META["/asset-rescan"] = _cmd_asset_rescan


# Add an asset watcher health check command
def _cmd_asset_watcher_check():


# ... rest of existing code ...

# Add a system guards health check command
def _cmd_system_guards_check():
    """Check system guards health and print status"""
    health = system_guards_health_check()
    print(f"\nSystem Guards Health: {health['status'].upper()}")
    
    disk_status = health["disk_status"]
    print(f"Disk usage: {disk_status.get('used_bytes', 0) / (1024*1024*1024):.2f} GB used, "
          f"{disk_status.get('free_percent', 0):.1f}% free")
    
    peer_info = health["peer_info"]
    active_peers = peer_info.get("active_peers", [])
    print(f"Active peers: {len(active_peers)}")
    if active_peers:
        for peer in active_peers[:5]:
            print(f"  - {peer}")
        if len(active_peers) > 5:
            print(f"  ... and {len(active_peers) - 5} more")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/system-check"] = _cmd_system_guards_check

# Add a DNA compression command
def _cmd_compress_dna():
    """Manually trigger DNA compression"""
    glyph = force_compression()
    if glyph:
        print(f"DNA compressed successfully with glyph: {glyph}")
        print(f"DNA entries: {len(DNA)}")
    else:
        print("DNA compression failed")

META["/compress-dna"] = _cmd_compress_dna

# Add a peer list command 
def _cmd_list_peers():
    """List active peers on the network"""
    peers = get_peers()
    print(f"\nActive peers: {len(peers)}")
    for i, peer in enumerate(peers, 1):
        print(f"  {i}. {peer}")
    
    if not peers:
        print("  No active peers discovered")
        if CFG.get("max_outbound_kbit", 0) <= 0:
            print("  Note: Peer broadcasting is disabled. Set max_outbound_kbit > 0 to enable.")

META["/peers"] = _cmd_list_peers

# Add a ClusterPlus health check command
def _cmd_cluster_plus_check():
    """Check ClusterPlus health and print status"""
    health = ClusterPlus.health_check()
    print(f"\nClusterPlus Health: {health['status'].upper()}")
    print(f"Message: {health['message']}")
    print(f"Peers: {health['peer_count']}")
    
    print("\nMy profile:")
    for k, v in health['my_profile'].items():
        if k not in {"disks", "ts"}:  # Skip verbose entries
            print(f"  {k}: {v}")
    
    peers = ClusterPlus.get_peers()
    if peers:
        print(f"\nDiscovered peers: {len(peers)}")
        for i, peer in enumerate(peers):
            print(f"  {i+1}. {peer['host']} - GPU: {peer['cuda']} - VRAM: {peer['vram']}GB - CPU Cores: {peer['cores']}")
    else:
        print("\nNo peers discovered yet")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/cluster-check"] = _cmd_cluster_plus_check

# Add storage best path command
def _cmd_best_storage():
    """Find best storage location for given size"""
    size_mb = input("Required storage (MiB)> ")
    try:
        size = int(size_mb)
        path = ClusterPlus.best_path(size)
        print(f"\nBest storage location for {size} MiB: {path}")
        print(f"This path {'exists' if path.exists() else 'DOES NOT exist'}")
        if path.exists():
            try:
                import shutil
                total, used, free = shutil.disk_usage(path)
                print(f"Free space: {free / (1024*1024):.1f} MiB")
            except Exception as e:
                print(f"Could not get free space: {e}")
    except ValueError:
        print("Please enter a valid number")

META["/best-storage"] = _cmd_best_storage

# Clean shutdown (at end of file, before if __name__ == "__main__":)
def _clean_shutdown():
    # Stop other services
    # ...
    # Stop ClusterPlus last
    ClusterPlus.stop()

atexit.register(_clean_shutdown)


# Add GUI launcher to META commands

def _launch_gui():
    """Launch the GUI in a separate process to avoid blocking the CLI"""
    try:
        import subprocess
        import sys
        
        cmd = [sys.executable, str(BASE / "organism_gui.py")]
        subprocess.Popen(cmd)
        print("GUI launched in a separate window")
    except Exception as e:
        print(f"Error launching GUI: {e}")

# Add to META commands
META["/gui"] = _launch_gui

# Add these META commands
META["/infer-stats"] = cmd_infer_stats
META["/infer"] = cmd_infer_custom

# Add a storage check command
def _cmd_storage_check():
    """Check storage health and print status"""
    health = check_storage_health()
    print(f"\nStorage Health: {health['status'].upper()}")
    print(f"Ecosystem Size: {health['metrics']['total_size_bytes'] / (1024*1024*1024):.2f} GB")
    print(f"Free Space: {health['metrics']['disk_free_percent']:.1f}%")
    
    if health["details"]:
        print("\nIssues:")
        for key, value in health["details"].items():
            print(f"  - {key}: {value}")
    else:
        print("\nNo issues detected.")

META["/storage-check"] = _cmd_storage_check

# Add a new command for RBY-weighted inference
def _cmd_ask_rby():
    """Ask a question using RBY-weighted inference"""
    q = input("question> ")
    if _inference_integration_available:
        print("\n" + integrated_infer(q) + "\n")
    else:
        print("\n" + neuro_query(q) + "\n")

META["/ask-rby"] = _cmd_ask_rby

# Add a periodic table exploration command
def _cmd_show_axioms():
    """Display all axioms in the periodic table"""
    axioms = get_all_axioms()
    if not axioms:
        print("No axioms found in the periodic table.")
        return
        
    print("\n=== Periodic Table Axioms ===")
    for ax in axioms:
        print(f"\n{ax['glyph']} | {ax['title']}")
        print(f"LaTeX: {ax['latex']}")
        print(f"Definition: {ax['definition']}")

# Add a search axioms command
def _cmd_search_axioms():
    """Search axioms by keyword"""
    query = input("Search axioms> ")
    if not query.strip():
        print("Please enter a search term.")
        return
        
    results = search_axioms(query)
    if not results:
        print(f"No axioms found matching '{query}'.")
        return
        
    print(f"\n=== Found {len(results)} matching axioms ===")
    for ax in results:
        print(f"\n{ax['glyph']} | {ax['title']}")
        print(f"LaTeX: {ax['latex']}")
        print(f"Definition: {ax['definition']}")

META["/axioms"] = _cmd_show_axioms
META["/search-axioms"] = _cmd_search_axioms

# Add knowledge graph exploration commands
def _cmd_show_facts():
    """Display facts about a subject"""
    subject = input("Subject> ")
    if not subject.strip():
        print("Please enter a subject.")
        return
    
    facts = get_facts_by_subject(subject)
    if not facts:
        print(f"No facts found about '{subject}'.")
        return
        
    print(f"\n=== Facts about '{subject}' ===")
    for fact in facts:
        print(f"{fact['subject']} {fact['predicate']} {fact['object']}")
        
def _cmd_explore_graph():
    """Explore the knowledge graph around an entity"""
    entity = input("Entity> ")
    if not entity.strip():
        print("Please enter an entity.")
        return
    
    print(f"\n=== Knowledge Graph around '{entity}' ===")
    related = get_related_entities(entity)
    
    for node, facts in related.items():
        if not facts:
            continue
        print(f"\n== {node.title()} ==")
        for fact in facts:
            direction = "<--" if fact.get("direction") == "incoming" else "-->"
            if "direction" in fact and fact["direction"] == "incoming":
                print(f"  {fact['subject']} {direction} {fact['predicate']} {direction} {node}")
            else:
                print(f"  {node} {direction} {fact['predicate']} {direction} {fact['object']}")

META["/facts"] = _cmd_show_facts
META["/explore"] = _cmd_explore_graph

# Add a pattern testing command
def _cmd_test_patterns():
    """Test pattern extraction on user input"""
    text = input("Enter text to extract facts from> ")
    if not text.strip():
        print("Please enter some text.")
        return
        
    facts = extract_facts(text)
    if not facts:
        print("No facts extracted.")
        return
        
    print("\n=== Extracted Facts ===")
    for subj, pred, obj, conf in facts:
        print(f"{subj} {pred} {obj} (confidence: {conf:.2f})")
    
    # Ask if user wants to store these facts
    store = input("\nStore these facts? (y/n)> ").lower().startswith('y')
    if store:
        extract_and_store(text, "user_input")
        print("Facts stored in knowledge database.")

# Add a custom pattern command
def _cmd_add_pattern():
    """Add a custom pattern for fact extraction"""
    print("Add a new pattern (format: regex | subject_group | predicate | object_group)")
    pattern = input("Pattern> ")
    
    parts = pattern.split('|')
    if len(parts) != 4:
        print("Invalid format. Expected: regex | subject_group | predicate | object_group")
        return
    
    regex, subj_group, pred, obj_group = [p.strip() for p in parts]
    
    try:
        # Create lambda function from the parts
        extractor_code = f"lambda m: (m.group('{subj_group}').strip(), '{pred}', m.group('{obj_group}').strip())"
        extractor = eval(extractor_code)
        
        success = add_pattern(regex, extractor, f"User pattern: {pattern}")
        if success:
            print(f"Pattern added successfully.")
        else:
            print("Failed to add pattern.")
    except Exception as e:
        print(f"Error creating pattern: {e}")

# Add to META commands
META["/extract"] = _cmd_test_patterns
META["/add-pattern"] = _cmd_add_pattern

# Add a scientific pattern testing command
def _cmd_test_science_patterns():
    """Test scientific pattern extraction on user input"""
    text = input("Enter scientific text to extract facts from> ")
    if not text.strip():
        print("Please enter some text.")
        return
        
    facts = extract_scientific_facts(text)
    if not facts:
        print("No scientific facts extracted.")
        return
        
    print("\n=== Extracted Scientific Facts ===")
    for subj, pred, obj, conf in facts:
        print(f"{subj} {pred} {obj} (confidence: {conf:.2f})")
    
    # Ask if user wants to store these facts
    store = input("\nStore these facts? (y/n)> ").lower().startswith('y')
    if store:
        from singularity_science_patterns import extract_and_store
        extract_and_store(text, "user_input")
        print("Scientific facts stored in knowledge database.")

# Add a LaTeX processing command
def _cmd_process_latex():
    """Process LaTeX content and extract definitions and theorems"""
    latex_file = input("Enter path to LaTeX file or paste LaTeX content> ")
    
    # Check if input is a file path
    if os.path.exists(latex_file):
        try:
            with open(latex_file, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"Error reading file: {e}")
            return
    else:
        content = latex_file  # Treat input as direct LaTeX content
    
    # Process the content
    from singularity_science_patterns import extract_latex_definitions, extract_scientific_facts
    
    definitions = extract_latex_definitions(content)
    facts = extract_scientific_facts(content)
    
    if definitions:
        print("\n=== LaTeX Definitions ===")
        for cmd, defn in definitions.items():
            print(f"{cmd}: {defn}")
    
    if facts:
        print("\n=== Facts from LaTeX ===")
        for subj, pred, obj, conf in facts:
            print(f"{subj} {pred} {obj} (confidence: {conf:.2f})")
    
    if not definitions and not facts:
        print("No LaTeX definitions or facts found.")

# Add to META commands
META["/extract-science"] = _cmd_test_science_patterns
META["/process-latex"] = _cmd_process_latex

# Add an NLP pattern testing command
def _cmd_test_nlp_patterns():
    """Test NLP pattern extraction on user input"""
    text = input("Enter linguistic text to extract facts from> ")
    if not text.strip():
        print("Please enter some text.")
        return
        
    facts = extract_nlp_facts(text)
    if not facts:
        print("No linguistic facts extracted.")
        return
        
    print("\n=== Extracted Linguistic Facts ===")
    for subj, pred, obj, conf in facts:
        print(f"{subj} {pred} {obj} (confidence: {conf:.2f})")
    
    # Ask if user wants to store these facts
    store = input("\nStore these facts? (y/n)> ").lower().startswith('y')
    if store:
        from singularity_nlp_patterns import extract_and_store
        extract_and_store(text, "user_input")
        print("Linguistic facts stored in knowledge database.")

# Add a translation lookup command
def _cmd_lookup_translations():
    """Look up translations for a word"""
    word = input("Enter word to translate> ")
    if not word.strip():
        print("Please enter a word.")
        return
    
    translations = get_translations(word.strip().lower())
    
    if not translations:
        print(f"No translations found for '{word}'.")
        return
    
    print(f"\n=== Translations for '{word}' ===")
    for lang, trans in translations.items():
        print(f"{lang.capitalize()}: {trans}")

# Add to META commands
META["/extract-nlp"] = _cmd_test_nlp_patterns
META["/translate"] = _cmd_lookup_translations

def _persist_fact(subject, predicate, obj, conf=0.75):
    """Persist a fact into the knowledge database."""
    learn_fact(subject, predicate, obj, confidence=conf)

# Initialize TOKEN_W from config or as empty dict
TOKEN_W = get_token_weights()

# Initialize lexical module
init_lexical(_FNUM, TOKEN_W)

# Initialize fact extractors module
init_fact_extractors(
    ptdb_con=PTDB,
    kdb_con=KNOWDB,
    glyph_id_function=glyph_id,
    trifecta_function=trifecta,
    fact_patterns=_FACT_PATTERNS
)

# Initialize token classify module
init_token_classify(_WORD_CLASS if 'WORD_CLASS' in globals() else None)

# Initialize token weight module
init_tokenweights(_FNUM, lexical_get_token_weight)

# Initialize energy module
init_energy(_FNUM, CFG)

# Initialize memory module
init_memory(_FNUM, CFG, ECO, EXC)

# Initialize RBY helpers module
init_rby_helpers(
    fnum_function=_FNUM,
    rby_function=rby,
    glyph_id_function=glyph_id,
    valid_glyph_function=valid_glyph,
    log_excretion_function=log_excretion,
    delta_e_function=delta_E,
    dna=DNA,
    hist=_HIST,
    energy=ENERGY,
    r0=R0,
    b0=B0,
    y0=Y0
)

# Add a fact extractor health check command
def _cmd_fact_extractor_check():
    """Check fact extractor health and print status"""
    health = fact_extractors_health_check()
    print(f"\nFact Extractor Health: {health['status'].upper()}")
    print(f"Facts Extracted: {health['metrics']['facts_extracted']}")
    print(f"Facts Persisted: {health['metrics']['facts_persisted']}")
    
    if health["details"]:
        print("\nDetails:")
        for key, value in health["details"].items():
            print(f"  - {key}: {value}")

META["/fact-check"] = _cmd_fact_extractor_check

# Add a lexical health check command
def _cmd_lexical_check():
    """Check lexical system health and print status"""
    health = lexical_health_check()
    print(f"\nLexical Classification Health: {health['status'].upper()}")
    print(f"Vocabulary Size: {health['vocabulary']['total_vocabulary']} entries")
    print(f"Classifications: {health['metrics']['tokens_classified']}")
    
    if health["details"]:
        print("\nDetails:")
        for key, value in health["details"].items():
            print(f"  - {key}: {value}")

META["/lexical-check"] = _cmd_lexical_check

# Add a token classification health check command
def _cmd_token_classify_check():
    """Check token classification system health and print status"""
    health = token_classify_health_check()
    print(f"\nToken Classification Health: {health['status'].upper()}")
    print(f"Message: {health['message']}")
    print(f"Total tokens classified: {health['metrics']['tokens_classified']}")
    print(f"Cache hit rate: {health['metrics'].get('cache_hit_rate', 0):.2%}")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/token-classify-check"] = _cmd_token_classify_check

# Add a token weight health check command
def _cmd_tokenweights_check():
    """Check token weight system health and print status"""
    health = tokenweights_health_check()
    print(f"\nToken Weight System Health: {health['status'].upper()}")
    print(f"Weights calculated: {health['metrics']['weights_calculated']}")
    print(f"Context adjustments: {health['metrics']['context_adjustments']}")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/tokenweights-check"] = _cmd_tokenweights_check

# Add a token weight test command
def _cmd_test_tokenweights():
    """Test token weight calculation on user input"""
    token = input("Token to get weight for> ")
    if not token.strip():
        print("Please enter a token.")
        return
    
    # Basic weight
    r, b, y = rby(token)
    print(f"\nToken: '{token}'")
    print(f"Basic weights: R={r:.4f}, B={b:.4f}, Y={y:.4f}")
    
    # With context
    context = input("Context tokens (comma-separated)> ")
    if context.strip():
        context_tokens = [t.strip() for t in context.split(",")]
        r_ctx, b_ctx, y_ctx = rby_with_context(token, context_tokens)
        print(f"With context: R={r_ctx:.4f}, B={b_ctx:.4f}, Y={y_ctx:.4f}")
        
        # Show difference
        print(f"Difference: R={r_ctx-r:.4f}, B={b_ctx-b:.4f}, Y={y_ctx-y:.4f}")

META["/test-weights"] = _cmd_test_tokenweights

# Add a question answering command
def _cmd_ask_fact():
    """Ask a question about stored facts"""
    question = input("Question> ")
    if not question.strip():
        print("Please enter a question.")
        return
    
    # Try the enhanced answer system first
    response = enhanced_answer(question)
    
    # Fall back to regular answer if nothing found
    if not response:
        response = answer(question)
    
    if response:
        print(f"\n{response}")
    else:
        print("\nI don't have an answer for that question.")

META["/ask-fact"] = _cmd_ask_fact

# Add a token tuning command for interactive lexical processing
def _cmd_tune_token():
    """Tune the RBY weights of a token based on its context"""
    token = input("Token to tune> ")
    if not token.strip():
        print("Please enter a token.")
        return
        
    context = input("Context sentence> ")
    if not context.strip():
        print("Please enter a context sentence.")
        return
    
    r, b, y = tune_unknown_word(token, context)
    print(f"\nToken '{token}' tuned to:")
    print(f"R: {r:.4f}  B: {b:.4f}  Y: {y:.4f}")
    
    # Visualize the weights as a simple bar
    bar_length = 40
    r_chars = int(r * bar_length)
    b_chars = int(b * bar_length)
    y_chars = bar_length - r_chars - b_chars
    
    print("\nRBY Distribution:")
    print(f"R: {'R' * r_chars}{' ' * (bar_length - r_chars)} {r:.2%}")
    print(f"B: {'B' * b_chars}{' ' * (bar_length - b_chars)} {b:.2%}")
    print(f"Y: {'Y' * y_chars}{' ' * (bar_length - y_chars)} {y:.2%}")

META["/tune-token"] = _cmd_tune_token

# Add a token classification test command
def _cmd_test_classify():
    """Test token classification on user input"""
    token = input("Token to classify> ")
    if not token.strip():
        print("Please enter a token.")
        return
    
    print(f"\nToken: '{token}'")
    print(f"Basic classification: {classify(token)}")
    print(f"Morphological classification: {classify_morphological(token)}")
    
    cls, conf = classify_with_confidence(token)
    print(f"Classification with confidence: {cls} ({conf:.2%})")

META["/classify-token"] = _cmd_test_classify

# Add an energy health check command
def _cmd_energy_check():
    """Check energy system health and print status"""
    health = energy_health_check()
    print(f"\nEnergy System Health: {health['status'].upper()}")
    print(f"Current Delta-E: {health['metrics']['last_energy_value']}")
    print(f"Min/Max: {health['energy_bounds']['min']} to {health['energy_bounds']['max']}")
    print(f"Cycle Completeness: {health['cycle_completeness']:.1%}")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/energy-check"] = _cmd_energy_check

# Add an energy visualization command
def _cmd_energy_preview():
    """Show energy predictions for the next 24 hours"""
    from singularity_energy import generate_energy_preview
    
    hours = 24
    points = 24
    
    try:
        preview = generate_energy_preview(hours=hours, points=points)
        
        print(f"\nEnergy Preview for next {hours} hours:")
        print("-" * 50)
        print("Hour  |  Delta-E")
        print("-" * 50)
        
        for hour, value in preview:
            stars = int(abs(value) * 400) # Scale for visualization
            bar = "+" * stars if value >= 0 else "-" * stars
            print(f"{hour:5.1f} | {value:+7.5f}  {bar}")
            
        print("-" * 50)
        
    except Exception as e:
        print(f"Error generating energy preview: {e}")

META["/energy-preview"] = _cmd_energy_preview

# Add a memory health check command
def _cmd_memory_check():
    """Check memory system health and print status"""
    health = memory_health_check()
    print(f"\nMemory System Health: {health['status'].upper()}")
    print(f"DNA buffer: {health['metrics']['dna_length']} of {health['metrics']['dna_capacity']} entries ({health['metrics']['dna_utilization']:.1%} full)")
    print(f"History buffer: {health['metrics']['hist_length']} of {health['metrics']['hist_capacity']} entries ({health['metrics']['hist_utilization']:.1%} full)")
    print(f"Current Energy: {health['metrics']['energy']}")
    print(f"Excretions logged: {health['metrics']['excretions_logged']}")
    
    if health["warnings"]:
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/memory-check"] = _cmd_memory_check

# Add a memory save command
def _cmd_memory_save():
    """Save current memory state to disk"""
    path = save_memory_state()
    if path:
        print(f"Memory state saved to {path}")
    else:
        print("Failed to save memory state")

META["/memory-save"] = _cmd_memory_save

# Add a memory load command
def _cmd_memory_load():
    """Load memory state from disk"""
    if load_memory_state():
        print(f"Memory state restored successfully")
        print(f"Current Energy: {ENERGY}")
        print(f"DNA entries: {len(DNA)}")
        print(f"History entries: {len(_HIST)}")
    else:
        print("Failed to load memory state")

META["/memory-load"] = _cmd_memory_load

# Add an RBY helpers health check command
def _cmd_rby_helpers_check():
    """Check RBY helper functions health and print status"""
    health = rby_helpers_health_check()
    print(f"\nRBY Helpers Health: {health['status'].upper()}")
    print(f"Trifecta calls: {health['metrics']['trifecta_calls']}")
    print(f"Perception calls: {health['metrics']['perception_calls']}")
    print(f"Cognition calls: {health['metrics']['cognition_calls']}")
    print(f"Execution calls: {health['metrics']['execution_calls']}")
    print(f"Glyph excretions: {health['metrics']['glyph_excretions']}")
    
    print("\nDependency Status:")
    for dep, status in health["dependencies"].items():
        status_symbol = "✓" if status else "✗"
        print(f"  {dep}: {status_symbol}")
    
    if health["metrics"]["errors"] > 0:
        print(f"\nErrors: {health['metrics']['errors']}")

META["/rby-check"] = _cmd_rby_helpers_check

# Add Beta Knowledge commands to META
META["/ask"] = _cmd_ask
META["/why"] = _cmd_why
META["/recall"] = _cmd_recall
META["/beta-status"] = _cmd_beta_status

# Add a Beta Knowledge health check command
def _cmd_beta_knowledge_check():
    """Check Beta Knowledge system health and print status"""
    health = beta_knowledge_health_check()
    print(f"\nBeta Knowledge Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print details
    if health.get("details"):
        print("\nDetails:")
        for key, value in health["details"].items():
            print(f"  {key}: {value}")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/beta-check"] = _cmd_beta_knowledge_check

# Add vector index commands to META
META["/index-status"] = _cmd_index_status
META["/index-search"] = _cmd_vector_search

# Add a vector index optimize command
def _cmd_optimize_index():
    """Optimize the vector index"""
    from singularity_vector_index import optimize_index
    if optimize_index():
        print("Vector index optimized successfully")
    else:
        print("Vector index optimization failed")

META["/optimize-index"] = _cmd_optimize_index

# Add NLG commands to META
META["/nlg-status"] = _cmd_nlg_status
META["/nlg-add-template"] = _cmd_add_template
META["/nlg-test"] = _cmd_test_nlg

# Add an NLG health check command
def _cmd_nlg_check():
    """Check NLG system health and print status"""
    health = nlg_health_check()
    print(f"\nNLG Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print template count
    if "template_count" in health["details"]:
        print(f"\nTemplates loaded: {health['details']['template_count']}")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/nlg-check"] = _cmd_nlg_check

# Add Knowledge API commands to META
META["/kapi-status"] = _cmd_kapi_status
META["/kapi-search"] = _cmd_kapi_search
META["/kapi-add-fact"] = _cmd_kapi_add_fact
META["/kapi-recent"] = _cmd_kapi_list_recent

# Add a Knowledge API health check command
def _cmd_knowledge_api_check():
    """Check Knowledge API system health and print status"""
    health = knowledge_api_health_check()
    print(f"\nKnowledge API Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print KV store count
    if "kv_count" in health["details"]:
        print(f"\nKV Store: {health['details']['kv_count']} entries")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/kapi-check"] = _cmd_knowledge_api_check

# Add fact learning commands to META
META["/fact-learning-status"] = _cmd_fact_learning_status
META["/add-fact"] = _cmd_add_fact

# Add a fact learning health check command
def _cmd_fact_learning_check():
    """Check fact learning system health and print status"""
    health = fact_learning_health_check()
    print(f"\nFact Learning Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print cache size
    if "fact_cache_size" in health["details"]:
        print(f"\nFact Cache: {health['details']['fact_cache_size']} entries")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/fact-learning-check"] = _cmd_fact_learning_check

# Add interactive commands to META
META["/ask"] = _cmd_ask
META["/why"] = _cmd_why
META["/recall"] = _cmd_recall
META["/interactive-commands-status"] = _cmd_interactive_commands_status

# Add an interactive commands health check command
def _cmd_interactive_commands_check():
    """Check interactive commands system health and print status"""
    health = interactive_commands_health_check()
    print(f"\nInteractive Commands Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print dependencies
    print("\nDependencies:")
    for name, status in health["details"].get("dependencies", {}).items():
        status_symbol = "✓" if status else "✗"
        print(f"  {name}: {status_symbol}")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/interactive-commands-check"] = _cmd_interactive_commands_check

# Add learning integration commands to META
META["/learning-status"] = _cmd_learning_integration_status
META["/optimize-learning"] = _cmd_learning_optimization

# Add a learning integration health check command
def _cmd_learning_check():
    """Check learning integration system health and print status"""
    health = learning_integration_health_check()
    print(f"\nLearning Integration Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print dependencies
    print("\nDependencies:")
    for name, status in health["details"].get("dependencies", {}).items():
        status_symbol = "✓" if status else "✗"
        print(f"  {name}: {status_symbol}")
    
    # Print memory usage
    if "memory_usage_mb" in health["details"]:
        print(f"\nMemory Usage: {health['details']['memory_usage_mb']} MB")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/learning-check"] = _cmd_learning_check

# Add CLI handler commands to META
META["/cli-status"] = _cmd_cli_handler_status

# Add a CLI handler health check command
def _cmd_cli_check():
    """Check CLI handler system health and print status"""
    health = cli_handler_health_check()
    print(f"\nCLI Handler Health: {health['status'].upper()}")
    
    # Print metrics
    print("\nMetrics:")
    for key, value in health["metrics"].items():
        print(f"  {key}: {value}")
    
    # Print dependencies
    print("\nDependencies:")
    for name, status in health["details"].get("dependencies", {}).items():
        status_symbol = "✓" if status else "✗"
        print(f"  {name}: {status_symbol}")
    
    # Print warnings
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

META["/cli-check"] = _cmd_cli_check

# entry ---------------------------------------------------------------------
if __name__=="__main__":
    # Verify critical storage paths on startup
    if not verify_critical_paths():
        print("WARNING: Critical storage paths could not be verified or recovered.")
        print("Some functionality may not work correctly.")
        
    if "--manual" in sys.argv:              # disable auto-accept
        ClusterPlus.AUTO=False
    repl()

# Start ReflexSupervisor
ReflexSupervisor.start()

META["/train-gpt"] = lambda *a,**k: train_transformer(ECO)
META["/ddp-launch"] = lambda *a,**k: launch
