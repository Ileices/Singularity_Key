#!/usr/bin/env python3
"""
Singularity Configuration Module
-------------------------------
Handles all configuration, bootstrap, and initialization operations.

Features:
- Thread-safe configuration loading and modification
- File integrity verification and auto-recovery
- Cross-platform path handling
- Performance monitoring
- Security checks
"""
import csv
import datetime as _dt
import functools as _ft
import hashlib as _h
import json as _json
import logging as _log
import math as _m
import os
import pathlib
import re
import shutil
import sqlite3
import stat
import sys
import threading
import time
import yaml
from typing import Dict, Any, Optional, Union, List, Tuple, Callable
from decimal import Decimal, getcontext
import warnings
import atexit
import tempfile
import platform

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization & path setup
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Track startup time
_startup_time = time.time()

# Base paths - using pathlib for cross-platform compatibility
BASE = pathlib.Path(__file__).parent.resolve()
ECO = BASE / "ecosystem"
ECO.mkdir(exist_ok=True)

# Audit directory
AUDIT_DIR = BASE / "modularization_audit"
AUDIT_DIR.mkdir(exist_ok=True, parents=True)

# Thread safety
_config_lock = threading.RLock()
_init_lock = threading.RLock()
_initialized = False

# Monitoring metrics
_metrics = {
    "startup_time_ms": 0,
    "config_load_time_ms": 0,
    "config_reload_count": 0,
    "recovery_attempts": 0,
    "successful_recoveries": 0,
    "last_health_check": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Logging setup
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def setup_logging():
    """Configure the logging system."""
    _log.basicConfig(
        level=_log.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[_log.StreamHandler(sys.stdout)]
    )
    return _log.getLogger("singularity")

logger = setup_logging()

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Configuration management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Default configuration for recovery
DEFAULT_CONFIG = {
    "high_precision_mode": True,
    "rby_baseline": {
        "R0": "0.333333333333333333333333333333333333333333333333333333333333",
        "B0": "0.333333333333333333333333333333333333333333333333333333333333",
        "Y0": "0.333333333333333333333333333333333333333333333333333333333333"
    },
    "token_weights": {
        "imperative": [
            "0.050000000000000000000000000000000000000000000000000000000000",
            "0.149999999999999999999999999999999999999999999999999999999999",
            "0.800000000000000000000000000000000000000000000000000000000000"
        ]
    },
    "apical_pulse": {
        "amplitude": "0.025000000000000000000000000000000000000000000000000000000000",
        "period_seconds": 43200,
        "damping_beta": "0.000001157407407407407407407407407407407407407407407407407407"
    },
    "memory_decay_lambda": "0.0000080128205128205128205128205128205128205128205128205128",
    "glyph_regex": "^⟐[0-9a-f]{16}$"
}

# Global configuration holder
CFG: Dict[str, Any] = {}

def verify_config_file_permissions():
    """Verify that config file has restricted permissions on Unix systems."""
    config_path = BASE / "singularity_config.yml"
    
    if not config_path.exists():
        logger.warning(f"Config file not found: {config_path}")
        return False
    
    # On Unix-like systems, check file permissions
    if platform.system() != "Windows":
        mode = os.stat(config_path).st_mode
        if (mode & stat.S_IRWXO) or (mode & stat.S_IRWXG):
            logger.warning(f"Config file has too permissive mode: {oct(mode)}")
            try:
                os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)
                logger.info(f"Fixed config file permissions to 600")
            except Exception as e:
                logger.error(f"Failed to fix config permissions: {e}")
                return False
    
    return True

def calculate_config_hash(config_data: str) -> str:
    """Calculate SHA-256 hash of config data for integrity verification."""
    return _h.sha256(config_data.encode('utf-8')).hexdigest()

def load_config(reload: bool = False) -> Dict[str, Any]:
    """
    Load configuration from YAML file with thread safety and integrity checks.
    
    Args:
        reload: If True, force reload from disk even if already loaded.
    
    Returns:
        Dictionary containing configuration values.
    """
    global CFG, _initialized
    
    with _config_lock:
        if _initialized and not reload:
            return CFG
        
        config_path = BASE / "singularity_config.yml"
        start_time = time.time()
        
        # Check if config exists, otherwise create default
        if not config_path.exists():
            logger.warning(f"Config file not found: {config_path}")
            create_default_config()
        
        # Verify permissions
        verify_config_file_permissions()
        
        # Load with integrity checking
        try:
            # Safely read file with explicit encoding
            config_data = config_path.read_text(encoding="utf-8")
            config_hash = calculate_config_hash(config_data)
            
            # Parse YAML
            loaded_cfg = yaml.safe_load(config_data)
            
            # Store config hash for integrity checks
            loaded_cfg['_meta'] = {
                'hash': config_hash,
                'last_loaded': time.time(),
                'load_count': CFG.get('_meta', {}).get('load_count', 0) + 1
            }
            
            # Update global config
            CFG = loaded_cfg
            _initialized = True
            
            # Update metrics
            _metrics["config_load_time_ms"] = (time.time() - start_time) * 1000
            if reload:
                _metrics["config_reload_count"] += 1
                
            logger.info(f"Configuration loaded successfully from {config_path}")
            return CFG
            
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            _metrics["recovery_attempts"] += 1
            
            # Attempt recovery if possible
            if recover_config():
                _metrics["successful_recoveries"] += 1
                # Try loading again
                return load_config(reload=True)
            else:
                # Use default config as fallback
                logger.warning("Using default configuration as fallback")
                CFG = DEFAULT_CONFIG.copy()
                return CFG
        finally:
            # Ensure file handles are released
            if 'config_data' in locals():
                del config_data

def create_default_config() -> bool:
    """Create default configuration file if it doesn't exist."""
    config_path = BASE / "singularity_config.yml"
    
    if config_path.exists():
        return True
        
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(DEFAULT_CONFIG, f, default_flow_style=False, sort_keys=False)
        
        # Set file permissions
        if platform.system() != "Windows":
            os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)
            
        logger.info(f"Created default configuration at {config_path}")
        return True
    except Exception as e:
        logger.error(f"Failed to create default configuration: {e}")
        return False

def recover_config() -> bool:
    """Attempt to recover corrupted configuration file."""
    config_path = BASE / "singularity_config.yml"
    backup_path = BASE / "singularity_config.bak.yml"
    
    # Check if backup exists
    if backup_path.exists():
        try:
            # Restore from backup
            shutil.copy2(backup_path, config_path)
            logger.info(f"Recovered config from backup: {backup_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to restore from backup: {e}")
    
    # No backup or restore failed - create new default
    return create_default_config()

def save_config(config: Optional[Dict[str, Any]] = None) -> bool:
    """
    Save configuration to file with thread safety and backups.
    
    Args:
        config: Configuration dict to save, or None to use current CFG.
    
    Returns:
        True if saved successfully, False otherwise.
    """
    global CFG
    
    with _config_lock:
        config_path = BASE / "singularity_config.yml"
        backup_path = BASE / "singularity_config.bak.yml"
        
        # Use provided config or current global config
        cfg_to_save = config if config is not None else CFG
        
        # Skip internal metadata when saving
        cfg_to_save = {k: v for k, v in cfg_to_save.items() if k != '_meta'}
        
        try:
            # Create backup of existing config first
            if config_path.exists():
                shutil.copy2(config_path, backup_path)
            
            # Write to temporary file first, then move atomically
            with tempfile.NamedTemporaryFile(mode='w', delete=False, 
                                             suffix='.yml', encoding='utf-8') as tmp:
                yaml.dump(cfg_to_save, tmp, default_flow_style=False, sort_keys=False)
            
            # Move temp file to actual config
            shutil.move(tmp.name, config_path)
            
            # Set file permissions
            if platform.system() != "Windows":
                os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)
            
            logger.info(f"Configuration saved successfully to {config_path}")
            
            # Reload to ensure consistency
            load_config(reload=True)
            return True
            
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
            # Try to clean up temporary file if it exists
            if 'tmp' in locals() and os.path.exists(tmp.name):
                try:
                    os.unlink(tmp.name)
                except:
                    pass
            return False

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# High precision mode and RBY baseline variables
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def setup_precision():
    """
    Configure the precision settings based on configuration.
    
    Returns:
        Tuple of (FNUM, R0, B0, Y0, PHI)
    """
    cfg = load_config()
    high_precision = cfg.get("high_precision_mode", True)
    
    # Set precision for Decimal
    if high_precision:
        getcontext().prec = 60
        _FNUM = Decimal
    else:
        _FNUM = float
    
    # Extract RBY baseline values
    rby = cfg.get("rby_baseline", {})
    R0 = _FNUM(rby.get("R0", "0.333333333333333333333333333333333333333333333333333333333333"))
    B0 = _FNUM(rby.get("B0", "0.333333333333333333333333333333333333333333333333333333333333"))
    Y0 = _FNUM(rby.get("Y0", "0.333333333333333333333333333333333333333333333333333333333333"))
    
    # Calculate PHI (golden ratio)
    if high_precision:
        PHI = (_FNUM(1) + _FNUM(5).sqrt()) / 2
    else:
        PHI = (1 + 5**0.5) / 2
    
    return _FNUM, R0, B0, Y0, PHI

# Call setup_precision to initialize these values
_FNUM, R0, B0, Y0, PHI = setup_precision()

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health check and monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics() -> Dict[str, Any]:
    """Get current metrics for monitoring."""
    with _config_lock:
        # Update startup time if not yet set
        if _metrics["startup_time_ms"] == 0:
            _metrics["startup_time_ms"] = (time.time() - _startup_time) * 1000
            
        # Add config meta information
        _metrics.update({
            "config_hash": CFG.get("_meta", {}).get("hash", "unknown"),
            "config_last_loaded": CFG.get("_meta", {}).get("last_loaded", 0),
            "config_load_count": CFG.get("_meta", {}).get("load_count", 0)
        })
        
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """
    Perform a health check of the configuration system.
    
    Returns:
        Dictionary with health status information.
    """
    with _config_lock:
        status = {
            "status": "healthy",
            "timestamp": time.time(),
            "metrics": get_metrics(),
            "checks": {
                "config_exists": False,
                "config_readable": False,
                "config_valid": False,
                "config_writable": False
            },
            "details": {}
        }
        
        config_path = BASE / "singularity_config.yml"
        
        # Check 1: Config file exists
        status["checks"]["config_exists"] = config_path.exists()
        if not status["checks"]["config_exists"]:
            status["status"] = "degraded"
            status["details"]["missing_config"] = str(config_path)
        
        # Check 2: Config is readable
        try:
            text = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
            status["checks"]["config_readable"] = bool(text)
        except Exception as e:
            status["checks"]["config_readable"] = False
            status["status"] = "degraded"
            status["details"]["read_error"] = str(e)
        
        # Check 3: Config is valid YAML
        try:
            if status["checks"]["config_readable"]:
                test_cfg = yaml.safe_load(text)
                status["checks"]["config_valid"] = isinstance(test_cfg, dict)
        except Exception as e:
            status["checks"]["config_valid"] = False
            status["status"] = "degraded"
            status["details"]["yaml_error"] = str(e)
        
        # Check 4: Config is writable
        try:
            if config_path.exists():
                # Test by touching file modification time
                os.utime(config_path, None)
                status["checks"]["config_writable"] = True
            else:
                # Test by creating a temp file in the same directory
                test_file = config_path.parent / f"test_{time.time()}.tmp"
                test_file.touch()
                test_file.unlink()
                status["checks"]["config_writable"] = True
        except Exception as e:
            status["checks"]["config_writable"] = False
            status["status"] = "degraded"
            status["details"]["write_error"] = str(e)
        
        # Update last health check time
        _metrics["last_health_check"] = time.time()
        
        return status

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Compatibility layer for backward compatibility
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Dict to store deprecated import warnings
_warned_imports = {}

def _deprecated_import_warning(name: str, alternative: str):
    """Show deprecation warning for old import paths."""
    global _warned_imports
    
    if name not in _warned_imports:
        warnings.warn(
            f"Importing '{name}' directly from singularity_boot is deprecated. "
            f"Use '{alternative}' instead.",
            DeprecationWarning, stacklevel=2
        )
        _warned_imports[name] = True

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Clean shutdown handling
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _shutdown_handler():
    """Handle clean shutdown operations."""
    # Save any pending configuration changes
    logger.info("Running shutdown handler for configuration module")
    
    # Save metrics before exit
    try:
        metrics_file = ECO / "metrics" / f"config_metrics_{int(time.time())}.json"
        metrics_file.parent.mkdir(exist_ok=True, parents=True)
        
        with open(metrics_file, 'w', encoding='utf-8') as f:
            json.dump(get_metrics(), f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save metrics during shutdown: {e}")

# Register shutdown handler
atexit.register(_shutdown_handler)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Audit trail for module initialization
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _log_init_audit():
    """Log initialization parameters to audit trail."""
    try:
        # Find the next available audit number
        existing = list(AUDIT_DIR.glob("modularization_audit_*.yaml"))
        next_num = 1
        if existing:
            existing_nums = [int(f.stem.split('_')[-1]) for f in existing 
                            if f.stem.split('_')[-1].isdigit()]
            next_num = max(existing_nums, default=0) + 1
        
        audit_file = AUDIT_DIR / f"modularization_audit_{next_num}.yaml"
        
        # Create audit data
        audit_data = {
            "module": "singularity_config",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "initialization_parameters": {
                "high_precision_mode": CFG.get("high_precision_mode", True),
                "startup_time_ms": get_metrics()["startup_time_ms"]
            },
            "integration": {
                "boot_script": "singularity_boot.py",
                "import_path": "from singularity_config import CFG, R0, B0, Y0, _FNUM, PHI",
                "config_path": str(BASE / "singularity_config.yml")
            },
            "verification": {
                "config_loaded": _initialized,
                "config_valid": isinstance(CFG, dict) and len(CFG) > 0,
                "precision_setup": getcontext().prec == 60 if CFG.get("high_precision_mode", True) else True
            }
        }
        
        # Write audit trail
        with open(audit_file, 'w', encoding='utf-8') as f:
            yaml.dump(audit_data, f, default_flow_style=False)
            
        logger.info(f"Initialization audit trail written to {audit_file}")
        
    except Exception as e:
        logger.error(f"Failed to write audit trail: {e}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialize on module import
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Load configuration on module import
load_config()
_log_init_audit()

# Export public API
__all__ = [
    'CFG', 'BASE', 'ECO', 
    'R0', 'B0', 'Y0', 'PHI', '_FNUM',
    'load_config', 'save_config', 'health_check',
    'get_metrics'
]

# Diagnostics output
logger.info(f"Singularity configuration module initialized in {get_metrics()['startup_time_ms']:.2f}ms")
