#!/usr/bin/env python3
"""
Singularity Pattern Recognition Module
-------------------------------------
Advanced pattern matching and fact extraction system for the Singularity organism.

Features:
- Rich collection of natural language pattern recognizers
- Thread-safe fact extraction operations
- Integration with knowledge database
- Multi-language support with i18n capability
- Context-aware pattern matching
- Confidence scoring for extracted facts

This module extends the basic pattern recognition capabilities by providing
a comprehensive set of patterns for extracting structured knowledge from
unstructured text, supporting the organism's semantic understanding.
"""
import re
import os
import time
import json
import logging
import threading
import warnings
from typing import List, Dict, Tuple, Callable, Optional, Any, Union, Pattern
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logger = logging.getLogger("singularity.patterns")

# Thread safety
_pattern_lock = threading.RLock()
_initialized = False
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "patterns_loaded": 0,
    "total_extractions": 0,
    "successful_extractions": 0,
    "errors": 0
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Base Pattern Definitions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Basic patterns
_FACT_PATTERNS = [
    #  1)  "my name is Alice"   →  subj=⟂self   pred=name   obj=Alice
    (re.compile(r"\bmy name is (?P<obj>.+)", re.I),
        lambda m: ("⟂self", "name", m.group("obj").strip("."))),
    #  2)  "X is Y"  (simple definitional)
    (re.compile(r"^(?P<subj>[\w\s]+?) is (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "is", m.group("obj").strip("."))),
]

# Richer patterns
_EXTRA_FACT_PATTERNS = [
    # 3) "I am 42 years old" / "I'm 42"  →  ⟂self, age, 42 years old
    (re.compile(r"\bI\s*(?:am|'m)\s+(?P<obj>\d+\s*(?:years?\s*old)?)", re.I),
        lambda m: ("⟂self", "age", m.group("obj").strip("."))),
    
    # 4) "Alice has 3 cats"  → subj=Alice, pred=has, obj=3 cats
    (re.compile(r"^(?P<subj>[\w\s]+?) has (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "has", m.group("obj").strip("."))),
    
    # 5) "The capital of France is Paris"  → subj=France, pred=capital, obj=Paris
    (re.compile(r"^(?:the\s+)?capital of (?P<subj>[\w\s]+?) is (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "capital", m.group("obj").strip("."))),
    
    # 6) "Mount Everest is in Nepal"  → subj=Mount Everest, pred=location, obj=Nepal
    (re.compile(r"^(?P<subj>[\w\s]+?) is in (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "location", m.group("obj").strip("."))),
    
    # 7) "Einstein was born on 14 March 1879"
    (re.compile(r"^(?P<subj>[\w\s]+?) was born on (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "birth_date", m.group("obj").strip("."))),
    
    # 8) "Water boils at 100°C"
    (re.compile(r"^(?P<subj>[\w\s]+?) boils at (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "boils_at", m.group("obj").strip("."))),
    
    # 9) "π equals 3.14159" / "X equals Y"
    (re.compile(r"^(?P<subj>[\w\s]+?) equals (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "equals", m.group("obj").strip("."))),
    
    #10) "Sodium, also known as Na,"  → subj=Sodium, pred=alias, obj=Na
    (re.compile(r"^(?P<subj>[\w\s]+?), also known as (?P<obj>[\w\s]+)", re.I),
        lambda m: (m.group("subj").strip().rstrip(","), "alias", m.group("obj").strip("."))),
    
    #11) "Photosynthesis means creating energy from light"
    (re.compile(r"^(?P<subj>[\w\s]+?) means (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "means", m.group("obj").strip("."))),
    
    #12) "The symbol for gold is Au"
    (re.compile(r"^(?:the\s+)?symbol for (?P<subj>[\w\s]+?) is (?P<obj>\w+)", re.I),
        lambda m: (m.group("subj").strip(), "symbol", m.group("obj").strip("."))),
]

# Academic and scientific patterns
_ACADEMIC_FACT_PATTERNS = [
    # Chemical reactions
    (re.compile(r"^(?P<subj>[\w\s]+?) reacts with (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "reacts_with", m.group("obj").strip("."))),
    
    # Mathematical relationships
    (re.compile(r"^(?P<subj>[\w\s]+?) is proportional to (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "proportional_to", m.group("obj").strip("."))),
    
    # Physics laws
    (re.compile(r"^(?P<subj>[\w\s]+?) states that (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "states", m.group("obj").strip("."))),
    
    # Technical specifications
    (re.compile(r"^(?P<subj>[\w\s]+?) operates at (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "operates_at", m.group("obj").strip("."))),
    
    # Taxonomic classification
    (re.compile(r"^(?P<subj>[\w\s]+?) belongs to (?:the )?(?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "belongs_to", m.group("obj").strip("."))),
]

# Integrate all patterns
_FACT_PATTERNS.extend(_EXTRA_FACT_PATTERNS)
_FACT_PATTERNS.extend(_ACADEMIC_FACT_PATTERNS)

# Import scientific patterns if available
try:
    from singularity_science_patterns import _SCI_MATH_PATTERNS
    logger.info(f"Loaded {len(_SCI_MATH_PATTERNS)} scientific patterns")
    _FACT_PATTERNS.extend(_SCI_MATH_PATTERNS)
except ImportError:
    logger.debug("Scientific patterns module not available")

# Import NLP patterns if available
try:
    from singularity_nlp_patterns import _NLP_PATTERNS
    logger.info(f"Loaded {len(_NLP_PATTERNS)} NLP patterns")
    _FACT_PATTERNS.extend(_NLP_PATTERNS)
except ImportError:
    logger.debug("NLP patterns module not available")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# User-defined and dynamic patterns
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_USER_PATTERNS = []  # User-defined patterns can be added at runtime

def add_pattern(regex_pattern: str, extractor_fn: Callable, description: str = ""):
    """
    Add a new pattern to the fact extraction system.
    
    Args:
        regex_pattern: Regular expression pattern string
        extractor_fn: Function that takes a match object and returns (subj, pred, obj)
        description: Optional description of the pattern
        
    Returns:
        True if successfully added, False otherwise
    """
    with _pattern_lock:
        try:
            compiled_pattern = re.compile(regex_pattern, re.I)
            _USER_PATTERNS.append((compiled_pattern, extractor_fn))
            logger.info(f"Added new pattern: {description or regex_pattern}")
            return True
        except Exception as e:
            logger.error(f"Failed to add pattern: {e}")
            _metrics["errors"] += 1
            return False

def get_all_patterns() -> List[Tuple[Pattern, Callable]]:
    """Get all available patterns (built-in + user-defined)."""
    with _pattern_lock:
        return _FACT_PATTERNS + _USER_PATTERNS

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Fact Extraction Engine
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_facts(text: str, confidence_threshold: float = 0.6) -> List[Tuple[str, str, str, float]]:
    """
    Extract facts from text using all available patterns.
    
    Args:
        text: Input text to analyze
        confidence_threshold: Minimum confidence level for returned facts
        
    Returns:
        List of (subject, predicate, object, confidence) tuples
    """
    _metrics["total_extractions"] += 1
    facts = []
    
    # Split into sentences for better pattern matching
    sentences = [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]
    
    all_patterns = get_all_patterns()
    
    for sentence in sentences:
        for pattern, extractor in all_patterns:
            try:
                for match in pattern.finditer(sentence):
                    try:
                        # Extract the triple
                        subj, pred, obj = extractor(match)
                        
                        # Calculate confidence score (simple heuristic)
                        # This could be replaced with ML-based confidence scoring
                        confidence = _calculate_confidence(subj, pred, obj, sentence)
                        
                        if confidence >= confidence_threshold:
                            facts.append((subj, pred, obj, confidence))
                            _metrics["successful_extractions"] += 1
                    except Exception as e:
                        logger.debug(f"Extraction error: {e}")
            except Exception as e:
                logger.debug(f"Pattern matching error: {e}")
                _metrics["errors"] += 1
    
    return facts

def _calculate_confidence(subj: str, pred: str, obj: str, original_text: str) -> float:
    """Calculate a confidence score for an extracted fact."""
    # This is a simple heuristic - could be replaced with an ML model
    confidence = 0.7  # Base confidence
    
    # Adjust based on length of components
    if len(subj) < 2 or len(pred) < 2 or len(obj) < 2:
        confidence -= 0.2
    
    # Adjust based on capitalization (proper nouns)
    if subj[0].isupper():
        confidence += 0.1
    
    # Adjust based on match coverage
    total_len = len(subj) + len(pred) + len(obj)
    coverage = total_len / len(original_text)
    confidence += min(0.2, coverage)  # Max 0.2 boost
    
    # Cap at 0.0-1.0 range
    return max(0.0, min(1.0, confidence))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Integration with Knowledge Database
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def extract_and_store(text: str, source: str = "pattern_extraction") -> List[Tuple[str, str, str, float]]:
    """
    Extract facts from text and store them in the knowledge database.
    
    Args:
        text: Input text to analyze
        source: Source identifier for the extracted facts
        
    Returns:
        List of extracted and stored (subject, predicate, object, confidence) tuples
    """
    facts = extract_facts(text)
    stored_facts = []
    
    try:
        # Import knowledge module dynamically to avoid circular imports
        from singularity_knowledge import add_fact
        
        for subj, pred, obj, conf in facts:
            try:
                success = add_fact(subj, pred, obj, confidence=conf, source=source)
                if success:
                    stored_facts.append((subj, pred, obj, conf))
            except Exception as e:
                logger.error(f"Error storing fact: {e}")
                _metrics["errors"] += 1
    except ImportError:
        logger.warning("Knowledge module not available, facts not stored")
        _metrics["errors"] += 1
    
    return stored_facts

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Check and Monitoring
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_patterns_metrics() -> Dict[str, Union[int, float]]:
    """Get metrics about pattern recognition operations."""
    with _pattern_lock:
        return _metrics.copy()

def health_check() -> Dict[str, Any]:
    """Perform a health check on the pattern recognition subsystem."""
    status = "healthy"
    details = {}
    
    # Check pattern counts
    total_patterns = len(_FACT_PATTERNS) + len(_USER_PATTERNS)
    _metrics["patterns_loaded"] = total_patterns
    details["total_patterns"] = total_patterns
    
    # Check extraction success rate
    if _metrics["total_extractions"] > 0:
        success_rate = _metrics["successful_extractions"] / _metrics["total_extractions"]
        details["extraction_success_rate"] = success_rate
        
        if success_rate < 0.5:  # Less than 50% success rate is concerning
            status = "warning" if status == "healthy" else status
            details["low_success_rate"] = f"Only {success_rate:.1%} of extractions succeed"
    
    # Check for errors
    if _metrics["errors"] > 0:
        status = "warning" if status == "healthy" else status
        details["error_count"] = _metrics["errors"]
    
    return {
        "status": status,
        "metrics": _metrics,
        "details": details,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Inject symbols into another module for backward compatibility.
    
    Args:
        target_module: The module object to inject symbols into
    """
    import warnings
    
    # Define symbols to export
    symbols = {
        "_FACT_PATTERNS": _FACT_PATTERNS,
        "_EXTRA_FACT_PATTERNS": _EXTRA_FACT_PATTERNS,
        "extract_facts": extract_facts,
    }
    
    # Export symbols with deprecation warnings
    for name, value in symbols.items():
        if not hasattr(target_module, name):
            setattr(target_module, name, value)
            
            # For callable objects, add warning wrapper
            if callable(value):
                original = getattr(target_module, name)
                
                def make_wrapper(func):
                    warned = [False]  # Use a list for nonlocal access
                    
                    def wrapper(*args, **kwargs):
                        if not warned[0]:
                            warnings.warn(
                                f"Direct access to {func.__name__} from {target_module.__name__} is deprecated. "
                                f"Import from singularity_patterns instead.",
                                DeprecationWarning, 2
                            )
                            warned[0] = True
                        return func(*args, **kwargs)
                    return wrapper
                
                setattr(target_module, name, make_wrapper(original))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    '_FACT_PATTERNS',  # For backward compatibility
    'extract_facts',
    'extract_and_store',
    'add_pattern',
    'get_all_patterns',
    'get_patterns_metrics',
    'health_check'
]

# Module self-test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print(f"=== Pattern Recognition Module Self-Test ===")
    print(f"Total built-in patterns: {len(_FACT_PATTERNS)}")
    
    # Test with some example sentences
    test_sentences = [
        "My name is John Smith.",
        "I am 35 years old.",
        "The capital of France is Paris.",
        "Water boils at 100 degrees Celsius.",
        "Einstein was born on 14 March 1879.",
        "Sodium, also known as Na, is a chemical element."
    ]
    
    print("\nExtracting facts from test sentences:")
    all_facts = []
    
    for sentence in test_sentences:
        print(f"\nFrom: '{sentence}'")
        facts = extract_facts(sentence)
        all_facts.extend(facts)
        
        for subj, pred, obj, conf in facts:
            print(f"  • {subj} {pred} {obj} (confidence: {conf:.2f})")
    
    print(f"\nSuccessfully extracted {len(all_facts)} facts from {len(test_sentences)} sentences")
    
    # Health check
    health = health_check()
    print(f"\nHealth status: {health['status']}")
    print(f"Metrics: {health['metrics']}")
