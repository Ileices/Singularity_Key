#!/usr/bin/env python3
"""
Singularity Natural Language Generation (NLG) Module
---------------------------------------------------
Rule-based natural language generation for creating human-readable responses
from structured data without requiring large language models.

Features:
- Template-based text generation with variable substitution
- Response formatting based on question type
- Support for various answer patterns (what, who, when, why, how)
- Customizable templates with extension points
- Thread-safe operation

This module is designed to work with the knowledge base and fact extraction
modules to provide quick, deterministic responses to user queries.
"""

import re
import logging
import threading
import time
import json
import random
import pathlib
from pathlib import Path
from typing import Dict, List, Any, Optional, Union, Tuple
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.nlg")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "templates_loaded": 0,
    "responses_generated": 0,
    "template_cache_hits": 0,
    "template_cache_misses": 0,
    "errors": 0
}

# Thread safety
_nlg_lock = threading.RLock()
_stats_lock = threading.RLock()

# Base paths
_BASE = Path(__file__).parent.resolve()
_ECO = _BASE / "ecosystem"
_ECO.mkdir(exist_ok=True)
_TEMPLATES_DIR = _ECO / "nlg_templates"
_TEMPLATES_DIR.mkdir(exist_ok=True)

# Default template file
_DEFAULT_TEMPLATES = _TEMPLATES_DIR / "default_templates.json"

# ──────────────────────────────────────────────────────────────────────────
# Rule-based NLG (answers who/what/when/why without LLM weight)
# ──────────────────────────────────────────────────────────────────────────
class NLG:
    """
    Rule-based Natural Language Generation system.
    
    Uses templates to generate responses based on subject-predicate-object triples.
    Templates can be extended and customized.
    """
    
    # Default response templates
    DEFAULT_TEMPLATES = {
        "what": "«{subj}» is {obj}.",
        "who": "{subj} is {obj}.",
        "name": "Your name appears as '{obj}'.",
        "equation": "{subj} is formalised as {obj}.",
        "when": "{subj} occurred in {obj}.",
        "where": "{subj} is located in {obj}.",
        "why": "The reason for {subj} is {obj}.",
        "how": "{subj} works by {obj}.",
        "definition": "{subj} is defined as {obj}.",
        "property": "The {pred} of {subj} is {obj}.",
        "relation": "{subj} {pred} {obj}.",
        "unknown": "I don't have information about {subj} {pred} {obj}.",
        "default": "{subj} {pred} {obj}."
    }
    
    def __init__(self, templates_file=None, load_defaults=True):
        """
        Initialize the NLG engine.
        
        Args:
            templates_file (Path, optional): Path to a JSON file with templates
            load_defaults (bool): Whether to load default templates
        """
        self.templates: Dict[str, str] = {}
        self.template_cache: Dict[str, str] = {}
        self.lock = threading.RLock()
        
        # Load default templates if requested
        if load_defaults:
            with self.lock:
                self.templates.update(self.DEFAULT_TEMPLATES)
                with _stats_lock:
                    _STATS["templates_loaded"] += len(self.DEFAULT_TEMPLATES)
        
        # Load custom templates from file if provided
        if templates_file:
            self.load_templates(templates_file)
            
        # Save defaults if template file doesn't exist
        if load_defaults and not _DEFAULT_TEMPLATES.exists():
            self.save_templates(_DEFAULT_TEMPLATES)
    
    def load_templates(self, file_path: Path) -> bool:
        """
        Load templates from a JSON file.
        
        Args:
            file_path: Path to the JSON file
            
        Returns:
            bool: True if templates were loaded successfully
        """
        try:
            if not file_path.exists():
                logger.warning(f"Template file not found: {file_path}")
                return False
            
            with file_path.open('r', encoding='utf-8') as f:
                new_templates = json.load(f)
            
            if not isinstance(new_templates, dict):
                logger.error(f"Invalid template format in {file_path}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return False
            
            with self.lock:
                # Update templates
                self.templates.update(new_templates)
                # Clear cache when templates change
                self.template_cache.clear()
                with _stats_lock:
                    _STATS["templates_loaded"] += len(new_templates)
            
            logger.info(f"Loaded {len(new_templates)} templates from {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error loading templates from {file_path}: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False
    
    def save_templates(self, file_path: Path) -> bool:
        """
        Save current templates to a JSON file.
        
        Args:
            file_path: Path for the JSON file
            
        Returns:
            bool: True if templates were saved successfully
        """
        try:
            # Ensure directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            with self.lock:
                with file_path.open('w', encoding='utf-8') as f:
                    json.dump(self.templates, f, indent=2)
            
            logger.info(f"Saved {len(self.templates)} templates to {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error saving templates to {file_path}: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False
    
    def add_template(self, type_key: str, template: str) -> bool:
        """
        Add a new template or update an existing one.
        
        Args:
            type_key: Template type key (what, who, etc.)
            template: Template string with {placeholders}
            
        Returns:
            bool: True if template was added successfully
        """
        try:
            with self.lock:
                self.templates[type_key] = template
                # Clear affected cache entries
                keys_to_clear = [k for k in self.template_cache if k.startswith(f"{type_key}:")]
                for k in keys_to_clear:
                    self.template_cache.pop(k, None)
                with _stats_lock:
                    _STATS["templates_loaded"] += 1
            return True
        except Exception as e:
            logger.error(f"Error adding template {type_key}: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return False
    
    def make_answer(self, subj: str, pred: str, obj: str) -> str:
        """
        Generate a natural language answer from subject-predicate-object triple.
        
        Args:
            subj: Subject of the triple
            pred: Predicate (relationship)
            obj: Object of the triple
            
        Returns:
            str: Generated natural language response
        """
        with _stats_lock:
            _STATS["responses_generated"] += 1
        
        # Handle empty values
        if not subj or not pred or not obj:
            return "I don't have complete information to answer that."
        
        # Create cache key
        cache_key = f"{pred}:{hashlib.md5(f'{subj}:{pred}:{obj}'.encode()).hexdigest()}"
        
        with self.lock:
            # Check cache first
            if cache_key in self.template_cache:
                with _stats_lock:
                    _STATS["template_cache_hits"] += 1
                return self.template_cache[cache_key]
            
            with _stats_lock:
                _STATS["template_cache_misses"] += 1
            
            # Get appropriate template
            tpl = self.templates.get(pred.lower(), self.templates.get("default", "{subj} {pred} {obj}."))
            
            try:
                # Format with the values
                result = tpl.format(subj=subj, pred=pred, obj=obj)
                
                # Cache the result
                self.template_cache[cache_key] = result
                
                # Limit cache size
                if len(self.template_cache) > 1000:
                    # Remove oldest entries (approximately)
                    for _ in range(100):
                        self.template_cache.pop(next(iter(self.template_cache)), None)
                
                return result
            except Exception as e:
                logger.error(f"Error formatting template: {e}")
                with _stats_lock:
                    _STATS["errors"] += 1
                return f"Error generating response: {e}"
    
    def generate_from_facts(self, facts: List[Tuple[str, str, str]], query: str = "") -> str:
        """
        Generate a more complex answer from multiple facts.
        
        Args:
            facts: List of (subject, predicate, object) triples
            query: Optional query to guide response generation
            
        Returns:
            str: Generated response combining information from facts
        """
        if not facts:
            return "I don't have enough information to answer that."
        
        # For single facts, use make_answer directly
        if len(facts) == 1:
            return self.make_answer(facts[0][0], facts[0][1], facts[0][2])
        
        # For multiple facts, create a composite answer
        responses = []
        used_facts = set()
        
        # Process query-relevant facts first if query is provided
        if query:
            query_lower = query.lower()
            # Sort facts by relevance to query
            facts = sorted(facts, key=lambda f: sum(1 for part in f if part.lower() in query_lower), reverse=True)
        
        # Generate response for each fact
        for fact in facts:
            fact_key = f"{fact[0]}:{fact[1]}:{fact[2]}"
            if fact_key in used_facts:
                continue
                
            responses.append(self.make_answer(fact[0], fact[1], fact[2]))
            used_facts.add(fact_key)
        
        # Combine responses
        if len(responses) == 1:
            return responses[0]
        elif len(responses) == 2:
            return f"{responses[0]} {responses[1]}"
        else:
            body = ". ".join(responses[:-1])
            return f"{body}. {responses[-1]}"

# Global instance placeholder
nlg_engine = None

# ──────────────────────────────────────────────────────────────────────────
# Legacy compatibility wrapper for β_NLG
# ──────────────────────────────────────────────────────────────────────────
class β_NLG:
    """Legacy compatibility wrapper for original β_NLG class."""
    
    RESP = {
        "what": "«{subj}» is {obj}.",
        "who": "{subj} is {obj}.",
        "name": "Your name appears as '{obj}'.",
        "equation": "{subj} is formalised as {obj}.",
    }
    
    def __init__(self):
        """Initialize with a warning about deprecation."""
        import warnings
        warnings.warn(
            "β_NLG is deprecated and will be removed in a future version. "
            "Use singularity_nlg.NLG instead.",
            DeprecationWarning,
            stacklevel=2
        )
        self._nlg_engine = nlg_engine if nlg_engine else NLG()
    
    def make_answer(self, subj, pred, obj):
        """Legacy method that delegates to the new engine."""
        return self._nlg_engine.make_answer(subj, pred, obj)

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(templates_file=None, config=None):
    """
    Initialize the NLG engine.
    
    Args:
        templates_file: Optional path to templates file
        config: Optional configuration dictionary
        
    Returns:
        Initialized NLG engine
    """
    global nlg_engine
    
    logger.info("Initializing NLG engine")
    
    # Use templates file from config if provided
    if config and not templates_file:
        nlg_config = config.get('nlg', {})
        templates_path = nlg_config.get('templates_file')
        if templates_path:
            templates_file = Path(templates_path)
    
    # Create the NLG engine
    nlg_engine = NLG(templates_file=templates_file)
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"NLG engine initialized in {_STATS['init_time_ms']} ms")
    
    # For backward compatibility
    global β_nlg
    β_nlg = β_NLG()
    
    return nlg_engine

def health_check() -> dict:
    """
    Perform a health check on the NLG module.
    
    Returns:
        Dictionary with health status information
    """
    global nlg_engine
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if engine is initialized
    if not nlg_engine:
        status = "error"
        warnings.append("NLG engine not initialized")
    else:
        try:
            # Get template count
            template_count = len(nlg_engine.templates)
            details["template_count"] = template_count
            
            # Check if templates are loaded
            if template_count == 0:
                warnings.append("No templates loaded")
                if status != "error":
                    status = "warning"
        except Exception as e:
            status = "error"
            warnings.append(f"NLG engine error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "nlg",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the NLG module.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown():
    """
    Perform clean shutdown of NLG resources.
    """
    global nlg_engine
    
    if nlg_engine:
        logger.info("Shutting down NLG engine")
        # Save templates if modified
        nlg_engine.save_templates(_DEFAULT_TEMPLATES)

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_nlg_status():
    """Command handler for /nlg-status"""
    if not nlg_engine:
        print("NLG engine not initialized")
        return
    
    health = health_check()
    
    print("\nNLG Engine Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    print(f"\nLoaded Templates: {health['details'].get('template_count', 0)}")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

def _cmd_add_template():
    """Command handler for /nlg-add-template"""
    if not nlg_engine:
        print("NLG engine not initialized")
        return
    
    type_key = input("Template type (e.g., what, who, definition): ")
    if not type_key.strip():
        print("Template type cannot be empty")
        return
    
    template = input("Template (use {subj}, {pred}, {obj} as placeholders): ")
    if not template.strip():
        print("Template cannot be empty")
        return
    
    if nlg_engine.add_template(type_key, template):
        print(f"Template for '{type_key}' added successfully")
        print("Example output:")
        print(nlg_engine.make_answer("Example Subject", type_key, "Example Object"))
    else:
        print("Failed to add template")

def _cmd_test_nlg():
    """Command handler for /nlg-test"""
    if not nlg_engine:
        print("NLG engine not initialized")
        return
    
    subject = input("Subject: ")
    predicate = input("Predicate: ")
    object_value = input("Object: ")
    
    result = nlg_engine.make_answer(subject, predicate, object_value)
    print(f"\nGenerated response: {result}")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'NLG',
    'β_NLG',
    'β_nlg',
    '_cmd_nlg_status',
    '_cmd_add_template',
    '_cmd_test_nlg'
]

# Create essential templates file if it doesn't exist
def _ensure_default_templates():
    """Ensure default templates file exists."""
    if not _DEFAULT_TEMPLATES.exists():
        engine = NLG()
        engine.save_templates(_DEFAULT_TEMPLATES)
        logger.info(f"Created default templates file: {_DEFAULT_TEMPLATES}")

# Run initialization code on module import
_ensure_default_templates()
