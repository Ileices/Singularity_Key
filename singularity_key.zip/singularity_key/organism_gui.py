"""
GUI frontend for Singularity
Provides graphical controls for training, data ingestion, and interaction
"""
import os, sys, threading, tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
from pathlib import Path
import queue
import time

# Base paths
BASE = Path(__file__).parent.resolve()
ECO = BASE / "ecosystem"
ECO.mkdir(exist_ok=True)

# Define queue for log messages
log_queue = queue.Queue()

class SingularityGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Singularity Control Panel")
        self.root.geometry("900x600")
        self.root.minsize(800, 500)
        
        # Set up the layout
        self._create_menu()
        self._create_frame_layout()
        self._create_neural_controls()
        self._create_autodata_controls()
        self._create_terminal()
        
        # Start log consumer
        self._start_log_consumer()

    def _create_menu(self):
        menu_bar = tk.Menu(self.root)
        
        # File menu
        file_menu = tk.Menu(menu_bar, tearoff=0)
        file_menu.add_command(label="Export Knowledge", command=self._export_knowledge)
        file_menu.add_command(label="Import Dataset", command=self._import_dataset)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menu_bar.add_cascade(label="File", menu=file_menu)
        
        # Neural menu
        neural_menu = tk.Menu(menu_bar, tearoff=0)
        neural_menu.add_command(label="Train Model", command=lambda: self._run_command("/train-once"))
        neural_menu.add_command(label="Distributed Training", command=lambda: self._run_command("/train-dist"))
        neural_menu.add_separator()
        neural_menu.add_command(label="Model Status", command=self._show_model_status)
        menu_bar.add_cascade(label="Neural", menu=neural_menu)
        
        # Crawler menu
        crawler_menu = tk.Menu(menu_bar, tearoff=0)
        crawler_menu.add_command(label="Start Crawler", command=lambda: self._run_command("/crawl-on"))
        crawler_menu.add_command(label="Stop Crawler", command=lambda: self._run_command("/crawl-off"))
        crawler_menu.add_command(label="Crawler Status", command=lambda: self._run_command("/crawl-status"))
        crawler_menu.add_command(label="Add URL", command=self._add_crawler_url)
        menu_bar.add_cascade(label="Crawler", menu=crawler_menu)
        
        # Help menu
        help_menu = tk.Menu(menu_bar, tearoff=0)
        help_menu.add_command(label="Commands", command=self._show_commands)
        help_menu.add_command(label="About", command=self._show_about)
        menu_bar.add_cascade(label="Help", menu=help_menu)
        
        self.root.config(menu=menu_bar)

    def _create_frame_layout(self):
        # Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Top controls area
        self.controls_frame = ttk.Frame(main_frame)
        self.controls_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Tabs for different control sections
        self.tab_control = ttk.Notebook(self.controls_frame)
        self.tab_control.pack(fill=tk.BOTH, expand=True)
        
        # Neural tab
        self.neural_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.neural_tab, text="Neural")
        
        # Autodata tab
        self.autodata_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.autodata_tab, text="AutoData")
        
        # Terminal area
        self.terminal_frame = ttk.LabelFrame(main_frame, text="Terminal")
        self.terminal_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def _create_neural_controls(self):
        # Neural controls
        ttk.Label(self.neural_tab, text="Neural Training Controls").pack(anchor=tk.W, padx=5, pady=5)
        
        train_frame = ttk.Frame(self.neural_tab)
        train_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(train_frame, text="Fine-tune (600)", 
                  command=lambda: self._run_command("/train-once")).pack(side=tk.LEFT, padx=2)
        ttk.Button(train_frame, text="DDP 1200", 
                  command=lambda: self._run_command("/train-dist")).pack(side=tk.LEFT, padx=2)
        ttk.Button(train_frame, text="Help", 
                  command=lambda: self._run_command("/train-help")).pack(side=tk.LEFT, padx=2)
        
        query_frame = ttk.Frame(self.neural_tab)
        query_frame.pack(fill=tk.X, padx=5, pady=10)
        
        ttk.Label(query_frame, text="Ask a question:").pack(side=tk.LEFT, padx=2)
        self.query_entry = ttk.Entry(query_frame)
        self.query_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        ttk.Button(query_frame, text="Ask", 
                  command=self._ask_question).pack(side=tk.LEFT, padx=2)

    def _create_autodata_controls(self):
        # Autodata controls
        ttk.Label(self.autodata_tab, text="AutoData Controls").pack(anchor=tk.W, padx=5, pady=5)
        
        folder_frame = ttk.Frame(self.autodata_tab)
        folder_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(folder_frame, text="Select Data Folders", 
                  command=lambda: self._run_command("/autodata-pick")).pack(side=tk.LEFT, padx=2)
        ttk.Button(folder_frame, text="Ingest Now", 
                  command=self._ingest_now).pack(side=tk.LEFT, padx=2)
        
        # Add monitoring status
        status_frame = ttk.LabelFrame(self.autodata_tab, text="Monitoring Status")
        status_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.monitoring_status = ttk.Label(status_frame, text="Unknown")
        self.monitoring_status.pack(padx=5, pady=5, anchor=tk.W)
        
        # Update status
        self._update_monitoring_status()

    def _create_terminal(self):
        # Terminal output
        terminal_controls = ttk.Frame(self.terminal_frame)
        terminal_controls.pack(fill=tk.X)
        
        ttk.Label(terminal_controls, text="Command:").pack(side=tk.LEFT, padx=2)
        self.cmd_entry = ttk.Entry(terminal_controls)
        self.cmd_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        self.cmd_entry.bind("<Return>", lambda e: self._execute_command())
        ttk.Button(terminal_controls, text="Execute", 
                  command=self._execute_command).pack(side=tk.LEFT, padx=2)
        ttk.Button(terminal_controls, text="Clear", 
                  command=self._clear_terminal).pack(side=tk.LEFT, padx=2)
        
        # Terminal output area
        self.terminal = scrolledtext.ScrolledText(self.terminal_frame, wrap=tk.WORD, 
                                                height=15, bg="black", fg="green")
        self.terminal.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.terminal.config(state=tk.DISABLED)

    def _start_log_consumer(self):
        """Start consuming logs from queue and display in terminal"""
        def consume_logs():
            while True:
                try:
                    log_entry = log_queue.get(timeout=0.1)
                    self.terminal.config(state=tk.NORMAL)
                    self.terminal.insert(tk.END, log_entry + "\n")
                    self.terminal.see(tk.END)
                    self.terminal.config(state=tk.DISABLED)
                except queue.Empty:
                    self.root.after(100, consume_logs)
                    break
        
        self.root.after(100, consume_logs)

    def _run_command(self, cmd):
        """Run a singularity command"""
        self._log(f"Running command: {cmd}")
        
        # This would normally import the command from singularity_boot
        # For now, we'll just simulate it
        if cmd == "/train-once":
            self._log("Starting fine-tune training (600 steps)...")
            threading.Thread(target=self._simulate_training, daemon=True).start()
        elif cmd == "/train-dist":
            self._log("Starting distributed training (1200 steps)...")
            threading.Thread(target=self._simulate_training, daemon=True).start()
        elif cmd == "/train-help":
            self._log(" /train-once  – local 600-step fine-tune")
            self._log(" /train-dist  – DDP on all GPUs (edit nodes arg)")
        elif cmd.startswith("/crawl"):
            self._log(f"Crawler command: {cmd}")

    def _execute_command(self):
        """Execute command from command entry"""
        cmd = self.cmd_entry.get().strip()
        if not cmd:
            return
            
        self._run_command(cmd)
        self.cmd_entry.delete(0, tk.END)

    def _ingest_now(self):
        """Trigger autodata ingestion"""
        self._log("Triggering immediate data ingestion...")
        
        # This would normally call organism_autodata.flush_to_organism()
        # For now, we'll just simulate it
        threading.Thread(target=self._simulate_ingestion, daemon=True).start()

    def _ask_question(self):
        """Ask a question to the neural engine"""
        question = self.query_entry.get().strip()
        if not question:
            return
            
        self._log(f"Question: {question}")
        
        # This would normally call organism_neuro.query()
        # For now, we'll just simulate it
        threading.Thread(target=self._simulate_query, args=(question,), daemon=True).start()
        
    def _update_monitoring_status(self):
        """Update the autodata monitoring status"""
        # This would normally check organism_autodata's running state
        # For now, we'll just show a placeholder
        self.monitoring_status.config(text="Active - Watching 3 folders")
        
        # Schedule next update
        self.root.after(60000, self._update_monitoring_status)  # Update every minute

    def _export_knowledge(self):
        """Export knowledge base"""
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("RDF files", "*.rdf"), ("All files", "*.*")]
        )
        if file_path:
            self._log(f"Exporting knowledge to {file_path}...")

    def _import_dataset(self):
        """Import a dataset"""
        file_path = filedialog.askopenfilename(
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if file_path:
            self._log(f"Importing dataset from {file_path}...")

    def _show_model_status(self):
        """Show neural model status"""
        # This would normally query the neural engine for status
        # For now, we'll just show a placeholder
        status = "GPT model loaded: gpt_20230815_120000\n"
        status += "VRAM usage: 4.2 GB / 8.0 GB\n"
        status += "Last training: 2023-08-15 12:00:00\n"
        status += "Custom vocabulary: 50,279 tokens"
        
        messagebox.showinfo("Neural Model Status", status)

    def _add_crawler_url(self):
        """Add a URL to the crawler"""
        url = simpledialog.askstring("Add URL", "Enter URL to crawl:")
        if url:
            self._log(f"Adding URL to crawler: {url}")
            # This would normally call the crawler add URL function

    def _show_commands(self):
        """Show available commands"""
        commands = """Available Commands:
/train-once - Run local fine-tuning (600 steps)
/train-dist - Run distributed training
/crawl-on - Start crawler
/crawl-off - Stop crawler
/crawl-status - Show crawler status
/crawl-add - Add URL to crawler
/ask - Ask a question
/autodata-pick - Select data folders"""
        
        messagebox.showinfo("Available Commands", commands)

    def _show_about(self):
        """Show about dialog"""
        about = """Singularity Control Panel
Version 1.0

A hybrid symbolic + neural organism that can:
• Embed text
• Reason over long context
• Draft & repair code
• Refine its own weights

Built with ❤️ using Python + PyTorch"""
        
        messagebox.showinfo("About", about)

    def _clear_terminal(self):
        """Clear the terminal"""
        self.terminal.config(state=tk.NORMAL)
        self.terminal.delete(1.0, tk.END)
        self.terminal.config(state=tk.DISABLED)

    def _log(self, message):
        """Add a log message to the queue"""
        log_queue.put(f"[{time.strftime('%H:%M:%S')}] {message}")

    # Simulation methods for demo purposes
    def _simulate_training(self):
        """Simulate a training run"""
        total_steps = 600
        for i in range(0, total_steps+1, 50):
            if i > 0:
                time.sleep(1)  # Simulate time passing
            if i < total_steps:
                self._log(f"Training step {i}/{total_steps}, loss: {5.0 - (i/total_steps)*4.5:.3f}")
        self._log("Training complete! Model saved to ecosystem/models/gpt_20230815_120000")

    def _simulate_ingestion(self):
        """Simulate data ingestion"""
        time.sleep(0.5)
        self._log("Found 42 files to process")
        for i in range(5):
            time.sleep(0.3)
            self._log(f"Processed batch {i+1}/5 ({8} files)")
        self._log("Ingestion complete: 42 files processed, 38 new entries added to corpus")

    def _simulate_query(self, question):
        """Simulate a neural query"""
        time.sleep(1)
        if "speed of light" in question.lower():
            self._log("Answer: The speed of light in vacuum is approximately 299,792,458 meters per second.")
        elif "neural" in question.lower() or "ai" in question.lower():
            self._log("Answer: Neural networks are computational systems inspired by biological neural networks that form animal brains. They consist of interconnected nodes or 'neurons' that process and transmit information.")
        else:
            self._log(f"Answer: I processed your question about '{question}'. To provide a more accurate answer, I would need to search my knowledge base and generate a response using the neural engine.")

# Run the GUI
if __name__ == "__main__":
    from tkinter import simpledialog
    
    root = tk.Tk()
    app = SingularityGUI(root)
    root.mainloop()
