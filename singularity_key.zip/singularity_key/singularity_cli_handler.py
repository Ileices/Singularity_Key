#!/usr/bin/env python3
"""
Singularity CLI Handler Module (Module γ - Part 2)
-------------------------------------------------
Processes command-line input in the REPL by integrating multiple learning systems:

Features:
- Interactive REPL line processing with fact learning
- Comprehensive trifecta management with energy reporting
- Thread-safe CLI handling with proper locking
- Metrics and monitoring with health check endpoints
- Backward compatibility with original trifecta echo

This module extends the Learning Integration module to handle CLI commands.
"""

import os
import sys
import time
import logging
import threading
import json
from pathlib import Path
from typing import Callable, Dict, Any, Optional, Union, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("singularity.cli_handler")

# Module initialization time for metrics
_start_time = time.time()

# Module statistics
_STATS = {
    "init_time_ms": 0,
    "cli_commands_processed": 0,
    "facts_learned": 0,
    "errors": 0
}

# Thread safety
_stats_lock = threading.RLock()
_cli_lock = threading.RLock()

# Original function references - populated during initialization
_original_trifecta_function = None
_learn_fact_function = None
_original_trifecta_echo = None
_energy_variable = None

class CLIHandlerSystem:
    """
    Handles CLI input processing by integrating multiple learning systems.
    
    This class processes user input in the REPL and:
    1. Learns facts from the input
    2. Processes the input through the trifecta function
    3. Shows the RBY and energy values to the user
    """
    
    def __init__(
        self,
        trifecta_function=None,
        learn_fact_function=None,
        energy_variable=None,
        original_trifecta_echo=None,
        logger=None
    ):
        """
        Initialize the CLI handler system.
        
        Args:
            trifecta_function: Function to process input through RBY
            learn_fact_function: Function for fact learning
            energy_variable: Reference to the ENERGY variable
            original_trifecta_echo: Original echo function
            logger: Logger instance
        """
        self.trifecta = trifecta_function
        self.learn_fact = learn_fact_function
        self.energy = energy_variable
        self.trifecta_echo = original_trifecta_echo or (lambda r, b, y: print(f"(R={r:.3f} B={b:.3f} Y={y:.3f}) ENERGY={self.energy:.3f}" if self.energy is not None else f"(R={r:.3f} B={b:.3f} Y={y:.3f})"))
        self.logger = logger or logging.getLogger("singularity.cli_handler")
        
        # Thread safety
        self.lock = threading.RLock()
        
        logger.info("CLIHandlerSystem initialized")
        
    def process_cli(self, line: str) -> Tuple[float, float, float]:
        """
        Process a line of user input from the REPL.
        
        This method:
        1. Learns facts from the input
        2. Processes the input through the trifecta function
        3. Shows the RBY and energy values to the user
        
        Args:
            line: Input line from the REPL
            
        Returns:
            Tuple of (R, B, Y) values
        """
        try:
            with self.lock:
                # Learn facts from the input
                if self.learn_fact:
                    try:
                        self.learn_fact(line)
                        with _stats_lock:
                            _STATS["facts_learned"] += 1
                    except Exception as e:
                        self.logger.error(f"Error in learn_fact: {e}")
                        with _stats_lock:
                            _STATS["errors"] += 1
                
                # Process through trifecta
                if self.trifecta:
                    try:
                        r, b, y = self.trifecta(line)
                    except Exception as e:
                        self.logger.error(f"Error in trifecta: {e}")
                        r, b, y = 0.0, 0.0, 0.0
                        with _stats_lock:
                            _STATS["errors"] += 1
                else:
                    r, b, y = 0.0, 0.0, 0.0
                
                # Echo the results
                if self.trifecta_echo:
                    self.trifecta_echo(r, b, y)
                
                with _stats_lock:
                    _STATS["cli_commands_processed"] += 1
                    
                return r, b, y
                
        except Exception as e:
            self.logger.error(f"Error in process_cli: {e}")
            with _stats_lock:
                _STATS["errors"] += 1
            return 0.0, 0.0, 0.0

# Global CLI handler instance
cli_handler = None

# ──────────────────────────────────────────────────────────────────────────
# Public API: CLI handling function for integration with singularity_boot
# ──────────────────────────────────────────────────────────────────────────
def _γ_process_cli(line: str) -> Tuple[float, float, float]:
    """
    Process a line of user input from the REPL.
    
    This function:
    1. Learns facts from the input
    2. Processes the input through the trifecta function
    3. Shows the RBY and energy values to the user
    
    Args:
        line: Input line from the REPL
        
    Returns:
        Tuple of (R, B, Y) values
    """
    global cli_handler
    
    if cli_handler:
        return cli_handler.process_cli(line)
    else:
        logger.warning("CLI handler system not initialized - using legacy implementation")
        
        # Fallback implementation for backward compatibility
        try:
            # Try to import required functions
            from singularity_boot import trifecta, _learn_fact, ENERGY
            
            # Learn fact and process through trifecta
            _learn_fact(line)
            r, b, y = trifecta(line)
            print(f"(R={r:.3f} B={b:.3f} Y={y:.3f}) ENERGY={ENERGY:.3f}")
            return r, b, y
        except ImportError as e:
            logger.error(f"Legacy implementation failed: {e}")
            logger.error("Cannot process CLI input - required functions not available")
            return 0.0, 0.0, 0.0

# ──────────────────────────────────────────────────────────────────────────
# Initialization and public API
# ──────────────────────────────────────────────────────────────────────────
def initialize(
    trifecta_function=None,
    learn_fact_function=None,
    energy_variable=None,
    original_trifecta_echo=None,
    logger=None
) -> CLIHandlerSystem:
    """
    Initialize the CLI handler system.
    
    Args:
        trifecta_function: Function to process input through RBY
        learn_fact_function: Function for fact learning
        energy_variable: Reference to the ENERGY variable
        original_trifecta_echo: Original echo function
        logger: Logger instance
        
    Returns:
        Initialized CLIHandlerSystem
    """
    global cli_handler
    global _original_trifecta_function, _learn_fact_function
    global _original_trifecta_echo, _energy_variable
    
    logger.info("Initializing CLI handler system")
    
    # Store references to required functions
    _original_trifecta_function = trifecta_function
    _learn_fact_function = learn_fact_function
    _original_trifecta_echo = original_trifecta_echo
    _energy_variable = energy_variable
    
    # Create CLI handler system
    cli_handler = CLIHandlerSystem(
        trifecta_function=trifecta_function,
        learn_fact_function=learn_fact_function,
        energy_variable=energy_variable,
        original_trifecta_echo=original_trifecta_echo,
        logger=logger
    )
    
    # Update initialization time metric
    with _stats_lock:
        _STATS["init_time_ms"] = int((time.time() - _start_time) * 1000)
    
    logger.info(f"CLI handler system initialized in {_STATS['init_time_ms']} ms")
    
    return cli_handler

def health_check() -> dict:
    """
    Perform a health check on the CLI handler system.
    
    Returns:
        Dictionary with health status information
    """
    global cli_handler
    
    status = "healthy"
    details = {}
    warnings = []
    
    # Check if system is initialized
    if not cli_handler:
        status = "error"
        warnings.append("CLI handler system not initialized")
    else:
        try:
            # Check dependencies
            dependencies = {
                "trifecta": cli_handler.trifecta is not None,
                "learn_fact": cli_handler.learn_fact is not None,
                "energy": cli_handler.energy is not None,
                "trifecta_echo": cli_handler.trifecta_echo is not None,
            }
            
            details["dependencies"] = dependencies
            
            # Check if any dependencies are missing
            missing_deps = [name for name, present in dependencies.items() if not present]
            if missing_deps:
                if status != "error":
                    status = "warning"
                warnings.append(f"Missing dependencies: {', '.join(missing_deps)}")
            
        except Exception as e:
            status = "error"
            warnings.append(f"CLI handler system error: {e}")
    
    # Check error count
    with _stats_lock:
        error_count = _STATS.get("errors", 0)
        if error_count > 0:
            if status != "error":
                status = "warning"
            warnings.append(f"{error_count} errors recorded")
    
    # Build health check response
    return {
        "status": status,
        "timestamp": time.time(),
        "module": "cli_handler",
        "metrics": _STATS.copy(),
        "details": details,
        "warnings": warnings
    }

def get_metrics() -> dict:
    """
    Get metrics from the CLI handler system.
    
    Returns:
        Dictionary with metrics
    """
    with _stats_lock:
        return _STATS.copy()

def shutdown() -> None:
    """
    Perform clean shutdown of CLI handler system resources.
    """
    global cli_handler
    
    if cli_handler:
        logger.info("Shutting down CLI handler system")
        # Nothing to clean up for now

# Register shutdown handler
import atexit
atexit.register(shutdown)

# ──────────────────────────────────────────────────────────────────────────
# Command handlers for META integration
# ──────────────────────────────────────────────────────────────────────────
def _cmd_cli_handler_status() -> None:
    """
    Command handler for /cli-status
    """
    if not cli_handler:
        print("CLI handler system not initialized")
        return
    
    health = health_check()
    
    print("\nCLI Handler System Status:")
    print(f"Status: {health['status'].upper()}")
    
    print("\nMetrics:")
    for name, value in health["metrics"].items():
        print(f"  {name}: {value}")
    
    print("\nDependencies:")
    for name, status in health["details"].get("dependencies", {}).items():
        status_symbol = "✓" if status else "✗"
        print(f"  {name}: {status_symbol}")
    
    if health.get("warnings"):
        print("\nWarnings:")
        for warning in health["warnings"]:
            print(f"  - {warning}")

# Export public API
__all__ = [
    'initialize',
    'health_check',
    'get_metrics',
    'shutdown',
    'CLIHandlerSystem',
    '_γ_process_cli',
    'cli_handler',
    '_cmd_cli_handler_status'
]
