#!/usr/bin/env python3
"""
Singularity Token Classification Module
--------------------------------------
Specialized token classification system with extended capabilities.

Features:
- Multiple classification strategies (regex-based, morphological, semantic)
- Thread-safe operations
- Cross-platform compatibility
- Integration with singularity_lexical and singularity_precision
- Performance metrics and health monitoring

This module extends the existing token classification system with more
sophisticated analysis approaches while maintaining backward compatibility.
"""
import re
import os
import time
import logging
import threading
from typing import Dict, List, Optional, Tuple, Union, Callable
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("singularity.token_classify")

# Thread safety
_token_classify_lock = threading.RLock()
_startup_time = time.time()

# Performance metrics
_metrics = {
    "init_time_ms": 0,
    "tokens_classified": 0,
    "cache_hits": 0,
    "errors": 0,
    "classification_time_ms": 0
}

# Caching for performance
_classification_cache = {}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Initialization and Configuration
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_initialized = False
_word_class_patterns = []

def initialize(patterns=None):
    """
    Initialize the module with word class patterns.
    
    Args:
        patterns: Optional list of (name, regex) tuples for token classification
    """
    global _initialized, _word_class_patterns
    
    with _token_classify_lock:
        # Use provided patterns or try to import from lexical/patterns modules
        if patterns:
            _word_class_patterns = patterns
        else:
            try:
                # Try to import from singularity_lexical first
                from singularity_lexical import _WORD_CLASS
                _word_class_patterns = _WORD_CLASS
                logger.info("Using word class patterns from singularity_lexical")
            except ImportError:
                # Default patterns if imports fail
                _word_class_patterns = [
                    # Legacy patterns from the original code
                    ("imperative", re.compile(r"^(run|build|create|delete)\b", re.I)),
                    ("modal", re.compile(r"^(can|should|must|may|might|could|shall|will|would)\b", re.I)),
                    ("negation", re.compile(r"^(not|never|no|none)$", re.I)),
                    ("punct_exec", re.compile(r"^[!?]$")),
                ]
                logger.warning("Using default word class patterns - singularity_lexical not found")
        
        _initialized = True
        _metrics["init_time_ms"] = (time.time() - _startup_time) * 1000
        logger.info("Token classification module initialized successfully")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Core Classification Functions
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _classify(tok: str) -> str:
    """
    Original classification logic, kept for backward compatibility.
    
    Args:
        tok: Token to classify
        
    Returns:
        Classification name
    """
    for name, rx in _word_class_patterns:
        if rx.search(tok): 
            return name
            
    # Default fallback classification
    if tok.istitle():
        return "proper_noun"
    if tok.isupper():
        return "acronym"
    if tok.isalpha():
        return "noun"
    return "glue"

def classify(tok: str) -> str:
    """
    Enhanced token classification with caching and metrics.
    
    Args:
        tok: Token to classify
        
    Returns:
        Classification name
    """
    if not _initialized:
        initialize()
    
    # Update metrics
    _metrics["tokens_classified"] += 1
    
    # Check cache first for performance
    with _token_classify_lock:
        if tok in _classification_cache:
            _metrics["cache_hits"] += 1
            return _classification_cache[tok]
    
    # Perform classification
    start_time = time.time()
    try:
        result = _classify(tok)
    except Exception as e:
        logger.error(f"Error classifying token '{tok}': {e}")
        _metrics["errors"] += 1
        result = "glue"  # Safe fallback
    
    # Update timing metrics
    _metrics["classification_time_ms"] += (time.time() - start_time) * 1000
    
    # Cache the result
    with _token_classify_lock:
        _classification_cache[tok] = result
        # Keep cache size reasonable
        if len(_classification_cache) > 10000:
            # Remove random 1000 entries to avoid memory bloat
            for _ in range(1000):
                _classification_cache.pop(next(iter(_classification_cache)), None)
    
    return result

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Extended Classification Methods
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def classify_morphological(tok: str) -> str:
    """
    Classify token based on morphological features (affixes, roots).
    
    Args:
        tok: Token to classify
        
    Returns:
        Classification name
    """
    # Suffix-based classification
    if tok.endswith(('ing')):
        return "gerund"
    elif tok.endswith(('ed')):
        return "past_tense"
    elif tok.endswith(('ly')):
        return "adverb"
    elif tok.endswith(('tion', 'sion', 'ment')):
        return "abstract_noun"
    elif tok.endswith(('er', 'or')):
        return "agent_noun"
    elif tok.endswith(('able', 'ible')):
        return "potential_adj"
    
    # Use the standard classification as fallback
    return classify(tok)

def classify_with_confidence(tok: str) -> Tuple[str, float]:
    """
    Classify token and return confidence score.
    
    Args:
        tok: Token to classify
        
    Returns:
        Tuple of (classification_name, confidence)
    """
    # Perfect match in the patterns gets highest confidence
    for name, rx in _word_class_patterns:
        if rx.search(tok):
            return name, 1.0
    
    # Secondary classification with lower confidence
    if tok.istitle():
        return "proper_noun", 0.9
    if tok.isupper():
        return "acronym", 0.85
    if tok.isalpha():
        return "noun", 0.75
    
    # Lowest confidence for unknown/punctuation
    return "glue", 0.5

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Health Monitoring and Metrics
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def get_metrics():
    """
    Get performance metrics for token classification.
    
    Returns:
        Dictionary of metrics
    """
    with _token_classify_lock:
        result = _metrics.copy()
        
        # Calculate derived metrics
        if result["tokens_classified"] > 0:
            result["cache_hit_rate"] = result["cache_hits"] / result["tokens_classified"]
            if result["classification_time_ms"] > 0:
                result["avg_classification_time_ms"] = result["classification_time_ms"] / (result["tokens_classified"] - result["cache_hits"])
        else:
            result["cache_hit_rate"] = 0
            result["avg_classification_time_ms"] = 0
            
        return result

def health_check():
    """
    Perform health check of the token classification system.
    
    Returns:
        Health status dictionary
    """
    if not _initialized:
        return {
            "status": "error",
            "message": "Token classification module not initialized",
            "timestamp": time.time()
        }
    
    metrics = get_metrics()
    cache_size = len(_classification_cache)
    
    # Determine overall status
    if metrics["errors"] > metrics["tokens_classified"] * 0.05:  # >5% error rate
        status = "warning"
        message = f"High error rate: {metrics['errors']} errors in {metrics['tokens_classified']} classifications"
    else:
        status = "healthy"
        message = f"Token classification healthy with {cache_size} cached tokens"
    
    return {
        "status": status,
        "message": message,
        "metrics": metrics,
        "patterns_count": len(_word_class_patterns),
        "cache_size": cache_size,
        "timestamp": time.time()
    }

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backward Compatibility
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def provide_backward_compatibility(target_module):
    """
    Add backward compatibility functions to the target module.
    
    Args:
        target_module: Module to inject compatibility functions into
    """
    import warnings
    
    # List of functions to inject
    compat_functions = {
        "_classify": _classify,
        "classify": classify
    }
    
    # Inject each function with a deprecation warning
    for name, func in compat_functions.items():
        # Only inject if not already present
        if not hasattr(target_module, name):
            # Create a wrapper function that shows a warning on first call
            def create_warning_wrapper(f, fname):
                warned = [False]  # Use a list for nonlocal access
                
                def wrapper(*args, **kwargs):
                    if not warned[0]:
                        warnings.warn(
                            f"Function {fname} is being used from {target_module.__name__} but "
                            f"has been moved to singularity_token_classify. Update your imports.",
                            DeprecationWarning, stacklevel=2
                        )
                        warned[0] = True
                    return f(*args, **kwargs)
                
                return wrapper
            
            # Set the function with warning wrapper
            setattr(target_module, name, create_warning_wrapper(func, name))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Memory Management
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def cleanup():
    """
    Clean up resources used by the token classification system.
    Should be called during application shutdown.
    """
    with _token_classify_lock:
        _classification_cache.clear()
        logger.info("Token classification resources cleaned up")

# Register cleanup handler
import atexit
atexit.register(cleanup)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Export Public API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
__all__ = [
    'initialize',
    'classify',
    'classify_morphological',
    'classify_with_confidence',
    'get_metrics',
    'health_check',
    'cleanup',
    'provide_backward_compatibility'
]

# Self-test when run directly
if __name__ == "__main__":
    initialize()
    
    # Test tokens
    test_tokens = [
        "run", "should", "not", "Hello", "NASA", "cat", 
        "walking", "decided", "quickly", "creation", "teacher", "readable",
        "the", ":", "42"
    ]
    
    print("Token Classification Test:")
    print("=" * 60)
    
    for token in test_tokens:
        cls = classify(token)
        morph_cls = classify_morphological(token)
        cls_conf, conf = classify_with_confidence(token)
        
        print(f"Token: '{token}'")
        print(f"  Basic Classification: {cls}")
        print(f"  Morphological: {morph_cls}")
        print(f"  With Confidence: {cls_conf} ({conf:.2f})")
        print("-" * 40)
    
    # Show metrics
    print("\nPerformance Metrics:")
    print("=" * 60)
    metrics = get_metrics()
    for key, value in metrics.items():
        print(f"{key}: {value}")
    
    # Show health check
    print("\nHealth Check:")
    print("=" * 60)
    health = health_check()
    print(f"Status: {health['status']}")
    print(f"Message: {health['message']}")
    print(f"Patterns: {health['patterns_count']}")
    print(f"Cache size: {health['cache_size']}")
