# ───────────────────────── organism_neuro.py ──────────────────────────
import os, json, time, pickle, socket, threading, uuid, pathlib, subprocess
from pathlib import Path
import torch
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer
import faiss                               # pip install faiss-cpu  (or faiss-gpu)
import readline                            # history ↑ ↓ for mini-REPL

# ---------- hardware probe ----------
CUDA_OK  = torch.cuda.is_available()
DEVICE   = torch.device("cuda" if CUDA_OK else "cpu")
GPU_NAME = torch.cuda.get_device_name(0) if CUDA_OK else "CPU"

# ---------- lightweight embedder ----------
_EMB_MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2",
                                 device=str(DEVICE))
EMB_DIM    = _EMB_MODEL.get_sentence_embedding_dimension()

# ---------- tiny local LLM (≈3 GiB) ----------
_LLM_ID   = "TheBloke/Llama-2-7B-Chat-GPTQ"
_TOKEN    = AutoTokenizer.from_pretrained(_LLM_ID, use_fast=True)
_LLM      = AutoModelForCausalLM.from_pretrained(_LLM_ID,
                        torch_dtype=torch.float16 if CUDA_OK else torch.float32,
                        device_map="auto" if CUDA_OK else None)

# ---------- Auto-load newest transformer ----------
MODELS_DIR = (Path("ecosystem") / "models").resolve()

def _load_custom_model():
    """Load the most recent custom model if available"""
    _snapshots = sorted(MODELS_DIR.glob("gpt_*")) if MODELS_DIR.exists() else []
    if not _snapshots:
        return None, None
        
    latest = _snapshots[-1]
    try:
        custom_llm = AutoModelForCausalLM.from_pretrained(
            latest, 
            torch_dtype=torch.float16 if CUDA_OK else torch.float32,
            device_map="auto" if CUDA_OK else None
        )
        custom_tok = AutoTokenizer.from_pretrained(latest)
        print(f"Loaded custom model from {latest}")
        return custom_llm, custom_tok
    except Exception as e:
        print(f"Error loading custom model: {e}")
        return None, None

# Initialize with default models
_CUSTOM_LLM, _CUSTOM_TOK = _load_custom_model()

# ---------- vector DB ----------
VEC_DIR   = Path("ecosystem") / "vectordb"
VEC_DIR.mkdir(exist_ok=True)
index_f   = VEC_DIR / "faiss.index"
META_f    = VEC_DIR / "meta.pkl"

if index_f.exists():
    index = faiss.read_index(str(index_f))
    meta  = pickle.loads(index.reconstruct(0))  # warm-up load
    with META_f.open("rb") as fh: META = pickle.load(fh)
else:
    index = faiss.IndexFlatIP(EMB_DIM)
    META  = []

# Make _save_index available externally
def _save_index():
    """Save the FAISS index and metadata to disk."""
    faiss.write_index(index, str(index_f))
    with META_f.open("wb") as fh: pickle.dump(META, fh)

# ---------- ingestion API ----------
def embed_and_store(text:str, source:str):
    vec = _EMB_MODEL.encode(text, convert_to_numpy=True, normalize_embeddings=True)
    idx = index.ntotal
    index.add(vec[None])
    META.append({"idx": idx, "src": source, "text": text[:2048]})
    if idx % 1000 == 0: _save_index()

# expose to Phase-1
def neuro_ingest(blob:str, tag="lecture"):
    # heuristic chunk to ≤400 tokens to keep embeddings cheap
    for paragraph in blob.split("\n\n"):
        p = paragraph.strip()
        if len(p.split()) < 5: continue
        embed_and_store(p, tag)

# ---------- retrieval + LLM ----------
def query(q:str, k=5, temperature=0.7, max_new=256):
    """Enhanced query function that tries custom model first, with better error handling"""
    # Try using the custom model first if available
    if _CUSTOM_LLM is not None and _CUSTOM_TOK is not None:
        try:
            prompt = f"Question: {q}\nAnswer:"
            streamer = TextIteratorStreamer(_CUSTOM_TOK, skip_prompt=True)
            gen_thr = threading.Thread(target=_CUSTOM_LLM.generate,
                    kwargs=dict(inputs=_CUSTOM_TOK(prompt, return_tensors="pt").to(DEVICE),
                                max_new_tokens=max_new,
                                temperature=temperature,
                                streamer=streamer))
            gen_thr.start()
            gen_thr.join(timeout=30)  # Add timeout to avoid hanging
            reply = "".join(token for token in streamer)
            if reply.strip():  # If we got a meaningful response
                return reply.strip()
            # Fall back to original RAG approach if response is empty
        except Exception as e:
            print(f"Custom model error: {e}, falling back to RAG")
    
    # Original RAG approach as fallback
    try:
        qv   = _EMB_MODEL.encode(q, convert_to_numpy=True, normalize_embeddings=True)
        D,I  = index.search(qv[None], k)
        context = "\n".join(META[i]["text"] for i in I[0] if i<len(META))
        prompt  = (f"[USER]{q}\n"
                f"[CONTEXT]\n{context}\n"
                f"[ASSISTANT]")
        streamer = TextIteratorStreamer(_TOKEN, skip_prompt=True)
        gen_thr  = threading.Thread(target=_LLM.generate,
                    kwargs=dict(inputs=_TOKEN(prompt,return_tensors="pt").to(DEVICE),
                                max_new_tokens=max_new,
                                temperature=temperature,
                                streamer=streamer))
        gen_thr.start()
        gen_thr.join(timeout=60)  # Add timeout to avoid hanging
        reply = "".join(token for token in streamer)
        return reply.strip()
    except Exception as e:
        return f"Error processing query: {e}"

# mini-test
if __name__ == "__main__":
    embed_and_store("Light travels approximately 299,792 kilometres per second.","seed")
    print(query("what is the speed of light?"))