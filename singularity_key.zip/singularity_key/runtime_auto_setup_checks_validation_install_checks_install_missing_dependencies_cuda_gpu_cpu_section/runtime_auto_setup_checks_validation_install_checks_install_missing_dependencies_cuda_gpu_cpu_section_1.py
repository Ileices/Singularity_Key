# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# Runtime Auto Setup and Validation - v1
# ======================================

"""
Runtime Auto Setup and Validation
--------------------------------
This script performs runtime checks to ensure all required dependencies
are available and properly configured. It will attempt to install
missing dependencies and configure the environment for optimal performance.

Features:
- Checks for required Python packages
- Validates CUDA/GPU availability
- Configures environment variables for optimal performance
- Installs missing dependencies (with user permission)
- Reports system status for inference workloads
"""

import os
import sys
import platform
import subprocess
import importlib
import logging
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s'
)
logger = logging.getLogger("runtime_setup")

# Base project path
BASE_PATH = Path(__file__).parent.parent.resolve()
REQUIREMENTS_PATH = BASE_PATH / "requirements.txt"
CONFIG_PATH = BASE_PATH / "runtime_config.json"

# Default configuration
DEFAULT_CONFIG = {
    "auto_install_dependencies": False,
    "use_gpu": True,
    "check_on_startup": True,
    "last_check_time": 0,
    "check_interval_hours": 24
}

# Required packages for different components
CORE_PACKAGES = [
    "torch", "transformers", "numpy", "pyyaml"
]

NEURAL_PACKAGES = [
    "sentence-transformers", "faiss-cpu", "pyarrow"
]

INFERENCE_PACKAGES = [
    "onnxruntime", "pyzmq"
]

AUTODATA_PACKAGES = [
    "watchdog", "pillow", "pytesseract"
]

# =============================================================================
# Utility Functions
# =============================================================================

def read_config() -> Dict:
    """Read configuration from file or create with defaults"""
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to read config: {e}")
    
    # Create default config
    with open(CONFIG_PATH, "w") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2)
    
    return DEFAULT_CONFIG

def save_config(config: Dict) -> None:
    """Save configuration to file"""
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)

def check_package(package_name: str) -> Tuple[bool, Optional[str]]:
    """Check if a package is installed and get its version"""
    try:
        module = importlib.import_module(package_name)
        version = getattr(module, "__version__", "unknown")
        return True, version
    except ImportError:
        return False, None

def install_package(package_name: str) -> bool:
    """Attempt to install a package"""
    logger.info(f"Installing {package_name}...")
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", package_name
        ])
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to install {package_name}: {e}")
        return False

def check_cuda() -> Tuple[bool, str]:
    """Check CUDA availability and version"""
    try:
        import torch
        if torch.cuda.is_available():
            return True, f"CUDA {torch.version.cuda} (device: {torch.cuda.get_device_name(0)})"
        return False, "CUDA not available"
    except ImportError:
        return False, "PyTorch not installed"

def check_rocm() -> Tuple[bool, str]:
    """Check ROCm availability for AMD GPUs"""
    try:
        import torch
        if hasattr(torch.version, 'hip') and torch.version.hip is not None:
            return True, f"ROCm {torch.version.hip}"
        return False, "ROCm not available"
    except ImportError:
        return False, "PyTorch not installed"

def get_system_info() -> Dict:
    """Get system information"""
    import psutil
    
    info = {
        "os": platform.system(),
        "python_version": platform.python_version(),
        "cpu_count": os.cpu_count(),
        "memory_gb": round(psutil.virtual_memory().total / (1024**3), 1),
    }
    
    # Add GPU info if available
    cuda_available, cuda_info = check_cuda()
    if cuda_available:
        info["gpu"] = cuda_info
    else:
        rocm_available, rocm_info = check_rocm()
        if rocm_available:
            info["gpu"] = rocm_info
        else:
            info["gpu"] = "No GPU detected"
    
    return info

# =============================================================================
# Main Check Functions
# =============================================================================

def check_dependencies() -> Dict:
    """Check all required dependencies"""
    results = {
        "core": {},
        "neural": {},
        "inference": {},
        "autodata": {},
        "missing": []
    }
    
    # Check core packages
    for pkg in CORE_PACKAGES:
        installed, version = check_package(pkg)
        results["core"][pkg] = {"installed": installed, "version": version}
        if not installed:
            results["missing"].append(pkg)
    
    # Check neural packages
    for pkg in NEURAL_PACKAGES:
        installed, version = check_package(pkg)
        results["neural"][pkg] = {"installed": installed, "version": version}
        if not installed:
            results["missing"].append(pkg)
    
    # Check inference packages
    for pkg in INFERENCE_PACKAGES:
        installed, version = check_package(pkg)
        results["inference"][pkg] = {"installed": installed, "version": version}
        if not installed:
            results["missing"].append(pkg)
    
    # Check autodata packages
    for pkg in AUTODATA_PACKAGES:
        installed, version = check_package(pkg)
        results["autodata"][pkg] = {"installed": installed, "version": version}
        if not installed:
            results["missing"].append(pkg)
    
    return results

def install_missing_dependencies(missing: List[str], auto_install: bool = False) -> bool:
    """Install missing dependencies"""
    if not missing:
        return True
    
    logger.info(f"Missing dependencies: {', '.join(missing)}")
    
    if not auto_install:
        answer = input("Would you like to install missing dependencies? (y/n): ").strip().lower()
        if answer not in ("y", "yes"):
            return False
    
    success = True
    for pkg in missing:
        if not install_package(pkg):
            success = False
    
    return success

def setup_environment() -> None:
    """Set up environment variables for optimal performance"""
    # PyTorch/CUDA optimization
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:512"
    
    # Transformers settings
    os.environ["TOKENIZERS_PARALLELISM"] = "true"
    
    # ORT settings for parallel execution
    os.environ["OMP_NUM_THREADS"] = str(max(1, os.cpu_count() // 2))

def check_inference_capabilities() -> Dict:
    """Check inference capabilities"""
    capabilities = {
        "gpu_inference": False,
        "onnx_acceleration": False,
        "distributed_inference": False,
        "rby_integration": False
    }
    
    # Check GPU inference
    cuda_available, _ = check_cuda()
    rocm_available, _ = check_rocm()
    capabilities["gpu_inference"] = cuda_available or rocm_available
    
    # Check ONNX acceleration
    try:
        import onnxruntime
        providers = onnxruntime.get_available_providers()
        capabilities["onnx_acceleration"] = "CUDAExecutionProvider" in providers or "ROCMExecutionProvider" in providers
    except ImportError:
        pass
    
    # Check distributed inference
    try:
        import zmq
        capabilities["distributed_inference"] = True
    except ImportError:
        pass
    
    # Check RBY integration
    try:
        import inference_integration
        capabilities["rby_integration"] = True
    except ImportError:
        # Try alternative check
        try:
            with open(BASE_PATH / "organism_inference.py", "r") as f:
                content = f.read()
                capabilities["rby_integration"] = "from singularity_boot import" in content and "rby" in content
        except:
            pass
    
    return capabilities

def print_status_report(dependencies: Dict, capabilities: Dict, system_info: Dict) -> None:
    """Print a status report"""
    print("\n" + "="*80)
    print(f"SINGULARITY RUNTIME STATUS REPORT")
    print("="*80)
    
    print(f"\nSystem Information:")
    print(f"  OS:            {system_info['os']}")
    print(f"  Python:        {system_info['python_version']}")
    print(f"  CPU Cores:     {system_info['cpu_count']}")
    print(f"  Memory:        {system_info['memory_gb']} GB")
    print(f"  GPU:           {system_info['gpu']}")
    
    print("\nInference Capabilities:")
    for cap, enabled in capabilities.items():
        print(f"  {cap.replace('_', ' ').title():20} {'✓' if enabled else '✗'}")
    
    print("\nDependency Status:")
    missing = dependencies.get("missing", [])
    if missing:
        print(f"  Missing Packages: {', '.join(missing)}")
    else:
        print("  All required packages installed!")
    
    print("\nKey Components:")
    components = [
        {"name": "PyTorch", "pkg": "torch"},
        {"name": "Transformers", "pkg": "transformers"},
        {"name": "ONNX Runtime", "pkg": "onnxruntime"},
        {"name": "FAISS", "pkg": "faiss-cpu"}
    ]
    
    for comp in components:
        pkg = comp["pkg"]
        for section in dependencies.values():
            if isinstance(section, dict) and pkg in section:
                info = section[pkg]
                status = "✓" if info["installed"] else "✗"
                version = info.get("version", "N/A")
                print(f"  {comp['name']:15} {status} {version}")
                break
    
    print("\nRecommendations:")
    if not capabilities["gpu_inference"]:
        print("  ⚠️ No GPU detected - inference will be slower on CPU")
        if system_info['os'] == 'Windows':
            print("     Consider installing CUDA from https://developer.nvidia.com/cuda-downloads")
    
    if missing:
        print(f"  ⚠️ Install missing dependencies with: pip install {' '.join(missing)}")
    
    if not capabilities["rby_integration"]:
        print("  ⚠️ RBY integration not detected - inference will not use RBY weights")
        print("     Ensure inference_integration.py is properly imported")
    
    print("\n" + "="*80)

# =============================================================================
# Main Function
# =============================================================================

def main() -> int:
    """Main function"""
    print("\nSingularity Runtime Setup and Validation")
    print("---------------------------------------\n")
    
    # Read configuration
    config = read_config()
    
    # Setup environment
    setup_environment()
    
    # Check dependencies
    dependencies = check_dependencies()
    
    # Install missing dependencies if configured or requested
    if dependencies["missing"]:
        success = install_missing_dependencies(
            dependencies["missing"], 
            config.get("auto_install_dependencies", False)
        )
        if success:
            # Refresh dependency check
            dependencies = check_dependencies()
    
    # Check inference capabilities
    capabilities = check_inference_capabilities()
    
    # Get system information
    system_info = get_system_info()
    
    # Print status report
    print_status_report(dependencies, capabilities, system_info)
    
    # Update config with check time
    import time
    config["last_check_time"] = int(time.time())
    save_config(config)
    
    # Return status code
    return 0 if not dependencies["missing"] else 1

if __name__ == "__main__":
    sys.exit(main())
