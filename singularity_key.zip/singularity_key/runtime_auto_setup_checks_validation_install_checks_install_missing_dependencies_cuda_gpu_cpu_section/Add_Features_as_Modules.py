


# ──────────────────────────────────────────────────────────────────────────
# 5. hook the learner we added earlier  – extend _learn_fact to push into API
# ──────────────────────────────────────────────────────────────────────────
def _learn_fact(line:str)->None:          # REUSE NAME – just *extend* body
    for rx, fn in _FACT_PATTERNS:
        m = rx.match(line)
        if not m: continue
        subj,pred,obj = fn(m)
        # (a) store triple in existing table
        gid = glyph_id(f"{subj}|{pred}|{obj}".encode())
        with con:
            con.execute("INSERT OR IGNORE INTO axiom(glyph,title,latex,definition)"
                        "VALUES(?,?,?,?)",
                        (gid, pred, pred, f"{subj} {pred} {obj}"))
        # (b) feed KnowledgeAPI
        β_kn.ingest_fact(subj,pred,obj, line)
        β_vdx.add_doc(gid, line)
        # (c) give RBY a nudge
        trifecta(line, weight=0.15)
        _log.debug(f"[β-learn] {subj} |{pred}| {obj}")
        break


# ──────────────────────────────────────────────────────────────────────────
# 6. Add interactive meta-commands (/ask   /why   /recall XYZ)
# ──────────────────────────────────────────────────────────────────────────
def _cmd_ask():
    q = input("question> ")
    print("\n" + neuro_query(q) + "\n")

META["/ask"]    = _cmd_ask

def _cmd_why():
    q=input("explain › ").strip()
    # just choose the first match for demo
    gids=β_vdx.search(q,1)
    if not gids: print("No causal data."); return
    gid=gids[0]
    row=con.execute("SELECT definition FROM axiom WHERE glyph=?",(gid,)).fetchone()
    if row: print(f"Because {row[0]}")
    else:   print("No explanation stored.")

def _cmd_recall():
    k=input("glyph or key › ").strip()
    blob=β_kv.get(k)
    if not blob:
        print("Nothing stored."); return
#    Hook _feed in lecture and interactive part – we already called _learn_fact,
#    so only ensure _learn_fact gets executed (done).
# ──────────────────────────────────────────────────────────────────────────

# end Module β
# ╰───────────────────────────  Module β  ───────────────────────────────╯

# ╭────────────────────────────  Module γ  ──────────────────────────────╮
#  Purpose: glue every input stream -> β_KnowledgeAPI  (true learning)
#           + add recall/summarise/export utilities
# ╰───────────────────────────────────────────────────────────────────────╯

import gzip as _γgz
import psutil as _γps
from datetime import datetime as _γnow
import functools as _γft

# ──────────────────────────────────────────────────────────────────────────
# 1. define _consume_block if not defined, then extend _feed inside lecture parser so it also calls _learn_fact
def _consume_block(lines: str, seq: int) -> None:
    trifecta(lines, weight=1.0)
    _log.info(f"Processed lecture block {seq}.")

#    (we monkey-patch the original _consume_block defined earlier)
# ──────────────────────────────────────────────────────────────────────────
_original_consume = _consume_block          # save ptr


def _γ_consume_block(lines:str, seq:int):
    """wrapper ⇒ original consume + fact learning per sentence"""
    # call original (handles ENERGY, RBY, idf etc.)
    _original_consume(lines, seq)

    # -------------- NEW learning pass -----------------------------------
    neuro_ingest(lines, tag=f"lecture_{seq:04d}")
    remote_call("organism_neuro.embed_and_store", lines, f"lecture_{seq:04d}")
    push_into_corpus(lines, source=f"lecture_{seq}")
    for ln in lines.splitlines():
        if ln.strip():
            _learn_fact(ln.strip())


# hot-swap
globals()['_consume_block'] = _γ_consume_block


# ──────────────────────────────────────────────────────────────────────────
# 2. intercept interactive REPL lines  (monkey-patch trifecta call site)
# ──────────────────────────────────────────────────────────────────────────
_original_trifecta_echo = lambda r,b,y: print(f"(R={r:.3f} B={b:.3f} Y={y:.3f}) ENERGY={ENERGY:.3f}")

def _γ_process_cli(line:str):
    _learn_fact(line)
    r,b,y = trifecta(line)
    _original_trifecta_echo(r,b,y)

# we just replace the small block in repl() by patching a helper:
globals()['_cli_handler'] = _γ_process_cli   # repl will call this


# ──────────────────────────────────────────────────────────────────────────
# 3. background watcher – absorb any NEW file that appears in seed_assets
# ──────────────────────────────────────────────────────────────────────────
_ASSET = (BASE / "seed_assets").resolve()
_ASSET.mkdir(exist_ok=True)

_seen = set(f.name for f in _ASSET.iterdir())

def _γ_asset_watch():
    while True:
        for fp in _ASSET.iterdir():
            if fp.name in _seen: continue
            _seen.add(fp.name)
            try:
                data = fp.read_text(encoding="utf-8", errors="ignore")
            except UnicodeDecodeError:
                continue
            _log.info("[seed_asset] NEW %s", fp.name)
            _γ_consume_block(data, seq=int(time.time())%10_000)
        time.sleep(15)

threading.Thread(target=_γ_asset_watch, daemon=True).start()


# ──────────────────────────────────────────────────────────────────────────
# 4. meta-commands  (/summarise  /export rdf|csv )
# ──────────────────────────────────────────────────────────────────────────
def _cmd_summarise():
    q = input("topic › ").strip()
    if not q: return
    gids = β_vdx.search(q, k=8)
    if not gids:
        print("No knowledge yet.")
        return
    bits=[]
    for gid in gids:
        row = con.execute("SELECT definition FROM axiom WHERE glyph=?",(gid,)).fetchone()
        if row: bits.append(row[0])
    text = "; ".join(bits)[:600]
    print("⊕", text if text else "No verbal definition stored.")

def _cmd_export():
    fmt = input("format (rdf/csv) › ").strip().lower()
    if fmt not in {"rdf","csv"}:
        print("choose rdf or csv"); return
    ts = _γnow().strftime("%Y%m%d_%H%M%S")
    out = ECO / f"axiom_dump_{ts}.{fmt}"
    cur = con.cursor()
    rows=cur.execute("SELECT glyph,title,definition FROM axiom").fetchall()
    if fmt=="csv":
        import csv as _γcsv
        with out.open("w",newline="",encoding="utf-8") as f:
            wr=_γcsv.writer(f)
            wr.writerow("glyph title definition".split())
            wr.writerows(rows)
    else:                         # RDF-ish Turtle
        with out.open("w",encoding="utf-8") as f:
            for g,t,d in rows:
                s=f":{g}  a :Axiom ;  :title \"{t}\" ; :definition \"{d}\" .\n"
                f.write(s)
    print("↳ exported", out)

META["/summarise"] = _cmd_summarise
META["/export"]    = _cmd_export
META["/who-leads"] = lambda: print(best_peer())
META["/ask-gpu"]   = lambda: print(llm_generate(input("Q> ")))


# ──────────────────────────────────────────────────────────────────────────
# 5. auto-vacuum + idf refresh nightly (02:30 local)
# ──────────────────────────────────────────────────────────────────────────
def _γ_nightly():
    while True:
        now = time.localtime()
        # run at 02:30
        if now.tm_hour==2 and now.tm_min==30:
            _log.info("[γ] nightly maintenance …")
            con.execute("VACUUM")
            # rebuild idf:   idf[t] = log(N/df)
            total = con.execute("SELECT COUNT(*) FROM vindex").fetchone()[0] or 1
            df=_βdd(int)
            for (_gid,vec_blob,_doc) in con.execute("SELECT gid,vec,doc FROM vindex"):
                for tok,_ in _βpkl.loads(vec_blob):
                    df[tok]+=1
            for tok,count in df.items():
                β_vdx.idf[tok] = _βm.log(total/(1+count))
            _log.info("[γ] idf refresh done (N=%s)", total)
            time.sleep(60)  # skip this minute
        time.sleep(30)

threading.Thread(target=_γ_nightly, daemon=True).start()


# ──────────────────────────────────────────────────────────────────────────
# 6. adaptive lecture gain ( logarithmic – prevents huge pastes dominating )
# ──────────────────────────────────────────────────────────────────────────
def _γ_gain(tokens:int):
    if tokens<=0: return 1.0
    return 1.0 + _βm.log10(tokens)/3   # ~1 → 3 across 1–1e6 tokens

# monkey-patch the constant used in _consume_block
globals()['LECTURE_GAIN'] = _γ_gain


# ──────────────────────────────────────────────────────────────────────────
# 7. patch repl() to use new CLI handler, keep all old behaviours
# ──────────────────────────────────────────────────────────────────────────
def repl():                      # overwrite old
    _log.info("Singularity Phase-1γ ready.  Paste • Lecture • Ask.  Ctrl-D/C.")
    lecture=False; buf=[]; seq=1
    while True:
        try:
            line=sys.stdin.readline()
            if not line:                              # EOF
                if lecture: _γ_consume_block("".join(buf),seq)
                break
            line=line.rstrip("\n")
        except KeyboardInterrupt:
            print(); break

        if lecture:
            if line in _LECTURE_OFF:
                _γ_consume_block("".join(buf),seq); buf.clear(); lecture=False; seq+=1
            else:
                buf.append(line+"\n")
            continue

        if line in _LECTURE_ON:
            lecture=True; buf=[]; continue

        if not line: continue                     # blank

        if line.startswith("/"):                  # meta command
            fn=META.get(line.strip().lower())
            if fn: fn(); continue
            print("Unknown command."); continue

        # ---------- here: regular interactive input ----------
        globals()['_cli_handler'](line)
    
    from organism_cluster import _save_index as _dummy  # no-op but keeps symmetry
    _dummy()
    from organism_neuro import _save_index as _nx_save
    _nx_save()

# Wire the /program command into META
META["/program"] = lambda arg=None: _cmd_program(arg)

# Start autonomous background workers
_auto_ingest_seed_assets()
_ProjectForge().start()
_compress_bloat()

# ────────────────────────────────────────────────────────────────────────────
# ░░░  BEGIN  CRAWLER  INJECTION  ░░░
# crawls http/https, respects robots.txt, obeys  max_outbound_kbit
# stores every page as   ecosystem/seed_assets/http_<sha>.txt
# after each page it calls  _consume_block(...)  (same routine used for lectures)
# ────────────────────────────────────────────────────────────────────────────
import asyncio, aiohttp, urllib.robotparser, textwrap
from aiohttp import ClientTimeout
from urllib.parse import urlparse
_CRAWL_CFG   = CFG.get("crawler" , {})              # see YAML snippet below
_CRAWL_ROOTS = _CRAWL_CFG.get("seeds" , [])
_CRAWL_RATE  = _CRAWL_CFG.get("pages_per_min", 30)
_CRAWL_MAX   = _CRAWL_CFG.get("max_pages",    500)
_OUT_KBIT    = CFG.get("max_outbound_kbit", 0)

_SEED_ASSETS = ECO / "seed_assets"
_SEED_ASSETS.mkdir(exist_ok=True)

_async_sem   = asyncio.Semaphore(max(1, _CRAWL_RATE//60))
_seen        = set()         # normalised URLs we already ingested
_rp_cache    = {}            # robots.txt parsers

def _robots_ok(url:str)->bool:
    dom  = urlparse(url).netloc
    if dom not in _rp_cache:
        rp = urllib.robotparser.RobotFileParser()
        try:
            rp.set_url(f"https://{dom}/robots.txt")
            rp.read()
        except Exception:
            rp = None
        _rp_cache[dom] = rp
    return True if rp is None else rp.can_fetch("*", url)

async def _fetch(session, url):
    if url in _seen or not _robots_ok(url): return
    _seen.add(url)
    try:
        async with _async_sem, session.get(url, timeout=ClientTimeout(total=12)) as r:
            if r.status!=200 or "text/html" not in r.headers.get("Content-Type",""):
                return
            txt = await r.text()
            fname = f"http_{hash(url)%2**32:x}.txt"
            (ECO/"seed_assets").joinpath(fname).write_text(
                f"{url}\n\n{textwrap.shorten(txt,20000,' [...]')}",
                encoding="utf-8", errors="ignore")
            _consume_block(txt, seq=9999)        # weight==lecture_gain
            _log.info(f"[crawler] ingested {url}")
            if len(_seen) >= _CRAWL_MAX: raise asyncio.CancelledError
            # simple link-harvest
            for m in re.finditer(r'href="(https?://[^"#]+)"', txt, re.I):
                asyncio.create_task(_fetch(session, m.group(1)))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        _log.debug(f"[crawler] {url} : {e}")

async def _crawl_loop():
    if _OUT_KBIT<=0 or not _CRAWL_ROOTS: return
    async with aiohttp.ClientSession() as sess:
        for u in _CRAWL_ROOTS:
            asyncio.create_task(_fetch(sess,u))
        try:
            while True: await asyncio.sleep(3600)
        except asyncio.CancelledError: pass

def start_crawler():
    loop = asyncio.new_event_loop()
    threading.Thread(target=loop.run_until_complete,
                     args=(_crawl_loop(),), daemon=True).start()

##############################################################################
# -- crawler controls --------------------------------------------------------
##############################################################################
_crawl_loop_handle = None        # will hold the asyncio loop thread

def start_crawler():
    global _crawl_loop_handle
    if _crawl_loop_handle is not None:
        print("[crawler] already running"); return
    print("[crawler] ▶ starting …")
    _crawl_loop_handle = threading.Thread(target=lambda:asyncio.run(_crawl_loop()),daemon=True)
    _crawl_loop_handle.start()

def stop_crawler():
    global _crawl_loop_handle
    if _crawl_loop_handle and _crawl_loop_handle.is_alive():
        print("[crawler] ■ stopping …")
        try:
            # Create a new event loop for cancellation
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            for task in asyncio.all_tasks(loop):
                task.cancel()
            _crawl_loop_handle = None
        except Exception as e:
            print(f"[crawler] error during stop: {e}")
    else:
        print("[crawler] not running")

def crawler_status():
    if _crawl_loop_handle and _crawl_loop_handle.is_alive():
        print(f"[crawler] running — pages seen: {len(_seen)} / {_CRAWL_MAX}")
    else:
        print("[crawler] stopped")

def add_root_url(u):
    if not u:
        print("usage:  /crawl add <full-URL>")
        return
    _CRAWL_ROOTS.append(u.strip())
    print(f"[crawler] seed added: {u.strip()}")

def set_crawl_limit(n):
    try:
        n = int(n)
        global _CRAWL_MAX
        _CRAWL_MAX = n
        print(f"[crawler] max pages set → {n}")
    except Exception: 
        print("usage: /crawl max <int>")

# Update META with crawler controls
META.update({
    "/crawl-on"      : lambda : start_crawler(),
    "/crawl-off"     : lambda : stop_crawler(),
    "/crawl-status"  : lambda : crawler_status(),
    "/crawl-add"     : lambda url=None: add_root_url(input("URL to add: ").strip() if url is None else url),
    "/crawl-max"     : lambda n=None: set_crawl_limit(input("Max pages: ").strip() if n is None else n),
})

start_crawler()
# ░░░  END  CRAWLER  INJECTION  ░░░
# ────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────
# ░░░  BEGIN  WAN-FEDERATION  INJECTION  ░░░
# connects to ws://RELAY_HOST:8765 , exchanges {"stats":{gpu,ram,storage}}
# the node with max(score) becomes MASTER and publishes  ⟐model_sync events
# ░░░  add in config:   relay_host: 1.2.3.4   ░░░
# ────────────────────────────────────────────────────────────────────────────
import psutil, websockets, json, asyncio, platform

_relay_host = CFG.get("relay_host")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
if _relay_host:
    _LLM_LOCAL = BASE / "llm_local"
    _LLM_LOCAL.mkdir(exist_ok=True)
    
    def _ensure_model_downloaded():
        _log.info("Downloading model weights (placeholder implementation)")
    
    def _ensure_model_downloaded():
        _log.info("Downloading model weights (placeholder implementation)")
    
    from transformers import AutoModelForCausalLM
    async def _wan_peer():
        uri = f"ws://{_relay_host}:8765"
        while True:
            try:
                async with websockets.connect(uri, max_size=2**22) as ws:
                    # announce self
                    stats = {
                        "gpu": torch.cuda.device_count()*torch.cuda.get_device_properties(0).multi_processor_count if torch.cuda.is_available() else 0,
                        "ram": psutil.virtual_memory().total//2**30,
                        "disk": shutil.disk_usage(str(BASE)).total//2**30,
                        "hostname": platform.node()
                    }
                    await ws.send(json.dumps({"stats":stats}))
                    async for msg in ws:
                        data=json.loads(msg)
                        if "model_sync" in data and DEVICE=="cpu":   # light node pulls weights
                            _ensure_model_downloaded()  # makes local dir
                            AutoModelForCausalLM.from_pretrained(
                                data["model_sync"]).save_pretrained(_LLM_LOCAL)
            except Exception as e:
                _log.warning(f"[WAN] {e} – reconnecting in 30 s"); await asyncio.sleep(30)

    threading.Thread(target=lambda: asyncio.run(_wan_peer()),
                     daemon=True).start()
# ░░░  END  WAN-FEDERATION  INJECTION  ░░░
# ────────────────────────────────────────────────────────────────────────────