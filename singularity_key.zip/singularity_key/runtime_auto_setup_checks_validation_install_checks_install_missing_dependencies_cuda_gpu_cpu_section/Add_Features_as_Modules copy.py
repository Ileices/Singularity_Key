# ╭──────────────────────── bootstrap & config ─────────────────────────────╮
BASE   = pathlib.Path(__file__).parent.resolve()
CFG    = yaml.safe_load((BASE / "singularity_config.yml").read_text(encoding="utf-8"))

_log.basicConfig(level=_log.INFO,
                 format="%(asctime)s | %(levelname)s | %(message)s",
                 handlers=[_log.StreamHandler(sys.stdout)])

# precision -----------------------------------------------------------------
if CFG.get("high_precision_mode"):
    getcontext().prec = 60
    _FNUM = Decimal
    _log.info("Decimal-60 precision active.")
else:
    _FNUM = float

PHI = (_FNUM(1)+_FNUM(5).sqrt())/2 if CFG.get("high_precision_mode") else (1+5**0.5)/2
R0,B0,Y0 = (_FNUM(CFG["rby_baseline"][k]) for k in ("R0","B0","Y0"))

# Initialize TOKEN_W from config or as empty dict
TOKEN_W = CFG.get("TOKEN_W", {})

# glyph helpers -------------------------------------------------------------
_GLY_RE = re.compile(CFG["glyph_regex"])
valid_glyph = _GLY_RE.fullmatch
glyph_id    = lambda b: f"⟐{_h.blake2b(b,digest_size=8).hexdigest()}"

# storage paths -------------------------------------------------------------
ECO        = (BASE / "ecosystem").resolve(); ECO.mkdir(exist_ok=True)
LECTUREDIR = ECO / "lectures";              LECTUREDIR.mkdir(exist_ok=True)
PTDB       = ECO / "periodic_table.db"
EXC        = ECO / "excretions.log"
# ── asset folders ──────────────────────────────────────────────────────────
ASSETS      = (BASE / "seed_assets").resolve()
ASSETS.mkdir(exist_ok=True)
PROC_ASSETS = (ECO  / "processed_assets").resolve()
PROC_ASSETS.mkdir(exist_ok=True)

# periodic-table ------------------------------------------------------------
con = sqlite3.connect(PTDB)
con.executescript("""
CREATE TABLE IF NOT EXISTS axiom(
 id INTEGER PRIMARY KEY,
 glyph TEXT UNIQUE, title TEXT, latex TEXT, definition TEXT);
CREATE TABLE IF NOT EXISTS term(
 id INTEGER PRIMARY KEY,
 term TEXT UNIQUE, glyph TEXT);
""")
for ax in CFG.get("axioms", []):
    con.execute("""INSERT OR IGNORE INTO axiom(glyph,title,latex,definition)
                   VALUES(?,?,?,?)""",(ax["glyph"],ax["title"],ax["latex"],ax["definition"]))
con.commit()

# Add missing definitions
META = {}  # Initialize empty dictionary for META commands
_LECTURE_ON = ["<BEGIN LECTURE>", "```lecture", "```block"]
_LECTURE_OFF = ["<END LECTURE>", "```", "</lecture>"]

# ──── ✂︎ BEGIN PATCH — add knowledge DB and fact patterns ────────────────
KNOWDB = ECO / "knowledge.db"
kcon   = sqlite3.connect(KNOWDB)
kcon.executescript("""
CREATE TABLE IF NOT EXISTS fact(
  id INTEGER PRIMARY KEY,
  subj TEXT, pred TEXT, obj TEXT,
  UNIQUE(subj,pred,obj)
);
""")

_FACT_PATTERNS = [
    #  1)  "my name is Alice"   →  subj=⟂self   pred=name   obj=Alice
    (re.compile(r"\bmy name is (?P<obj>.+)", re.I),
        lambda m: ("⟂self", "name", m.group("obj").strip("."))),
    #  2)  "X is Y"  (simple definitional)
    (re.compile(r"^(?P<subj>[\w\s]+?) is (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "is", m.group("obj").strip("."))),
]

# ─── richer natural-language fact patterns ──────────────────────────────────
_EXTRA_FACT_PATTERNS = [
    # 3) "I am 42 years old" / "I'm 42"  →  ⟂self, age, 42 years old
    (re.compile(r"\bI\s*(?:am|'m)\s+(?P<obj>\d+\s*(?:years?\s*old)?)", re.I),
        lambda m: ("⟂self", "age", m.group("obj").strip("."))),
    
    # 4) "Alice has 3 cats"  → subj=Alice, pred=has, obj=3 cats
    (re.compile(r"^(?P<subj>[\w\s]+?) has (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "has", m.group("obj").strip("."))),
    
    # 5) "The capital of France is Paris"  → subj=France, pred=capital, obj=Paris
    (re.compile(r"^(?:the\s+)?capital of (?P<subj>[\w\s]+?) is (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "capital", m.group("obj").strip("."))),
    
    # 6) "Mount Everest is in Nepal"  → subj=Mount Everest, pred=location, obj=Nepal
    (re.compile(r"^(?P<subj>[\w\s]+?) is in (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "location", m.group("obj").strip("."))),
    
    # 7) "Einstein was born on 14 March 1879"
    (re.compile(r"^(?P<subj>[\w\s]+?) was born on (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "birth_date", m.group("obj").strip("."))),
    
    # 8) "Water boils at 100°C"
    (re.compile(r"^(?P<subj>[\w\s]+?) boils at (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "boils_at", m.group("obj").strip("."))),
    
    # 9) "π equals 3.14159" / "X equals Y"
    (re.compile(r"^(?P<subj>[\w\s]+?) equals (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "equals", m.group("obj").strip("."))),
    
    #10) "Sodium, also known as Na,"  → subj=Sodium, pred=alias, obj=Na
    (re.compile(r"^(?P<subj>[\w\s]+?), also known as (?P<obj>[\w\s]+)", re.I),
        lambda m: (m.group("subj").strip().rstrip(","), "alias", m.group("obj").strip("."))),
    
    #11) "Photosynthesis means creating energy from light"
    (re.compile(r"^(?P<subj>[\w\s]+?) means (?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "means", m.group("obj").strip("."))),
    
    #12) "The symbol for gold is Au"
    (re.compile(r"^(?:the\s+)?symbol for (?P<subj>[\w\s]+?) is (?P<obj>\w+)", re.I),
        lambda m: (m.group("subj").strip(), "symbol", m.group("obj").strip("."))),
]
_FACT_PATTERNS.extend(_EXTRA_FACT_PATTERNS)

# ─── MATH / SCIENCE "fact" patterns ─────────────────────────────────────────
_SCI_MATH_PATTERNS: list[tuple[re.Pattern, callable]] = [
    # 13) "Let x be the length of the rod"
    (re.compile(r"\blet (?P<subj>\w+) be (?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "defined_as", m.group("obj"))),
    
    # 14) "x ∈ ℝ" or "n ∈ ℤ"
    (re.compile(r"^(?P<subj>\w+)\s*∈\s*(?P<obj>.+)$", re.I),
        lambda m: (m.group("subj"), "in_set", m.group("obj"))),
    
    # 15) "f is continuous on (a,b)"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(?P<pred>continuous|differentiable|integrable)\s+on\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), m.group("pred"), m.group("obj"))),
    
    # 16) "E = mc^2"
    (re.compile(r"^(?P<subj>[^=]+?)\s*=\s*(?P<obj>.+)$"),
        lambda m: (m.group("subj").strip(), "equals", m.group("obj").strip())),
    
    # 17) "p ≥ 0" or "θ < π/2"
    (re.compile(r"^(?P<subj>[^<>=]+?)\s*(?P<sym>[<>]=?)\s*(?P<obj>.+)$"),
        lambda m: (m.group("subj").strip(), m.group("sym"), m.group("obj").strip())),
    
    # 18) "c is 3.00×10^8 m/s"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(?P<obj>[\d\.\s×\^eE\-\+]+.*)$"),
        lambda m: (m.group("subj"), "value", m.group("obj"))),
    
    # 19) "Theorem X states that …"
    (re.compile(r"^(?P<subj>[\w\s\-]+?)\s+states that\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), "states", m.group("obj"))),
    
    # 20) "Smith et al. (2021) showed that …"
    (re.compile(r"^(?P<subj>[\w\s\.]+?)\s*\(\s*\d{4}\s*\)\s+(?P<pred>showed|proved|demonstrated|found)\s+that\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj").strip(), m.group("pred"), m.group("obj"))),
    
    # 21) "H₂O is water"
    (re.compile(r"^(?P<subj>[A-Za-z0-9₀-₉\(\)]+)\s+is\s+(?P<obj>[\w\s\-]+)$", re.I),
        lambda m: (m.group("subj"), "alias_of", m.group("obj"))),
    
    # 22) "2 H₂ + O₂ → 2 H₂O"
    (re.compile(r"^(?P<subj>.+?)\s*→\s*(?P<obj>.+)$"),
        lambda m: (m.group("subj").strip(), "yields", m.group("obj").strip())),
    
    # 23) "dV/dt equals …"
    (re.compile(r"^(?P<subj>d\w+/d\w+)\s+equals\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "equals", m.group("obj"))),
]
_FACT_PATTERNS.extend(_SCI_MATH_PATTERNS)

# ─── NLP / LEXICON fact-patterns ───────────────────────────────────────────
_NLP_PATTERNS: list[tuple[re.Pattern, callable]] = [

    # 24) Dictionary-style definition:  "serendipity means fortunate discovery"
    (re.compile(r"^(?P<subj>\w+)\s+(means|signifies|denotes)\s+(?P<obj>.+)", re.I),
        lambda m: (m.group("subj"), "means", m.group("obj"))),

    # 25) Synonymy:  "happy is synonymous with joyful"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(synonymous with|a synonym of)\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "synonym", m.group("obj"))),

    # 26) Antonymy:  "cold is the opposite of hot"
    (re.compile(r"^(?P<subj>\w+)\s+(is|'s)\s+the\s+opposite\s+of\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "antonym", m.group("obj"))),

    # 27) Hypernym / hyponym:  "A robin is a kind of bird"
    (re.compile(r"^(?P<subj>[\w\s]+?)\s+is\s+(a\s+kind|type)\s+of\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj").strip(), "hyponym_of", m.group("obj"))),

    # 28) Part-of-speech annotation:  "run is a verb"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+(a|an)\s+(?P<obj>noun|verb|adjective|adverb|pronoun|preposition|conjunction|interjection)", re.I),
        lambda m: (m.group("subj"), "part_of_speech", m.group("obj"))),

    # 29) Morphological rule:  "plural of mouse is mice"
    (re.compile(r"^plural of (?P<subj>\w+)\s+is\s+(?P<obj>\w+)", re.I),
        lambda m: (m.group("subj"), "plural", m.group("obj"))),

    # 30) Translation gloss:  "'hello' in French is 'bonjour'"
    (re.compile(r"[\"'""]?([\w\s]+)[\"'""]?\s+in\s+(?P<lang>\w+)\s+is\s+[\"'""]?(?P<obj>.+)[\"'""]?", re.I),
        lambda m: (m.group(1).strip(), f"translation_{m.group('lang').lower()}", m.group("obj").strip())),

    # 31) Pronunciation / IPA:  "queue is pronounced /kjuː/"
    (re.compile(r"^(?P<subj>\w+)\s+is\s+pronounced\s+(?P<obj>/.*?/)", re.I),
        lambda m: (m.group("subj"), "pronunciation", m.group("obj"))),

    # 32) Language-family membership:  "Basque belongs to the language isolate family"
    (re.compile(r"^(?P<subj>\w+)\s+belongs to (the )?(?P<obj>.+?) family", re.I),
        lambda m: (m.group("subj"), "in_family", m.group("obj"))),
]
_FACT_PATTERNS.extend(_NLP_PATTERNS)

# ─────────────────── Fact-extraction & persistence ────────────────────────
def _persist_fact(line:str)->None:
    """Try to harvest (subject,predicate,object) from *line* into periodic-table DB."""
    for rx, fn in _FACT_PATTERNS:
        m = rx.match(line)
        if not m:                                  # no match → keep trying
            continue
        subj, pred, obj = fn(m)

        # 1) store in DB  (subject & object as rows, predicate inside axiom)
        gid = glyph_id(f"{subj}|{pred}|{obj}".encode())
        with con:                                  # transaction
            con.execute("INSERT OR IGNORE INTO term(term,glyph) VALUES(?,?)", (subj, gid))
            con.execute("INSERT OR IGNORE INTO term(term,glyph) VALUES(?,?)", (obj, gid))
            con.execute(
              "INSERT OR IGNORE INTO axiom(glyph,title,latex,definition)"
              "VALUES(?,?,?,?)",
              (gid, pred, pred, f"{subj} {pred} {obj}")
            )

        # 2) optional console feedback
        _log.info(f"[FACT] {subj} ▸{pred}▸ {obj}  → {gid}")

        # 3) feed into RBY cycle once so ENERGY / DNA reflect it
        trifecta(f"{subj} {pred} {obj}", weight=0.2)
        break                      # stop after the first successful pattern

def _learn_fact(line: str) -> None:
    """Try to parse *line* and insert a fact if pattern matches."""
    for rx, builder in _FACT_PATTERNS:
        m = rx.match(line)
        if m:
            subj, pred, obj = builder(m)
            try:
                kcon.execute("INSERT OR IGNORE INTO fact(subj,pred,obj) VALUES(?,?,?)",
                             (subj.lower(), pred.lower(), obj))
                kcon.commit()
            except Exception as e:
                _log.error(f"knowledge-insert failed: {e}")
            break

def _answer(question: str) -> Optional[str]:
    """Very small deterministic QA engine."""
    q = question.lower().strip().rstrip("?")
    if q in {"who am i", "who am i"}:
        row = kcon.execute("SELECT obj FROM fact WHERE subj='⟂self' AND pred='name'").fetchone()
        if row:
            return f"You are {row[0]}."
    m = re.match(r"who is (.+)", q)
    if m:
        subj = m.group(1).strip()
        row = kcon.execute("SELECT obj FROM fact WHERE subj=? AND pred='is'", (subj,)).fetchone()
        if row:
            return f"{subj} is {row[0]}."
    m = re.match(r"what is (.+)", q)
    if m:
        subj = m.group(1).strip()
        row = kcon.execute("SELECT obj FROM fact WHERE subj=? AND pred='is'", (subj,)).fetchone()
        if row:
            return f"{subj} is {row[0]}."
    return None

# ────────────────────────────────────────────────────────────────────────────
# Lexical classes & dynamic token-weights
# ────────────────────────────────────────────────────────────────────────────
#
#  •  Six new high-level classes:  
#       STOP,   CONJ,  QWORD,  AUX,   STATE,  NUMBER
#  •  Ultra-light default RBY for stop-/function-words
#  •  "Unknown-word tuner" – every unseen token is given an
#     adaptive RBY vector based on the sentence it first appears in.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 1) static, pre-seeded weights  (fine-tune in YAML later if you wish)
#    R,B,Y values are _FNUM so they respect high-precision mode.
# ---------------------------------------------------------------------------
STATIC_TOKEN_W = {
    # existing classes (may already be in your YAML):
    "imperative": TOKEN_W.get("imperative", (_FNUM("0.05"), _FNUM("0.15"), _FNUM("0.80"))),
    "modal"     : TOKEN_W.get("modal"     , (_FNUM("0.15"), _FNUM("0.70"), _FNUM("0.15"))),
    "negation"  : TOKEN_W.get("negation"  , (_FNUM("0.20"), _FNUM("0.60"), _FNUM("0.20"))),
    "punct_exec": TOKEN_W.get("punct_exec", (_FNUM("0.00"), _FNUM("0.00"), _FNUM("1.00"))),

    # NEW: stop/function words     – almost zero execution value
    "stop"      : (_FNUM("0.01"), _FNUM("0.05"), _FNUM("0.02")),
    "conj"      : (_FNUM("0.02"), _FNUM("0.08"), _FNUM("0.02")),

    # NEW: question words ("who / what …") – cognition-heavy
    "qword"     : (_FNUM("0.05"), _FNUM("0.85"), _FNUM("0.10")),

    # NEW: auxiliaries / light verbs
    "aux"       : (_FNUM("0.10"), _FNUM("0.30"), _FNUM("0.60")),

    # NEW: state adjectives ("full / empty / broken …")
    "state"     : (_FNUM("0.25"), _FNUM("0.55"), _FNUM("0.20")),

    # NEW: numeric tokens captured via regex  (good for math facts)
    "number"    : (_FNUM("0.40"), _FNUM("0.50"), _FNUM("0.10")),
}

# ---------------------------------------------------------------------------
# 2) regex maps for the new classes
# ---------------------------------------------------------------------------
_WORD_CLASS = [
    # HIGH-PRIORITY specialised classes first
    ("stop", re.compile(r"^(?:a|an|the|and|or|of|in|on|to|for|with|as|at|by|from)$", re.I)),
    ("conj", re.compile(r"^(?:but|yet|so|nor|though|although)$", re.I)),
    ("qword", re.compile(r"^(?:who|what|when|where|why|how|which|whom|whose)$", re.I)),
    ("aux", re.compile(r"^(?:do|does|did|dont|doesnt|go|goes|went|try|tries|tried|help|fix|run|make)$", re.I)),
    ("state", re.compile(r"^(?:full|empty|none|complete|incomplete|broken|ready|busy|idle)$", re.I)),
    ("number", re.compile(r"^\d+(\.\d+)?$")),   #  42   3.14159 …

    # legacy specialised classes
    ("imperative", re.compile(r"^(run|build|create|delete)\b", re.I)),
    ("modal",      re.compile(r"^(can|should|must|may|might|could|shall|will|would)\b", re.I)),
    ("negation",   re.compile(r"^(not|never|no|none)$", re.I)),
    ("punct_exec", re.compile(r"^[!?]$")),
]

# ---------------------------------------------------------------------------
# 3) dynamic weight table   (+ persistence later if you like)
# ---------------------------------------------------------------------------
from typing import Union

from typing import Union
_DYNAMIC_W: dict[str, tuple[Union[float, Decimal], Union[float, Decimal], Union[float, Decimal]]] = {}

# ---------------------------------------------------------------------------
# 4) helper – look up / learn weight for one token
# ---------------------------------------------------------------------------
def _get_weight(tok: str, ctx_rby: Optional[Tuple[float, float, float]] = None) -> Tuple[Union[float, Decimal], Union[float, Decimal], Union[float, Decimal]]:
    """Return (R,B,Y) for *tok*.
       • prefer static table
       • else check dynamic table
       • else *learn*: estimate from ctx_rby or fall back to (R0,B0,Y0)."""
    # Static?
    cls = _classify(tok)
    if cls in STATIC_TOKEN_W:
        return STATIC_TOKEN_W[cls]

    # Dynamic already?
    if tok in _DYNAMIC_W:
        return _DYNAMIC_W[tok]

    # Learn a first guess
    if ctx_rby is not None:
        # split context evenly among new words in the sentence
        est = tuple(v * _FNUM("0.20") for v in ctx_rby)   # 20 % of sentence energy
    else:
        est = (R0, B0, Y0)

    _DYNAMIC_W[tok] = est
    return est

# ---------------------------------------------------------------------------
# 5) new classify()  (rename old → _classify to avoid collision)
# ---------------------------------------------------------------------------
def _classify(tok:str)->str:          # keep the original classification logic
    for name,rx in _WORD_CLASS:
        if rx.match(tok): return name
    if tok.istitle():  return "proper_noun"
    if tok.isupper():  return "acronym"
    if tok.isalpha():  return "noun"
    return "glue"

def classify(tok:str)->str:           # external callers get fresh behaviour
    return _classify(tok)             # (exposed for debugging if you need)


# ---------------------------------------------------------------------------
# 6) update **rby()** to use dynamic weights
# ---------------------------------------------------------------------------
def rby(tok:str, ctx:Optional[tuple[float, float, float]]=None
       ) -> tuple[float, float, float]:
    return _get_weight(tok, ctx_rby=ctx)

# ────────────────────────────────────────────────────────────────────────────
# End of lexical-class upgrade
# ────────────────────────────────────────────────────────────────────────────

# apical-pulse & energy -----------------------------------------------------
A,T,BETA = (_FNUM(CFG["apical_pulse"][k]) for k in ("amplitude","period_seconds","damping_beta"))
_t0=_dt.datetime.utcnow(); _2π_over_T=2*_m.pi/float(T)
def delta_E(now=None):
    t=(now or _dt.datetime.utcnow()-_t0).total_seconds()
    return _FNUM(float(A)*_m.sin(_2π_over_T*t)*_m.exp(-float(BETA)*t))

# memory & logs -------------------------------------------------------------
def log_excretion(msg:str):
    with open(EXC,"a",encoding="utf-8") as f:
        f.write(f"{_dt.datetime.utcnow().isoformat()} | {msg}\n")

ENERGY=_FNUM(1); DNA=deque(maxlen=10_000); _HIST=deque(maxlen=4096)

# basic RBY helpers ---------------------------------------------------------
def _sum(txt,idx,default): v=sum(rby(t)[idx] for t in txt.split()); return v or default
def perception(t): return _sum(t,0,R0)
def cognition (t): return _sum(t,1,B0)
def execution (t):
    y=_sum(t,2,Y0)
    gid=glyph_id(t.encode())
    if valid_glyph(gid): log_excretion(f"GLYPH {gid} {t[:40]}")
    return y
def trifecta(text, weight=1.0):
    global ENERGY
    w = _FNUM(weight)  # convert weight to _FNUM to ensure type consistency
    r,b,y = perception(text)*w, cognition(text)*w, execution(text)*w
    DNA.append((r,b,y))
    _HIST.append(r+b+y)
    ENERGY += delta_E()
    return r,b,y

# peer & disk guards (unchanged) -------------------------------------------
def _peer_loop():
    if CFG["max_outbound_kbit"]<=0: return
    port=CFG["primary_port"]; period=CFG.get("peer_broadcast_period_s",60)
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
    sock.bind(("",port))
    while True:
        pkt=_json.dumps({"t":time.time(),"gid":glyph_id(str(time.time()).encode())}).encode()
        sock.sendto(pkt,("255.255.255.255",port)); time.sleep(period)
threading.Thread(target=_peer_loop,daemon=True).start()

def _disk_guard():
    thresh=CFG["disk_collapse_free_percent"]
    while True:
        total,used,free=shutil.disk_usage(ECO)
        if 100*free/total < thresh:
            log_excretion("COMPRESSION-BEGIN")
            digest=_h.sha256(_json.dumps(list(DNA)).encode()).hexdigest()
            log_excretion(f"DNA-COMPRESS {glyph_id(digest.encode())}"); DNA.clear()
        time.sleep(300)
threading.Thread(target=_disk_guard,daemon=True).start()

# ───────────────────────── CLUSTER-PLUS  (inject as one block) ───────────────────────
"""
All public entry points:
    ClusterPlus.start(auto_accept: bool = True)          # boot networking
    ClusterPlus.put_job(kind:str, fn:str, args:tuple, kw:dict) -> Any
            kind ∈ {"gpu","cpu"}   – remote-exec with fallback chain
    ClusterPlus.best_path(size_MiB:int) -> pathlib.Path
            returns a writable sub-dir (local or remote mount) that still
            has ≥ size_MiB free.
Nothing else in your organism needs to change.
"""
from __future__ import annotations
import json, os, socket, struct, threading, time, queue, pickle, pathlib, shutil, psutil, subprocess
from   typing import Dict, Tuple, Any, Callable
import torch, logging as _log

# ===== 0. CONSTANTS =========================================================
_CL_PORT     = 39401
_PROTO_ID    = b'\xE2\x9F\x90CLU'  # 4-byte magic, ignore foreign traffic
_AD, _REQ, _ACK, _DEN, _RPC     = range(1,6)

_TASK_TIMEOUT = 30              # sec – if no response, run locally
_BROADCAST    = ('255.255.255.255', _CL_PORT)

_BASE  = pathlib.Path(__file__).parent.resolve()
_NETFS = _BASE / "net_mounts"    # local dir where remote shares are mounted

# ===== 1. helpers ===========================================================
def _profile() -> Dict[str,Any]:
    """live hardware & capacity report"""
    cuda = torch.cuda.is_available()
    rocm = torch.version.hip is not None and torch.version.hip != ""
    disks = { d.mountpoint: psutil.disk_usage(d.mountpoint).free//2**30
              for d in psutil.disk_partitions(all=False)
              if os.access(d.mountpoint, os.W_OK) }
    return dict(
        host   = socket.gethostname(),
        pid    = os.getpid(),
        cores  = psutil.cpu_count(logical=False),
        ram    = psutil.virtual_memory().total//2**30,
        cuda   = cuda,
        rocm   = rocm,
        vram   = torch.cuda.get_device_properties(0).total_memory//2**30
                 if cuda else 0,
        free_gb= sum(disks.values()),
        disks  = disks,
        ts     = time.time()
    )

def _score(p:Dict)->int:        # bigger = better
    s  = p["cores"]*10 + p["ram"]
    s += p["free_gb"]//10
    s += p["vram"]*5
    if p["cuda"]: s += 500
    elif p["rocm"]: s += 300
    return s

# ===== 2.  Cluster object ===================================================
class ClusterPlus:
    ME        = _profile()
    PEERS: Dict[str,Dict] = {}        # ip -> profile
    AUTO      = True
    LEADER    = ME["host"]
    _jobs     = queue.Queue()         # local tasks waiting for peer
    _pending  : Dict[str,queue.Queue] = {}   # job-id -> return-Queue

    # -----------------------------------------------------------------
    @classmethod
    def start(cls, auto_accept:bool=True):
        cls.AUTO = auto_accept
        threading.Thread(target=cls._udp_beacon, daemon=True).start()
        threading.Thread(target=cls._udp_listener, daemon=True).start()
        threading.Thread(target=cls._tcp_listener, daemon=True).start()
        threading.Thread(target=cls._arbiter     , daemon=True).start()

    # ===== PUBLIC API ==================================================
    @classmethod
    def put_job(cls, kind:str, fn:str, args:tuple=(), kw:dict|None=None):
        """Execute *fn* on best peer (kind=gpu/cpu) or fall back to local."""
        kw = kw or {}
        target = cls._choose_worker(kind)
        if target == "local":
            return globals()[fn](*args, **kw)   # direct call
        j_id  = f"{cls.ME['pid']}-{time.time_ns()}"
        qret  = queue.Queue()
        cls._pending[j_id] = qret
        payload = dict(id=j_id, kind=kind, fn=fn, args=args, kw=kw)
        cls._rpc(target, "run", payload)
        try:                                    # wait N sec then local
            return qret.get(timeout=_TASK_TIMEOUT)
        except queue.Empty:
            _log.warning("remote job timeout – running locally")
            return globals()[fn](*args, **kw)

    @classmethod
    def best_path(cls, size_MiB:int) -> pathlib.Path:
        """Return a path (possibly mounted) guaranteed to have free space."""
        size_B = size_MiB*2**20
        candidates = [(free*2**30, pathlib.Path(mp))
                      for mp,free in cls.ME["disks"].items()]
        for peer in cls.PEERS.values():
            for mp,free in peer.get("disks",{}).items():
                candidates.append((free*2**30, cls._ensure_mount(peer["host"], mp)))
        best = max(candidates, key=lambda t:t[0] if t[0]>=size_B else -1)
        return best[1]

    # ===== NETWORK THREADS =============================================
    @classmethod
    def _udp_beacon(cls):
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
        while True:
            pkt = _PROTO_ID + struct.pack("!B",_AD) + json.dumps(cls.ME).encode()
            sock.sendto(pkt, _BROADCAST)
            time.sleep(10)

    @classmethod
    def _udp_listener(cls):
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        sock.bind(('',_CL_PORT))
        while True:
            data,addr = sock.recvfrom(16384)
            if not data.startswith(_PROTO_ID): continue
            t = data[4]
            if t!=_AD: continue
            try:
                prof=json.loads(data[5:].decode())
                if prof["pid"]==cls.ME["pid"]: continue
                cls.PEERS[addr[0]]=prof
                if prof.get("status")!="linked":
                    threading.Thread(target=cls._handshake, args=(addr[0],), daemon=True).start()
            except: pass

    @classmethod
    def _handshake(cls, ip:str):
        s=socket.socket(); s.settimeout(5)
        try:
            s.connect((ip,_CL_PORT))
            s.send(json.dumps({"type":_REQ,"prof":cls.ME}).encode())
            resp=json.loads(s.recv(4096).decode())
            if resp.get("type")==_ACK:
                cls.PEERS[ip]["status"]="linked"
        except Exception:
            pass
        finally: s.close()

    @classmethod
    def _tcp_listener(cls):
        srv=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        srv.bind(('',_CL_PORT)); srv.listen(10)
        while True:
            conn,addr = srv.accept()
            threading.Thread(target=cls._tcp_handle,args=(conn,addr),daemon=True).start()

    @classmethod
    def _tcp_handle(cls,conn,addr):
        try:
            msg=json.loads(conn.recv(16384).decode())
            if msg["type"]==_REQ:
                ok = cls.AUTO or _yes_no(f"accept node {addr[0]} ?", True)
                conn.send(json.dumps({"type": _ACK if ok else _DEN}).encode())
                if ok:
                    cls.PEERS[addr[0]] = msg["prof"]|{"status":"linked"}
            elif msg["type"]==_RPC:
                out = cls._exec_rpc(msg["call"])
                conn.send(json.dumps({"ok":out}).encode())
        except Exception as e:
            _log.error(f"tcp handle err {e}")
        finally: conn.close()

    # ===== RPC =========================================================
    @classmethod
    def _rpc(cls, host:str, action:str, payload:Any) -> Any:
        try:
            with socket.create_connection((host,_CL_PORT), timeout=8) as s:
                s.send(json.dumps({"type":_RPC,"call":[action,payload]}).encode())
                resp=json.loads(s.recv(16384).decode())
                return resp.get("ok")
        except Exception as e:
            _log.error(f"RPC to {host} failed: {e}")

    @classmethod
    def _exec_rpc(cls, call):
        action,payload = call
        if action=="run":
            return cls._do_remote_job(payload)
        return None

    @classmethod
    def _do_remote_job(cls, p:Dict):
        try:
            fn = globals()[p["fn"]]
            res = fn(*p["args"], **p["kw"])
            # send back result
            cls._rpc(p["kw"].get("origin",""), "ret", {"id":p["id"],"res":res})
            return "ok"
        except Exception as e:
            return str(e)

    # ===== OTHER HELPERS ==============================================
    @classmethod
    def _choose_worker(cls, kind:str)->str:
        """Return ip or 'local'."""
        if kind=="gpu":
            if cls.ME["cuda"] or cls.ME["rocm"]: return "local"
            gpu_peers=[(ip,p) for ip,p in cls.PEERS.items()
                       if p.get("cuda") or p.get("rocm")]
            if gpu_peers:
                ip,_=max(gpu_peers,key=lambda t:_score(t[1]))
                return ip
        # fallback: biggest CPU box
        best = max([("local",cls.ME), *[(ip,p) for ip,p in cls.PEERS.items()]],
                   key=lambda t:_score(t[1]))
        return best[0]

    @classmethod
    def _ensure_mount(cls, host:str, remote_mp:str)->pathlib.Path:
        """Very small demo: sshfs-mount once per host."""
        local = _NETFS / host.replace(".","_")
        if local.exists(): return local
        local.mkdir(parents=True, exist_ok=True)
        cmd = ["sshfs", f"{host}:{remote_mp}", str(local), "-o","ro"]
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL)
        except Exception as e:
            _log.warning(f"sshfs mount failed: {e}")
        return local

    @classmethod
    def _arbiter(cls):
        while True:
            # refresh own profile/free space every minute
            cls.ME = _profile()
            cls._elect_leader()
            time.sleep(60)

    @classmethod
    def _elect_leader(cls):
        best = max([cls.ME,*cls.PEERS.values()], key=_score)
        cls.LEADER = best["host"]

def _yes_no(q:str,default=False)->bool:
    if not sys.__stdin__.isatty(): return default
    try:
        ans=input(f"{q} [{'Y/n' if default else 'y/N'}] ").strip().lower()
        if not ans: return default
        return ans.startswith("y")
    except KeyboardInterrupt:
        return default
# ───────────────────────── CLUSTER-PLUS  (inject as one block) ───────────────────────

# ╭───────────────────────────  Module β  ───────────────────────────────╮
#  Adds:
#    • β_KVStore          – ultra-light persistent KV over SQLite
#    • β_VectorIndex      – cosine-similarity search on any text
#    • β_NLG              – quick rule-based answer generator
#    • β_KnowledgeAPI     – single public façade that wraps it all
#    • β_meta dispatcher  – new /ask /why /recall commands
#
#  *No* external deps; pure-stdlib. 400 lines incl. docs.
# ╰───────────────────────────────────────────────────────────────────────╯

import math as _βm
import itertools as _βit
from collections import defaultdict as _βdd
import threading as _βth
import random as _βrnd
import pickle  as _βpkl
from pathlib import Path as _βPath

# ──────────────────────────────────────────────────────────────────────────
# 1. persistent KV store (uses _existing_ cursor/DB connection `con`)
# ──────────────────────────────────────────────────────────────────────────
class β_KVStore:
    """Ultra-thin key/value table (string→bytes)."""
    _INIT_SQL = "CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY,val BLOB)"
    def __init__(self, dbcon):
        self.cur  = dbcon.cursor()
        self.cur.execute(self._INIT_SQL)
        self.lock = _βth.Lock()

    def __setitem__(self, k, v:bytes):
        with self.lock, self.cur.connection:
            self.cur.execute("INSERT OR REPLACE INTO kv(key,val) VALUES(?,?)",(k,v))

    def __getitem__(self, k)->bytes:
        row = self.cur.execute("SELECT val FROM kv WHERE key=?",(k,)).fetchone()
        if not row: raise KeyError(k)
        return row[0]

    def get(self, k, default=None):
        try: return self[k]
        except KeyError: return default

    def keys(self):
        return [r[0] for r in self.cur.execute("SELECT key FROM kv")]

β_kv = β_KVStore(con)          # global instance


# ──────────────────────────────────────────────────────────────────────────
# 2. Tiny in-DB vector index  (TF-idf + cosine) for fast "what facts match X"
# ──────────────────────────────────────────────────────────────────────────
class β_VectorIndex:
    """Stores 512-d sparse vectors as pickled list[(token,tfidf)]."""
    _CREATE = """CREATE TABLE IF NOT EXISTS vindex(
                   gid TEXT PRIMARY KEY, vec BLOB, doc TEXT)"""
    def __init__(self, dbcon):
        self.cur = dbcon.cursor(); self.cur.execute(self._CREATE)
        self.idf = _βdd(lambda: 1.0)   # lazy until finalise()

    # ------------- public API ------------------------------------------------
    def add_doc(self, gid:str, doc:str):
        vec = self._vectorise(doc)
        blob=_βpkl.dumps(vec, protocol=4)
        with self.cur.connection:
            self.cur.execute("INSERT OR REPLACE INTO vindex VALUES(?,?,?)",
                             (gid, blob, doc))

    def search(self, query:str, k:int=5):
        qv  = self._vectorise(query)
        qn2 = sum(v*v for _,v in qv)
        if not qn2: return []

        results=[]
        for gid, blob, _ in self.cur.execute("SELECT gid,vec,doc FROM vindex"):
            dv  = _βpkl.loads(blob)
            dot = self._dot(qv,dv)
            dn2 = sum(v*v for _,v in dv)
            if dot==0 or dn2==0: continue
            sim = dot / (_βm.sqrt(qn2)*_βm.sqrt(dn2))
            results.append((sim,gid))
        return [gid for sim,gid in sorted(results,reverse=True)[:k]]

    # ------------- helpers ---------------------------------------------------
    _TOK = re.compile(r"[A-Za-z0-9]+")

    def _vectorise(self, txt:str):
        tokens=[t.lower() for t in self._TOK.findall(txt)]
        if not tokens: return []
        tf=_βdd(int)
        for t in tokens: tf[t]+=1
        # crude idf after first 200 docs
        vec=[(t, tf[t]*self.idf[t]) for t in tf]
        return vec

    @staticmethod
    def _dot(v1,v2):
        d2=dict(v2); return sum(val*d2.get(tok,0) for tok,val in v1)

β_vdx = β_VectorIndex(con)


# ──────────────────────────────────────────────────────────────────────────
# 3. Rule-based NLG (answers who/what/when/why without LLM weight)
# ──────────────────────────────────────────────────────────────────────────
class β_NLG:
    RESP = {
        "what":  "«{subj}» is {obj}.",
        "who":   "{subj} is {obj}.",
        "name":  "Your name appears as '{obj}'.",
        "equation": "{subj} is formalised as {obj}.",
    }
    def make_answer(self, subj, pred, obj):
        tpl = self.RESP.get(pred, "{subj} {pred} {obj}.")
        return tpl.format(subj=subj, pred=pred, obj=obj)

β_nlg = β_NLG()

# ──────────────────────────────────────────────────────────────────────────
# 4. Knowledge API – ties everything together
# ──────────────────────────────────────────────────────────────────────────
class β_KnowledgeAPI:
    def __init__(self, dbcon):
        self.db = dbcon
        self.cur= dbcon.cursor()

    # --- ingestion -----------------------------------------------------------
    def ingest_fact(self, subj,pred,obj, src:str):
        gid = glyph_id(f"{subj}|{pred}|{obj}".encode())
        if β_kv.get(gid): return  # already have
        β_kv[gid]=src.encode()
        β_vdx.add_doc(gid, f"{subj} {pred} {obj}")

    # --- retrieval -----------------------------------------------------------
    def query(self, text:str):
        gids = β_vdx.search(text, k=5)
        if not gids:
            return "I don't have any facts like that yet."
        rows=[]
        for gid in gids:
            ax = self.cur.execute(
                "SELECT definition FROM axiom WHERE glyph=?", (gid,)
            ).fetchone()
            if ax:
                rows.append(ax[0])
        return " ‖ ".join(rows[:3]) if rows else "I found glyphs but no verbal facts."

β_kn = β_KnowledgeAPI(con)


# ──────────────────────────────────────────────────────────────────────────
# 5. hook the learner we added earlier  – extend _learn_fact to push into API
# ──────────────────────────────────────────────────────────────────────────
def _learn_fact(line:str)->None:          # REUSE NAME – just *extend* body
    for rx, fn in _FACT_PATTERNS:
        m = rx.match(line)
        if not m: continue
        subj,pred,obj = fn(m)
        # (a) store triple in existing table
        gid = glyph_id(f"{subj}|{pred}|{obj}".encode())
        with con:
            con.execute("INSERT OR IGNORE INTO axiom(glyph,title,latex,definition)"
                        "VALUES(?,?,?,?)",
                        (gid, pred, pred, f"{subj} {pred} {obj}"))
        # (b) feed KnowledgeAPI
        β_kn.ingest_fact(subj,pred,obj, line)
        β_vdx.add_doc(gid, line)
        # (c) give RBY a nudge
        trifecta(line, weight=0.15)
        _log.debug(f"[β-learn] {subj} |{pred}| {obj}")
        break


# ──────────────────────────────────────────────────────────────────────────
# 6. Add interactive meta-commands (/ask   /why   /recall XYZ)
# ──────────────────────────────────────────────────────────────────────────
def _cmd_ask():
    q = input("question> ")
    print("\n" + neuro_query(q) + "\n")

META["/ask"]    = _cmd_ask

def _cmd_why():
    q=input("explain › ").strip()
    # just choose the first match for demo
    gids=β_vdx.search(q,1)
    if not gids: print("No causal data."); return
    gid=gids[0]
    row=con.execute("SELECT definition FROM axiom WHERE glyph=?",(gid,)).fetchone()
    if row: print(f"Because {row[0]}")
    else:   print("No explanation stored.")

def _cmd_recall():
    k=input("glyph or key › ").strip()
    blob=β_kv.get(k)
    if not blob:
        print("Nothing stored."); return
#    Hook _feed in lecture and interactive part – we already called _learn_fact,
#    so only ensure _learn_fact gets executed (done).
# ──────────────────────────────────────────────────────────────────────────

# end Module β
# ╰───────────────────────────  Module β  ───────────────────────────────╯

# ╭────────────────────────────  Module γ  ──────────────────────────────╮
#  Purpose: glue every input stream -> β_KnowledgeAPI  (true learning)
#           + add recall/summarise/export utilities
# ╰───────────────────────────────────────────────────────────────────────╯

import gzip as _γgz
import psutil as _γps
from datetime import datetime as _γnow
import functools as _γft

# ──────────────────────────────────────────────────────────────────────────
# 1. define _consume_block if not defined, then extend _feed inside lecture parser so it also calls _learn_fact
def _consume_block(lines: str, seq: int) -> None:
    trifecta(lines, weight=1.0)
    _log.info(f"Processed lecture block {seq}.")

#    (we monkey-patch the original _consume_block defined earlier)
# ──────────────────────────────────────────────────────────────────────────
_original_consume = _consume_block          # save ptr


def _γ_consume_block(lines:str, seq:int):
    """wrapper ⇒ original consume + fact learning per sentence"""
    # call original (handles ENERGY, RBY, idf etc.)
    _original_consume(lines, seq)

    # -------------- NEW learning pass -----------------------------------
    neuro_ingest(lines, tag=f"lecture_{seq:04d}")
    remote_call("organism_neuro.embed_and_store", lines, f"lecture_{seq:04d}")
    push_into_corpus(lines, source=f"lecture_{seq}")
    for ln in lines.splitlines():
        if ln.strip():
            _learn_fact(ln.strip())


# hot-swap
globals()['_consume_block'] = _γ_consume_block


# ──────────────────────────────────────────────────────────────────────────
# 2. intercept interactive REPL lines  (monkey-patch trifecta call site)
# ──────────────────────────────────────────────────────────────────────────
_original_trifecta_echo = lambda r,b,y: print(f"(R={r:.3f} B={b:.3f} Y={y:.3f}) ENERGY={ENERGY:.3f}")

def _γ_process_cli(line:str):
    _learn_fact(line)
    r,b,y = trifecta(line)
    _original_trifecta_echo(r,b,y)

# we just replace the small block in repl() by patching a helper:
globals()['_cli_handler'] = _γ_process_cli   # repl will call this


# ──────────────────────────────────────────────────────────────────────────
# 3. background watcher – absorb any NEW file that appears in seed_assets
# ──────────────────────────────────────────────────────────────────────────
_ASSET = (BASE / "seed_assets").resolve()
_ASSET.mkdir(exist_ok=True)

_seen = set(f.name for f in _ASSET.iterdir())

def _γ_asset_watch():
    while True:
        for fp in _ASSET.iterdir():
            if fp.name in _seen: continue
            _seen.add(fp.name)
            try:
                data = fp.read_text(encoding="utf-8", errors="ignore")
            except UnicodeDecodeError:
                continue
            _log.info("[seed_asset] NEW %s", fp.name)
            _γ_consume_block(data, seq=int(time.time())%10_000)
        time.sleep(15)

threading.Thread(target=_γ_asset_watch, daemon=True).start()


# ──────────────────────────────────────────────────────────────────────────
# 4. meta-commands  (/summarise  /export rdf|csv )
# ──────────────────────────────────────────────────────────────────────────
def _cmd_summarise():
    q = input("topic › ").strip()
    if not q: return
    gids = β_vdx.search(q, k=8)
    if not gids:
        print("No knowledge yet.")
        return
    bits=[]
    for gid in gids:
        row = con.execute("SELECT definition FROM axiom WHERE glyph=?",(gid,)).fetchone()
        if row: bits.append(row[0])
    text = "; ".join(bits)[:600]
    print("⊕", text if text else "No verbal definition stored.")

def _cmd_export():
    fmt = input("format (rdf/csv) › ").strip().lower()
    if fmt not in {"rdf","csv"}:
        print("choose rdf or csv"); return
    ts = _γnow().strftime("%Y%m%d_%H%M%S")
    out = ECO / f"axiom_dump_{ts}.{fmt}"
    cur = con.cursor()
    rows=cur.execute("SELECT glyph,title,definition FROM axiom").fetchall()
    if fmt=="csv":
        import csv as _γcsv
        with out.open("w",newline="",encoding="utf-8") as f:
            wr=_γcsv.writer(f)
            wr.writerow("glyph title definition".split())
            wr.writerows(rows)
    else:                         # RDF-ish Turtle
        with out.open("w",encoding="utf-8") as f:
            for g,t,d in rows:
                s=f":{g}  a :Axiom ;  :title \"{t}\" ; :definition \"{d}\" .\n"
                f.write(s)
    print("↳ exported", out)

META["/summarise"] = _cmd_summarise
META["/export"]    = _cmd_export
META["/who-leads"] = lambda: print(best_peer())
META["/ask-gpu"]   = lambda: print(llm_generate(input("Q> ")))


# ──────────────────────────────────────────────────────────────────────────
# 5. auto-vacuum + idf refresh nightly (02:30 local)
# ──────────────────────────────────────────────────────────────────────────
def _γ_nightly():
    while True:
        now = time.localtime()
        # run at 02:30
        if now.tm_hour==2 and now.tm_min==30:
            _log.info("[γ] nightly maintenance …")
            con.execute("VACUUM")
            # rebuild idf:   idf[t] = log(N/df)
            total = con.execute("SELECT COUNT(*) FROM vindex").fetchone()[0] or 1
            df=_βdd(int)
            for (_gid,vec_blob,_doc) in con.execute("SELECT gid,vec,doc FROM vindex"):
                for tok,_ in _βpkl.loads(vec_blob):
                    df[tok]+=1
            for tok,count in df.items():
                β_vdx.idf[tok] = _βm.log(total/(1+count))
            _log.info("[γ] idf refresh done (N=%s)", total)
            time.sleep(60)  # skip this minute
        time.sleep(30)

threading.Thread(target=_γ_nightly, daemon=True).start()


# ──────────────────────────────────────────────────────────────────────────
# 6. adaptive lecture gain ( logarithmic – prevents huge pastes dominating )
# ──────────────────────────────────────────────────────────────────────────
def _γ_gain(tokens:int):
    if tokens<=0: return 1.0
    return 1.0 + _βm.log10(tokens)/3   # ~1 → 3 across 1–1e6 tokens

# monkey-patch the constant used in _consume_block
globals()['LECTURE_GAIN'] = _γ_gain


# ──────────────────────────────────────────────────────────────────────────
# 7. patch repl() to use new CLI handler, keep all old behaviours
# ──────────────────────────────────────────────────────────────────────────
def repl():                      # overwrite old
    _log.info("Singularity Phase-1γ ready.  Paste • Lecture • Ask.  Ctrl-D/C.")
    lecture=False; buf=[]; seq=1
    while True:
        try:
            line=sys.stdin.readline()
            if not line:                              # EOF
                if lecture: _γ_consume_block("".join(buf),seq)
                break
            line=line.rstrip("\n")
        except KeyboardInterrupt:
            print(); break

        if lecture:
            if line in _LECTURE_OFF:
                _γ_consume_block("".join(buf),seq); buf.clear(); lecture=False; seq+=1
            else:
                buf.append(line+"\n")
            continue

        if line in _LECTURE_ON:
            lecture=True; buf=[]; continue

        if not line: continue                     # blank

        if line.startswith("/"):                  # meta command
            fn=META.get(line.strip().lower())
            if fn: fn(); continue
            print("Unknown command."); continue

        # ---------- here: regular interactive input ----------
        globals()['_cli_handler'](line)
    
    from organism_cluster import _save_index as _dummy  # no-op but keeps symmetry
    _dummy()
    from organism_neuro import _save_index as _nx_save
    _nx_save()

# Wire the /program command into META
META["/program"] = lambda arg=None: _cmd_program(arg)

# Start autonomous background workers
_auto_ingest_seed_assets()
_ProjectForge().start()
_compress_bloat()

# ────────────────────────────────────────────────────────────────────────────
# ░░░  BEGIN  CRAWLER  INJECTION  ░░░
# crawls http/https, respects robots.txt, obeys  max_outbound_kbit
# stores every page as   ecosystem/seed_assets/http_<sha>.txt
# after each page it calls  _consume_block(...)  (same routine used for lectures)
# ────────────────────────────────────────────────────────────────────────────
import asyncio, aiohttp, urllib.robotparser, textwrap
from aiohttp import ClientTimeout
from urllib.parse import urlparse
_CRAWL_CFG   = CFG.get("crawler" , {})              # see YAML snippet below
_CRAWL_ROOTS = _CRAWL_CFG.get("seeds" , [])
_CRAWL_RATE  = _CRAWL_CFG.get("pages_per_min", 30)
_CRAWL_MAX   = _CRAWL_CFG.get("max_pages",    500)
_OUT_KBIT    = CFG.get("max_outbound_kbit", 0)

_SEED_ASSETS = ECO / "seed_assets"
_SEED_ASSETS.mkdir(exist_ok=True)

_async_sem   = asyncio.Semaphore(max(1, _CRAWL_RATE//60))
_seen        = set()         # normalised URLs we already ingested
_rp_cache    = {}            # robots.txt parsers

def _robots_ok(url:str)->bool:
    dom  = urlparse(url).netloc
    if dom not in _rp_cache:
        rp = urllib.robotparser.RobotFileParser()
        try:
            rp.set_url(f"https://{dom}/robots.txt")
            rp.read()
        except Exception:
            rp = None
        _rp_cache[dom] = rp
    return True if rp is None else rp.can_fetch("*", url)

async def _fetch(session, url):
    if url in _seen or not _robots_ok(url): return
    _seen.add(url)
    try:
        async with _async_sem, session.get(url, timeout=ClientTimeout(total=12)) as r:
            if r.status!=200 or "text/html" not in r.headers.get("Content-Type",""):
                return
            txt = await r.text()
            fname = f"http_{hash(url)%2**32:x}.txt"
            (ECO/"seed_assets").joinpath(fname).write_text(
                f"{url}\n\n{textwrap.shorten(txt,20000,' [...]')}",
                encoding="utf-8", errors="ignore")
            _consume_block(txt, seq=9999)        # weight==lecture_gain
            _log.info(f"[crawler] ingested {url}")
            if len(_seen) >= _CRAWL_MAX: raise asyncio.CancelledError
            # simple link-harvest
            for m in re.finditer(r'href="(https?://[^"#]+)"', txt, re.I):
                asyncio.create_task(_fetch(session, m.group(1)))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        _log.debug(f"[crawler] {url} : {e}")

async def _crawl_loop():
    if _OUT_KBIT<=0 or not _CRAWL_ROOTS: return
    async with aiohttp.ClientSession() as sess:
        for u in _CRAWL_ROOTS:
            asyncio.create_task(_fetch(sess,u))
        try:
            while True: await asyncio.sleep(3600)
        except asyncio.CancelledError: pass

def start_crawler():
    loop = asyncio.new_event_loop()
    threading.Thread(target=loop.run_until_complete,
                     args=(_crawl_loop(),), daemon=True).start()

##############################################################################
# -- crawler controls --------------------------------------------------------
##############################################################################
_crawl_loop_handle = None        # will hold the asyncio loop thread

def start_crawler():
    global _crawl_loop_handle
    if _crawl_loop_handle is not None:
        print("[crawler] already running"); return
    print("[crawler] ▶ starting …")
    _crawl_loop_handle = threading.Thread(target=lambda:asyncio.run(_crawl_loop()),daemon=True)
    _crawl_loop_handle.start()

def stop_crawler():
    global _crawl_loop_handle
    if _crawl_loop_handle and _crawl_loop_handle.is_alive():
        print("[crawler] ■ stopping …")
        try:
            # Create a new event loop for cancellation
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            for task in asyncio.all_tasks(loop):
                task.cancel()
            _crawl_loop_handle = None
        except Exception as e:
            print(f"[crawler] error during stop: {e}")
    else:
        print("[crawler] not running")

def crawler_status():
    if _crawl_loop_handle and _crawl_loop_handle.is_alive():
        print(f"[crawler] running — pages seen: {len(_seen)} / {_CRAWL_MAX}")
    else:
        print("[crawler] stopped")

def add_root_url(u):
    if not u:
        print("usage:  /crawl add <full-URL>")
        return
    _CRAWL_ROOTS.append(u.strip())
    print(f"[crawler] seed added: {u.strip()}")

def set_crawl_limit(n):
    try:
        n = int(n)
        global _CRAWL_MAX
        _CRAWL_MAX = n
        print(f"[crawler] max pages set → {n}")
    except Exception: 
        print("usage: /crawl max <int>")

# Update META with crawler controls
META.update({
    "/crawl-on"      : lambda : start_crawler(),
    "/crawl-off"     : lambda : stop_crawler(),
    "/crawl-status"  : lambda : crawler_status(),
    "/crawl-add"     : lambda url=None: add_root_url(input("URL to add: ").strip() if url is None else url),
    "/crawl-max"     : lambda n=None: set_crawl_limit(input("Max pages: ").strip() if n is None else n),
})

start_crawler()
# ░░░  END  CRAWLER  INJECTION  ░░░
# ────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────
# ░░░  BEGIN  WAN-FEDERATION  INJECTION  ░░░
# connects to ws://RELAY_HOST:8765 , exchanges {"stats":{gpu,ram,storage}}
# the node with max(score) becomes MASTER and publishes  ⟐model_sync events
# ░░░  add in config:   relay_host: 1.2.3.4   ░░░
# ────────────────────────────────────────────────────────────────────────────
import psutil, websockets, json, asyncio, platform

_relay_host = CFG.get("relay_host")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
if _relay_host:
    _LLM_LOCAL = BASE / "llm_local"
    _LLM_LOCAL.mkdir(exist_ok=True)
    
    def _ensure_model_downloaded():
        _log.info("Downloading model weights (placeholder implementation)")
    
    def _ensure_model_downloaded():
        _log.info("Downloading model weights (placeholder implementation)")
    
    from transformers import AutoModelForCausalLM
    async def _wan_peer():
        uri = f"ws://{_relay_host}:8765"
        while True:
            try:
                async with websockets.connect(uri, max_size=2**22) as ws:
                    # announce self
                    stats = {
                        "gpu": torch.cuda.device_count()*torch.cuda.get_device_properties(0).multi_processor_count if torch.cuda.is_available() else 0,
                        "ram": psutil.virtual_memory().total//2**30,
                        "disk": shutil.disk_usage(str(BASE)).total//2**30,
                        "hostname": platform.node()
                    }
                    await ws.send(json.dumps({"stats":stats}))
                    async for msg in ws:
                        data=json.loads(msg)
                        if "model_sync" in data and DEVICE=="cpu":   # light node pulls weights
                            _ensure_model_downloaded()  # makes local dir
                            AutoModelForCausalLM.from_pretrained(
                                data["model_sync"]).save_pretrained(_LLM_LOCAL)
            except Exception as e:
                _log.warning(f"[WAN] {e} – reconnecting in 30 s"); await asyncio.sleep(30)

    threading.Thread(target=lambda: asyncio.run(_wan_peer()),
                     daemon=True).start()
# ░░░  END  WAN-FEDERATION  INJECTION  ░░░
# ────────────────────────────────────────────────────────────────────────────